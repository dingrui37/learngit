/*
 * CNodeMgr.cpp
 *
 *  Created on: 2014-8-31
 *      Author: kejin
 */

#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/errno.h>

#include "CNodeClient.h"
void constrConfInfo(T_ZCMS_CONFIG_INFO &tConf, CNodeConfig *pCNodeConf);

extern ZENIC_RESULT zcs_constructJID(uint16_t job_type, uint16_t instance,JID &tJid);

CNodeClient::CNodeClient()
    : m_pConfig(NULL), m_pZcmsMgr(NULL), m_isClientWorking(false), m_isSvcLauched(false),
      m_isInMCastGrp(false), m_dwCurMgrPoweronTick(0),
      m_eSelfLinkState(E_ZCMS_NODE_STATE_INIT), m_dwQueueID(0), m_dwReqTimerID(0),
      m_dwEchoTimerID(0), m_dwRstSilentDuration(0), m_ptActiveNodeList(NULL)
{
    memset(&tCNodeStt, 0, sizeof(tCNodeStt));
    memset(&mMasterNodeJID, 0, sizeof(mMasterNodeJID));
    memset(&m_tCurMgrNodeType, 0, sizeof(m_tCurMgrNodeType));
    memset(&m_tCurMgrPhyAddr, 0, sizeof(m_tCurMgrPhyAddr));
}

ZENIC_RESULT CNodeClient::init(CNodeConfig *ptNodeConf, CZcmsMgr *ptCZcmsMgr, uint16_t wWorkState)
{
    XOS_ASSERT(ptNodeConf);
    XOS_ASSERT(ptCZcmsMgr);
    
    m_pConfig = ptNodeConf;
    m_pZcmsMgr = ptCZcmsMgr;
    m_isClientWorking = FALSE;
    m_isSvcLauched = FALSE;
    m_isInMCastGrp = FALSE;
    
    if(!(ptNodeConf->getConfSelfNodeRole() & ZCS_NODE_ROLE_SERVICE))
    {
    	   m_pZcmsMgr->setSelfNodeState(ZCS_NODE_STATE_ACTIVE);
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_BUF_ZCMS,"CNodeClient init, I'm Not client Node!\n");
        return RESULT_ZENIC_SUCCESS;
    }
    
    constrMasterNodeMgrJID();
    memset(&m_tCurMgrNodeType, 0, sizeof(m_tCurMgrNodeType));
    
    m_dwCurMgrPoweronTick = 0;
    m_eSelfLinkState = E_ZCMS_NODE_STATE_INIT;
    m_dwQueueID = ZCMS_QUEUE_INVALID_ID;
    zcms_init_timer(m_dwReqTimerID);
    zcms_init_timer(m_dwEchoTimerID);
    m_dwRstSilentDuration = ZCMS_CLIENT_RST_SILENT_MIN_PERIOD;
    m_ptActiveNodeList = NULL;
    memset(&tCNodeStt, 0, sizeof(tCNodeStt));
    
    m_isClientWorking = TRUE;
    return RESULT_ZENIC_SUCCESS;
}

bool CNodeClient::isServiceLaunched()
{
    return m_isSvcLauched;
}

void CNodeClient::onReceiveNotifyLaunchService()
{
    tCNodeStt.dwLauchSvcRcvCnt++;
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onReceiveNotifyLaunchService Rcv EV_SYS_ZCS_LAUNCH_SERVICE Msg, Launch Client Service!\n");
    m_isSvcLauched = TRUE;

    JID tSnderJid;
    memset(&tSnderJid, 0, sizeof(tSnderJid));
    XOS_Sender(&tSnderJid);
    
    XOS_STATUS ret = XOS_SendAsynMsg(EV_SYS_ZCS_LAUNCH_SERVICE_ACK, (uint8_t *)NULL, 0, 0, 0, (void *)&tSnderJid);
    if(XOS_SUCCESS != ret)
    {        
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onReceiveNotifyLaunchService Rcv EV_SYS_ZCS_LAUNCH_SERVICE Msg, send ack err:%u!\n",ret);
    }    
}

uint32_t CNodeClient::getPowerOnTick()
{
    return m_pZcmsMgr->getSelfPowerOnTick();
}

void CNodeClient::constrMasterNodeMgrJID()
{
    memset(&mMasterNodeJID, 0, sizeof(mMasterNodeJID));
    mMasterNodeJID.dwJno       = XOS_ConstructJNO(ZCS_JOB_TYPE_ZCMS, 1);
    mMasterNodeJID.wModule     = OMP_MODULE;
    mMasterNodeJID.wUnit       = OMP_UNIT;
    mMasterNodeJID.ucSUnit     = OMP_SUNIT;
    mMasterNodeJID.ucSubSystem = OMP_SUBSYSTEM;
    mMasterNodeJID.ucRouteType = COMM_MASTER_SERVICE;
    return;
}

void CNodeClient::constrCNodeInfo(T_ZCMS_CNODE_INFO &tNodeInfo)
{
    m_pZcmsMgr->getSelfPhyAddr(&tNodeInfo.tPhyAddrInfo);
    tNodeInfo.dwCNodePoweronTick = getPowerOnTick();
    m_pZcmsMgr->getSelfNodeType(&tNodeInfo.tNodeType);
    tNodeInfo.wCSvcState = m_pZcmsMgr->m_wSvcState;
    tNodeInfo.eLinkState = m_eSelfLinkState;
    return;
}

ZENIC_RESULT CNodeClient::setSelfLinkState(E_ZCMS_NODE_LINK_STATE eSelfState)
{
    m_eSelfLinkState = eSelfState;
    return RESULT_ZENIC_SUCCESS;
}

E_ZCMS_NODE_LINK_STATE CNodeClient::getSelfLinkState()
{    	  
    return m_eSelfLinkState;
}

uint16_t CNodeClient::getSelfNodeID()
{    	  
    return m_pZcmsMgr->getSelfNodeID();
}

ZENIC_RESULT CNodeClient::saveMgrInfo(T_ZCMS_MGRNODE_INFO* ptMgrInfo)
{
    if(NULL == ptMgrInfo)
    {
        XOS_ASSERT(0);
        return ERROR_NULL_POINTER;
    }
    m_tCurMgrNodeType = ptMgrInfo->tCurMgrNodeInfo;
    m_tCurMgrPhyAddr = ptMgrInfo->tCurMgrPhyAddrInfo;
    m_dwCurMgrPoweronTick = ptMgrInfo->dwCurMgrPowerOnTick;
	if(m_pZcmsMgr !=NULL)
	   m_pZcmsMgr->setSelfPowerOnTick(m_dwCurMgrPoweronTick);
    return RESULT_ZENIC_SUCCESS;
}

bool CNodeClient::checkMgrInfo(T_ZCMS_MGRNODE_INFO* ptMgrInfo)
{
    if(NULL == ptMgrInfo)
    {
        XOS_ASSERT(0);
        return FALSE;
    }

    if((m_tCurMgrNodeType.nodeId != ptMgrInfo->tCurMgrNodeInfo.nodeId)
    	|| (m_tCurMgrNodeType.moduleId != ptMgrInfo->tCurMgrNodeInfo.moduleId)
    	|| (m_tCurMgrNodeType.route_type != ptMgrInfo->tCurMgrNodeInfo.route_type)
    	|| (!XOS_ComparePhyAdd(&m_tCurMgrPhyAddr, &ptMgrInfo->tCurMgrPhyAddrInfo)
    	|| m_dwCurMgrPoweronTick != ptMgrInfo->dwCurMgrPowerOnTick))
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"checkMgrInfo N:M:R[%d:%d:%d] PA[%d:%d:%d:%d] POTick[%u] differs prev N:M:R[%d:%d:%d] PA[%d:%d:%d:%d] POTick[%u]!\n",
        	ptMgrInfo->tCurMgrNodeInfo.nodeId, ptMgrInfo->tCurMgrNodeInfo.moduleId, ptMgrInfo->tCurMgrNodeInfo.route_type,
        	ptMgrInfo->tCurMgrPhyAddrInfo.ucRackId, ptMgrInfo->tCurMgrPhyAddrInfo.ucShelfId,
        	ptMgrInfo->tCurMgrPhyAddrInfo.ucSlotId, ptMgrInfo->tCurMgrPhyAddrInfo.ucCpuId, 
        	ptMgrInfo->dwCurMgrPowerOnTick,
         m_tCurMgrNodeType.nodeId, m_tCurMgrNodeType.moduleId, m_tCurMgrNodeType.route_type,
        	m_tCurMgrPhyAddr.ucRackId, m_tCurMgrPhyAddr.ucShelfId,
        	m_tCurMgrPhyAddr.ucSlotId, m_tCurMgrPhyAddr.ucCpuId,
        	m_dwCurMgrPoweronTick);
        return FALSE;
    }
    
    return TRUE;
}

void CNodeClient::onCHandleQueueAck(void *pMsg, uint16_t msg_len)
{
    ZCMS_QUEUE_ACK_MSG *pQueueAck = (ZCMS_QUEUE_ACK_MSG *)pMsg;

    if(msg_len != sizeof(ZCMS_QUEUE_ACK_MSG) || pMsg==NULL)
    {
    	   tCNodeStt.dwErrorMsgRcv++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "onHandleQueueAck rcv Error Msg:length %d should be:%d, pMsg: %p!\n", 
        	        msg_len, sizeof(ZCMS_QUEUE_ACK_MSG), pMsg);
        XOS_ASSERT(0);
        return;
    }

    tCNodeStt.dwQAckRcvCnt++;
    #if ZCMS_DEBUG
    printQueueAckMsg(pQueueAck);
    #endif

    saveMgrInfo(&pQueueAck->tCurMGRInfo);
    m_dwQueueID = pQueueAck->dwYourQueueID;
    
    if(m_dwQueueID == ZCMS_QUEUE_ID_NUMBER_FIRST)
    {
        zcms_cancel_timer(m_dwReqTimerID);
        /* ������ʽע������*/
        //onFormallyRegReq();
        m_dwReqTimerID = zcms_set_timer(EV_SYS_ZCMS_CLIENT_REG_TIMER, ZCMS_CLIENT_TIMER_REG_PERIOD, PARAM_NULL);
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onCHandleQueueAck Queue No.1 and Start Register!\n");
    }
    else
    {
    	   ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onCHandleQueueAck Queue No.%u!\n", m_dwQueueID);
        //�������ٴ��·�QueueApply
        m_dwReqTimerID = zcms_set_timer(EV_SYS_ZCMS_CLIENT_QUEUE_TIMER, ZCMS_CLIENT_TIMER_Q_APPLY_PERIOD,PARAM_NULL);
    }

    //�յ��Ŷ�ȷ�ϼ��ɿ�ʼ����
    m_dwEchoTimerID = zcms_set_looptimer(EV_SYS_ZCMS_CLIENT_ECHO_TIMER, pQueueAck->dwHBPeriod, PARAM_NULL);
    return;
}

void CNodeClient::onCHandleRegAck(void *pMsg, uint16_t msg_len)
{
    ZCMS_REG_ACK_MSG *pRegAck = (ZCMS_REG_ACK_MSG *)pMsg;

    if(msg_len != sizeof(ZCMS_REG_ACK_MSG) || pMsg==NULL)
    {
    	   tCNodeStt.dwErrorMsgRcv++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "onCHandleRegAck rcv Error Msg:length %d should be:%d, pMsg: %p!\n", 
        	        msg_len, sizeof(ZCMS_REG_ACK_MSG), pMsg);
        XOS_ASSERT(0);
        return;
    }

    tCNodeStt.dwRegAckRcvCnt++;
    #if ZCMS_DEBUG
    printRegAckMsg(pRegAck);
    #endif

    if(!checkMgrInfo(&pRegAck->tCurMGRInfo))
    {
    	   tCNodeStt.dwMgrDiff++;
        ZCS_LOG(ZCS_LOG_WARN, ZCS_LOG_MOD_ZCMS, "onCHandleRegAck Recv ZCMS_REG_ACK_MSG from differient Mgr!\n");
        saveMgrInfo(&pRegAck->tCurMGRInfo);
    }
    
    if(pRegAck->dwRegStatus == ZCMS_REG_RESULT_SUCCESS)
    {
        setSelfLinkState(E_ZCMS_NODE_STATE_ACTIVE);
        zcms_cancel_timer(m_dwReqTimerID);
        m_dwRstSilentDuration = ZCMS_CLIENT_RST_SILENT_MIN_PERIOD;
        joinMultiCastGroup(ZCMS_MULTICAST_GROUPID);
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onCHandleRegAck Register Success!\n");
    }
    else
    {
        //�������ٴ��·�REG_REQ
        m_dwReqTimerID = zcms_set_timer(EV_SYS_ZCMS_CLIENT_REG_TIMER, ZCMS_CLIENT_TIMER_REG_PERIOD, PARAM_NULL);
    }
    
    return;
}

void CNodeClient::onRegQueueReq()
{
    XOS_STATUS ret;
    ZCMS_QUEUE_REQ_MSG tQReq;

    if(!m_isClientWorking)
    {
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onRegQueueReq: I'm NOT client Node, do not Launch queue request!\n");
        return;
    }
    
    XOS_ASSERT((getSelfLinkState() == E_ZCMS_NODE_STATE_INIT) 
            || (getSelfLinkState() == E_ZCMS_NODE_STATE_INACTIVE)
            || (getSelfLinkState() == E_ZCMS_NODE_STATE_QUEUEING));

    if(getSelfLinkState() != E_ZCMS_NODE_STATE_QUEUEING)
    {
        setSelfLinkState(E_ZCMS_NODE_STATE_QUEUEING);
    }
    
    m_dwReqTimerID = zcms_set_timer(EV_SYS_ZCMS_CLIENT_QUEUE_TIMER, ZCMS_CLIENT_TIMER_Q_APPLY_PERIOD, PARAM_NULL);

    if(!isServiceLaunched())
    {
        return;
    }
    
    memset(&tQReq, 0, sizeof(tQReq));
    constrCNodeInfo(tQReq.tCNodeInfo);
    
    #if ZCMS_DEBUG
    printQueueApplyMsg(&tQReq);
    #endif
    
    ret = XOS_SendAsynMsg(EV_SYS_ZCMS_QUEUE_APPLY, (uint8_t *)&tQReq, (uint16_t)sizeof(ZCMS_QUEUE_REQ_MSG), XOS_MSG_VER0, XOS_MSG_LOW, (void *)&mMasterNodeJID);
    if (XOS_SUCCESS != ret)
    {
    	   tCNodeStt.dwQApplySndFailed++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "onRegQueueReq Msg to MasterNode Failed!\n");
        return;
    }

    tCNodeStt.dwQApplySndCnt++;
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onRegQueueReq Msg to MasterNode Success!\n");
    return;
}
	
void CNodeClient::onFormallyRegReq()
{
    XOS_STATUS ret;
    ZCMS_REG_REQ_MSG tFReg;

    XOS_ASSERT((getSelfLinkState() == E_ZCMS_NODE_STATE_QUEUEING) 
            || (getSelfLinkState() == E_ZCMS_NODE_STATE_REGISTERING));
    
    if(getSelfLinkState() != E_ZCMS_NODE_STATE_REGISTERING)
    {
        setSelfLinkState(E_ZCMS_NODE_STATE_REGISTERING);
    }

    m_dwReqTimerID = zcms_set_timer(EV_SYS_ZCMS_CLIENT_REG_TIMER, ZCMS_CLIENT_TIMER_REG_PERIOD, PARAM_NULL);

    memset(&tFReg, 0, sizeof(tFReg));
    constrCNodeInfo(tFReg.tCNodeInfo);

    #if ZCMS_DEBUG
    printFormallyRegMsg(&tFReg);
    #endif
    
    ret = XOS_SendAsynMsg(EV_SYS_ZCMS_REG_APPLY, (uint8_t *)&tFReg, (uint16_t)sizeof(ZCMS_REG_REQ_MSG), XOS_MSG_VER0, XOS_MSG_LOW, (void *)&mMasterNodeJID);
    if (XOS_SUCCESS != ret)
    {
    	   tCNodeStt.dwRegSndFailed++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "onFormallyRegReq Msg to MasterNode Failed\n");
        return;
    }

    tCNodeStt.dwRegSndCnt++;
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onFormallyRegReq Msg to MasterNode Success\n");
    return;
}

void CNodeClient::onClientHeatBeat()
{
    XOS_STATUS ret;
    ZCMS_HEART_BEAT_MSG tEcho;

    memset(&tEcho, 0, sizeof(tEcho));
    constrCNodeInfo(tEcho.tCNodeInfo);

    /*  �����߽���ͨ��������ӵ���������� */
    ret = XOS_SendUrgentAsynMsg(EV_SYS_ZCMS_ECHO_REQUEST, (uint8_t *)&tEcho, (uint16_t)sizeof(ZCMS_HEART_BEAT_MSG),
                                                             XOS_MSG_VER0, (void *)&mMasterNodeJID);
    if (XOS_SUCCESS != ret)
    {
        tCNodeStt.dwHBSndFailed++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "onClientHeatBeat Msg to MasterNode Failed\n");
        tCNodeStt.dwHBSndContinuousFailed++;
        if(tCNodeStt.dwHBSndContinuousFailed >= 3 * m_pConfig->getConfKeepAliveHBCount())
        {
            tCNodeStt.dwHBSndContinuousFailed = 0;
            resetMyNodeConnectionLink();
        }
        return;
    }
    else
    {        
        tCNodeStt.dwHBSndContinuousFailed = 0;    
        tCNodeStt.dwHBSndCnt++;
    }
    
    return;
}

void CNodeClient::onCHandleLinkResetMsg(void *pMsg, uint16_t msg_len)
{
    JID tMgrJid;
    ZCMS_RESET_LINK_MSG *pReset = (ZCMS_RESET_LINK_MSG *)pMsg;
    
    XOS_Sender(&tMgrJid);

    if(msg_len != sizeof(ZCMS_RESET_LINK_MSG) || pMsg==NULL)
    {
    	   tCNodeStt.dwErrorMsgRcv++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "onCHandleLinkResetMsg rcv Error Msg:length %d should be:%d, pMsg: %p!\n", 
        	        msg_len, sizeof(ZCMS_RESET_LINK_MSG), pMsg);
        XOS_ASSERT(0);
        return;
    }

    tCNodeStt.dwRstRcvCnt++;
    ZCS_LOG(ZCS_LOG_WARN, ZCS_LOG_MOD_ZCMS, 
    	               "onCHandleLinkResetMsg Recv RESET_LINK Msg, reason:%d[%s] From JID[Module:%d, RouteType:%d]\n", 
    	               pReset->eRSTLinkReason, zcmsRstReasonToStr(pReset->eRSTLinkReason), tMgrJid.wModule, tMgrJid.ucRouteType);
    
    if(pReset->eRSTLinkReason < E_ZCMS_RESET_LINK_REASON_MAXCOUNT)
    {
        tCNodeStt.dwRstReason[pReset->eRSTLinkReason]++;
    }
    
    resetMyNodeConnectionLink();    
}

void CNodeClient::onHandleMultiCastSync(void *pMsg, uint16_t msg_len)
{
	   XOS_STATUS xos_ret;
	   T_EV_ZCMS_MULTICAST_ACK tMCAck;
    JID tMgrJid;
    
	   T_EV_ZCMS_MULTICAST_SYNC* ptSyncData = (T_EV_ZCMS_MULTICAST_SYNC*)pMsg;
	   
	   if(msg_len != sizeof(T_EV_ZCMS_MULTICAST_SYNC) || pMsg==NULL)
    {
    	   tCNodeStt.dwErrorMsgRcv++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "onHandleMultiCastSync rcv Error Msg:length %d should be:%d, pMsg: %p!\n", 
        	        msg_len, sizeof(T_EV_ZCMS_MULTICAST_SYNC), pMsg);
        XOS_ASSERT(0);
        return;
    }

    tCNodeStt.dwMCastRcvCnt++;
    
	   if(getSelfLinkState()!=E_ZCMS_NODE_STATE_ACTIVE)
	   {
        ZCS_LOG(ZCS_LOG_WARN, ZCS_LOG_MOD_ZCMS, "onHandleMultiCastSync Rcv Msg at State:%d, ignore!\n", getSelfLinkState());
        return;
	   }
	   
    writeShmActiveNodes((void *)&ptSyncData->tMultiNodeSync, sizeof(T_ZCS_NODE_LIST));
    writeShmSelfNodesState();
    
    xos_ret = XOS_Sender(&tMgrJid);
    if (XOS_SUCCESS != xos_ret)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "onHandleMultiCastSync get XOS_Sender Failed:%d!\n", xos_ret);
        return;
    }
	if(this->m_dwCurMgrPoweronTick != ptSyncData->dwCurMgrPoweronTick)
	{
	    tCNodeStt.dwErrorPowerTickCnt++;
	    return ;
	}
	tMCAck.dwCurMgrPoweronTick = ptSyncData->dwCurMgrPoweronTick;
    tMCAck.wNodeID = getSelfNodeID();
    tMCAck.dwSeqAcked = ptSyncData->dwSyncSeq;
    xos_ret = XOS_SendAsynMsg(EV_SYS_ZCMS_MULTISYNC_ACK, (uint8_t *)&tMCAck, (uint16_t)sizeof(tMCAck),
    	                                                   XOS_MSG_VER0, XOS_MSG_LOW, (void *)&tMgrJid);

    if (XOS_SUCCESS != xos_ret)
    {
    	   tCNodeStt.dwMCastAckFailed++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "onHandleMultiCastSync Snd EV_SYS_ZCMS_MULTISYNC_ACK To MasterNodeMgr JID[Jno:0x%x,Module:%d,RouteType:%d] XOS_SendAsynMsg Failed:%d!\n",
        	      tMgrJid.dwJno, tMgrJid.wModule, tMgrJid.ucRouteType, xos_ret);
        return;
    }

    tCNodeStt.dwMCastAckCnt++;
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onHandleMultiCastSync Snd EV_SYS_ZCMS_MULTISYNC_ACK To MasterNodeMgr Success!\n");
    return;
}

ZENIC_RESULT CNodeClient::clearShmActiveNodes()
{
    if(NULL==m_ptActiveNodeList || (T_ZCS_NODE_LIST *)-1==m_ptActiveNodeList)
    {
        int flag = O_CREAT | O_RDWR;
        int mode = S_IRUSR | S_IWUSR;
        int proto = PROT_READ | PROT_WRITE;
        
        int shm_id1 = shm_open(pZcsActiveNodesShmName, flag, mode);
    
        if(shm_id1<0)
        {
        	   ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS, "clearShmActiveNodes ZcsActiveNodesShm shm_open Failed!\n");
        	   return ERROR_FILE_OPEN_FAIL;
        }
        
        ftruncate(shm_id1, sizeof(T_ZCS_NODE_LIST));
        m_ptActiveNodeList = (T_ZCS_NODE_LIST *)mmap(NULL,sizeof(T_ZCS_NODE_LIST), proto, MAP_SHARED, shm_id1, 0);
        
        if(m_ptActiveNodeList == (T_ZCS_NODE_LIST *)-1)
        {
            int err = errno;
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS, "clearShmActiveNodes ZcsActiveNodesShmName mmap Result:%d!\n", err);
            close(shm_id1);
            return ERROR_ALLOC_MEM_FAIL;
        }
        close(shm_id1);
    }

    memset(m_ptActiveNodeList, 0, sizeof(T_ZCS_NODE_LIST));
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeClient::writeShmActiveNodes(void *data, uint32_t len)
{
    XOS_ASSERT(data);
    XOS_ASSERT(sizeof(T_ZCS_NODE_LIST) == len);

    if(NULL==m_ptActiveNodeList || (T_ZCS_NODE_LIST *)-1==m_ptActiveNodeList)
    {
        int flag = O_CREAT | O_RDWR;
        int mode = S_IRUSR | S_IWUSR;
        int proto = PROT_READ | PROT_WRITE;
        
        int shm_id1 = shm_open(pZcsActiveNodesShmName, flag, mode);
    
        if(shm_id1<0)
        {
        	   ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS, "writeShmActiveNodes ZcsActiveNodesShm shm_open Failed!\n");
        	   return ERROR_FILE_OPEN_FAIL;
        }
        
        ftruncate(shm_id1, sizeof(T_ZCS_NODE_LIST));
        m_ptActiveNodeList = (T_ZCS_NODE_LIST *)mmap(NULL,sizeof(T_ZCS_NODE_LIST), proto, MAP_SHARED, shm_id1, 0);
        
        if(m_ptActiveNodeList == (T_ZCS_NODE_LIST *)-1)
        {
            int err = errno;
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS, "writeShmActiveNodes ZcsActiveNodesShm mmap Result:%d!\n", err);
            close(shm_id1);
            return ERROR_ALLOC_MEM_FAIL;
        }
        close(shm_id1);
    }

    memcpy(m_ptActiveNodeList, data, len);
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeClient::writeShmSelfNodesState()
{
    if(NULL==m_ptActiveNodeList || (T_ZCS_NODE_LIST *)-1==m_ptActiveNodeList)
    {    
        return ERROR_NULL_POINTER;
    }
    
    for(uint16_t node_idx=0; node_idx<m_ptActiveNodeList->node_num; node_idx++)
    {
        if(m_ptActiveNodeList->tNodes[node_idx].nodeId==getSelfNodeID())
        {
            m_pZcmsMgr->setSelfNodeState(m_ptActiveNodeList->tNodes[node_idx].state);
            return RESULT_ZENIC_SUCCESS;
        }
    }

    m_pZcmsMgr->setSelfNodeState(ZCS_NODE_STATE_INACTIVE);
    return RESULT_ZENIC_SUCCESS;
}

void CNodeClient::resetMyNodeConnectionLink()
{
    closeLinkConnection();

    m_dwRstSilentDuration = ZCMS_MIN(m_dwRstSilentDuration*2, ZCMS_CLIENT_RST_SILENT_MAX_PERIOD);
    m_dwReqTimerID = zcms_set_timer(EV_SYS_ZCMS_CLIENT_QUEUE_TIMER, m_dwRstSilentDuration, PARAM_NULL);
}

void CNodeClient::sendCleanRteTable()
{
    JID tZcrsJid;
    if(RESULT_ZENIC_SUCCESS!=zcs_constructJID(ZCS_JOB_TYPE_ZCRS,1,tZcrsJid))
    {
        return ;
    }
    XOS_STATUS xos_ret = XOS_SendAsynMsg(EV_SYS_ZCS_INNER_CLEAN_RTE_TABLE,NULL,0,0,0,&tZcrsJid);
    if (XOS_SUCCESS != xos_ret)
    {
        XOS_ASSERT(0);
        tCNodeStt.dwSndMsgFailed++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "send clear rte table failed:%d\n",xos_ret);
    }
}

void CNodeClient::closeLinkConnection()
{
    memset(&m_tCurMgrNodeType, 0, sizeof(m_tCurMgrNodeType));
    
    m_dwCurMgrPoweronTick = 0;
    setSelfLinkState(E_ZCMS_NODE_STATE_INACTIVE);
    m_dwQueueID = ZCMS_QUEUE_INVALID_ID;
    zcms_cancel_timer(m_dwReqTimerID);
    zcms_cancel_timer(m_dwEchoTimerID);
    quitMultiCastGroup(ZCMS_MULTICAST_GROUPID);
    clearShmActiveNodes();
    writeShmSelfNodesState();
    sendCleanRteTable();
    return;
}

ZENIC_RESULT CNodeClient::joinMultiCastGroup(uint16_t wGroupNo)
{
    if (XOS_SUCCESS != XOS_AddToMultiGroup(wGroupNo))
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "CNodeClient joinMultiCastGroup Failed\n");
        return ERROR_COMMON_ERROR;
    }

    m_isInMCastGrp = TRUE;
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "CNodeClient joinMultiCastGroup %#x Success!\n", wGroupNo);
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeClient::quitMultiCastGroup(uint16_t wGroupNo)
{
    if(!m_isInMCastGrp)
    {
        return RESULT_ZENIC_SUCCESS;
    }
    
    if (XOS_SUCCESS != XOS_ExitFromMultiGroup(wGroupNo))
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "CNodeClient quitMultiCastGroup Failed\n");
        return ERROR_COMMON_ERROR;
    }

    m_isInMCastGrp = FALSE;
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "CNodeClient quitMultiCastGroup %#x Success!\n", wGroupNo);
    return RESULT_ZENIC_SUCCESS;
}

void CNodeClient::adminReset(void *pMsg, uint16_t msg_len)
{
    uint8_t type;
    XOS_ASSERT(pMsg);
    XOS_ASSERT(msg_len==sizeof(uint8_t));
    type = *(uint8_t*)pMsg;

    if(type == TYPE_CLIENT_ELEGANT_RESET)
    {
        E_ZCMS_NODE_LINK_STATE state = getSelfLinkState();
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "=====Elegant admin Reset Client Node=====\n");
        if(state!=E_ZCMS_NODE_STATE_INACTIVE && state!=E_ZCMS_NODE_STATE_INIT)
        {
            ZCS_LOG(ZCS_LOG_WARN, ZCS_LOG_MOD_ZCMS, "Elegant adminReset while LinkState is %d, ignore!\n", state);
            return;
        }
    }
    else
    {
        ZCS_LOG(ZCS_LOG_WARN, ZCS_LOG_MOD_ZCMS, "=====!!!Force admin Reset Client Node!!!=====\n");
    }
    closeLinkConnection();
    m_dwRstSilentDuration = ZCMS_CLIENT_RST_SILENT_MIN_PERIOD;
    m_dwReqTimerID = zcms_set_timer(EV_SYS_ZCMS_CLIENT_QUEUE_TIMER, m_dwRstSilentDuration, PARAM_NULL);
}

void CNodeClient::printQueueApplyMsg(ZCMS_QUEUE_REQ_MSG *pQueueReq)
{
	   XOS_ASSERT(pQueueReq);
    printf("My QueueApply:\n");
    printf("=========My NodeInfo:========\n");
    printCNodeInfo(&pQueueReq->tCNodeInfo);
    printf("=========My NodeInfo:========\n");
    
    return;
}

void CNodeClient::printQueueAckMsg(ZCMS_QUEUE_ACK_MSG *pQueueAck)
{
	   XOS_ASSERT(pQueueAck);
    printf("Client Rcv QueueAck:\n");
    printf("=========Mgr NodeInfo:========\n");
    printMgrNodeInfo(&pQueueAck->tCurMGRInfo);
    printf("=========My QueueID:%u========\n", pQueueAck->dwYourQueueID);
    
    return;
}

void CNodeClient::printFormallyRegMsg(ZCMS_REG_REQ_MSG *pFReq)
{
	   XOS_ASSERT(pFReq);
    printf("My Formally Register:\n");
    printf("=========My NodeInfo:========\n");
    printCNodeInfo(&pFReq->tCNodeInfo);
    printf("=========My NodeInfo:========\n");
    
    return;
}

void CNodeClient::printRegAckMsg(ZCMS_REG_ACK_MSG *pRegAck)
{
	   XOS_ASSERT(pRegAck);
    printf("Mgr RegAck:\n");
    printf("=========Mgr NodeInfo:========\n");
    printMgrNodeInfo(&pRegAck->tCurMGRInfo);
    printf("=========Mgr NodeInfo:========\n");
    printf("Register Result [%u]\n", pRegAck->dwRegStatus);
    
    return;
}

void CNodeClient::showStt()
{
    printf("Queue2MasterDuration:   %-10lu\n", m_dwRstSilentDuration);
    printf("LauchSvcRcvCnt:         %-10u HBSndCnt:              %-10u\n", tCNodeStt.dwLauchSvcRcvCnt, tCNodeStt.dwHBSndCnt);
    printf("QApplySndCnt:           %-10u QAckRcvCnt:            %-10u\n", tCNodeStt.dwQApplySndCnt, tCNodeStt.dwQAckRcvCnt);
    printf("RegSndCnt:              %-10u RegAckRcvCnt:          %-10u\n", tCNodeStt.dwRegSndCnt, tCNodeStt.dwRegAckRcvCnt);
    printf("MCastRcvCnt:            %-10u MCastAckCnt:           %-10u\n", tCNodeStt.dwMCastRcvCnt, tCNodeStt.dwMCastAckCnt);
    printf("QApplySndFailed:        %-10u RegSndFailed:          %-10u\n", tCNodeStt.dwQApplySndFailed, tCNodeStt.dwRegSndFailed);
    printf("HBSndFailed:            %-10u MCastAckFailed:        %-10u\n", tCNodeStt.dwHBSndFailed, tCNodeStt.dwMCastAckFailed);
    printf("ErrorMsgRcv:            %-10u MgrDiff:               %-10u\n", tCNodeStt.dwErrorMsgRcv, tCNodeStt.dwMgrDiff);
    printf("SndMsgFailed:           %-10u ContinuousFailed:      %-10u\n", tCNodeStt.dwSndMsgFailed, tCNodeStt.dwHBSndContinuousFailed);
    printf("dwErrorPowerTickCnt:    %-10u RstRcvCnt:             %-10u\n", tCNodeStt.dwErrorPowerTickCnt, tCNodeStt.dwRstRcvCnt);
    printf("Reasons:\n");
    for(uint32_t i = E_ZCMS_RESET_LINK_ERROR_STATE; i < E_ZCMS_RESET_LINK_REASON_MAXCOUNT; i++)
    {
        printf("%-15s         %-10u\n", zcmsRstReasonToStr((E_ZCMS_RESET_LINK_REASON)i), tCNodeStt.dwRstReason[i]);
    }
}

ZENIC_RESULT CNodeClient::shutdown()
{ 
    if(m_isClientWorking == FALSE)
    {    
        return RESULT_ZENIC_SUCCESS;
    }

    memset(&mMasterNodeJID, 0, sizeof(mMasterNodeJID));
    memset(&m_tCurMgrNodeType, 0, sizeof(m_tCurMgrNodeType));
    
    m_dwCurMgrPoweronTick = 0;
    m_eSelfLinkState = E_ZCMS_NODE_STATE_INIT;
    m_dwQueueID = ZCMS_QUEUE_INVALID_ID;
    zcms_cancel_timer(m_dwReqTimerID);
    zcms_cancel_timer(m_dwEchoTimerID);
    m_dwRstSilentDuration = ZCMS_CLIENT_RST_SILENT_MIN_PERIOD;
    m_ptActiveNodeList = NULL;
    
    m_isClientWorking = FALSE;
    return RESULT_ZENIC_SUCCESS;
}

CNodeClient::~CNodeClient() {
    // TODO Auto-generated destructor stub
}


