/*
 * zcms_common.h
 *
 *  Created on: 2014-9-4
 *      Author: kejin
 */

#ifndef ZCMS_COMMON_H_
#define ZCMS_COMMON_H_
#include <stdint.h>
#include <stddef.h>
#include "tulip_lib.h"
#include "zcs_common.h"
#include "zcs_api.h"
#include "zcs_log.h"
#include "zcs_job_def.h"
#include "zcs_types.h"

#define ZCMS_DEBUG 0
#define ZCMS_MGR_CLIENT_COMBINE 1

#define ZCMS_MULTICAST_GROUPID 0x1784

const uint16_t ZCMS_DEFAULT_REPLICA_COPY = 2; //1+1

const uint16_t ZCMS_INVALID_QUEUEID=0xffff;

const uint32_t ZCMS_INVALID_SYNC_SEQ=0;
const uint32_t ZCMS_INIT_SYNC_SEQ=ZCMS_INVALID_SYNC_SEQ+1;

const uint16_t ZCMS_MAX_NODE_EVENT_NUM = 3*ZCS_MAX_NODE_NUM;
const uint16_t ZCMS_MAX_NODE_EVENT_SUBSCRIBER_NUM = 10;

/*���ؽڵ���Ұ�NODE_ID�������ҵ��ڵ���̻�Ϊ256��ģ��*/
const uint16_t ZCMS_VIRTUAL_RIGHT_OMP_NODE_ID = ZCS_MASTER_NODE_ID_2;


/*zcms ע��ǰ�Ŷ���Ϣ����ҵ�������ؽڵ�*/
const uint32_t EV_SYS_ZCMS_MSSYNC_REQ = EV_SYS_INNER_ZCMS_BEGIN+0;     //10060
const uint32_t EV_SYS_ZCMS_MSSYNC = EV_SYS_INNER_ZCMS_BEGIN+1;
const uint32_t EV_SYS_ZCMS_MSSYNC_ACK = EV_SYS_INNER_ZCMS_BEGIN+2;
const uint32_t EV_SYS_ZCMS_MULTISYNC = EV_SYS_INNER_ZCMS_BEGIN+3;
const uint32_t EV_SYS_ZCMS_MULTISYNC_ACK = EV_SYS_INNER_ZCMS_BEGIN+4;

const uint32_t EV_SYS_ZCMS_QUEUE_APPLY = EV_SYS_INNER_ZCMS_BEGIN+5;     //10065
const uint32_t EV_SYS_ZCMS_QUEUE_ACK = EV_SYS_INNER_ZCMS_BEGIN+6;
const uint32_t EV_SYS_ZCMS_REG_APPLY = EV_SYS_INNER_ZCMS_BEGIN+7;
const uint32_t EV_SYS_ZCMS_REG_ACK = EV_SYS_INNER_ZCMS_BEGIN+8;
const uint32_t EV_SYS_ZCMS_RESET_LINK = EV_SYS_INNER_ZCMS_BEGIN+9;

/*�ڲ�������Ϣ������zcms֮����б�������ط���ҵ��ڵ�*/
const uint32_t EV_SYS_ZCMS_ECHO_REQUEST = EV_SYS_INNER_ZCMS_BEGIN+10; //10070

const uint32_t EV_SYS_ZCMS_CHG_OVER_TIMER = EV_SYS_INNER_ZCMS_BEGIN+11;  
const uint32_t EV_SYS_ZCMS_CLIENT_QUEUE_TIMER = EV_SYS_INNER_ZCMS_BEGIN+12;
const uint32_t EV_SYS_ZCMS_CLIENT_REG_TIMER = EV_SYS_INNER_ZCMS_BEGIN+13;
const uint32_t EV_SYS_ZCMS_CLIENT_ECHO_TIMER = EV_SYS_INNER_ZCMS_BEGIN+14;
const uint32_t EV_SYS_ZCMS_MGR_CHECK_HBTO_TIMER = EV_SYS_INNER_ZCMS_BEGIN+15;
const uint32_t EV_SYS_ZCMS_SLAVEMGR_SYNC_REQ_TIMER = EV_SYS_INNER_ZCMS_BEGIN+16;
const uint32_t EV_SYS_ZCMS_MASTERMGR_MSSYNC_TIMER = EV_SYS_INNER_ZCMS_BEGIN+17;
const uint32_t EV_SYS_ZCMS_MASTERMGR_MULTICAST_TIMER = EV_SYS_INNER_ZCMS_BEGIN+18;
const uint32_t EV_SYS_ZCMS_CLIENT_RESET = EV_SYS_INNER_ZCMS_BEGIN+19;
const uint32_t EV_SYS_ZCMS_SELF_TRIGGER_MSG = 1000+EV_SYS_INNER_ZCMS_BEGIN+20; //11080
const uint32_t EV_SYS_ZCMS_NOTIFY_UPL_WAIT_ACK_TIMER = 1000+EV_SYS_INNER_ZCMS_BEGIN+21;//11081

const uint32_t ZCMS_QUEUE_ID_NUMBER_FIRST = 1;

const uint32_t ZCMS_PRE_CHANGEOVER = 1;
const uint32_t ZCMS_MS_CHANGEOVER = 1<<1;

const uint32_t ZCMS_REG_RESULT_SUCCESS = 1;
const uint32_t ZCMS_REG_RESULT_FAILED = 2;

enum E_ZCMS_RESET_LINK_REASON {
    E_ZCMS_RESET_LINK_ERROR_STATE = 1, 
    E_ZCMS_RESET_LINK_ECHO_TIMEOUT = 2,
    E_ZCMS_RESET_DIFF_NODEINFO = 3,
    E_ZCMS_RESET_UNAUTHORIZED = 4,
    E_ZCMS_RESET_MGR_CHG_OVER = 5,
    E_ZCMS_RESET_LINK_COMMON_REASON = 6,
    E_ZCMS_RESET_LINK_REASON_MAXCOUNT = 7
};

enum E_ZCMS_NODE_LINK_STATE {
    E_ZCMS_NODE_STATE_INIT = 0,
    E_ZCMS_NODE_STATE_QUEUEING = 1, 
    E_ZCMS_NODE_STATE_REGISTERING = 2, 
    E_ZCMS_NODE_STATE_ACTIVE = 3,
    E_ZCMS_NODE_STATE_INACTIVE = 4
};

struct T_ZCMS_CONFIG_INFO
{
    T_ZCS_NODE_ROLE tSelfRole;
    uint32_t tAliveTimer;//���ʱ�����ȣ���ms��Ϊ��λ
    uint16_t tAliveCount;
    uint16_t tReplica_Mode;
    uint16_t tReserved;// reserved field
    uint16_t tConfNodeNum;//�Ѿ����õĽڵ�����
    T_ZCS_NODE tNodes[ZCS_MAX_NODE_NUM];//�ڵ��б�
}_ZENIC_PACKED;

struct T_ZCMS_CNODE_INFO {
    T_ZCS_NODE tNodeType;
    T_PhysAddress tPhyAddrInfo; //������Ŀǰ����nodeID��key��ʵ��Ӧ����phyAddr��������nodeID+RouteType
    uint32_t dwCNodePoweronTick;
    E_ZCMS_NODE_LINK_STATE eLinkState;
    uint16_t wCSvcState; /* M_WORKING, M_SLAVE, S_WORKING */
}_ZENIC_PACKED;

struct T_ZCMS_NODE_REG_STT{
    uint32_t dwQApplyRcvCnt;
    uint32_t dwRegRcvCnt;
    uint32_t dwHBRcvCnt;
    uint32_t dwQAckSndCnt;
    uint32_t dwRegAckSndCnt;
    uint32_t dwRstSndCnt;
    uint32_t dwHBToGtExpect;
    uint32_t dwHBToMax;
    
    /* Notify UPL event stt */
    uint32_t dwUPLJoinNotify;
    uint32_t dwUPLJoinAck;
    uint32_t dwUPLQuitNotify;
    uint32_t dwUPLQuitAck;
    uint32_t dwUPLBlockNotify;
    uint32_t dwUPLBlockAck;
    uint32_t dwUPLUnblockNotify;
    uint32_t dwUPLUnblockAck;
    uint32_t dwUPLJoinNotifyFailed;
    uint32_t dwUPLQuitNotifyFailed;
    uint32_t dwUPLBlockNotifyFailed;
    uint32_t dwUPLUnblockNotifyFailed;
}_ZENIC_PACKED;

struct T_ZCMS_NODE_STT {
    T_ZCMS_NODE_REG_STT tCurStt;
    T_ZCMS_NODE_REG_STT tLastStt;
    T_ZCMS_NODE_REG_STT tHistoryStt;
}_ZENIC_PACKED;

struct T_ZCMS_NODE_DATA {
    uint16_t wNodeId;
    uint16_t wModule;
    T_ZCS_NODE_STATE tManageStatus;
    uint16_t wRouteType;
    T_PhysAddress tPhyAddrInfo; //������Ŀǰ����nodeID��key��ʵ��Ӧ����phyAddr��������nodeID+RouteType
    uint32_t dwCNodePoweronTick;
    
    JID tSender;
    E_ZCMS_NODE_LINK_STATE eLinkState;
    uint32_t dwNodeHBeatTOCnt; /*  ������ʱ����ͳ��*/
    uint32_t dwQueueID;
    uint16_t wCSvcState; /* M_WORKING, M_SLAVE, S_WORKING */
}_ZENIC_PACKED;

struct T_ZCMS_NODE_INFO {
    uint32_t dwSyncSeq;
    T_ZCMS_NODE_DATA tCNodeData;
    T_ZCMS_NODE_STT tCNodeStt;
}_ZENIC_PACKED;

struct T_ZCMS_MGRNODE_INFO {
    T_ZCS_NODE tCurMgrNodeInfo;
    T_PhysAddress tCurMgrPhyAddrInfo;
    uint32_t dwCurMgrPowerOnTick;
}_ZENIC_PACKED;

struct ZCMS_QUEUE_REQ_MSG
{
    T_ZCMS_CNODE_INFO tCNodeInfo;
}_ZENIC_PACKED;

struct ZCMS_QUEUE_ACK_MSG
{
    T_ZCMS_MGRNODE_INFO tCurMGRInfo;
    uint32_t dwHBPeriod;
    uint32_t dwYourQueueID;
}_ZENIC_PACKED;

struct ZCMS_REG_REQ_MSG
{
    T_ZCMS_CNODE_INFO tCNodeInfo;
}_ZENIC_PACKED;

struct ZCMS_REG_ACK_MSG
{
    T_ZCMS_MGRNODE_INFO tCurMGRInfo;
    uint16_t dwRegStatus;
}_ZENIC_PACKED;

struct ZCMS_HEART_BEAT_MSG
{
    T_ZCMS_CNODE_INFO tCNodeInfo;
}_ZENIC_PACKED;

struct ZCMS_RESET_LINK_MSG
{
    E_ZCMS_RESET_LINK_REASON eRSTLinkReason;
}_ZENIC_PACKED;

struct T_ZCMS_NODE_SYNC_INFO {
    uint16_t tNodeDataNum;
    uint32_t dwSyncSeq;
    T_ZCMS_NODE_DATA   tNodeData[ZCS_MAX_NODE_NUM];
}_ZENIC_PACKED;

struct T_ZCMS_NODE_EVENT_SYNC_UNIT {
    uint16_t node_id;
    T_ZCS_NODE_EVENT node_op;
}_ZENIC_PACKED;

struct T_ZCMS_NODE_EVENT_SUB {
    uint32_t dwRegJNO;
    bool     bNeedAck;
    bool     bIsCurEventSnd;
    bool     bIsCurEventAcked;
}_ZENIC_PACKED;

struct T_ZCMS_NODE_EVENT_SYNC {
    uint32_t dwEventNum;
    uint32_t dwSubscriberNum;
    T_ZCMS_NODE_EVENT_SYNC_UNIT tEventUnit[ZCMS_MAX_NODE_EVENT_NUM];
    T_ZCMS_NODE_EVENT_SUB tEventSubscriber[ZCMS_MAX_NODE_EVENT_SUBSCRIBER_NUM];
}_ZENIC_PACKED;

const uint32_t ZCMS_SYNC_TYPE_CONFIG=1;
const uint32_t ZCMS_SYNC_TYPE_ACTIVENODE=1<<1;
const uint32_t ZCMS_SYNC_TYPE_EVENT=1<<2;

#define SYNC_CONFIG ZCMS_SYNC_TYPE_CONFIG
#define SYNC_NODES ZCMS_SYNC_TYPE_ACTIVENODE
#define SYNC_EVENTS ZCMS_SYNC_TYPE_EVENT
#define SYNC_ALL SYNC_CONFIG|SYNC_NODES|SYNC_EVENTS

struct T_EV_ZCMS_DATA_SYNC {
    uint32_t dwSyncType;
	uint32_t dwCurMgrPoweronTick;
    T_ZCMS_CONFIG_INFO tConfInfo;
    T_ZCMS_NODE_SYNC_INFO tNodeSync;
    T_ZCMS_NODE_EVENT_SYNC tNodeEvent;
}_ZENIC_PACKED;

struct T_EV_ZCMS_DATA_ACK {
    uint16_t wReserved;
}_ZENIC_PACKED;

struct T_EV_ZCMS_MULTICAST_SYNC {
    uint32_t dwSyncSeq;
	uint32_t dwCurMgrPoweronTick;
    T_ZCS_NODE_LIST tMultiNodeSync;
};

struct T_EV_ZCMS_MULTICAST_ACK {
    uint16_t wNodeID;
    uint16_t wReserved;
    uint32_t dwSeqAcked;
	uint32_t dwCurMgrPoweronTick;
}_ZENIC_PACKED;

const uint32_t ZCMS_QUEUE_INVALID_ID = 0xffffffff;
const uint32_t ZCMS_QUEUE_START_REG_ID=0;


const uint32_t ZCMS_CLIENT_TIMER_Q_APPLY_PERIOD = 15000;
const uint32_t ZCMS_CLIENT_TIMER_REG_PERIOD = 10000;
const uint32_t ZCMS_CLIENT_RST_SILENT_MIN_PERIOD=ZCMS_CLIENT_TIMER_Q_APPLY_PERIOD;
const uint32_t ZCMS_CLIENT_RST_SILENT_MAX_PERIOD=ZCMS_CLIENT_TIMER_Q_APPLY_PERIOD*2;
const uint32_t ZCMS_SLAVEMGR_SYNC_REQ_PERIOD = 2000;
const uint32_t ZCMS_MASTERMGR_MS_SYNC_PERIOD = 800;
const uint32_t ZCMS_MASTERMGR_MULTICAST_PERIOD = 1000;
const uint32_t ZCMS_MS_CHGOVER_TIMER_PERIOD = 60*1000; // 60 seconds
const uint32_t ZCMS_NOTIFY_UPL_WAIT_ACK_PERIOD = 100; 

/* Macros for min/max.  */
#define ZCMS_MIN(a,b) (((a)<(b))?(a):(b))
#define ZCMS_MAX(a,b) (((a)>(b))?(a):(b))


#define TYPE_CLIENT_ELEGANT_RESET 1
#define TYPE_CLIENT_FORCE_RESET   2

void printConfInfo(T_ZCMS_CONFIG_INFO *ptConf);

void printCNodeInfo(T_ZCMS_CNODE_INFO *ptNodeInfo);

void printMgrNodeInfo(T_ZCMS_MGRNODE_INFO *ptCurMGRInfo);

char* zcmsRstReasonToStr(E_ZCMS_RESET_LINK_REASON eReason);

char* zcmsAdminOpToStr(T_ZCS_NODE_MGR_OP op);

char* zcmsEventToStr(T_ZCS_NODE_EVENT event);

uint32_t  zcms_set_timer(uint32_t dwTimerNo, int32_t sdwDuration, uint32_t dwParam);

uint32_t  zcms_set_looptimer(uint32_t dwTimerNo, int32_t sdwDuration, uint32_t dwParam);

void zcms_cancel_timer(uint32_t &timer_id);

void zcms_init_timer(uint32_t &timer_id);

bool zcms_timer_invalid(uint32_t &timer_id);

#endif /* ZCMS_COMMON_H_ */
