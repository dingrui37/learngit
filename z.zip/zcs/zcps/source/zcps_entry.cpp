/*
 * zcps_entry.cpp
 * ZCPSģ�����
 * ��Ҫ���ܣ�
 * 1��ά��Ӧ������ͬ����ʧ��״̬
 * 2����������ͬ������
 *
 *  Created on: 2014-8-31
 *      Author: wangjun
 */


#include "tulip.h"
#include "tulip_oss.h"
#include "tulip.h"
#include "tulip_scs.h"
#include "zcs_common.h"
#include "zcs_job_def.h"
#include "CSyncStateMgr.h"
#include "CCpEventReg.h"
#include "zcps_common.h"

#define LOG_TULIP_EMERGENCY    0
#define LOG_TULIP_ALERT        1
#define LOG_TULIP_CRITICAL     2
#define LOG_TULIP_ERROR        3
#define LOG_TULIP_NOTICE       5
#define LOG_TULIP_DEBUG        7

void zcps_snode_work_msg_handler(uint32_t msgId, void *pMsg, void *pPData);
void zcps_snode_init(uint16_t startup_state);

uint16_t g_dwDbgAppId = 0;
uint16_t g_dwDbgDataType = 0;

JID g_zcps_Jid;
CSyncStateMgr g_zcpsSyncMgr;
/*ZCMS�������*/
#ifdef __cplusplus
extern "C" {
#endif

void zcps_entry(WORD16 wState, WORD32 dwMsgId, void *pMsgBody, void *pPData, BOOLEAN bSame)
{
    switch(wState)
    {
        case S_StartUp:
            XOS_GetSelfJID(&g_zcps_Jid);
            switch(dwMsgId)
            {
            case EV_MASTER_POWER_ON:
                if(g_zcps_Jid.wModule==1)
                {
                    zcps_snode_init(ZCS_JOB_STATE_MNODE_WORK);
                }
                else
                    zcps_snode_init(ZCS_JOB_STATE_SNODE_WORK);
                XOS_PowerOnAck(EV_POWER_ON_SUCCESS, NULL, 0, 0);
                XOS_SetNextState(ZCS_JOB_STATE_SNODE_WORK);
                break;
            case EV_SLAVE_POWER_ON:
                if(g_zcps_Jid.wModule==1)
                {
                    zcps_snode_init(ZCS_JOB_STATE_MNODE_SLAVE);
                 }
                 else
                 {
                     printf("[ZSPC]Initialize, expected MASTER_POWER_ON on service Node, but received EV_SLAVE_POWER_ON,ModuleNo=%u\n",
                             g_zcps_Jid.wModule);
                 }
                XOS_PowerOnAck(EV_POWER_ON_SUCCESS, NULL, 0, 0);
                XOS_SetNextState(ZCS_JOB_STATE_SNODE_WORK);
                break;
            }
            break;
        case ZCS_JOB_STATE_SNODE_WORK:
            zcps_snode_work_msg_handler(dwMsgId,pMsgBody,pPData);
            XOS_SetDefaultNextState();
            break;
        default:
            XOS_SetDefaultNextState();
            break;
    }

    XOS_SetDefaultNextState();

    return;
}

#ifdef __cplusplus
}
#endif

//��ʼ��
void zcps_snode_init(uint16_t startup_state)
{
    uint16_t node_id,module_id;
    T_ZCS_ROUTE_TYPE route_type;
    uint32_t zcrs_jno = (ZCS_JOB_TYPE_ZCRS<<16)+1;
	//10091051���޸�zcps�ȴ�zcrs�ϵ�ʱ��Ϊ10s
    XOS_WaitJob(zcrs_jno,startup_state,10*1000);
    zcs_register_rte_event(true);
    if(RESULT_ZENIC_SUCCESS!=zcs_get_self_node_info(node_id,module_id,route_type))
    {
        printf("[ZCPS]Error while get Self node info, init failed\n");
        return ;
    }
    g_zcpsSyncMgr.init(node_id);
    CCpEventReg::init();
}

/*zcps������*/
void zcps_snode_work_msg_handler(uint32_t msgId, void *pMsg, void *pPData)
{
    uint16_t msg_len;
    XOS_GetMsgDataLen(&msg_len);

    switch(msgId)
    {
        case EV_SYS_ZCS_APP_SYNC_DATA:
        {
            g_zcpsSyncMgr.onAppSyncData((uint8_t *)pMsg,msg_len);
            break;
        }
        case EV_SYS_ZCS_INNER_DATA_SYNC_ACK:
        {
            g_zcpsSyncMgr.onSyncAck((uint8_t *)pMsg,msg_len);
            break;
        }

        case EV_SYS_ZCS_REGISTER_DATA_EVENT:
        {
            CCpEventReg::onRegisterData((uint8_t *)pMsg);
            break;
        }
        case EV_SYS_ZCS_RTE_CHGOVER_NOTIFY:
        {
            //todo ������Ϣʵ��
            g_zcpsSyncMgr.onChgOverMsg((uint8_t *)pMsg);
            break;
        }
        case EV_SYS_ZCS_DATA_CHG_OVER_ACK:
        {
            break;
        }

        case EV_SYS_ZCPS_SCAN_TIMER:
        {
            g_zcpsSyncMgr.onScanTimerEvent(XOS_GetParaOfCurTimer());
            break;
        }
        case EV_SYS_ZCPS_SYNC_TIMER:
        {
            g_zcpsSyncMgr.onSyncTimerEvent(XOS_GetParaOfCurTimer());
            break;
        }
		case EV_SYS_ZCRS_WAIT_SYNC_ACK_TIMER:
		{
			g_zcpsSyncMgr.onSyncTimerOutEvent(XOS_GetParaOfCurTimer());
			break;
		}

    }

}

extern "C" {

void XOS_DbgSetSlJobLevel(WORD16, BYTE);
void XOS_DbgSetSlSysLevel(BYTE ucPrnLevel);

void zcps_show(uint16_t dwShowAppId, uint16_t dwShowDataType)
{
    if(NULL != CCpEventReg::findRegInfo(dwShowAppId, dwShowDataType))
    {
        g_dwDbgAppId = dwShowAppId;
        g_dwDbgDataType = dwShowDataType;
        XOS_DbgSetSlJobLevel(ZCS_JOB_TYPE_ZCPS, LOG_TULIP_DEBUG);
        XOS_DbgSetSlJobLevel(ZCS_JOB_TYPE_ZCPS_RECV, LOG_TULIP_DEBUG);
        XOS_DbgSetSlSysLevel(LOG_TULIP_DEBUG);
        printf("You can see app_id[0x%4x]..data_type[%u] sync data\n",dwShowAppId,dwShowDataType);
    }
    else
    {
        if((DBG_APP_ANY == dwShowAppId) || DBG_DATA_ANY == dwShowDataType)
        {
            g_dwDbgAppId = dwShowAppId;
            g_dwDbgDataType = dwShowDataType;
            XOS_DbgSetSlJobLevel(ZCS_JOB_TYPE_ZCPS, LOG_TULIP_DEBUG);
            XOS_DbgSetSlJobLevel(ZCS_JOB_TYPE_ZCPS_RECV, LOG_TULIP_DEBUG);
            XOS_DbgSetSlSysLevel(LOG_TULIP_DEBUG);
            printf("You can see sync data of all app_id or all data_type of some app_id!\n",dwShowAppId,dwShowDataType);
            return;
        }
        printf("There's NO app_id[0x%4x]..data_type[%u] regist to ZCPS!\n",dwShowAppId,dwShowDataType);
    }
}

void zcps_unshow()
{
    g_dwDbgAppId = 0;
    g_dwDbgDataType = 0;
    XOS_DbgSetSlJobLevel(ZCS_JOB_TYPE_ZCPS, LOG_TULIP_NOTICE);
    XOS_DbgSetSlJobLevel(ZCS_JOB_TYPE_ZCPS_RECV, LOG_TULIP_NOTICE);   
    XOS_DbgSetSlSysLevel(LOG_TULIP_NOTICE);
    printf("You can NOT see sync data any more!\n");
}

void zcps_show_stats(uint32_t dwType)
{
    g_zcpsSyncMgr.print_stats(dwType);
}
void zcps_show_event_reg(uint32_t isPrintStats)
{
    CCpEventReg::print_stats(isPrintStats);
}

void zcps_show_send_detail(uint16_t nodeId)
{
    if(ZCS_MASTER_NODE_ID_2 == nodeId)
    {
        CCpEventReg::print_stats_send(0);
    }
    else if(0 < nodeId && nodeId < ZCS_MAX_NODE_NUM)
    {
        CCpEventReg::print_stats_send(nodeId);
    }
    else if(0 == nodeId)
    {
        CCpEventReg::print_stats_send(ZCS_INVALID_NODEID);
    }
    else
    {
        printf("You input wrong nodeId!\n");
        return;
    }
}

void zcps_show_unsync_detail(uint16_t start, uint16_t total)
{
    XOS_DbgSetSlJobLevel(ZCS_JOB_TYPE_ZCPS, LOG_TULIP_DEBUG);
    XOS_DbgSetSlJobLevel(ZCS_JOB_TYPE_ZCPS_RECV, LOG_TULIP_DEBUG);
    XOS_DbgSetSlSysLevel(LOG_TULIP_DEBUG);

    g_zcpsSyncMgr.showZcpsUnSyncDetail(start, total);    

    XOS_DbgSetSlJobLevel(ZCS_JOB_TYPE_ZCPS, LOG_TULIP_NOTICE);
    XOS_DbgSetSlJobLevel(ZCS_JOB_TYPE_ZCPS_RECV, LOG_TULIP_NOTICE);   
    XOS_DbgSetSlSysLevel(LOG_TULIP_NOTICE);
}

void zcps_clean_reg_stat(uint32_t isCleanAllHistory)
{
    CCpEventReg::clean_reg_stats(isCleanAllHistory);
    printf("clear rcvAppSyn,sendNum,rcvZcpsSyn!\n");
}

void zcps_clean_st_data()
{
    g_zcpsSyncMgr.cleanStatisticsData();
}

void zcps_show_st_stats()
{
    g_zcpsSyncMgr.printPullPushDataState();
}

void zcps_show_inst_stats()
{
    g_zcpsSyncMgr.showInstMgrStats();
}

}
