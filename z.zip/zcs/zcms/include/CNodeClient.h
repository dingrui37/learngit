/*
 * CNodeMgr.h
 *
 *  Created on: 2014-8-31
 *      Author: wangjun
 */

#ifndef CNODECLNT_H_
#define CNODECLNT_H_

#include "zcms_common.h"
#include "CInstMgr.hpp"
#include "CZcmsMgr.h"
#include "CNodeConfig.h"

class CNodeClient {
struct CNode_cb_t
{
    uint32_t dwLauchSvcRcvCnt;
    uint32_t dwQApplySndCnt;
    uint32_t dwRegSndCnt;
    uint32_t dwHBSndCnt;
    uint32_t dwQAckRcvCnt;
    uint32_t dwRegAckRcvCnt;
    uint32_t dwMCastRcvCnt;
    uint32_t dwMCastAckCnt;
    uint32_t dwRstRcvCnt;
    uint32_t dwRstReason[E_ZCMS_RESET_LINK_REASON_MAXCOUNT];

    /* error stt */
    uint32_t dwQApplySndFailed;
    uint32_t dwRegSndFailed;
    uint32_t dwHBSndFailed;
    uint32_t dwHBSndContinuousFailed;
    uint32_t dwMCastAckFailed;
    uint32_t dwMgrDiff;
    uint32_t dwErrorMsgRcv;
    uint32_t dwSndMsgFailed;
    uint32_t dwErrorPowerTickCnt;
};

public:
    CNodeConfig *m_pConfig;
    CZcmsMgr *m_pZcmsMgr;
    bool m_isClientWorking;
    bool m_isSvcLauched;
    bool m_isInMCastGrp;
    
private:
    JID mMasterNodeJID;
    T_ZCS_NODE m_tCurMgrNodeType;
    T_PhysAddress m_tCurMgrPhyAddr;
    uint32_t m_dwCurMgrPoweronTick;
    
    E_ZCMS_NODE_LINK_STATE m_eSelfLinkState;
    uint32_t m_dwQueueID;
    uint32_t m_dwReqTimerID;
    uint32_t m_dwEchoTimerID;
    uint32_t m_dwRstSilentDuration;
    T_ZCS_NODE_LIST *m_ptActiveNodeList;
    
    CNode_cb_t tCNodeStt;
    
public:
    CNodeClient();
    ZENIC_RESULT init(CNodeConfig *ptNodeConf, CZcmsMgr *ptCZcmsMgr, uint16_t wWorkState);
    bool isServiceLaunched();
    void onReceiveNotifyLaunchService();
    uint32_t getPowerOnTick();
    void constrCNodeInfo(T_ZCMS_CNODE_INFO &tNodeInfo);
    void constrMasterNodeMgrJID();
    ZENIC_RESULT setSelfLinkState(E_ZCMS_NODE_LINK_STATE eSelfState);
    E_ZCMS_NODE_LINK_STATE getSelfLinkState();
    uint16_t getSelfNodeID();
    ZENIC_RESULT saveMgrInfo(T_ZCMS_MGRNODE_INFO* ptMgrInfo);
    bool checkMgrInfo(T_ZCMS_MGRNODE_INFO* ptMgrInfo);

    void onRegQueueReq();
    void onCHandleQueueAck(void *pMsg, uint16_t msg_len);
    void onFormallyRegReq();
    void onCHandleRegAck(void *pMsg, uint16_t msg_len);	
    void onClientHeatBeat();
    void onCHandleLinkResetMsg(void *pMsg, uint16_t msg_len);
    void onHandleMultiCastSync(void *pMsg, uint16_t msg_len);
    ZENIC_RESULT writeShmActiveNodes(void *data, uint32_t len);
    ZENIC_RESULT clearShmActiveNodes();
    ZENIC_RESULT writeShmSelfNodesState();
    void resetMyNodeConnectionLink();
    void sendCleanRteTable();
    void closeLinkConnection();
    ZENIC_RESULT joinMultiCastGroup(uint16_t wGroupNo);
    ZENIC_RESULT quitMultiCastGroup(uint16_t wGroupNo);
    
    void adminReset(void *pMsg, uint16_t msg_len);
    void printQueueApplyMsg(ZCMS_QUEUE_REQ_MSG *pQueueReq);
    void printQueueAckMsg(ZCMS_QUEUE_ACK_MSG *pQueueAck);
    void printFormallyRegMsg(ZCMS_REG_REQ_MSG *pFReq);
    void printRegAckMsg(ZCMS_REG_ACK_MSG *pRegAck);


    /*��ȡ��Ŀ������б�*/
    ZENIC_RESULT getActiveNodes(T_ZCS_NODE *nodes, uint16_t max_num);
    void showStt();

    ZENIC_RESULT shutdown();
    virtual ~CNodeClient();
};

#endif /* CNODECLNT_H_ */
