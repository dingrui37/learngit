/*
 * CSyncStateMgr.cpp
 *
 *  Created on: 2014-9-3
 *      Author: wangjun
 */

#include "CSyncStateMgr.h"
#include "tulip.h"
#include "tulip_oss.h"
#include "zcps_common.h"
#include "CCpEventReg.h"
#include <algorithm>
#include "CHdTimer.hpp"

extern uint16_t g_dwDbgAppId;
extern uint16_t g_dwDbgDataType;
CSyncStateMgr::CSyncStateMgr()
    : max_ordinary_data_num(0), max_chgover_data_num(0),cur_scan_index1(0),
      cur_scan_index2(0), cur_idle_scan_index(0), m_to_scaned_data1(0),
      m_to_scaned_data2(0), m_state(E_ZCPS_CHOVER_WORK), m_module_id(0),
      m_node_id(0), m_route_type(0), m_scan_timer(0), m_sync_timer(0),
      m_sync_over_timer(0), m_sync_data_pool(),m_chgover_task_mgr(),
      m_sync_state_mutex(), m_chgover_state_mutex(),
      m_send_sync_request(0),m_recv_app_sync(0), m_recv_app_sync_add(0),
      m_recv_app_sync_mod(0),m_recv_app_sync_del(0),m_recv_app_sync_other(0),
      m_recv_app_sync_error(0),m_recv_sync_lookup_error(0),
      m_recv_sync_findRegInfo_error(0),m_recv_sync_notmasternode_error(0),
      m_recv_sync_insertsyncstate_error(0),m_recv_sync_nobackupnode_error(0),
      m_recv_peer_insertsyncstate_error(0),m_sent_sync_notify(0),
      m_sent_sync_notify_add(0),m_sent_sync_notify_mod(0),m_sent_sync_notify_del(0),
      m_sent_sync_notify_other(0),m_sent_notify_app_error(0),m_recv_backup_ack(0),
      m_recv_chgover_only(0),m_recv_chgover_only_add(0),m_recv_chgover_only_del(0),
      m_recv_chgover_only_other(0),m_del_chgover_data(0),m_del_ori_data(0),
      m_del_chgover_data_fail(0),m_del_ori_data_fail(0),
      bChgOverTimeOut(false)
{
    cur_idle_scan_index = 0;
    resetChgoverCounters();
}

/*����ʣ���ڴ��С���������������������*/
void CSyncStateMgr::calc_data_state_num()
{
    uint8_t ucVectorId = 0;
    zc_license_get_mem_vector(ucVectorId);
    max_chgover_data_num = ZCPS_CHGOVER_DATA_NUM;
    max_ordinary_data_num=ZCPS_MAX_CHGOVER_DATA_NUM[ucVectorId];
}

/*��ʼ��ϵͳ״̬������*/
ZENIC_RESULT CSyncStateMgr::init(uint16_t self_node_id)
{
    int ret1,ret2,ret3;

    m_node_id = self_node_id;
    calc_data_state_num();//������������С
    m_ChgOverScanRound=0;
    cur_scan_index1 = 0;
    cur_scan_index2 = 0;    
    m_chgover_timer_count = 0;
    m_instMgr1_err = 0;
    m_acked_synced_count = 0;
    m_acked_unsynced_count = 0;

    ret1=m_data_state.init(max_ordinary_data_num);
    ret2=m_chgover_data_state.init(max_chgover_data_num);
	ret3=m_pull_push_diff.init(ZCPS_MAX_JOB_NUM);
    ZENIC_RESULT ret= m_sync_data_pool.init(m_node_id);

    m_chgover_task_mgr.init(self_node_id);
    stateMachine(E_ZCPS_INNER_EVENT_INIT);
    setTimer();
    if(ret!=RESULT_ZENIC_SUCCESS || ret1!=InstMgr::RESULT_INST_SUCCESS ||
		ret2!=InstMgr::RESULT_INST_SUCCESS || ret3!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG_SIMPLE(LOG_CRITICAL,"[ZCPS]Init sync data state failed,ret1=%d,ret2=%d,ret3=%d,ret=%d\n",ret1,ret2,ret3,ret);
        return ERROR_ALLOC_INSTANCE_FAIL;
    }
    else
    {
        ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCPS]Startup Success ,node_id=%u, data1_num=%u, data2_num=%u\n",
                self_node_id, max_ordinary_data_num,max_chgover_data_num);
        return RESULT_ZENIC_SUCCESS;
    }


}

char* dataop2string(T_ZCS_DATA_OP dataop)
{
    static char opbuf[15];
    char *pbuf = opbuf;
    memset(opbuf, 0, sizeof(opbuf));
    if((dataop&(~ZCS_DATA_OP_CHGOVER_ONLY)) == ZCS_DATA_OP_ADD)
    {
        sprintf(pbuf, "ADD");
        pbuf += strlen("ADD");
    }
    else if((dataop&(~ZCS_DATA_OP_CHGOVER_ONLY)) == ZCS_DATA_OP_MODIFY)
    {
        sprintf(pbuf, "MOD");
        pbuf += strlen("MOD");
    }
    else if((dataop&(~ZCS_DATA_OP_CHGOVER_ONLY)) == ZCS_DATA_OP_DELETE)
    {
        sprintf(pbuf, "DEL");
        pbuf += strlen("DEL");
    }

    if(dataop&ZCS_DATA_OP_CHGOVER_ONLY)
    {
        sprintf(pbuf, "|CHGOVER");
    }
    return opbuf;
}

void printZcpsSyncData(T_ZCS_DATA_KEY datakey, T_ZCS_RESOURCE_KEY reskey, T_ZCS_DATA_OP dataop, uint16_t data_len, uint16_t printIndex)
{
    static char buf[ZCS_MAX_RECORD_KEY_LEN * 3 + ZCS_MAX_RESOURCE_KEY_LEN * 3 + 120];
    char *pbuf=buf;
    memset(buf, 0, sizeof(buf));
    if(printIndex == 2)
    {
        sprintf(pbuf, "[ZCPS_DBG]app_id:0x%4x data_type:%8u rec_key:", datakey.app_id, datakey.data_type);
        pbuf += strlen("[ZCPS_DBG]app_id:0x     data_type:         rec_key:");
    }
    else if(printIndex == 1)
    {
        sprintf(pbuf, "[ZCPS_APP]app_id:0x%4x data_type:%8u len:%8u rec_key:", datakey.app_id, datakey.data_type, data_len);
        pbuf += strlen("[ZCPS_APP]app_id:0x     data_type:         len:         rec_key:");
    }
    else
    {
        sprintf(pbuf, "[ZCPS_SYNC]rec_key:");
        pbuf += strlen("[ZCPS_SYNC]rec_key:");
    }
    if(datakey.tRecKey.key_len > ZCS_MAX_RECORD_KEY_LEN || reskey.key_len > ZCS_MAX_RESOURCE_KEY_LEN)
    {
        char errBuf[40];
        sprintf(errBuf, "[E]ResKeyLen:%u RecKeyLen:%u\n", datakey.tRecKey.key_len, reskey.key_len);
        ZCS_LOG_SIMPLE(LOG_ERROR,"%s\n", errBuf);
    }
    int recordLen = datakey.tRecKey.key_len < ZCS_MAX_RECORD_KEY_LEN ? datakey.tRecKey.key_len : ZCS_MAX_RECORD_KEY_LEN;
    for(int i = 0;i < recordLen; i++)
    {
        if(i%4 == 0)
        {
            sprintf(pbuf, " ");
            pbuf += 1;
        }
        sprintf(pbuf, "%02x", datakey.tRecKey.rec_key[i]);
        pbuf += 2;
    }
    sprintf(pbuf, " res_key:");
    pbuf += strlen(" res_key:");
    int resLen = reskey.key_len < ZCS_MAX_RESOURCE_KEY_LEN ? reskey.key_len : ZCS_MAX_RESOURCE_KEY_LEN;
    for(int i = 0;i < resLen; i++)
    {
        if(i%4 == 0)
        {
            sprintf(pbuf, " ");
            pbuf += 1;
        }
        sprintf(pbuf, "%02x", reskey.res_key[i]);
        pbuf += 2;
    }
    sprintf(pbuf, " dataop:%s(%d)", dataop2string(dataop), dataop);
    bool bMaster;
    bool bLocal = zcs_is_local(reskey, bMaster);
    if (bLocal)
    {    
        sprintf(pbuf, " Local:%s", bMaster ? "MASTER" : "SLAVE");
    }
    else
    {
        sprintf(pbuf, " Local:%s", "Remote");
    }
    ZCS_LOG_SIMPLE(LOG_NOTICE,"%s", buf);
}

/*�յ�Ӧ������ͬ�����������ȼ�¼��ʧ����������Ȼ�����ͬ��ʵ���ؽ���ͬ������
 * ��¼ʧ������״̬��ͬʱ���鿴�������Ƿ���Ҫ����ȷ�ϣ������Ҫ������뵹��������*/
void CSyncStateMgr::onAppSyncData(uint8_t* msg, uint16_t len)
{
    uint32_t idx;
    T_EV_ZCS_APP_SYNC_DATA *ptData = (T_EV_ZCS_APP_SYNC_DATA *)msg;
    T_DHT_NODES_GROUP tNodes;
    ZENIC_RESULT ret = RESULT_ZENIC_SUCCESS;
    T_ZCPS_EVENT_REG_VALUE tValue;

    if((ptData->tSyncHdr.app_id == g_dwDbgAppId && ptData->tSyncHdr.tDataKey.data_type == g_dwDbgDataType)
        || DBG_APP_ANY == g_dwDbgAppId || (ptData->tSyncHdr.app_id == g_dwDbgAppId && DBG_DATA_ANY == g_dwDbgDataType))
    {
        printZcpsSyncData(ptData->tSyncHdr.tDataKey, ptData->tSyncHdr.tResKey, ptData->tSyncHdr.dataop, ptData->tSyncHdr.data_len, 1);
    }
    
    //ͳ�Ƹ����������ͷ�����Ϣ��
    ret = CCpEventReg::findRegInfoIncCounter(ptData->tSyncHdr.app_id,ptData->tSyncHdr.tDataKey.data_type,tValue);
    if(RESULT_ZENIC_SUCCESS != ret)
    {
        m_recv_app_sync_error++;
        m_recv_sync_findRegInfo_error++;
        ZCS_LOG_SIMPLE(LOG_ERROR,"[ZCPS]recv unregister app sync request, app_id=0x%x, data_type=%u,data_len=%u\n",
                     ptData->tSyncHdr.app_id,ptData->tSyncHdr.tDataKey.data_type,ptData->tSyncHdr.data_len);
        return ;
    }    
    
    m_recv_app_sync++;
    if (ptData->tSyncHdr.dataop == ZCS_DATA_OP_ADD)
    {
        m_recv_app_sync_add++;
    }
    else if (ptData->tSyncHdr.dataop == ZCS_DATA_OP_MODIFY)
    {
        m_recv_app_sync_mod++;
    }
    else if (ptData->tSyncHdr.dataop == ZCS_DATA_OP_DELETE)
    {
        m_recv_app_sync_del++;
    }
    else /* ZCS_DATA_OP_CHGOVER_ONLY here */
    {
        m_recv_app_sync_other++;
    } 
    
    /*�����м�̬�������·�ɱ�ǰ���Ȳ��ҵ�������*/
    /*·�ɱ�����ʧ�ܻ��߷Ǳ��ڵ㸺�����ݣ��жϲ������ͣ����������CHGOVER_ONLY�������Ƕ���������֪ͨ�ģ��������״̬��
     * �����账��*/
    if (m_state != E_ZCPS_CHOVER_WORK)
    {
        if(!m_chgover_task_mgr.findTaskItem(ptData->tSyncHdr.tResKey,tNodes))
        {
            ret = zcs_inner_rte_lookup(ptData->tSyncHdr.tResKey,tNodes);
            if(ret!=RESULT_ZENIC_SUCCESS)
            {
                m_recv_app_sync_error++;
                m_recv_sync_lookup_error++;
                ZCS_LOG_SIMPLE(LOG_ERROR,"[ZCPS]lookup Routing Table failed, app_id=0x%x, data_type=%u,data_len=%u\n",
                ptData->tSyncHdr.app_id,ptData->tSyncHdr.tDataKey.data_type,ptData->tSyncHdr.data_len);
                return;
            }
        }
    }
    else
    {
        ret = zcs_inner_rte_lookup(ptData->tSyncHdr.tResKey,tNodes);
        if(ret!=RESULT_ZENIC_SUCCESS)
        {
            m_recv_app_sync_error++;
            m_recv_sync_lookup_error++;
            ZCS_LOG_SIMPLE(LOG_ERROR,"[ZCPS]lookup Routing Table failed, app_id=0x%x, data_type=%u,data_len=%u\n",
            ptData->tSyncHdr.app_id,ptData->tSyncHdr.tDataKey.data_type,ptData->tSyncHdr.data_len);
            return;
        }
    }

    /*�����ҪChangeOver Notify,���¼���뵹��״̬������������ͬ��*/
    if(tValue.neekChgOver)
    {
        if(tNodes.master_node_id==m_node_id)
        {
            ret = insertChgoverState((const T_ZCPS_MSG *)ptData,true,idx);
        }
        else if(isBackupNode(tNodes,m_node_id))
        {
            ret = insertChgoverState((const T_ZCPS_MSG *)ptData,false,idx);
        }

        if (ret != RESULT_ZENIC_SUCCESS)
        {
            ZCS_LOG_SIMPLE(LOG_ERROR,"[ZCPS] insertChgoverState() failed,ret=%u.\n",ret);
        }
    }

    /*�����CHGOVER_ONLY�����ݣ��򷵻أ�����ͬ��*/
    if((ptData->tSyncHdr.dataop & ZCS_DATA_OP_CHGOVER_ONLY)!=0)
    {
        m_recv_chgover_only++;
        if ((ptData->tSyncHdr.dataop & 0x7F) == ZCS_DATA_OP_ADD)
            m_recv_chgover_only_add++;
        else if ((ptData->tSyncHdr.dataop & 0x7F) == ZCS_DATA_OP_DELETE)
            m_recv_chgover_only_del++;
        else
            m_recv_chgover_only_other++;
        return ;
    }
    
    /*����Remote Put�������Ҫ֪ͨ�����ϲ�Ӧ��*/
    if(ptData->tSyncHdr.remote_put)
    {
        CCpEventReg::notifyApp(*ptData);
    }

    /*�������ݱ��ݴ���*/
    this->syncData(ptData,tNodes);
}

/*�յ�ͬ��ȷ�ϵĴ�������Ҫ����ͬ����ʧ��״̬*/
void CSyncStateMgr::onSyncAck(uint8_t* msg, uint16_t len)
{
    ZENIC_RESULT ret;
    uint32_t idx;
    T_ZCPS_SYNC_ACK* pSyncAck = (T_ZCPS_SYNC_ACK*)msg;
    if(len<=_OFFSET(T_ZCPS_SYNC_ACK, tObjAck)
        ||len!=_OFFSET(T_ZCPS_SYNC_ACK, tObjAck)+pSyncAck->wObjAckCnt*sizeof(T_EV_ZCS_INNNER_DATA_SYNC_ACK))
    {
        m_recv_backup_err_ack++;
        ZCS_LOG_SIMPLE(LOG_NOTICE, "==onSyncAck rcv ack err len:%d, should be %d", 
                    len, _OFFSET(T_ZCPS_SYNC_ACK, tObjAck)+pSyncAck->wObjAckCnt*sizeof(T_EV_ZCS_INNNER_DATA_SYNC_ACK));
        return;
    }
    ZCS_LOG_SIMPLE(LOG_DEBUG, "==onSyncAck rcv ack from Node[%d]:ItemTsn[%u] contain AckCnt [%d]", 
                    pSyncAck->wNodeId, pSyncAck->dwTsn, pSyncAck->wObjAckCnt);
    for(uint16_t cnt = 0; cnt < pSyncAck->wObjAckCnt; cnt++)
    {
        T_EV_ZCS_INNNER_DATA_SYNC_ACK *ptAck = &pSyncAck->tObjAck[cnt];

        ret = m_sync_data_pool.onSyncAck(*ptAck,idx);
        if(ret==RESULT_ZENIC_SUCCESS)
        {
            ackState(idx,ptAck->dataop);
        }
    }
}

bool CSyncStateMgr::isChgOverFirstRound()
{
    return (m_ChgOverScanRound==1);
}

void CSyncStateMgr::setChgOverFirstRound()
{
    m_ChgOverScanRound=1;
}

void CSyncStateMgr::incChgOverRound()
{
    m_ChgOverScanRound++;
}

void CSyncStateMgr::resetChgoverCounters()
{
    m_remain_pool_data = 0;    
    m_scan_end_error = 0;
    m_chgover_notify_delete_count = 0;
    m_idle_noLocal_delete_count = 0;
    m_chgover_task_op_none_count = 0;
    m_chgover_sync_remove_count = 0;
    m_chgover_send_syncReq_common = 0;
    m_insertSync_delete_count = 0;
    m_removeSync_count = 0;
    m_syncAck_dataop_delete_count = 0;
    m_syncAck_notify_delete_count = 0;  
    m_acked_synced_count = 0;
    m_acked_unsynced_count = 0;

    m_dataop_delete_count=0;
    m_insert_noexist_count=0;
    m_delete_notify_count=0;

    m_ack_state_SYNC_count=0;
    m_insert_syncState_SYNC_count=0;
    m_init_syncstate_UNSYNC_count=0;
    m_insert_syncState_UNSYNC_count=0;
    m_insert_chgoverState_UNSYNC_count=0;    
    m_pre_set_SYNC_count=0;
    m_pre_set_UNSYNC_count=0;
    m_send_request_noneOp_SYNC_count=0;
    m_send_request_return_SYNC_count=0;
    m_sync_data_SYNC_count=0;

    m_unsync_data = 0;
}

void CSyncStateMgr::preSetDataState()
{
    T_ZCPS_SYNC_STATE* ptState;
    for(uint32_t i = 0; i < m_data_state.getTotalInstNum(); i++)
    {
        if(m_data_state.getInstanceState(i)==InstMgr::INST_STATE_ALLOCATED)
        {   
            ptState = &m_data_state[i];
            ptState->chgover_op = m_chgover_task_mgr.getDataChgOverOp(ptState->tResKey,ptState->tChgOverNodes);
            if(CChgOverTask::E_CHGOVER_DATA_OP_NONE == ptState->chgover_op 
                || CChgOverTask::E_CHGOVER_DATA_OP_CHGOVER == ptState->chgover_op)
            {        
                m_pre_set_SYNC_count++;
                ptState->data_state = E_ZCPS_DATA_SYNC_STATE_SYNCHRONIZED;                    
            }
            else
            {
                m_pre_set_UNSYNC_count++;
                ptState->data_state = E_ZCPS_DATA_SYNC_STATE_UNSYNCHRONIZED;
                if(CChgOverTask::E_CHGOVER_DATA_OP_DELETE == ptState->chgover_op)
                {
                    ptState->chgover_op = CChgOverTask::E_CHGOVER_DATA_OP_DELETE;                    
                }
            }
        }
    }
    uint64_t scan_over_time = zenic::CHdTimer::getCurTime();
    printf("[ZCPS]scan over, last:%llu\n",scan_over_time - m_prechg_time);
}

/*Ԥ������������Ҫ���´������������б�*/
void CSyncStateMgr::onPreChg(const T_EV_ZCS_RTE_CHGOVER_EVENT *ptEvent)
{
    stateMachine(E_ZCPS_INNER_EVENT_RECV_RTE_CHG);
    m_prechg_time = zenic::CHdTimer::getCurTime();
    m_chgover_time = m_prechg_time;
    printf("[ZCPS]Begin chgover, m_prechg_time:%llu\n",m_prechg_time);
    m_chgover_task_mgr.addChgoverTask(ptEvent);
    setChgOverFirstRound();
    cur_scan_index1=cur_scan_index2=0;
    resetChgoverCounters();
    CCpEventReg::clean_reg_tmp_stats();
    
    if(m_chgover_task_mgr.hasBackupTask())
        m_to_scaned_data1 = m_data_state.getAllocatedInstNum();
    else
        m_to_scaned_data1 = 0;
    if(m_chgover_task_mgr.hasDataChgOverTask())
        m_to_scaned_data2 = m_chgover_data_state.getAllocatedInstNum();
    else
        m_to_scaned_data2 = 0;
    ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCPS]Enter Prechg State ,cur_state=%u, data1_to_scan_=%u, data2_to_scan=%u\n",
            m_state, m_to_scaned_data1,m_to_scaned_data2);
    if(0 != m_to_scaned_data1)
    {
        preSetDataState();
    }
    //����ͬ����ʱ��ʱ��
    m_sync_over_timer = XOS_SetRelativeTimer(EV_SYS_ZCRS_WAIT_SYNC_ACK_TIMER, ZCS_MIGRATE_SYNC_TIMER,PARAM_NULL);
}

/*ɨ�趨ʱ��������ɨ�����е�״̬�����ͬ������
 * ͬʱ��Ҫ����״̬������*/
void CSyncStateMgr::onScanTimerEvent(uint32_t param)
{
    uint32_t scan_count = 0;
    uint32_t process_count = 0;
    T_ZCPS_SYNC_STATE *ptState;

    uint32_t process_per_round = this->getScanWindowSize();

    /*IDLE��PRECHG��״̬�½���������ɨ�裬�ֱ���*/
    if(m_state==E_ZCPS_CHOVER_WORK || m_state==E_ZCPS_CHOVER_POSTCHG)
    {
        idleStateScan(process_per_round);
        return;
    }
    else if(m_state==E_ZCPS_CHOVER_SCAN_CHGOVER_DATA)
    {
        if(this->onScanChgOverData(process_per_round))
        {
            this->stateMachine(E_ZCPS_INNER_EVENT_SCAN_CHGOVER_DATA_FINISH);
            ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCPS]change Over data scan finished ,cur_state=%u,instance_num=%u, scan_idx=%u\n",
                    m_state, m_chgover_data_state.getAllocatedInstNum(),cur_scan_index2);
            return;
        }
    }

    /*  ״̬����ʵ��Ϊ�գ���������ɨ���Ѿ�����ϵͳ��������������������
     *  ���Ӳ�����ɨ����ж�����:
     *  ֻ��ɨ����в�Ϊ�ղŲ�����ɨ�裬������Щ��ʧ�����ݻ�Ҫ����һ�ֲ���ɨ��ͬ��*/
    if(!m_chgover_task_mgr.hasBackupTask() || cur_scan_index1>=max_ordinary_data_num || m_to_scaned_data1==0)
    {
        if(m_to_scaned_data1==0 && m_chgover_task_mgr.getPendingChgOverDataNum()==0 
            && m_sync_data_pool.getChgOverDataNum()==0 && m_sync_data_pool.getPoolDataNum()==0)
        {
            stateMachine(E_ZCPS_INNER_EVENT_SCAN_FINISH);
            ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCPS]data scan finished ,cur_state=%u, instance_num=%u, scan_idx=%u, max_ordinary_data_num:%u\n",
                m_state, m_data_state.getAllocatedInstNum(),cur_scan_index1,max_ordinary_data_num);
            return;
        }
        else if(cur_scan_index1>=max_ordinary_data_num || m_to_scaned_data1==0)
        {
            if(m_sync_data_pool.getPoolDataNum()==0)
            {
                incChgOverRound();
                m_to_scaned_data1 = getUnSynchronized(cur_scan_index1);
                m_chgover_task_mgr.clearPendingChgOverDataNum();
                ZCS_LOG_SIMPLE(LOG_NOTICE,"Scan from head again time:%llu\n", zenic::CHdTimer::getCurTime());
            }
            else
            {
                ZCS_LOG_SIMPLE(LOG_NOTICE,"hasBackupTask:%d, cur_scan_index1:%u, max_ordinary_data_num:%u, m_to_scaned_data1:%u\
                getPendingChgOverDataNum:%u,getChgOverDataNum:%u,  getPoolDataNum:%u\n",
                m_chgover_task_mgr.hasBackupTask(),cur_scan_index1,max_ordinary_data_num,m_to_scaned_data1,
                m_chgover_task_mgr.getPendingChgOverDataNum(),m_sync_data_pool.getChgOverDataNum(),m_sync_data_pool.getPoolDataNum());
                
                m_remain_pool_data++;
                return;
            }            
        }
        else
        {
            m_scan_end_error++;
            return;
        }
    }
    
    uint32_t scan_per_round = this->getMaxCntInOnceScan();
    /*ɨ�����ݣ���Ӧ�÷�������*/
    while(scan_count<scan_per_round && process_count<process_per_round)
    {
        if(m_data_state.getInstanceState(cur_scan_index1)==InstMgr::INST_STATE_ALLOCATED)
        {
            ptState = &m_data_state[cur_scan_index1];
            if(E_ZCPS_DATA_SYNC_STATE_SYNCHRONIZED!=ptState->data_state)
            {
                if(RESULT_ZENIC_SUCCESS == sendSyncRequest(ptState,cur_scan_index1))
                {
                    m_to_scaned_data1--;
                }
            }
            process_count++;
        }

        scan_count++;
        cur_scan_index1++;
        if(cur_scan_index1>=max_ordinary_data_num || m_to_scaned_data1==0)
        {
            return;//�Ѿ�ɨ�����
        }
    }

}

/*ͬ����ʱ������*/
void CSyncStateMgr::onSyncTimerEvent(uint32_t param)
{
    m_sync_data_pool.onSyncTimerEvent(param);
}

/*ͬ����ʱ��ʱ������*/
void CSyncStateMgr::onSyncTimerOutEvent(uint32_t param)
{
    m_chgover_timer_count++;
    m_chgover_time = zenic::CHdTimer::getCurTime();
    printf("[ZCPS]Sync Time Out[%llu seconds]!prechgtime:%llu, m_chgover_time:%llu\n",
            (m_chgover_time-m_prechg_time)/1000000, m_prechg_time,m_chgover_time);
    stateMachine(E_ZCPS_INNER_EVENT_SCAN_FINISH);
}

/*������ɴ�������ZCRS����ȷ����Ϣ*/
void CSyncStateMgr::onChgOverFinish(T_ZCS_CHGOVER_EVENT tEvent)
{
    ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCPS]change Over finish, cur_state=%u\n", m_state);
    cur_idle_scan_index = cur_scan_index1;
    if(tEvent==ZCS_EV_PRE_CHGOVER)
    {        
        zcs_rte_chgover_ack(ZCS_EV_PRE_CHGOVER,m_chgover_task_mgr.tSegList);
    }
    m_chgover_task_mgr.clear();
    //���pull/push����״̬
    clearPullPushDataState();
    uint32_t firstIndex = 0;
    m_unsync_data = getUnSynchronized(firstIndex);
}

/*��ȡ��ǰ״̬*/
E_ZCPS_CHOVER_STATE CSyncStateMgr::getState()
{
    return m_state;
}

/*����ɨ�贰�ڵĴ�С������̬�ͷǵ���̬�ֱ�����
 * ɨ�贰�ڴ�С��ʧ����������С�йأ�ÿ50msɨ��һ�Σ�ÿ����ɨ��20*windowSize�����ݣ�
 * ����̬��֤2����ɨ����ϣ���2M���ݵ�windowSizeΪ874
 * ɨ�贰�������Ϊ2048ʱ������ֻ̬�ܱ�֤ɨ��4.9M������*/
uint32_t CSyncStateMgr::getScanWindowSize()
{
    uint32_t window;
    if(m_state==E_ZCPS_CHOVER_WORK)
    {
       window = std::min<uint32_t>(max_ordinary_data_num>>12,ZCPS_MAX_DATA_SCAN_COUNT>>2);
    }
    else
    {
        window = std::min<uint32_t>(max_ordinary_data_num>>10,ZCPS_MAX_DATA_SCAN_COUNT);
    }

    return std::min<uint32_t>(window,m_sync_data_pool.getFreeLen()/2);

}

uint32_t CSyncStateMgr::getMaxCntInOnceScan()
{
    return std::max<uint32_t>((ZCPS_MAX_DATA_SCAN_COUNT<<3), getScanWindowSize());
}

/*ͳ�ƴ�ӡ���������ڵ�����;*/
void CSyncStateMgr::print_stats(uint32_t dwType)
{
    uint32_t FirstIndex;
    uint32_t TotalUnsync;
    printf("\nzcps Change_over_state=%u, ChgOverScanRound:%u, Scan_idx1=%u,Scan_idx2=%u, wait_scan_data1=%u,wait_scan_data2=%u\n",
            m_state,m_ChgOverScanRound,cur_scan_index1,cur_scan_index2,m_to_scaned_data1,m_to_scaned_data2);
    printf("idleScan:cur_idle_scan_index=%u,process_per_round=%u,scan_per_round=%u\n", cur_idle_scan_index, getScanWindowSize(), getMaxCntInOnceScan());
    printf("zcps statistics: send_sync_request=%u,recv_App_sync_req=%u(%u:%u:%u:%u)\n"
           "App_sync_req_err=%u(%u:%u:%u:%u:%u:%u),recv_backup_ack=%u,m_recv_backup_err_ack:%u,m_recv_chgover_only=%u(%u,%u,%u)\n"
           "m_send_sync_retry=%u,m_recv_peer_insertsyncstate_error=%u,m_recv_peer_msglength_error=%u,Notify_to_app=%u(%u:%u:%u:%u)\n"
           "m_sent_notify_app_error=%u,m_instMgr1_err=%u,ack_unsynced:%u,ack_synced:%u\n"
           "m_del_ori_data=%u,m_del_chgover_data=%u,m_del_ori_data_fail=%u,m_del_chgover_data_fail=%u\n",
            m_send_sync_request,m_recv_app_sync, m_recv_app_sync_add,m_recv_app_sync_mod,m_recv_app_sync_del,m_recv_app_sync_other,
            m_recv_app_sync_error+m_sync_data_pool.getSyncPoolAllocFailCount(),
            m_recv_sync_lookup_error,m_recv_sync_findRegInfo_error,m_recv_sync_notmasternode_error,
            m_recv_sync_insertsyncstate_error,m_recv_sync_nobackupnode_error,m_sync_data_pool.getSyncPoolAllocFailCount(),
            m_recv_backup_ack,m_recv_backup_err_ack,m_recv_chgover_only,m_recv_chgover_only_add,m_recv_chgover_only_del,m_recv_chgover_only_other,
            m_sync_data_pool.getSendRetryCount(),m_recv_peer_insertsyncstate_error,m_recv_peer_msglength_error,
            m_sent_sync_notify,m_sent_sync_notify_add,m_sent_sync_notify_mod,m_sent_sync_notify_del,m_sent_sync_notify_other,
            m_sent_notify_app_error,m_instMgr1_err,m_acked_unsynced_count,m_acked_synced_count,
            m_del_ori_data,m_del_chgover_data,
            m_del_ori_data_fail,m_del_chgover_data_fail);
    
    printf("m_remain_pool_data=%u,m_scan_end_error=%u,m_chgover_notify_delete_count:%u, m_chgover_task_op_none_count:%u, m_chgover_sync_remove_count:%u,\nm_idle_noLocal_delete_count:%u, m_chgover_send_syncReq_common:%u\n", 
        m_remain_pool_data, m_scan_end_error, m_chgover_notify_delete_count, m_chgover_task_op_none_count, m_chgover_sync_remove_count, m_idle_noLocal_delete_count, m_chgover_send_syncReq_common);
    printf("m_insertSync_delete_count:%u, m_removeSync_count:%u, m_syncAck_dataop_delete_count:%u, m_syncAck_notify_delete_count:%u\n", 
        m_insertSync_delete_count, m_removeSync_count, m_syncAck_dataop_delete_count, m_syncAck_notify_delete_count);
    printf("m_dataop_delete_count:%u, m_insert_noexist_count:%u, m_delete_notify_count:%u\n",m_dataop_delete_count,m_insert_noexist_count,m_delete_notify_count);

    printf("m_chgover_timer_count:%u,m_prechg_time:%llu,m_prechg_time:%llu,last time:%llu,m_unsync_data:%u\n",
                    m_chgover_timer_count,m_prechg_time,m_chgover_time,m_chgover_time-m_prechg_time,m_unsync_data);
    printf("m_ack_state_SYNC_count=%u,m_insert_syncState_SYNC_count=%u,m_pre_set_SYNC_count=%u,m_sync_data_SYNC_count=%u,m_send_request_noneOp_SYNC_count=%u,m_send_request_return_SYNC_count=%u\n",
            m_ack_state_SYNC_count,
            m_insert_syncState_SYNC_count,    
            m_pre_set_SYNC_count,
            m_sync_data_SYNC_count,
            m_send_request_noneOp_SYNC_count,
            m_send_request_return_SYNC_count);
    printf("m_init_syncstate_UNSYNC_count=%u,m_insert_syncState_UNSYNC_count=%u,m_insert_chgoverState_UNSYNC_count=%u,m_pre_set_UNSYNC_count=%u\n",
            m_init_syncstate_UNSYNC_count,            
            m_insert_syncState_UNSYNC_count,
            m_insert_chgoverState_UNSYNC_count,
            m_pre_set_UNSYNC_count);
    FirstIndex = max_ordinary_data_num;
    TotalUnsync = getUnSynchronized(FirstIndex);
    printf("Normal_Data_State_Entry:capacity=%u, allocated=%u, Unsynchronized=%u, FirstIndex=%u\n",
            m_data_state.getTotalInstNum(),
            m_data_state.getAllocatedInstNum(),
            TotalUnsync, FirstIndex);
    printf("ChgOver_Data_State_Entry:capacity=%u, allocated=%u\n",
            m_chgover_data_state.getTotalInstNum(),
            m_chgover_data_state.getAllocatedInstNum());
    printf("\n---------------------Data Pool Statistics------------------------\n");    
    m_sync_data_pool.print_stats();
    if(dwType)
        m_chgover_task_mgr.print_stats();
}

/*������Ϣ����������Ԥ�����͵������*/
void CSyncStateMgr::onChgOverMsg(const uint8_t* msg)
{
    T_EV_ZCS_RTE_CHGOVER_EVENT *ptEvent = (T_EV_ZCS_RTE_CHGOVER_EVENT *)msg;

    ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCPS]Recv ChgOver msg, m_state=%u,event=%u,changed_rte_num=%u\n",
            m_state,ptEvent->event_type,ptEvent->rte_num);
    if(ptEvent->event_type ==ZCS_EV_PRE_CHGOVER)
    {
        ZCS_LOG_SIMPLE(LOG_NOTICE,"zcps start chgover and syncdata time:%llu\n", zenic::CHdTimer::getCurTime());
        stateMachine(E_ZCPS_INNER_EVENT_RECV_RTE_CHG);
        onPreChg(ptEvent);
    }
    else if(ptEvent->event_type ==ZCS_EV_CHGOVER_FINISH)
    {
        m_chgover_time = zenic::CHdTimer::getCurTime();
        ZCS_LOG_SIMPLE(LOG_NOTICE,"zcps end chgover and syncdata time:%llu\n", m_chgover_time);
        printf("[ZCPS]Sync Finish[%llu seconds], m_prechg_time:%llu, m_chgover_time:%llu\n",
                    (m_chgover_time-m_prechg_time)/1000000, m_prechg_time,m_chgover_time);
        stateMachine(E_ZCPS_INNER_EVENT_RECV_RTE_CHG_FINISH);
    }
}

/*ͬ��״̬ʵ���ĳ�ʼ��*/
void CSyncStateMgr::initSyncState(uint32_t idx,
        const T_EV_ZCS_APP_SYNC_DATA* tSyncData, bool exist)
{
    T_ZCPS_SYNC_STATE * pState = &m_data_state[idx];
    m_init_syncstate_UNSYNC_count++;
    pState->data_state = E_ZCPS_DATA_SYNC_STATE_UNSYNCHRONIZED;
    if(!exist)
    {
        memcpy(&pState->tResKey,&tSyncData->tSyncHdr.tResKey,sizeof(T_ZCS_RESOURCE_KEY));
        pState->tDataKey = tSyncData->tSyncHdr.tDataKey;
        pState->chgover = E_ZCPS_DATA_CHGOVER_INIT;
        pState->last_op = tSyncData->tSyncHdr.dataop;

        incAppRegInfoUsedNum(tSyncData->tSyncHdr.app_id,tSyncData->tSyncHdr.tDataKey.data_type);
    }
}

/*�յ�ȷ����Ϣ�Ĵ���������ɾ��������ʵ��ɾ����
 * ���������޸Ĳ�����������״̬��Ϊ��ͬ��
 * Ŀǰ��������������Ȼ��Ҫ����*/
void CSyncStateMgr::ackState(uint32_t idx, T_ZCS_DATA_OP dataop)
{
    if(m_data_state.getInstanceState(idx)!=InstMgr::INST_STATE_ALLOCATED)
        return;
    T_ZCPS_SYNC_STATE * pState = &m_data_state[idx];

    T_ZCPS_EVENT_REG_VALUE tRegInfo;
    ZENIC_RESULT ret = CCpEventReg::findRegInfo(pState->tDataKey.app_id,pState->tDataKey.data_type,tRegInfo);
    if(RESULT_ZENIC_SUCCESS == ret)
    {        
        CCpEventReg::inc_ack_stats(tRegInfo.app_id,tRegInfo.data_type);
    }
    else
    {
        return ;
    }

    /*����ɾ�����ݵ���״̬��*/
    if(dataop==ZCS_DATA_OP_DELETE && pState->last_op==dataop)
    {
        //this->removeChgOverState(pState->tDataKey);
        m_syncAck_dataop_delete_count++;
        removeSyncState(idx);
        return;
    }
    else if((pState->chgover_op&CChgOverTask::E_CHGOVER_DATA_OP_BACKUP) && (pState->chgover_op&CChgOverTask::E_CHGOVER_DATA_OP_DELETE))
    {
        pState->chgover_op = CChgOverTask::E_CHGOVER_DATA_OP_DELETE;
        m_syncAck_notify_delete_count++;
        ret = notifyDeleteData(pState, idx, tRegInfo.regJid);
        if(RESULT_ZENIC_SUCCESS == ret)
        {
            CCpEventReg::inc_notify_stats(tRegInfo.app_id,tRegInfo.data_type,ZCS_DATA_OP_DELETE);
        }
        return ;
    }
    if(pState->data_state != E_ZCPS_DATA_SYNC_STATE_SYNCHRONIZED)
    {
        m_acked_unsynced_count++;
    }
    else
    {
        m_acked_synced_count++;
    }
    m_ack_state_SYNC_count++;
    pState->data_state = E_ZCPS_DATA_SYNC_STATE_SYNCHRONIZED;
    pState->chgover_op = CChgOverTask::E_CHGOVER_DATA_OP_NONE;
}

/*����һ��ͬ�������Ӧ�ã�Ҫ���ĳ�����ݽ���ͬ��*/
ZENIC_RESULT CSyncStateMgr::sendSyncRequest(T_ZCPS_SYNC_STATE* ptState,uint32_t idx)
{
    T_EV_ZCS_REQUEST_SYNC_DATA tReq;
    T_ZCPS_EVENT_REG_VALUE tRegInfo;
    ZENIC_RESULT ret;    
    ret = CCpEventReg::findRegInfo(ptState->tDataKey.app_id,ptState->tDataKey.data_type,tRegInfo);
    if(ret!=RESULT_ZENIC_SUCCESS)
    {
        return ret;
    }

    if(ptState->chgover_op==CChgOverTask::E_CHGOVER_DATA_OP_DELETE)
    {
        m_chgover_notify_delete_count++;
        ret = notifyDeleteData(ptState,idx,tRegInfo.regJid);
        if(RESULT_ZENIC_SUCCESS == ret)
        {
            CCpEventReg::inc_notify_stats(tRegInfo.app_id,tRegInfo.data_type,ZCS_DATA_OP_DELETE);
        }
        return ret;
    }
    
    //op=m_chgover_task_mgr.getDataChgOverOp(ptState->tResKey,tNodes);
    if(ptState->chgover_op==CChgOverTask::E_CHGOVER_DATA_OP_NONE)
    {        
        m_chgover_task_op_none_count++;
        m_send_request_noneOp_SYNC_count++;
        ptState->data_state = E_ZCPS_DATA_SYNC_STATE_SYNCHRONIZED;
        return RESULT_ZENIC_SUCCESS;
    }    

    tReq.tKey = ptState->tDataKey;
    memcpy(&tReq.tResourceKey,&ptState->tResKey,sizeof(T_ZCS_RESOURCE_KEY));

    //����Ǳ��ݲ��������������ݱ��ݲ��������屸�ݶ������յ�AppSync��Ĳ�������
    //���һ�����ݱ��ڵ������ýڵ㣬��ȫ�ӽڵ��б���ɾ��������Ҫ����ͬ���������Ժ�ɾ������     
    if((ptState->chgover_op & CChgOverTask::E_CHGOVER_DATA_OP_BACKUP)!=0)
    {
        if((ptState->last_op & 0x7F)!=ZCS_DATA_OP_DELETE || (ptState->chgover_op & CChgOverTask::E_CHGOVER_DATA_OP_DELETE))
        {
            XOS_STATUS res = XOS_SendAsynMsg(EV_SYS_ZCS_REQUEST_SYNC_DATA, 
                                  (uint8_t *)&tReq,sizeof(tReq),0,0,&tRegInfo.regJid);
            m_chgover_task_mgr.incPendingChgOverData();
            if (XOS_SUCCESS == res)
            {
                m_send_sync_request++;
                CCpEventReg::inc_request_stats(tRegInfo.app_id,tRegInfo.data_type);
                uint32_t dwIndex = 0;
                int iRet = m_pull_push_diff.findInstByKey1(tRegInfo.regJid.dwJno, dwIndex);
                if(iRet==InstMgr::RESULT_INST_SUCCESS)
                {
                    m_pull_push_diff[dwIndex]++;
                    m_pull_push_diff.setInstByIndex(dwIndex, m_pull_push_diff[dwIndex]);
                }
                else
                {
                    m_pull_push_diff.allocInstByKey1(tRegInfo.regJid.dwJno,dwIndex);
                    m_pull_push_diff[dwIndex] = 1;
                }
                return RESULT_ZENIC_SUCCESS;
            }
            else
            {
                return ERROR_SEND_MSG_FAIL;
            }
        }
        else  //delete sync
        {
            m_chgover_sync_remove_count++;
            return SyncRemoveData(ptState,idx,ptState->tChgOverNodes);
        }
    }

    m_chgover_send_syncReq_common++;
    m_send_request_return_SYNC_count++;
    ptState->data_state = E_ZCPS_DATA_SYNC_STATE_SYNCHRONIZED;
    return RESULT_ZENIC_SUCCESS;
}


/*�������յ����ݱ��ݵ�������Ҫ:
 * 1�����뱸��״̬
 * 2��֪ͨ�ϲ�Ӧ��*/
void CSyncStateMgr::onDataSync(const uint8_t* msg, uint16_t lenth, JID* ptSender, T_ZCPS_SYNC_ACK& tAckPack)
{
    uint32_t idx;
    ZENIC_RESULT ret;
    T_EV_ZCS_INNNER_DATA_SYNC *ptSync = (T_EV_ZCS_INNNER_DATA_SYNC *)msg;
    //ͳ�Ƹ����������ͽ��յ���Ϣ��
    CCpEventReg::incRecvCounter(ptSync->tSyncHdr.app_id,ptSync->tSyncHdr.tDataKey.data_type);

    if(ptSync->tSyncHdr.app_id == g_dwDbgAppId && ptSync->tSyncHdr.tDataKey.data_type == g_dwDbgDataType)
    {
        printZcpsSyncData(ptSync->tSyncHdr.tDataKey, ptSync->tSyncHdr.tResKey, ptSync->tSyncHdr.dataop, ptSync->tSyncHdr.data_len, 0);  
    }

    /*��������ͬ��״̬�Ϊ��������������ʹ��*/
    bool isExist = false;
    T_DHT_NODES_GROUP tTmpNodes;
    ret = this->insertSyncState(ptSync,tTmpNodes,false,idx,isExist);
    if(RESULT_ZENIC_SUCCESS!=ret)
    {
        m_recv_peer_insertsyncstate_error++;
        ZCS_LOG_SIMPLE(LOG_ERROR,"[ZCPS]rcvDataSync,insertSyncState fail(%d),srcModule=%u,dstAppId=0x%x,DataType=%u,DataSize=%u,DataOp=%u\n",
          ret,ptSender->wModule, ptSync->tSyncHdr.app_id, ptSync->tSyncHdr.tDataKey.data_type, ptSync->tSyncHdr.data_len,ptSync->tSyncHdr.dataop);
        if((ptSync->tSyncHdr.dataop & 0x7F)!=ZCS_DATA_OP_DELETE)
            return ;
    }
    
    /*֪ͨӦ��*/
    m_sent_sync_notify++;
    if (ptSync->tSyncHdr.dataop == ZCS_DATA_OP_ADD)
    {
        m_sent_sync_notify_add++;
    }
    else if (ptSync->tSyncHdr.dataop == ZCS_DATA_OP_MODIFY)
    {
        m_sent_sync_notify_mod++;
    }
    else if (ptSync->tSyncHdr.dataop == ZCS_DATA_OP_DELETE)
    {
        m_sent_sync_notify_del++;
    }
    else
    {
        m_sent_sync_notify_other++;
    }

    ret = CCpEventReg::notifyApp(*ptSync);
    if(RESULT_ZENIC_SUCCESS != ret)
    {
        ZCS_LOG_SIMPLE(LOG_ERROR,"[ZCPS]recv data sync from module=%u, dest_app_id=0x%x, data_type=%u,data_size=%u, data_op=%u,ret=%u\n",
                ptSender->wModule, ptSync->tSyncHdr.app_id, ptSync->tSyncHdr.tDataKey.data_type,
                ptSync->tSyncHdr.data_len,ptSync->tSyncHdr.dataop,ret);
        m_sent_notify_app_error++;
        return ;
    }

    ZCS_LOG_SIMPLE(LOG_DEBUG,"[ZCPS]recv data sync app_id=0x%x, seq=0x%x, data_size=%u, data_op=%u\n",
        ptSync->tSyncHdr.app_id, ptSync->tSyncHdr.seq,
        ptSync->tSyncHdr.data_len,ptSync->tSyncHdr.dataop);
    onPackAckData(ptSync, ptSender, tAckPack);
}

void CSyncStateMgr::onPackAckData(T_EV_ZCS_INNNER_DATA_SYNC *ptSync, JID* pAckRcver, T_ZCPS_SYNC_ACK& tAckPack)
{
    /* �������Ӧ����Ϣ*/
    if(tAckPack.wObjAckCnt >= ZCPS_MAX_SYNC_ACK)
    {
        onFlushAckPack(pAckRcver, tAckPack);
    }
    
    if(tAckPack.wObjAckCnt < ZCPS_MAX_SYNC_ACK)
    {
        uint16_t cnt = tAckPack.wObjAckCnt;
        tAckPack.tObjAck[cnt].seq = ptSync->tSyncHdr.seq;
        tAckPack.tObjAck[cnt].dataop = ptSync->tSyncHdr.dataop;
        tAckPack.tObjAck[cnt].node_id = this->m_node_id;
        tAckPack.wObjAckCnt++;
        return;
    }
}

void CSyncStateMgr::onFlushAckPack(JID* pAckRcver, T_ZCPS_SYNC_ACK& tAckPack)
{
    if(tAckPack.wObjAckCnt)
    {
        uint16_t dwMsgLengh = _OFFSET(T_ZCPS_SYNC_ACK, tObjAck) + tAckPack.wObjAckCnt*sizeof(T_EV_ZCS_INNNER_DATA_SYNC_ACK);
        XOS_STATUS ret = XOS_SendAsynMsg(EV_SYS_ZCS_INNER_DATA_SYNC_ACK, (uint8_t *)&tAckPack, dwMsgLengh, 0, 0, pAckRcver);
        if(ret==XOS_SUCCESS)
        {
            ZCS_LOG_SIMPLE(LOG_DEBUG,"[ZCPS]ack Module[%d] Tsn[%u] contains ItemAckCnt[%d] Length[%d] success", 
                                     pAckRcver->wModule, tAckPack.dwTsn, tAckPack.wObjAckCnt, dwMsgLengh);
            tAckPack.wObjAckCnt = 0;
        }
        else
        {
            ZCS_LOG_SIMPLE(LOG_ERROR,"[ZCPS]ack Module[%d] Tsn[%u] Contain ItemAckCnt[%d] Length[%d] failCode:%d", 
                                     pAckRcver->wModule, tAckPack.dwTsn, tAckPack.wObjAckCnt, dwMsgLengh, ret);
        }
    }
}

void CSyncStateMgr::onPackDataSync(const uint8_t* msg, uint16_t msg_len)
{
    JID tSender;
    XOS_Sender(&tSender);
    
    T_ZCPS_ITEM_HEAD* pPackHead = (T_ZCPS_ITEM_HEAD*)msg;
    if(msg_len<=sizeof(T_ZCPS_ITEM_HEAD) || msg_len!=sizeof(T_ZCPS_ITEM_HEAD)+pPackHead->wObjLen)
    {
        m_recv_peer_msglength_error++;
        return;
    }
    
    T_ZCPS_SYNC_ACK tAckPack;
    //memset(&tAckPack, 0, sizeof(tAckPack); //don't memset for efficiency.
    tAckPack.dwTsn = pPackHead->dwTsn;
    tAckPack.wNodeId = this->m_node_id;;
    tAckPack.wObjAckCnt = 0;

    uint16_t lenth = 0;
    uint16_t TotalLen = 0;
    T_ZCPS_ITEM_OBJ* pObj = pPackHead->tItemData;
    for(uint16_t i=0; i<pPackHead->wObjCnt && TotalLen<pPackHead->wObjLen; i++)
    {
        lenth = pObj->tObjHdr.data_len+sizeof(T_ZCS_APP_SYNC_MSG_HDR);
        onDataSync((uint8_t*)pObj, lenth, &tSender, tAckPack);
        
        TotalLen += lenth;
        pObj = (T_ZCPS_ITEM_OBJ*)((uint8_t*)pPackHead->tItemData + TotalLen);
    }
    onFlushAckPack(&tSender, tAckPack);
}

/*����ͬ��״̬���������������
 * 1������������������״̬��
 * 2�������϶���ɾ������������Ҫɾ��״̬��*/
ZENIC_RESULT CSyncStateMgr::insertSyncState(
        const T_EV_ZCS_APP_SYNC_DATA* tSyncData, const T_DHT_NODES_GROUP tNodes, bool master_copy, uint32_t &index,bool &isExist)
{
    int ret;
    uint32_t idx;
    isExist=false;
    
    /*����Changover Only�����ݲ�����ͬ��״̬������*/
    if((tSyncData->tSyncHdr.dataop & ZCS_DATA_OP_CHGOVER_ONLY)!=0)
    {
        return ERROR_INVALID_PARAM;
    }

    /*���Ȳ���״̬����Ƿ����*/
    zenic::sdn_lock lock(m_sync_state_mutex);
    ret = m_data_state.findInstByKey1(tSyncData->tSyncHdr.tDataKey,idx);
    if(ret==InstMgr::RESULT_INST_SUCCESS)
    {
        index = idx;
        isExist = true;
        if(!master_copy && (tSyncData->tSyncHdr.dataop & 0x7F)==ZCS_DATA_OP_DELETE)
        {
            m_insertSync_delete_count++;
            removeSyncStateNoLock(idx);
            return RESULT_ZENIC_SUCCESS;
        }
    }
    else
    {
        if(master_copy || (tSyncData->tSyncHdr.dataop & 0x7F)!=ZCS_DATA_OP_DELETE)
        {
            ret = m_data_state.allocInstByKey1(tSyncData->tSyncHdr.tDataKey,idx);
        }
    }
    lock.unlock();
    /*������ҡ������ʧ�ܣ��򲻽��в���*/
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        m_instMgr1_err++;
        return ERROR_ALLOC_INSTANCE_FAIL;
    }
    index =idx;
    T_ZCPS_SYNC_STATE * pState = &m_data_state[idx];
    if((false == isExist) //������ �� ������ͬ��
        || ((true == isExist)&&(pState->data_state == E_ZCPS_DATA_SYNC_STATE_SYNCHRONIZED)))
    {
        pState->tChgOverNodes = tNodes;
    }
    
    if(master_copy)
    {
        m_insert_syncState_UNSYNC_count++;
        pState->data_state = E_ZCPS_DATA_SYNC_STATE_UNSYNCHRONIZED;  
        //pState->chgover_op = CChgOverTask::E_CHGOVER_DATA_OP_BACKUP;
    }
    else
    {
        m_insert_syncState_SYNC_count++;
        pState->data_state = E_ZCPS_DATA_SYNC_STATE_SYNCHRONIZED;
        pState->chgover_op = CChgOverTask::E_CHGOVER_DATA_OP_NONE;
    }

    pState->last_op = tSyncData->tSyncHdr.dataop;

    if(!isExist)
    {
        memcpy(&pState->tResKey,&tSyncData->tSyncHdr.tResKey,sizeof(T_ZCS_RESOURCE_KEY));
        pState->tDataKey = tSyncData->tSyncHdr.tDataKey;
        pState->chgover = E_ZCPS_DATA_CHGOVER_INIT;
        m_insert_noexist_count++;
        incAppRegInfoUsedNum(tSyncData->tSyncHdr.app_id,tSyncData->tSyncHdr.tDataKey.data_type);
    }
    return RESULT_ZENIC_SUCCESS;
}


/*ɾ��ͬ��״̬*/
ZENIC_RESULT CSyncStateMgr::removeSyncStateNoLock(uint32_t index)
{
    int ret;
    T_ZCPS_SYNC_STATE pState = m_data_state[index];
    ret = m_data_state.releaseInst(index);
    if(ret==InstMgr::RESULT_INST_SUCCESS)
    {
        m_del_ori_data++;
        
        decAppRegInfoUsedNum(pState.tDataKey.app_id,pState.tDataKey.data_type);
        return RESULT_ZENIC_SUCCESS;
    }
    else
    {
        m_del_ori_data_fail++;
        //m_instMgr1_err++;
        return ERROR_RECORD_NOT_FOUND;
    }
}

/*ɾ��ͬ��״̬*/
ZENIC_RESULT CSyncStateMgr::removeSyncState(uint32_t index)
{
    ZENIC_RESULT ret;
    zenic::sdn_lock lock(m_sync_state_mutex);
    m_removeSync_count++;
    ret = removeSyncStateNoLock(index);
    return ret;
}

/*�ж�ĳ���ڵ��Ƿ���·�ɱ��еı����ڵ�*/
inline bool CSyncStateMgr::isBackupNode(const T_DHT_NODES_GROUP& tNodes, const uint16_t node_id) 
{

    for(uint8_t i=0;i<tNodes.backup_nodes_num;i++)
    {
        if(node_id==tNodes.backup_nodes[i])
            return true;
    }
    return false;
}

/*���������л�״̬��
 * ��������Ҫ������ɾ��*/
ZENIC_RESULT CSyncStateMgr::insertChgoverState(
        const T_EV_ZCS_APP_SYNC_DATA* tSyncData, bool master_copy,
        uint32_t& index)
{
    int ret;
    uint32_t idx;
    zenic::sdn_lock lock(m_chgover_state_mutex);
    bool exist=false;

    /*���Ȳ���״̬����Ƿ����*/
    ret = m_chgover_data_state.findInstByKey1(tSyncData->tSyncHdr.tDataKey,idx);
    if(ret==InstMgr::RESULT_INST_SUCCESS)
    {
        index = idx;

        if((tSyncData->tSyncHdr.dataop & 0x7F)==ZCS_DATA_OP_DELETE)
        {
            removeChgOverStateNoLock(tSyncData->tSyncHdr.tDataKey);
            return RESULT_ZENIC_SUCCESS;
        }
        exist = true;
    }
    else  //��״̬����ڣ�ֻҪ����DELETE��������Ӧ�ò���
    {
        if((tSyncData->tSyncHdr.dataop & 0x7F)!=ZCS_DATA_OP_DELETE)
        {
            ret = m_chgover_data_state.allocInstByKey1(tSyncData->tSyncHdr.tDataKey,idx);
        }
    }

    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        return ERROR_ALLOC_INSTANCE_FAIL;
    }
    lock.unlock();
    index =idx;
    T_ZCPS_SYNC_STATE * pState = &m_chgover_data_state[idx];
    m_insert_chgoverState_UNSYNC_count++;
    pState->data_state = E_ZCPS_DATA_SYNC_STATE_UNSYNCHRONIZED;
    pState->last_op = tSyncData->tSyncHdr.dataop;
    if(!exist)
    {
        memcpy(&pState->tResKey,&tSyncData->tSyncHdr.tResKey,sizeof(T_ZCS_RESOURCE_KEY));
        pState->tDataKey = tSyncData->tSyncHdr.tDataKey;
        pState->chgover = E_ZCPS_DATA_CHGOVER_INIT;

    }

    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CSyncStateMgr::removeChgOverState(const T_ZCS_DATA_KEY& tDataKey)
{
    ZENIC_RESULT ret;
    zenic::sdn_lock lock(m_chgover_state_mutex);
	ret = removeChgOverStateNoLock(tDataKey);
	return ret;
}

ZENIC_RESULT CSyncStateMgr::removeChgOverStateNoLock(const T_ZCS_DATA_KEY& tDataKey)
{
    int ret;

    ret = m_chgover_data_state.releaseInstByKey1(tDataKey);
    if(ret==InstMgr::RESULT_INST_SUCCESS)
    {
        m_del_chgover_data++;
        //m_chgover_task_mgr.tSegList.wSegNum++;
        return RESULT_ZENIC_SUCCESS;
    }
    else
    {
        m_del_chgover_data_fail++;
        return ERROR_RECORD_NOT_FOUND;
    }
}


//��������ɨ�裬ɨ����ɺ󷵻�true,���򷵻�false
bool CSyncStateMgr::onScanChgOverData(uint32_t windowSize)
{
    uint32_t scan_count = 0;
    uint32_t process_count = 0;
    T_ZCPS_SYNC_STATE *ptState;
    if(cur_scan_index2>=max_chgover_data_num)
        cur_scan_index2=0;

    /*ֻ����PRECHG��״̬�½���������ɨ��*/
    if(m_state!=E_ZCPS_CHOVER_SCAN_CHGOVER_DATA)
    {
        return true;
    }
    /*״̬����ʵ��Ϊ�գ��������*/
    if(!m_chgover_task_mgr.hasDataChgOverTask() || m_to_scaned_data2==0)
    {
        return true;
    }

    uint32_t dwScanCntOnce = getMaxCntInOnceScan();
    /*ɨ�����ݣ���Ӧ�÷�������*/
    while(scan_count<dwScanCntOnce && process_count < windowSize)
    {
        if(m_chgover_data_state.getInstanceState(cur_scan_index2)==InstMgr::INST_STATE_ALLOCATED)
        {
            ptState = &m_chgover_data_state[cur_scan_index2];
            this->processChgOverData(ptState);
            m_to_scaned_data2--;
            process_count++;
        }
        scan_count++;
        cur_scan_index2++;

        if(cur_scan_index2>=max_chgover_data_num || m_to_scaned_data2==0)
            return true;//�Ѿ�ɨ�����
    }

    return false;
}

//ϵͳ״̬������
void CSyncStateMgr::stateMachine(E_ZCPS_INNER_EVENT newEvent)
{
    switch(m_state)
    {
        case E_ZCPS_CHOVER_WORK:
        {
            switch(newEvent)
            {
                case E_ZCPS_INNER_EVENT_RECV_RTE_CHG:
                    m_state = E_ZCPS_CHOVER_PRECHG;
                    break;
                default:
                    break;
            }
            break;
        }
        case E_ZCPS_CHOVER_PRECHG:
        {
            switch(newEvent)
            {
                case E_ZCPS_INNER_EVENT_SCAN_FINISH:
                    m_state = E_ZCPS_CHOVER_SCAN_CHGOVER_DATA;
                    zcps_kill_timer(m_sync_over_timer);
                    break;
                case E_ZCPS_INNER_EVENT_SCAN_CHGOVER_DATA_FINISH:
                    m_state = E_ZCPS_CHOVER_POSTCHG;
                    this->onChgOverFinish(ZCS_EV_PRE_CHGOVER);
                    break;
                case E_ZCPS_INNER_EVENT_RECV_RTE_CHG_FINISH:
                    this->onChgOverFinish(ZCS_EV_CHGOVER_FINISH);
                    m_state = E_ZCPS_CHOVER_WORK;
                    break;
                default:
                    break;
            }
            break;
        }
        case E_ZCPS_CHOVER_SCAN_CHGOVER_DATA:
        {
            switch(newEvent)
            {
                 case E_ZCPS_INNER_EVENT_SCAN_FINISH:
                     m_state = E_ZCPS_CHOVER_SCAN_CHGOVER_DATA;
                     break;
                 case E_ZCPS_INNER_EVENT_SCAN_CHGOVER_DATA_FINISH:
                    // ��Ҫ����ȷ����Ϣ
                     this->onChgOverFinish(ZCS_EV_PRE_CHGOVER);
                     m_state = E_ZCPS_CHOVER_POSTCHG;
                     break;
                 case E_ZCPS_INNER_EVENT_RECV_RTE_CHG_FINISH:
                     m_state = E_ZCPS_CHOVER_WORK;
                     this->onChgOverFinish(ZCS_EV_CHGOVER_FINISH);
                     break;
                 default:
                     break;
             }
             break;
        }
        case E_ZCPS_CHOVER_POSTCHG:
        {
            switch(newEvent)
             {
             case E_ZCPS_INNER_EVENT_RECV_RTE_CHG_FINISH:
                 this->onChgOverFinish(ZCS_EV_CHGOVER_FINISH);
                 m_state = E_ZCPS_CHOVER_WORK;
                 break;
             default:
                 break;
             }
            break;
        }
    }
}

/*�����������ݣ�֪ͨ�ϲ�Ӧ��*/
void CSyncStateMgr::processChgOverData(const T_ZCPS_SYNC_STATE* ptState)
{
    //T_ZCS_CHGOVER_RTE_ITEM tItem;
    T_ZCS_CHGOVER_DATA_ITEM tDataItem;
    T_ZCPS_EVENT_REG_VALUE *pRegInfo;
    T_ZCS_DATA_STATE oldState,newState;
    T_ZCS_CHGOVER_RTE_ITEM chgoverItem;
    ZENIC_RESULT ret = RESULT_ZENIC_SUCCESS;
    bool found;

     //m_chgover_task_mgr.needDataChgOver(ptState->tResKey);

    found = m_chgover_task_mgr.needDataChgOver(ptState->tResKey,oldState,newState);
    if(!found)
    {
        return ;
    }
    ret = m_chgover_task_mgr.findChgOverItem(ptState->tResKey,chgoverItem);
    tDataItem.tDataKey = ptState->tDataKey;
    tDataItem.curState = oldState;
    tDataItem.newState = newState;
    //����޸��˽ṹ���ܻ�������
    if (RESULT_ZENIC_SUCCESS == ret)
    {
        tDataItem.old_master = chgoverItem.old_master;
        tDataItem.new_master = chgoverItem.new_master;
        tDataItem.old_backup_node_num = chgoverItem.old_backup_node_num;
        tDataItem.new_backup_node_num = chgoverItem.new_backup_node_num;
        memcpy(tDataItem.old_backup_node, chgoverItem.old_backup_node,
            sizeof(tDataItem.old_backup_node[0])*ZCS_MAX_BACKUP_NODE_NUM);
        memcpy(tDataItem.new_backup_node, chgoverItem.new_backup_node,
            sizeof(tDataItem.new_backup_node[0])*ZCS_MAX_BACKUP_NODE_NUM);
    }
    else
    {
        ZCS_LOG_SIMPLE(LOG_ERROR,"[ZCPS]findChgOverItem failed,tDataItem.old_master=%d,tDataItem.new_master=%d.\n",tDataItem.old_master,tDataItem.new_master);
    }
    pRegInfo = CCpEventReg::findRegInfo(ptState->tDataKey.app_id,ptState->tDataKey.data_type);
    if(NULL!=pRegInfo)
    {
        ZCS_LOG_SIMPLE(LOG_NOTICE,"CSyncStateMgr::processChgOverData() oldState=%d,newState=%d.\n",oldState,newState);
        zcps_send_msg(EV_SYS_ZCS_DATA_CHGOVER_NOTIFY,(uint8_t *)&tDataItem,sizeof(tDataItem),
            m_node_id,pRegInfo->regJid);
        //���newStateΪZCS_DATA_STATE_DELETE,��ɾ��ʧ�����еļ�¼����Ϊ����·�ɱ�������ɣ����յ�device_mgr��ɾ����Ϣ����ʱ�޷�ɾ����
        if (newState == ZCS_DATA_STATE_DELETE)
        {
            if( m_chgover_task_mgr.tSegList.wSegNum < ZCS_MAX_RTE_ENTRY )
            {
                m_chgover_task_mgr.tSegList.aSegIdx[m_chgover_task_mgr.tSegList.wSegNum] = chgoverItem.start_seg*DHT_MAX_RTE_ENTRY/65536;			
                m_chgover_task_mgr.tSegList.wSegNum++;
            }
            removeChgOverState(ptState->tDataKey);
        }
    }
}

/*�������ݲ��������ǵ�ǰ��������״̬
 * �������ͨ����̬����ֱ����·�ɱ����ҽ��Ϊ׼
 * ������ҵ��������ж������Ƿ���Ҫ���µ�·�ɱ����б���*/
void CSyncStateMgr::syncData(const T_EV_ZCS_APP_SYNC_DATA* tSyncData,
        T_DHT_NODES_GROUP& tOrigNodes)
{
    uint32_t idx;
    ZENIC_RESULT ret;
    CChgOverTask::E_CHGOVER_DATA_OP dataop;
    bool isChgOverData = false;
    T_DHT_NODES_GROUP tTmpNodes,tBackupNodes=tOrigNodes;
    bool isExist = false;
    ret=this->insertSyncState((const T_ZCPS_MSG *)tSyncData,tOrigNodes,true,idx,isExist);
    if(ret!=RESULT_ZENIC_SUCCESS)
    {
        m_recv_app_sync_error++;
        m_recv_sync_insertsyncstate_error++;
        ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCPS]Error Recording Data State,ret=%d, app_id=0x%x\n",
                ret,tSyncData->tSyncHdr.app_id);
        idx = ZCPS_INVALID_DATA_INDEX;
        return ;
    }

    /*������״̬����Ҫ�����Ƿ���ڵ�������������ڣ����Ե��������е�����Ϊ׼*/
    if(m_state!= E_ZCPS_CHOVER_WORK)
    {
        dataop=m_chgover_task_mgr.getDataChgOverOp(tSyncData->tSyncHdr.tResKey,tTmpNodes);
        if((dataop & CChgOverTask::E_CHGOVER_DATA_OP_BACKUP) !=0)
        {
            tBackupNodes = tTmpNodes;
            isChgOverData = true;
            m_chgover_task_mgr.decPendingChgOverData();
            
            JID tSender;
            XOS_Sender(&tSender);
            uint32_t dwIndex;
            int iRet = m_pull_push_diff.findInstByKey1(tSender.dwJno, dwIndex);
            if(iRet==InstMgr::RESULT_INST_SUCCESS)
            {
                if (m_pull_push_diff[dwIndex]>0)
                    m_pull_push_diff[dwIndex]--;
                m_pull_push_diff.setInstByIndex(dwIndex, m_pull_push_diff[dwIndex]);
            }
        }
    }
    //�����Ƿ����ʵ��״̬�������ɹ�����ִ��ͬ������Ҫ���Ǳ��ݽڵ㲻���ڵ����
    T_ZCPS_SYNC_STATE * pState = &m_data_state[idx];
    if(tBackupNodes.backup_nodes_num==0)
    {
        m_recv_app_sync_error++;
        m_recv_sync_nobackupnode_error++;
        /*ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCPS]recv app sync, but backup node does not existed, jno=0x%x, data_type=%u,data_len=%u\n",
                tSyncData->tSyncHdr.app_id,tSyncData->tSyncHdr.tDataKey.data_type,
                tSyncData->tSyncHdr.data_len);*/
        m_sync_data_SYNC_count++;
        pState->data_state = E_ZCPS_DATA_SYNC_STATE_SYNCHRONIZED;
        if ((tSyncData->tSyncHdr.dataop & 0x7F)==ZCS_DATA_OP_DELETE && idx != ZCPS_INVALID_DATA_INDEX)
        {
            m_dataop_delete_count++;    
            removeSyncState(idx);
        }        
        return ;
    }
    /*��������ͬ������*/
    if((m_state==E_ZCPS_CHOVER_WORK || m_state==E_ZCPS_CHOVER_POSTCHG) && isExist)
    {   
        tBackupNodes = pState->tChgOverNodes;
    }
    for(uint16_t i=0;i<tBackupNodes.backup_nodes_num;i++)
    {
        m_sync_data_pool.syncData(*(T_ZCPS_MSG *)tSyncData,tBackupNodes.backup_nodes[i],idx,isChgOverData);
    }
}

void CSyncStateMgr::setTimer()
{
    m_scan_timer = XOS_SetLoopTimer(EV_SYS_ZCPS_SCAN_TIMER,ZCPS_DEFALT_SCAN_TIMER,1);
    m_sync_timer = XOS_SetLoopTimer(EV_SYS_ZCPS_SYNC_TIMER,ZCPS_DEFALT_SYNC_TIMER,1);
}

/*IDLE״̬�µ�����ɨ�裬ͬ��ʧ�������ݣ����������󱾻���Ӧ�ø��������*/
void CSyncStateMgr::idleStateScan(uint32_t windowSize)
{
    T_ZCPS_SYNC_STATE *ptState;

    if(m_state!=E_ZCPS_CHOVER_WORK) //����ֻ����IDLE״̬ɨ��
        return ;
    uint32_t dwWinCnt;
    uint32_t dwRndCnt;
    uint32_t dwScanCntOnce = getMaxCntInOnceScan();
    for(dwWinCnt=0,dwRndCnt=0; dwWinCnt<windowSize && dwRndCnt < dwScanCntOnce; dwRndCnt++)
    {
        cur_idle_scan_index %=max_ordinary_data_num;
        if(m_data_state.getInstanceState(cur_idle_scan_index)==InstMgr::INST_STATE_ALLOCATED)
        {
            ptState = &m_data_state[cur_idle_scan_index];
            SyncDataByState(ptState,cur_idle_scan_index);
            dwWinCnt++;
        }

        cur_idle_scan_index++;
    }
}

uint32_t CSyncStateMgr::getUnSynchronized(uint32_t &firstUnsyncIndex)
{
    uint32_t total = 0;
    bool found=false;
    for(uint32_t i = 0; i < m_data_state.getTotalInstNum(); i++)
    {
        if(m_data_state.getInstanceState(i)==InstMgr::INST_STATE_ALLOCATED)
        {
            if(m_data_state[i].data_state != E_ZCPS_DATA_SYNC_STATE_SYNCHRONIZED)
            {
                if(!found)
                {
                    firstUnsyncIndex=i;
                    found=true;
                }
                total++;
            }
        }        
    }
    return total;
}

void CSyncStateMgr::showZcpsUnSyncDetail(uint16_t start, uint16_t total)
{
    if(start > m_data_state.getAllocatedInstNum())
    {
        ZCS_LOG_SIMPLE(LOG_NOTICE, "%s", "print 0 unsync data!\n");
        return ;
    }
    T_ZCPS_SYNC_STATE *ptState;
    uint16_t idx = 0;
    uint16_t num = 0;
    for(uint32_t i = 0; i < m_data_state.getTotalInstNum(); i++)
    {
        if(m_data_state.getInstanceState(i)==InstMgr::INST_STATE_ALLOCATED)
        {
            ptState = &m_data_state[i];
            if(ptState->data_state != E_ZCPS_DATA_SYNC_STATE_SYNCHRONIZED)
            {
                idx++;                
                if(idx > start)
                {
                    num++;                    
                    printZcpsSyncData(ptState->tDataKey,ptState->tResKey,ptState->last_op, 0, 2);
                    if(num == total)
                    {
                        ZCS_LOG_SIMPLE(LOG_NOTICE, "print %d unsync data!\n", num);
                        return ;
                    }
                }
            }
        }
    }
    ZCS_LOG_SIMPLE(LOG_NOTICE, "print %d unsync data!\n", num);
}

//Idle״̬������ɨ�裬ֻɨ��״̬δͬ��������
void CSyncStateMgr::SyncDataByState(T_ZCPS_SYNC_STATE* ptState,uint32_t index)
{
    T_EV_ZCS_REQUEST_SYNC_DATA tReq;
    T_ZCPS_EVENT_REG_VALUE tRegInfo;
    T_DHT_NODES_GROUP tNodes = ptState->tChgOverNodes;
    ZENIC_RESULT ret;
    //����δͬ�������ݲ���Ҫ����
    if(ptState->data_state!=E_ZCPS_DATA_SYNC_STATE_UNSYNCHRONIZED)
    {
        return ;
    }

    ret = CCpEventReg::findRegInfo(ptState->tDataKey.app_id,ptState->tDataKey.data_type,tRegInfo);
    if(ret!=RESULT_ZENIC_SUCCESS)
    {
        ZCS_LOG_SIMPLE(LOG_ERROR,"CSyncStateMgr::SyncDataByState() appid=%u,data_type=%u.\n",ptState->tDataKey.app_id,ptState->tDataKey.data_type);
        return ;
    }

    if(ptState->chgover_op==CChgOverTask::E_CHGOVER_DATA_OP_DELETE)
    {
        m_chgover_notify_delete_count++;
        ret = notifyDeleteData(ptState,index,tRegInfo.regJid);
        if(RESULT_ZENIC_SUCCESS == ret)
        {
           m_idle_noLocal_delete_count++;
           CCpEventReg::inc_notify_stats(tRegInfo.app_id,tRegInfo.data_type,ZCS_DATA_OP_DELETE);
        }
        return ;
    }

    //����Ǳ��ݲ��������������ݱ��ݲ��������屸�ݶ������յ�AppSync��Ĳ�������
    if((ptState->last_op & 0x7F)!=ZCS_DATA_OP_DELETE)
    {
        //todo ��Ӧ����������
        tReq.tKey = ptState->tDataKey;
        memcpy(&tReq.tResourceKey,&ptState->tResKey,sizeof(T_ZCS_RESOURCE_KEY));
        XOS_SendAsynMsg(EV_SYS_ZCS_REQUEST_SYNC_DATA, (uint8_t *)&tReq,sizeof(tReq),0,0,&tRegInfo.regJid);
        m_send_sync_request++;//idleScan,���������?        
        CCpEventReg::inc_request_stats(tRegInfo.app_id,tRegInfo.data_type);
        return ;
    }
    else
    {
        //ɾ������
        SyncRemoveData(ptState,index,tNodes);
    }
}

/*֪ͨӦ��ɾ��һ������*/
ZENIC_RESULT CSyncStateMgr::notifyDeleteData(const T_ZCPS_SYNC_STATE* ptState, uint32_t index,JID &tJid)
{
    XOS_STATUS ret;
    T_EV_ZCS_SYNC_DATA_NOTIFY tNotify;
    tNotify.data_len = 0;
    tNotify.tDataKey = ptState->tDataKey;
    tNotify.tResKey = ptState->tResKey;
    tNotify.dataop = ZCS_DATA_OP_DELETE;
    ret = XOS_SendAsynMsg(EV_SYS_ZCS_NOTIFY_SYNC_DATA,(uint8_t *)&tNotify,sizeof(tNotify),
            0,0,&tJid);
    if(XOS_SUCCESS != ret)
    {
        return ERROR_SEND_MSG_FAIL;
    }
    m_delete_notify_count++;
    removeSyncState(index);
    return RESULT_ZENIC_SUCCESS;    
}

/*����ɾ������*/
ZENIC_RESULT CSyncStateMgr::SyncRemoveData(const T_ZCPS_SYNC_STATE* ptState,
                                   uint32_t index, const T_DHT_NODES_GROUP& tNodes)
{

    T_ZCPS_MSG tMsg;
    ZENIC_RESULT ret;
    
    if((ptState->last_op & 0x7F)!=ZCS_DATA_OP_DELETE)
        return ERROR_INVALID_PARAM;
    tMsg.tSyncHdr.app_id = ptState->tDataKey.app_id;
    tMsg.tSyncHdr.tDataKey = ptState->tDataKey;
    tMsg.tSyncHdr.tResKey = ptState->tResKey;
    tMsg.tSyncHdr.data_len = 0;
    tMsg.tSyncHdr.dataop = ptState->last_op;
    tMsg.tSyncHdr.remote_put = 0;
    for(uint16_t i=0;i<tNodes.backup_nodes_num;i++)
    {
        ret = m_sync_data_pool.syncData(tMsg,tNodes.backup_nodes[i],index,false);
        if(RESULT_ZENIC_SUCCESS != ret)
        {
            return ret;
        }
    }
    return RESULT_ZENIC_SUCCESS;
}

//���ͳ��ֵ
void CSyncStateMgr::cleanStatisticsData()
{
	m_send_sync_request=0;
	m_recv_app_sync=0;
	m_recv_app_sync_add=0;
	m_recv_app_sync_mod=0;
	m_recv_app_sync_del=0;
	m_recv_app_sync_other=0;
	
	m_recv_app_sync_error=0;
	m_recv_sync_insertsyncstate_error=0;
	m_recv_sync_nobackupnode_error=0;
	m_recv_sync_lookup_error=0;
	m_recv_sync_findRegInfo_error=0;
	m_recv_sync_notmasternode_error=0;
	m_sync_data_pool.resetSyncPoolAllocFailCount();

	m_recv_peer_insertsyncstate_error=0;
		
	m_sent_sync_notify=0;
	m_sent_sync_notify_add=0;
	m_sent_sync_notify_mod=0;
	m_sent_sync_notify_del=0;
	m_sent_sync_notify_other=0;
	
	m_recv_backup_ack=0;
	m_recv_chgover_only=0;
	m_recv_chgover_only_add=0;
	m_recv_chgover_only_del=0;
	m_recv_chgover_only_other=0;
	m_sent_notify_app_error=0;
	
	
	m_del_chgover_data=0;
	m_del_ori_data=0;
	m_del_chgover_data_fail=0;
	m_del_ori_data_fail=0;

	m_sync_data_pool.resetSendRetryCount();

    m_data_state.getStats().init();  
    m_chgover_data_state.getStats().init();  
    m_sync_data_pool.cleanDataPoolStats();    
}

//��ӡ����job��������ͬ�����ݵ�״̬
void CSyncStateMgr::printPullPushDataState()
{
	uint32_t dwIndex=0;
	uint32_t dwJnoSta=0;
	while (1)
	{
		if(m_pull_push_diff.getInstanceState(dwIndex)==InstMgr::INST_STATE_ALLOCATED)
        {            
			dwJnoSta = m_pull_push_diff.getKey1(dwIndex);
			printf("Jno:%x  %u.\n",dwJnoSta,m_pull_push_diff[dwIndex]);
        }
        if(++dwIndex>=ZCPS_MAX_JOB_NUM)
        {
            return;//�Ѿ�ɨ�����
        }
	}
}

void CSyncStateMgr::showInstMgrStats()
{
    printf("m_data_state stats:\n");
    m_data_state.showStats();    
    printf("\nm_chgover_data_state stats:\n");
    m_chgover_data_state.showStats();    
    printf("\n");
    m_sync_data_pool.showInstMgrStats();
}

//��λ����job��������ͬ�����ݵ�״̬
void CSyncStateMgr::clearPullPushDataState()
{
	uint32_t dwIndex=0;
    while (m_pull_push_diff.getAllocatedInstNum()>0)
	{
		if(m_pull_push_diff.getInstanceState(dwIndex)==InstMgr::INST_STATE_ALLOCATED)
        {            
			m_pull_push_diff[dwIndex]=0;
        }
        if(++dwIndex>=ZCPS_MAX_JOB_NUM)
        {
            return;//�Ѿ�ɨ�����
        }
	}
}

/*ɱ����ʱ��������������ʱ����Ϊ��Чֵ*/
void CSyncStateMgr::zcps_kill_timer(uint32_t &timer_id)
{
    if(INVALID_TIMER_ID!=timer_id)
    {
        XOS_KillTimerByTimerId(timer_id);
        timer_id = INVALID_TIMER_ID;
    }
}

void CSyncStateMgr::incAppRegInfoUsedNum(uint16_t app_id,uint16_t data_type)
{
    T_ZCPS_EVENT_REG_VALUE *ptRegInfo;
    ptRegInfo = CCpEventReg::findRegInfo(app_id,data_type);
    if(ptRegInfo!=NULL)
    {
        ptRegInfo->used_record_num++;
    }
}

void CSyncStateMgr::decAppRegInfoUsedNum(uint16_t app_id,uint16_t data_type)
{
    T_ZCPS_EVENT_REG_VALUE *ptRegInfo;
    ptRegInfo = CCpEventReg::findRegInfo(app_id,data_type);
    if(ptRegInfo!=NULL)
    {
        ptRegInfo->used_record_num--;
    }
}

CSyncStateMgr::~CSyncStateMgr()
{
    // TODO Auto-generated destructor stub
}

/*������Ϣ����NodeId����ת������*/
ZENIC_RESULT zcps_send_msg(uint32_t msg_id,const uint8_t *msg,uint16_t len, uint16_t node_id, JID &tJid)
{
    XOS_STATUS ret;
    switch(node_id)
    {
    case 1:
        tJid.ucRouteType = ZCS_LEFT_BOARD;
        tJid.wModule = 1;
        break;
    case 256:
        tJid.ucRouteType = ZCS_RIGHT_BOARD;
        tJid.wModule = 1;
        break;
    default:
        tJid.wModule = node_id;
        tJid.ucRouteType = ZCS_MASTER_BOARD;
        break;
    }

    ret = XOS_SendAsynMsg(msg_id,(uint8_t *)msg,len,0,0,&tJid);
    if(ret!=XOS_SUCCESS)
    {
        ZCS_LOG_SIMPLE(LOG_ERROR,"[ZCPS]Send Msg Error(%u),msg_id=%u,msg_len=%u,dst_module=%u,Jno=0x%x\n",
                ret,msg_id,len,tJid.wModule,tJid.dwJno);
        return ERROR_SEND_MSG_FAIL;
    }
    return RESULT_ZENIC_SUCCESS;
}

