/*
 * CZcrsEventReg.cpp
 *  ·���¼����Ĵ�����
 *  Created on: 2014-9-5
 *      Author: wangjun
 */

#include "CZcrsEventReg.h"
#include <stdio.h>
#include "zcs_common.h"

InstMgr::CInstMgr1<uint32_t,T_ZCRS_EVENT_REG_ITEM> CZcrsEventReg::m_event_reg;
uint32_t CZcrsEventReg::m_needAckCount;
uint32_t CZcrsEventReg::m_recved_ack;
bool CZcrsEventReg::m_bNeedAck;

CZcrsEventReg::CZcrsEventReg() {
    // TODO Auto-generated constructor stub

}

void CZcrsEventReg::init()
{
    int ret;

    m_needAckCount = 0;

    ret = m_event_reg.init(ZCRS_MAX_APP_SUPPORT);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        printf("[ZCRS]Init Event registry failed,ret=%d\n",ret);
    }
    else
        reset();
}

/*�¼����Ĵ���*/
void CZcrsEventReg::onRegEvent(uint8_t* msg, uint16_t len)
{
    JID tJid;
    int ret;
    uint32_t idx;
    bool needAck;

    needAck = (len>=sizeof(bool)?*((bool *)msg):false);
    XOS_Sender(&tJid);

    ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCRS]recv app register message, JNO=0x%x,needAck=%s\n",
            tJid.dwJno,needAck?"true":"false");

    ret = m_event_reg.allocInstByKey1(tJid.dwJno,idx);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCRS]App register failed, JNO=0x%x,needAck=%s,ret=%d\n",
                tJid.dwJno,needAck?"true":"false",ret);
        return ;
    }

    m_event_reg[idx].tJid = tJid;
    m_event_reg[idx].needAck = needAck;
    m_event_reg[idx].ackState = false;
    if(needAck)
        m_needAckCount++;


}

/*������Ӧ�÷���֪ͨ��Ϣ�����ȴ�ȷ��
 * needAck��ʾ����Ϣ�Ƿ�Ҫ�ȴ�ȷ��*/
bool CZcrsEventReg::notifyMessage(uint32_t msg_id,uint8_t* msg, uint16_t msg_len,bool needAck)
{
    uint32_t reg_app = 0;
    if(needAck) reset();
    for(uint32_t i=0;i<m_event_reg.getTotalInstNum();i++)
    {
        if(m_event_reg.getInstanceState(i)==InstMgr::INST_STATE_ALLOCATED)
        {
            ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCRS]Notify App routing Changed,Jno=0x%x,msg_id=%u,msg_len=%u\n",
                    m_event_reg[i].tJid.dwJno,msg_id,msg_len);
            XOS_SendUrgentAsynMsg(msg_id,msg, msg_len, 0, &m_event_reg[i].tJid);
            if(++reg_app>=m_event_reg.getAllocatedInstNum())
                break;
        }
    }

    /*ע��ʱ�Ѿ�ͳ����Ҫȷ�ϵ�Ӧ�����������������=0, �����ֱ�ӽ�����һ����������
     * ������Ҫ�ȴ���������ȷ����Ϣ*/
    if(m_needAckCount==0)
    {
        m_bNeedAck = false;
        return true;
    }
    else
    {
        m_bNeedAck = needAck;
        return !needAck;
    }
}

/*����Ӧ�õ�ȷ����Ϣ�������ж��Ƿ��Ѿ���������Ӧ����Ϣ*/
bool CZcrsEventReg::onRecvAck(const uint8_t* msg, uint16_t len)
{
    JID tJid;
    int ret;
    uint32_t idx;

    T_EV_ZCS_RTE_CHG_OVER_ACK *ptAck = (T_EV_ZCS_RTE_CHG_OVER_ACK *)msg;
    XOS_Sender(&tJid);

    ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCRS]Recv App ChgOver Ack Msg,Jno=0x%x,Event=%u,bNeedAck=%s\n",
                tJid.dwJno,ptAck->event_type,m_bNeedAck?"true":"false");

    if(!m_bNeedAck || m_recved_ack>=m_needAckCount)
        return true;



    ret = m_event_reg.findInstByKey1(tJid.dwJno,idx);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
        return false;

    if(m_event_reg[idx].needAck && m_event_reg[idx].ackState==false)
    {
        m_event_reg[idx].ackState = true;
        m_recved_ack++;
        if(m_recved_ack>=m_needAckCount)
        {
            return true;
        }
    }

    return false;

}

/*״̬��0*/
void CZcrsEventReg::reset()
{
    m_recved_ack = 0;
    m_bNeedAck = false;
    for(uint32_t i=0;i<m_event_reg.getTotalInstNum();i++)
    {
        m_event_reg[i].ackState = false;
    }
}

/*ͳ�Ƶ�����Ϣ*/
void CZcrsEventReg::print_stats()
{
    uint32_t num = m_event_reg.getAllocatedInstNum();
    uint32_t count=0;
    for(uint32_t i=0;i<m_event_reg.getTotalInstNum();i++)
    {
        if(m_event_reg.getInstanceState(i)==InstMgr::INST_STATE_ALLOCATED)
        {
            printf("seq=%u,Jno=0x%x,needAck=%s,AckState=%s\n",
                    ++count,
                    m_event_reg[i].tJid.dwJno,m_event_reg[i].needAck?"true":"false",
                    m_event_reg[i].ackState?"true":"false");
            if(count>=num)
                break;
        }

    }
}

CZcrsEventReg::~CZcrsEventReg() {
    // TODO Auto-generated destructor stub
}

