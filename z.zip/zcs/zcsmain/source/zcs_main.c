/*********************************************************************
* ��Ȩ���� (C)2007, ����������ͨѶ�ɷ����޹�˾��
*
* �ļ����ƣ� xos_admMain.c
* �ļ���ʶ�� 
* ����˵���� ��������������
* ��ǰ�汾�� V1.0
* ��    �ߣ� 
* ������ڣ� 
*
* �޸ļ�¼1��
*    �޸����ڣ�2008��01��25��
*    �� �� �ţ�V1.0
*    �� �� �ˣ�
*    �޸����ݣ�����
**********************************************************************/
#include "tulip.h"
#include "tulip_oss.h"
#include "zcs_job_def.h"
#include "zcs_test.h"


/**************************************************************************
*                            ����                                        *
**************************************************************************/


/**************************************************************************
*                            ��                                          *
**************************************************************************/

/**************************************************************************
*                          ��������                                       *
**************************************************************************/

/**************************************************************************
*                           ȫ�ֱ���                                      *
**************************************************************************/

/**************************************************************************
*                           ���ر���                                      *
**************************************************************************/

/**************************************************************************
*                           �ֲ�����ԭ��                                  *
**************************************************************************/
/* ʹ���ļ�ģ�鹦�� */
#define TULIP_FILE_MODULE_ENABLE
/* ʹ���ڴ�ģ�鹦�� */
#define TULIP_MEM_MODULE_ENABLE
/* �û������������С Ϊ4K�ı���,���64K */
#define TULIP_MEM_USER_SBLOCK_SIZE     4096
/* �û���ʼ������������� */
#define TULIP_MEM_USER_SBLOCK_NUM      400
/* ʹ�ܷ��ű�ģ�鹦�� */
#define TULIP_SYMTAB_MODULE_ENABLE
/* ʹ���ض���ģ�鹦�� */
#define TULIP_IORDR_MODULE_ENABLE
/* ʹ�ܶ�ʱ��ģ�鹦�� */
#define TULIP_TIMER_MODULE_ENABLE
/* ʹ�ܵ���ͨ��ģ�鹦�� */
#define TULIP_SCHE_COMM_MODULE_ENABLE
/* ʹ��SysLogģ�鹦�� */
#define TULIP_SYSLOG_MODULE_ENABLE
/* ʹ��Udpͨ�Ź��� */
#define TULIP_UDP_COMM_MODULE_ENABLE
/* ʹ��UShellģ�鹦�� */
#define TULIP_USHELL_MODULE_ENABLE
/* ʹ�ܶ��ķ����� */
#define TULIP_SUBSCR_MODULE_ENABLE



/* ������ */
#define TEST1_FUNBITS      JOB_NEED_PRE_CHGOVER|JOB_NEED_PRE_CHGOVER_ACK|JOB_NEED_S2M_CHGOVER|JOB_NEED_S2M_CHGOVER_ACK| \
                          JOB_NEED_M2S_CHGOVER|JOB_NEED_M2S_CHGOVER_ACK|JOB_NEED_S2M_FINISH | JOB_NEED_M2S_FINISH | \
                          JOB_NEED_POWERON_ACK | JOB_NEED_POWEROFF_ACK | JOB_NEED_PRE_STARTUP | JOB_NEED_PRE_STARTUP_ACK

#define TEST2_FUNBITS      JOB_NEED_PRE_CHGOVER|JOB_NEED_PRE_CHGOVER_ACK|JOB_NEED_S2M_CHGOVER|JOB_NEED_S2M_CHGOVER_ACK| \
                          JOB_NEED_M2S_CHGOVER|JOB_NEED_M2S_CHGOVER_ACK| \
                          JOB_NEED_POWEROFF_ACK | JOB_NEED_PRE_STARTUP | JOB_NEED_PRE_STARTUP_ACK
                          
#define ZCS_BASIC         JOB_NEED_S2M_CHGOVER|JOB_NEED_M2S_CHGOVER|JOB_NEED_M2S_FINISH|JOB_NEED_S2M_FINISH

#define ZCMS_FUN          ZCS_BASIC|JOB_NEED_PRE_CHGOVER|JOB_NEED_PRE_CHGOVER_ACK|JOB_NEED_POWERON_ACK|JOB_NEED_POWERON_FINISH| \
	                      JOB_NEED_S2M_CHGOVER_ACK|JOB_NEED_M2S_CHGOVER_ACK
                          
#define ZCRS_FUN          ZCS_BASIC|JOB_NEED_POWERON_ACK
#define ZCPS_FUN          ZCS_BASIC

extern void zcms_entry(WORD16 wState, WORD32 dwMsgId, void *pMsgBody, void *pPData, BOOLEAN bSame);
extern void zcrs_entry(WORD16 wState, WORD32 dwMsgId, void *pMsgBody, void *pPData, BOOLEAN bSame);
extern void zcps_entry(WORD16 wState, WORD32 dwMsgId, void *pMsgBody, void *pPData, BOOLEAN bSame);
extern void zcps_recv_entry(WORD16 wState, WORD32 dwMsgId, void *pMsgBody, void *pPData, BOOLEAN bSame);
extern SWORD32 ZCSInitLogSema(VOID);
extern BOOLEAN ZCSLogMemMalloc(void);

T_ossJobCreatReg g_atJobRegTbl[] = 
{
/*   wJobType           wPri  wSchIndex  wInstance acName   PEntry            StckSize DataSize   JobMinInst   JobMaxInst     dwFlags */

    {ZCS_JOB_TYPE_ZCMS,     19,  1,         1,   "ZCMS",     &zcms_entry,     1024*1024, 4096,       1,           1,           ZCMS_FUN},
    {ZCS_JOB_TYPE_ZCRS,     18,  2,         1,   "ZCRS",     &zcrs_entry,     1024*1024, 4096,       1,           1,           ZCRS_FUN},
    {ZCS_JOB_TYPE_ZCPS,     17,  3,         1,   "ZCPS",     &zcps_entry,     1024*1024, 4096,       1,           1,           ZCPS_FUN},
    {ZCS_JOB_TYPE_ZCPS_RECV,17,  4,         1,   "ZCPS_RECV",&zcps_recv_entry,1024*1024, 4096,       1,           1,           ZCPS_FUN},

#ifdef ZCS_TEST
    {ZCS_JOB_TYPE_TEST,     0,   10,        1,   "ZCS_TEST", &zcs_test_entry, 1024*1024, 4096,       1,           1,           ZCS_BASIC}
#endif
};

WORD32 g_dwNumOfAppJob = sizeof(g_atJobRegTbl) / sizeof (T_ossJobCreatReg);

WORD32 AppMainInit(VOID);

/*Ӧ�ó�ʼ�����Ӻ���ԭ��*/
typedef WORD32 (*APPINITFUNCPTR)(VOID);

APPINITFUNCPTR   g_pAppMainInit = AppMainInit; 
/**************************************************************************
*                     ȫ�ֺ���ʵ��                                      *
**************************************************************************/
#include "tulip_zcs_main.c"

WORD32 AppMainInit(VOID)
{
    printf("#~~~#-------------ZCS: AppMainInit PowerOn!-------------#~~~#\n");
    ZCSInitLogSema();
    if(ZCSLogMemMalloc())
    {
        printf("------[ZCS] mem_log malloc success\n");
    }
    else
    {
        printf("------[ZCS] Error: mem_log malloc failed\n");
    }

    return 0;
}

