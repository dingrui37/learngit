/*ZCMS���
 * ���ߣ�Wang          Jun
 * ʱ�䣺2014-8-31
 * zcms�����ؽڵ㡢ҵ��ڵ���ͬʱ�������е��Ľ�ɫ����������
 * ���ؽڵ�zcms��1)��ȡzcs�����ļ�����ִ�г�ʼ����2)�����Ľڵ���������Echo_request����
 *              3)�����������ݵ�����ͬ��
 * ҵ��ڵ�zcms��1)�ϵ���zcms���ؽڵ㷢�ͽڵ��������2)ִ�б������*/

#include "tulip.h"
#include "tulip_oss.h"
#include "tulip_scs.h"
#include "../../../adm/plat/include/pub_eventdef.h"

#include "zcs_common.h"
#include "zcs_log.h"

#include "CZcmsMgr.h"
#include "CNodeMgr.h"
#include "CNodeClient.h"


uint16_t zcms_poweron_msg_handler(BOOLEAN IsWorking);
void zcms_startup_msg_handler(uint32_t msgId, void *pMsg, uint16_t msg_len, void *pPData);
void zcms_mnode_work_msg_handler(uint32_t msgId, void *pMsg, uint16_t msg_len, void *pPData);
void zcms_mnode_slave_msg_handler(uint32_t msgId, void *pMsg, uint16_t msg_len, void *pPData);
void zcms_snode_work_msg_handler(uint32_t msgId, void *pMsg, uint16_t msg_len, void *pPData);

static BYTE bPowerOnStr[]="ZCMS";

CZcmsMgr tCZcmsMgr;
CNodeConfig tCNodeConfig;
CNodeMgr tCNodeMgr;
CNodeClient tCNodeClient;

#ifdef __cplusplus
extern "C" {
#endif

void zcms_PowerONAck(uint16_t NextState)
{
    WORD32 dwMsgId;
    if(NextState == ZCS_JOB_STATE_INVALID)
    {
        dwMsgId = EV_POWER_ON_FAIL;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "ZCMS POWER_ON_FAIL!\n");
    }
    else
    {
        dwMsgId = EV_POWER_ON_SUCCESS;
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "ZCMS POWER_ON_SUCCESS!\n");
    }
    
    XOS_PowerOnAck(dwMsgId, bPowerOnStr, sizeof(bPowerOnStr), 0);
    return;
}

void zcms_ChangeOverAck()
{
	   char* pstr;
	   uint32_t dwMsgId;
	   
	   if(tCNodeMgr.getChangeOverState()==ZCMS_PRE_CHANGEOVER)
	   {
        pstr = "EV_PRE_CHANGEOVER_SUCCESS";
        dwMsgId = EV_PRE_CHANGEOVER_SUCCESS;
	   }
	   else if(tCNodeMgr.getChangeOverState()==ZCMS_MS_CHANGEOVER)
	   {
        pstr = "EV_CHANGEOVER_SUCCESS";
        dwMsgId = EV_CHANGEOVER_SUCCESS;
	   }
	   else
	   {
        return;
	   }

	   if(tCNodeMgr.isChangingOver() && tCNodeMgr.metSndChgOverAckCondition())
	   {
        XOS_RespondToMCM(dwMsgId, NULL, 0, 0);
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "zcms_ChangeOverAck %s!\n", pstr);
	   }
    
    return;
}

/*ZCMS�������*/
void zcms_entry(WORD16 wState, WORD32 dwMsgId, void *pMsgBody, void *pPData, BOOLEAN bSame)
{
    uint16_t msg_len;
    XOS_GetMsgDataLen(&msg_len);
    switch(wState)
    {
        case S_StartUp:
            zcms_startup_msg_handler(dwMsgId, pMsgBody, msg_len, pPData);
            break;
        case ZCS_JOB_STATE_MNODE_WORK:
            zcms_mnode_work_msg_handler(dwMsgId, pMsgBody, msg_len, pPData);
            break;

        case ZCS_JOB_STATE_MNODE_SLAVE:
            zcms_mnode_slave_msg_handler(dwMsgId, pMsgBody, msg_len, pPData);
            break;

        case ZCS_JOB_STATE_SNODE_WORK:
            zcms_snode_work_msg_handler(dwMsgId, pMsgBody, msg_len, pPData);
            break;
        default:
        	   ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "zcms_entry goes into Unkown State:%d!\n", wState);
            XOS_SetDefaultNextState();
            break;
    }

    XOS_SetDefaultNextState();
    return;
}

#ifdef __cplusplus
}
#endif

uint16_t zcms_poweron_msg_handler(BOOLEAN IsWorking)
{
    uint16_t NextState = ZCS_JOB_STATE_INVALID;
    ZENIC_RESULT ret;
    
    ret = tCZcmsMgr.init(IsWorking, NextState);
    if(ret != RESULT_ZENIC_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "PowerOn CZcmsMgr init Failed ret:%d, Go to invalid state:%d!\n", ret, NextState);
        return NextState;

    }
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "PowerOn CZcmsMgr init Success!\n");
    
    ret = tCNodeConfig.init();
    if(ret != RESULT_ZENIC_SUCCESS)
    {
        NextState = ZCS_JOB_STATE_INVALID;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "PowerOn CNodeConfig init Failed ret:%d, Go to invalid state:%d!\n", ret, NextState);
        return NextState;

    }
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "PowerOn CNodeConfig init Success!\n");
    
    ret = tCNodeMgr.init(&tCNodeConfig, &tCZcmsMgr, NextState);
    if(ret != RESULT_ZENIC_SUCCESS)
    {
        NextState = ZCS_JOB_STATE_INVALID;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "CNodeMgr init Failed ret:%d, Go to invalid state:%d!\n", ret, NextState);
        return NextState;

    }
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "PowerOn CNodeMgr init Success!\n");
    
    ret = tCNodeClient.init(&tCNodeConfig, &tCZcmsMgr, NextState);
    if(ret != RESULT_ZENIC_SUCCESS)
    {
        NextState = ZCS_JOB_STATE_INVALID;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "PowerOn CNodeClient init Failed ret:%d, Go to invalid state:%d!\n", ret, NextState);
        return NextState;

    }
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "PowerOn CNodeClient init Success!\n");
    
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "ZCMS PowerOn init Success, Go to State:%d!\n", NextState);
    return NextState;

}

/*zcms����ʱ�Ĵ���*/
void zcms_startup_msg_handler(uint32_t msgId, void *pMsg, uint16_t msg_len, void *pPData)
{
    switch (msgId)
    {       
        case EV_MASTER_POWER_ON:
        {
            uint16_t NextState;
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "Rcv EV_MASTER_POWER_ON!\n");
            NextState = zcms_poweron_msg_handler(TRUE);
            zcms_PowerONAck(NextState);
            XOS_SetNextState(NextState);
        }
        break;
            
        case EV_SLAVE_POWER_ON:
        {
        	   uint16_t NextState;
        	   ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "Rcv EV_SLAVE_POWER_ON!\n");   
            NextState = zcms_poweron_msg_handler(FALSE);
            zcms_PowerONAck(NextState);
            XOS_SetNextState(NextState);
        }
        break;
            
        default:
        {
        	   ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "Rcv Unkown Msg %u!\n", msgId);
            XOS_SetDefaultNextState();
        }
        break;
    }
}

/*���ؽڵ����ýڵ��߼�*/
void zcms_mnode_work_msg_handler(uint32_t msgId, void *pMsg, uint16_t msg_len, void *pPData)
{   
    switch(msgId)
    {
        case EV_SYS_ZCMS_QUEUE_APPLY:
        {
        	   tCNodeMgr.onQueueApplyAck(pMsg, msg_len);
            XOS_SetDefaultNextState();
        }
        break;
        
        case EV_SYS_ZCMS_REG_APPLY:
        {
        	   tCNodeMgr.onNodeJoinAck(pMsg, msg_len);
            XOS_SetDefaultNextState();
        }
        break;
        
        case EV_SYS_ZCMS_ECHO_REQUEST:
        {
            tCNodeMgr.onHandleClientHeartBeat(pMsg, msg_len);
            XOS_SetDefaultNextState();
        }
        break;
        
        case EV_SYS_ZCMS_MGR_CHECK_HBTO_TIMER:
        {
            tCNodeMgr.checkLinkNodeTimeOut();
            XOS_SetDefaultNextState();
        }
        break;
        
        case EV_SYS_ZCMS_MSSYNC_REQ:
        {
        	   ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CWorking]Rcv EV_SYS_ZCMS_MSSYNC_REQ msg!\n");
        	   tCNodeMgr.onZcsMSSync(SYNC_ALL);
            XOS_SetDefaultNextState();
        }
        break;
        
        case EV_SYS_ZCMS_MASTERMGR_MSSYNC_TIMER:
        {
        	   ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CWorking]Rcv EV_SYS_ZCMS_MASTERMGR_MSSYNC_TIMER msg!\n");
        	   tCNodeMgr.onZcsMSSync(XOS_GetParaOfCurTimer());
            XOS_SetDefaultNextState();
        }
        break;

        case EV_SYS_ZCMS_MSSYNC_ACK:
        {
        	   ZCS_LOG(ZCS_LOG_DEBUG, ZCS_LOG_MOD_ZCMS, "[CWorking]Rcv EV_SYS_ZCMS_MSSYNC_ACK msg!\n");
        	   tCNodeMgr.onZcsHandleMSSyncAck();
        	   zcms_ChangeOverAck();
            XOS_SetDefaultNextState();
        }
        break;

        case EV_SYS_ZCMS_MASTERMGR_MULTICAST_TIMER:
        {
        	   tCNodeMgr.onZcsMultiCastSync();
            XOS_SetDefaultNextState();
        }
        break;

        case EV_SYS_ZCMS_MULTISYNC_ACK:
        {
            tCNodeMgr.onHandleMultiCastSyncAck(pMsg, msg_len);
            XOS_SetDefaultNextState();
        }
        break;
        
        case EV_SYS_ZCS_REGISTER_NODE_EVENT:
        {
        	   //ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CWorking]Rcv EV_SYS_ZCS_REGISTER_NODE_EVENT msg!\n");
        	   tCNodeMgr.onNodeEventSubscribe(pMsg, msg_len);
            XOS_SetDefaultNextState();
        }
        break;

        case EV_SYS_ZCS_NODE_EVENT_ACK:
        {
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CWorking]Rcv EV_SYS_ZCS_NODE_EVENT_ACK msg!\n");
            tCNodeMgr.onNodeEventAck(pMsg, msg_len);
            zcms_ChangeOverAck();
            XOS_SetDefaultNextState();
        }
        break;
        case EV_SYS_ZCMS_NOTIFY_UPL_WAIT_ACK_TIMER:
        {
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CWorking]ZCMS_NOTIFY_UPL_WAIT_ACK timeout and ack reSend notify!\n");
            tCNodeMgr.notifyUPLNodeEvent(false);
            XOS_SetDefaultNextState();            
        }
        break;
        case EV_SYS_ZCMS_SELF_TRIGGER_MSG:
        {
        	   ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CWorking]Rcv EV_SYS_ZCMS_SELF_TRIGGER_MSG msg!\n");
        	   tCNodeMgr.onSelfTriggerNodeEventAck(pMsg, msg_len);
        	   zcms_ChangeOverAck();
            XOS_SetDefaultNextState();
        }
        break;        
        case EV_SYS_ZCS_NODE_MGR:
        {
        	   tCNodeMgr.onNodeAdminManage(pMsg, msg_len);
            XOS_SetDefaultNextState();
        }
        break;

        case EV_SYS_ZCMS_CHG_OVER_TIMER:
        {
        	   ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CWorking]PreChangeOver timeout and ack EV_PRE_CHANGEOVER_SUCCESS!\n");
        	   XOS_RespondToMCM(EV_PRE_CHANGEOVER_SUCCESS, NULL, 0, 0);
            XOS_SetDefaultNextState();
        }
        break;
        
        /* Just for test, to simulate client actions */
        #if ZCMS_MGR_CLIENT_COMBINE
        case EV_SYS_ZCMS_CLIENT_QUEUE_TIMER:
        case EV_SYS_ZCMS_CLIENT_REG_TIMER:
        case EV_SYS_ZCMS_CLIENT_ECHO_TIMER:
        case EV_SYS_ZCMS_QUEUE_ACK:        
        case EV_SYS_ZCMS_REG_ACK:
        case EV_SYS_ZCMS_RESET_LINK:
        case EV_SYS_ZCMS_MULTISYNC:
        case EV_SYS_ZCS_LAUNCH_SERVICE:
        case EV_SYS_ZCMS_CLIENT_RESET:
        {
        	   zcms_snode_work_msg_handler(msgId, pMsg, msg_len, pPData);
            XOS_SetDefaultNextState();
        }
        break;
        #endif
        
        case EV_BOARD_POWERON_SUCCESS:
        {
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[MWorking]Rcv EV_BOARD_POWERON_SUCCESS!\n");
            #if ZCMS_MGR_CLIENT_COMBINE
            zcms_snode_work_msg_handler(EV_SYS_ZCMS_CLIENT_QUEUE_TIMER, NULL, 0, NULL);
            #endif
            XOS_SetDefaultNextState();
        }
        break;
        
        case EV_BOARD_LOGIC_ADDR_REQ: //�����߼���ַ������
        {
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CWorking]Rcv EV_BOARD_LOGIC_ADDR_REQ!\n");
            tCNodeMgr.onAppLAReq(pMsg, msg_len);
            XOS_SetDefaultNextState();
        }
        break;
        
        case EV_BOARD_PHY_INFO_REPORT:
        {
            XOS_SetDefaultNextState();
        }
        break;
        
        case EV_PRE_CHANGEOVER:
        {
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CWorking]Rcv EV_PRE_CHANGEOVER!\n");
            tCNodeMgr.preChangeOver();
            zcms_ChangeOverAck();
            XOS_SetDefaultNextState();
        }
        break;
        
        case EV_MASTER_TO_SLAVE:
        {
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CWorking]Rcv EV_MASTER_TO_SLAVE!\n");
            tCNodeMgr.changeOver();
        	   zcms_ChangeOverAck();
            XOS_SetDefaultNextState();
        }
        break;
        
        case EV_MS_FINISH:
        {
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CWorking]Rcv EV_MS_FINISH!\n");
            tCNodeMgr.postChangeOver();
            XOS_SetNextState(ZCS_JOB_STATE_MNODE_SLAVE);
        }
        break;

        case EV_POWER_OFF:
        {
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CWorking]Rcv EV_POWER_OFF Msg!\n");
            XOS_SetDefaultNextState();
        }
        break;

        case EV_SUBSCR_EVENT_TOAPP:
        {
        	   ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CWorking]Rcv EV_SUBSCR_EVENT_TOAPP Msg!\n");
        	   tCNodeMgr.onHandleTipcSubscribe(pMsg, msg_len);
            XOS_SetDefaultNextState();
        }
        break;
        
        default:
        {
        	   ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CWorking]Rcv Unknown Msg %u!\n", msgId);
            XOS_SetDefaultNextState();
        }
        break;
    }
}


void zcms_mnode_slave_msg_handler(uint32_t msgId, void *pMsg, uint16_t msg_len, void *pPData)
{

    switch(msgId)
    {    
        case EV_BOARD_LOGIC_ADDR_REQ: //�����߼���ַ������
        {
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CStandby]Rcv EV_BOARD_LOGIC_ADDR_REQ, Ignore!\n");
            XOS_SetDefaultNextState();
        }
        break;
        
        case EV_PRE_CHANGEOVER:
        {
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CStandby]Rcv EV_PRE_CHANGEOVER!\n");
            tCNodeMgr.preChangeOver();
            zcms_ChangeOverAck();
            XOS_SetDefaultNextState();
        }
        break;
        
        case EV_SLAVE_TO_MASTER:
        {
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CStandby]Rcv EV_SLAVE_TO_MASTER!\n");
            tCNodeMgr.changeOver();
            zcms_ChangeOverAck();
            XOS_SetDefaultNextState();
        }
        break;
  
        case EV_SM_FINISH:
        {
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CStandby]Rcv EV_SM_FINISH!\n");
            tCNodeMgr.postChangeOver();
            XOS_SetNextState(ZCS_JOB_STATE_MNODE_WORK);
        }
        break;
        
        case EV_POWER_OFF:
        {
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CStandby]Rcv EV_POWER_OFF Msg!\n");
            XOS_SetDefaultNextState();
        }
        break;
        
        case EV_BOARD_POWERON_SUCCESS:
        {
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CStandby]Rcv EV_BOARD_POWERON_SUCCESS!\n");
            tCNodeMgr.onZcsMSSyncReq();
            #if ZCMS_MGR_CLIENT_COMBINE
            zcms_snode_work_msg_handler(EV_SYS_ZCMS_CLIENT_QUEUE_TIMER, NULL, 0, NULL);
            #endif
            XOS_SetDefaultNextState();
        }
        break;

        case EV_SUBSCR_EVENT_TOAPP:
        {
        	   ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CStandby]Rcv EV_SUBSCR_EVENT_TOAPP Msg!\n");
        	   tCNodeMgr.onHandleTipcSubscribe(pMsg, msg_len);
            XOS_SetDefaultNextState();
        }
        break;
        
        case EV_SYS_ZCMS_SLAVEMGR_SYNC_REQ_TIMER:
        {
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CStandby]Rcv EV_SYS_ZCMS_SLAVEMGR_SYNC_REQ_TIMER msg!\n");
            tCNodeMgr.onZcsMSSyncReq();
            XOS_SetDefaultNextState();
        }
        break;

        case EV_SYS_ZCMS_MSSYNC:
        {
            ZCS_LOG(ZCS_LOG_DEBUG, ZCS_LOG_MOD_ZCMS, "[CStandby]Rcv EV_SYS_ZCMS_MSSYNC msg!\n");
            tCNodeMgr.onZcsMSSyncAck(pMsg, msg_len);
            XOS_SetDefaultNextState();
        }
        break;
        
        case EV_SYS_ZCS_REGISTER_NODE_EVENT:
        {
        	   ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CStandby]Rcv EV_SYS_ZCS_REGISTER_NODE_EVENT msg!\n");
            tCNodeMgr.onNodeEventSubscribe(pMsg, msg_len);
            XOS_SetDefaultNextState();
        }
        break;

        #if ZCMS_MGR_CLIENT_COMBINE
        case EV_SYS_ZCMS_CLIENT_QUEUE_TIMER:
        case EV_SYS_ZCMS_CLIENT_REG_TIMER:
        case EV_SYS_ZCMS_CLIENT_ECHO_TIMER:
        case EV_SYS_ZCMS_QUEUE_ACK:        
        case EV_SYS_ZCMS_REG_ACK:
        case EV_SYS_ZCMS_RESET_LINK:
        case EV_SYS_ZCMS_MULTISYNC:
        case EV_SYS_ZCS_LAUNCH_SERVICE:
        case EV_SYS_ZCMS_CLIENT_RESET:
        {
        	   zcms_snode_work_msg_handler(msgId, pMsg, msg_len, pPData);
            XOS_SetDefaultNextState();
        }
        break;
        #endif
        
        default:
        {
        	   ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[CStandby]Rcv Unknown Msg %u!\n", msgId);
            XOS_SetDefaultNextState();
        }
        break;
    }

}

/*ҵ��ڵ�����Ϣ��������*/
void zcms_snode_work_msg_handler(uint32_t msgId, void *pMsg, uint16_t msg_len, void *pPData)
{
    switch(msgId)
    {        
        case EV_SYS_ZCMS_CLIENT_REG_TIMER:
        {
        	   tCNodeClient.onFormallyRegReq();
            XOS_SetDefaultNextState();
        }
        break;
        
        case EV_SYS_ZCMS_CLIENT_ECHO_TIMER:
        {
        	   tCNodeClient.onClientHeatBeat();
            XOS_SetDefaultNextState();
        }
        break;
        
        case EV_SYS_ZCMS_QUEUE_ACK:
        {
        	   tCNodeClient.onCHandleQueueAck(pMsg, msg_len);
            XOS_SetDefaultNextState();
        }
        break;
        
        case EV_SYS_ZCMS_REG_ACK:
        {
        	   tCNodeClient.onCHandleRegAck(pMsg, msg_len);
            XOS_SetDefaultNextState();
        }
        break;

        case EV_SYS_ZCMS_RESET_LINK:
        {
        	   tCNodeClient.onCHandleLinkResetMsg(pMsg, msg_len);
            XOS_SetDefaultNextState();
        }
        break;

        case EV_SYS_ZCMS_MULTISYNC:
        {
        	   tCNodeClient.onHandleMultiCastSync(pMsg, msg_len);
            XOS_SetDefaultNextState();
        }
        break;

        case EV_SYS_ZCS_LAUNCH_SERVICE:
        {
        	   tCNodeClient.onReceiveNotifyLaunchService();
            XOS_SetDefaultNextState();
        }
        break;

        case EV_BOARD_POWERON_SUCCESS:
        {
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[SWorking]Rcv EV_POWER_ON_FINISH!\n");
        }
        case EV_SYS_ZCMS_CLIENT_QUEUE_TIMER:
        {
        	   tCNodeClient.onRegQueueReq();
            XOS_SetDefaultNextState();
        }
        break;

        case EV_SYS_ZCMS_CLIENT_RESET:
        {
        	   tCNodeClient.adminReset(pMsg, msg_len);
            XOS_SetDefaultNextState();
        }
        
        case EV_POWER_OFF:
        {
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[SWorking]Rcv EV_POWER_OFF Msg!\n");
            XOS_SetDefaultNextState();
        }
        break;
        
        default:
        {
        	   ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[SWorking]Rcv Unknown Msg %u!\n", msgId);
            XOS_SetDefaultNextState();
        }
        break;
    }
}


