/*
 * zcs_rte_def.h
 *
 *  Created on: 2014-9-4
 *      Author: wangjun
 */

#ifndef ZCS_RTE_DEF_H_
#define ZCS_RTE_DEF_H_
#include "zcs_types.h"

typedef uint8_t T_DHT_NODE_STATE;
static const T_DHT_NODE_STATE DHT_NODE_NOT_EXIST =0;
static const T_DHT_NODE_STATE DHT_NODE_ACTIVE =1;
static const T_DHT_NODE_STATE DHT_NODE_JOINING =2;
static const T_DHT_NODE_STATE DHT_NODE_LEAVING =3;
static const T_DHT_NODE_STATE DHT_NODE_INACTIVE =4;
static const T_DHT_NODE_STATE DHT_NODE_BLOCKED =5;

static const uint16_t DHT_INVALID_NODE_ID = 0xFFFF;

static const uint8_t ADD_ADJUST_MASTER=1;
static const uint8_t DEL_ADJUST_MASTER=2;
static const uint8_t BLK_ADJUST_MASTER=3;

const uint16_t DHT_MAX_RTE_ENTRY = ZCS_MAX_RTE_ENTRY;//����·�ɱ�����Ŀ
    struct T_DHT_SEGMENT_PAIR {
        uint16_t start_idx;
        uint16_t end_idx;
        bool operator==(const T_DHT_SEGMENT_PAIR & tPair)
        {
            return (start_idx==tPair.start_idx && end_idx==tPair.end_idx);
        }
    }_ZENIC_PACKED;

/*DHT·�ɱ���*/
    struct T_DHT_RTE_ENTRY {
        T_DHT_SEGMENT_PAIR tSegPair;
        T_DHT_NODES_GROUP tNodes;
        bool has_m2s;
        bool bRejectSwitchAccess;
        T_DHT_RTE_ENTRY():has_m2s(0), bRejectSwitchAccess(0) {
            memset(&tSegPair, 0, sizeof(tSegPair) );
        }
        bool operator==(const T_DHT_RTE_ENTRY &that)
        {
            if(tSegPair.start_idx!=that.tSegPair.start_idx ||
                    tSegPair.end_idx!=that.tSegPair.end_idx ||
                    tNodes.master_node_id != that.tNodes.master_node_id ||
                    tNodes.backup_nodes_num!=that.tNodes.backup_nodes_num)
                return false;
            for(uint8_t i=0;i<tNodes.backup_nodes_num;i++)
            {
                if(tNodes.backup_nodes[i]!=that.tNodes.backup_nodes[i])
                    return false;
            }
            return true;
        }

        bool operator!=(const T_DHT_RTE_ENTRY &that)
        {
            return !((*this)==that);
        }
    }_ZENIC_PACKED;

    struct T_DHT_NODE {
        uint16_t node_id;
        T_DHT_NODE_STATE node_state;
    }_ZENIC_PACKED;

    struct T_DHT_NODE_LIST {
        uint16_t node_num;
        T_DHT_NODE nodes[DHT_MAX_NODE_NUMBER];
    }_ZENIC_PACKED;

    struct T_DHT_RTE_TABLE {
        T_DHT_NODE_LIST  tActiveNodes;//��Ľڵ�
        uint16_t backup_copy;//��������
        uint16_t m_seg_num;//��Ƭ����
        uint16_t m_seg_per_node;//ÿ���ڵ����Ƭ����
        uint16_t m_num_per_seg;
        uint16_t m_self_node_id;
        uint16_t m_rte_entry_num;//ʵ�ʵ�·�ɱ�����
        T_DHT_RTE_ENTRY rtEntry[DHT_MAX_RTE_ENTRY];
        T_DHT_RTE_TABLE():backup_copy(0), m_seg_num(0), m_seg_per_node(0), m_num_per_seg(0),
            m_self_node_id(0), m_rte_entry_num(0) {
            memset(&tActiveNodes, 0, sizeof(tActiveNodes) );
        }
    }_ZENIC_PACKED;


#endif /* ZCS_RTE_DEF_H_ */
