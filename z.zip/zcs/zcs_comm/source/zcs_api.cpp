/*
 * zcs_api.cpp
 *
 *  Created on: 2014-9-2
 *      Author: wangjun
 */

#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/errno.h>
#include <stdio.h>
#include "zcs_api.h"
#include "zcs_job_def.h"
#include "tulip.h"
#include "tulip_oss.h"
#include "zcs_common.h"
#include "zcs_rte_def.h"
#include "CSyncMsg.h"
#include "tulip_appcommon.h"

ZENIC_RESULT zcs_send_msg(uint32_t msg_id,const uint8_t *msg,uint16_t len, T_ZCS_NODE_ROUTE &route)
{
    XOS_STATUS ret;
    JID tJid={0};

    ret =XOS_GetSelfJID(&tJid);
    if(XOS_SUCCESS != ret){
        //printf("zcs_send_msg:XOS_GetSelfJID ERROR_COMMON_ERROR\n");
        return ERROR_COMMON_ERROR;
    }
    
    tJid.dwJno = route.jNo;

    switch(route.nodeId)
    {
    case ZCS_MASTER_NODE_ID_1:
        tJid.wModule = ZCS_MASTER_NODE_MODULE_NO;
        //tJid.ucRouteType = COMM_LEFT_CONTROL;
        break;
    case ZCS_MASTER_NODE_ID_2:
        tJid.wModule = ZCS_MASTER_NODE_MODULE_NO;
        //tJid.ucRouteType = COMM_RIGHT_CONTROL;
        break;
    default:
        tJid.wModule = route.nodeId;
        //tJid.ucRouteType = COMM_MASTER_SERVICE;
        break;
    }
    
    switch(route.route_type)
    {
    case ZCS_LEFT_BOARD:
        tJid.ucRouteType = COMM_LEFT_CONTROL;
        break;
    case ZCS_RIGHT_BOARD:
        tJid.ucRouteType = COMM_RIGHT_CONTROL;
        break;
    case ZCS_MASTER_BOARD:
    default:
        tJid.ucRouteType = COMM_MASTER_SERVICE;
        break;
    }
    ret = XOS_SendAsynMsg(msg_id,(uint8_t *)msg,len,0,0,&tJid);
    if(XOS_SUCCESS != ret){
        //printf("zcs_send_msg:XOS_SendAsynMsg Node[%d][%d:%d:0x%x] error!\n",route.nodeId, tJid.wModule, tJid.ucRouteType, tJid.dwJno);
        return ERROR_COMMON_ERROR;
    }
    return RESULT_ZENIC_SUCCESS;
}
ZENIC_RESULT zcs_constructJID(uint16_t job_type, uint16_t instance,JID &tJid);
/*�ڵ�����ӿ�*/
ZENIC_RESULT zcs_node_mgr(T_ZCS_NODE_MGR_OP node_op, uint16_t node_id);
/*��ȡ�ڵ��ɫ*/
T_ZCS_NODE_ROLE zcs_get_node_role()
{
    ZENIC_RESULT ret;
    T_ZCS_CONFIG_INFO tConf = {0};
    ret = zcs_get_config_info(tConf);
    if(ret != RESULT_ZENIC_SUCCESS)
    {
        printf("zcs_get_config_info failed:%d\n", ret);
        return ZCS_NODE_ROLE_INVALID;
    }
    return tConf.node_role;
}

/*��ȡ������Ϣ*/
ZENIC_RESULT zcs_get_config_info(T_ZCS_CONFIG_INFO &tConf)
{
    static T_ZCS_CONFIG_INFO *ptMemConf=(T_ZCS_CONFIG_INFO *)-1;

    if((T_ZCS_CONFIG_INFO *)-1==ptMemConf)
    {    
        int shm_id1 = shm_open(pZcsConfigShmName, O_RDONLY, S_IRUSR);
        
        if(shm_id1<0) 
        {
            return ERROR_FILE_OPEN_FAIL;
        }
    
        ftruncate(shm_id1, sizeof(T_ZCS_CONFIG_INFO));
        ptMemConf = (T_ZCS_CONFIG_INFO *)mmap(NULL,sizeof(T_ZCS_CONFIG_INFO), PROT_READ, MAP_SHARED, shm_id1, 0);
        
        if(ptMemConf == (T_ZCS_CONFIG_INFO *)-1)
        {
            int err = errno;
            printf("zcs_get_config_info mmap Result:%d!\n", err);
            close(shm_id1);
            return ERROR_ALLOC_MEM_FAIL;
        }
        close(shm_id1);
    }
    
    memcpy(&tConf, ptMemConf, sizeof(T_ZCS_CONFIG_INFO));
    return RESULT_ZENIC_SUCCESS;
}

/*����JID����API������Ϣʹ��*/
ZENIC_RESULT zcs_constructJID(uint16_t job_type, uint16_t instance,JID &tJid)
{
    static bool first_run=true;
    static JID  tTmpJid;
    if(first_run)
    {
        if(XOS_SUCCESS!=XOS_GetSelfJID(&tTmpJid))
            return ERROR_COMMON_ERROR;
        first_run = false;
    }

    tJid=tTmpJid;
    tJid.dwJno = (job_type<<16) + instance;
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT zcs_get_self_node_info(uint16_t &node_id,uint16_t &module_id,T_ZCS_ROUTE_TYPE &routType)
{
    T_ZCS_NODE tSelfNode;
    ZENIC_RESULT ret;
    
    ret = zcs_get_self_node_info(tSelfNode);
    node_id = tSelfNode.nodeId;
    module_id = tSelfNode.moduleId;
    routType = tSelfNode.route_type;
    return ret;
}

/*�����ӿ�*/
/*��ȡ��ǰ�ڵ�������Ϣ*/
ZENIC_RESULT zcs_get_self_node_info(T_ZCS_NODE &tSelfNode)
{
    static T_ZCS_NODE *ptSelfNode=(T_ZCS_NODE *)-1;

    if((T_ZCS_NODE *)-1==ptSelfNode)
    {
        int shm_id1 = shm_open(pZcsSelfNodeShmName, O_RDONLY, S_IRUSR);
    
        if(shm_id1<0) 
        {
            return ERROR_FILE_OPEN_FAIL;
        }
    
        ftruncate(shm_id1, sizeof(T_ZCS_NODE));
        ptSelfNode = (T_ZCS_NODE *)mmap(NULL,sizeof(T_ZCS_NODE), PROT_READ, MAP_SHARED, shm_id1, 0);
        
        if(ptSelfNode == (T_ZCS_NODE *)-1)
        {
            int err = errno;
            printf("zcs_get_self_node_info mmap Result:%d\n", err);
            close(shm_id1);
            return ERROR_ALLOC_MEM_FAIL;
        }
        close(shm_id1);
    }

    memcpy(&tSelfNode, ptSelfNode, sizeof(tSelfNode));
    return RESULT_ZENIC_SUCCESS;
}

/*��ȡ��ǰ���нڵ�������Ϣ*/
ZENIC_RESULT zcs_get_nodes(T_ZCS_NODE_LIST &tNodeList, T_ZCS_NODE_STATE tState)
{
    static T_ZCS_NODE_LIST *ptNodeL=(T_ZCS_NODE_LIST *)-1;
    uint16_t node_idx;
    
    if((T_ZCS_NODE_LIST *)-1==ptNodeL)
    {    
        int shm_id1 = shm_open(pZcsActiveNodesShmName, O_RDONLY, S_IRUSR);
    
        if(shm_id1<0) 
        {
            return ERROR_FILE_OPEN_FAIL;
        }
    
        ftruncate(shm_id1, sizeof(T_ZCS_NODE_LIST));
        ptNodeL = (T_ZCS_NODE_LIST *)mmap(NULL,sizeof(T_ZCS_NODE_LIST), PROT_READ, MAP_SHARED, shm_id1, 0);
        
        if(ptNodeL == (T_ZCS_NODE_LIST *)-1)
        {
            int err = errno;
            printf("zcs_get_nodes mmap Result:%d\n", err);
            close(shm_id1);
            return ERROR_ALLOC_MEM_FAIL;
        }
        close(shm_id1);
    }

    tNodeList.node_num=0;
    for(node_idx=0; node_idx<ptNodeL->node_num; node_idx++)
    {
        if(ptNodeL->tNodes[node_idx].state & tState)
        {
            tNodeList.tNodes[tNodeList.node_num++]=ptNodeL->tNodes[node_idx];
        }
    }

    return RESULT_ZENIC_SUCCESS;
}

/*��ȡ��ǰ���нڵ�������Ϣ*/
ZENIC_RESULT zcsmgr_get_all_nodes(T_ZCS_NODE_LIST &tNodeList)
{
    static T_ZCS_NODE_LIST *ptAllNodeL=(T_ZCS_NODE_LIST *)-1;
    
    if((T_ZCS_NODE_LIST *)-1==ptAllNodeL)
    {    
        int shm_id1 = shm_open(pZcsMgrNodesShmName, O_RDONLY, S_IRUSR);
    
        if(shm_id1<0) 
        {
            return ERROR_FILE_OPEN_FAIL;
        }
    
        ftruncate(shm_id1, sizeof(T_ZCS_NODE_LIST));
        ptAllNodeL = (T_ZCS_NODE_LIST *)mmap(NULL,sizeof(T_ZCS_NODE_LIST), PROT_READ, MAP_SHARED, shm_id1, 0);
        
        if(ptAllNodeL == (T_ZCS_NODE_LIST *)-1)
        {
            int err = errno;
            printf("zcsmgr_get_all_nodes mmap Result:%d\n", err);
            close(shm_id1);
            return ERROR_ALLOC_MEM_FAIL;
        }
        close(shm_id1);
    }

    memcpy(&tNodeList, ptAllNodeL, sizeof(T_ZCS_NODE_LIST));
    return RESULT_ZENIC_SUCCESS;
}

/*��ȡ��ǰ����blocked �ڵ�������Ϣ*/
ZENIC_RESULT zcs_get_blocked_nodes(T_ZCS_NODE_LIST &tNodeList)
{
    return zcs_get_nodes(tNodeList, ZCS_NODE_STATE_BLOCKED);
}

/*��ȡ��ǰ���л�Ծ�ڵ�������Ϣ*/
ZENIC_RESULT zcs_get_active_nodes(T_ZCS_NODE_LIST &tNodeList)
{
    return zcs_get_nodes(tNodeList, ZCS_NODE_STATE_ACTIVE);
}

/* UPL notify ZCMS client to launch service and register */
ZENIC_RESULT zcs_launch_service()
{
    JID tZcmsJid;    
    if(XOS_SUCCESS!=XOS_GetSelfJID(&tZcmsJid))
        return ERROR_COMMON_ERROR;

    tZcmsJid.dwJno = (ZCS_JOB_TYPE_ZCMS<<16) + 1;

    XOS_STATUS ret = XOS_SendAsynMsg(EV_SYS_ZCS_LAUNCH_SERVICE, (uint8_t *)NULL, 0, 0, 0, &tZcmsJid);
    if(XOS_SUCCESS != ret)
    {
        return ERROR_SEND_MSG_FAIL;
    }

    return RESULT_ZENIC_SUCCESS;
}

/*ע����սڵ�����˳���������������¼�*/
ZENIC_RESULT zcs_register_node_event(bool needAck)
{
    JID tZcmsJid;
    if(RESULT_ZENIC_SUCCESS!=zcs_constructJID(ZCS_JOB_TYPE_ZCMS,1,tZcmsJid))
    {
        return ERROR_COMMON_ERROR;
    }

    XOS_SendAsynMsg(EV_SYS_ZCS_REGISTER_NODE_EVENT,(uint8_t *)&needAck,sizeof(bool),0,0,
            &tZcmsJid);
    return RESULT_ZENIC_SUCCESS;
}

/*Ӧ��ȷ�Ͻڵ��¼�*/
void zcs_ack_node_event(uint16_t node_id, T_ZCS_NODE_EVENT event)
{
    JID tZcmsJid;
    T_EV_ZCS_NODE_EVENT_ACK tAck;
    if(RESULT_ZENIC_SUCCESS!=zcs_constructJID(ZCS_JOB_TYPE_ZCMS,1,tZcmsJid))
    {
        return ;
    }
    tAck.event_type = event;
    tAck.node_id = node_id;
    XOS_SendAsynMsg(EV_SYS_ZCS_NODE_EVENT_ACK,(uint8_t *)&tAck,sizeof(T_EV_ZCS_NODE_EVENT_ACK),0,0,
             &tZcmsJid);
}
/*ע��·�ɱ仯֪ͨ
 * ��Σ�
 * needAck bool �Ƿ�ʵ��ȷ�ϻ��ƣ����Ϊtrue����zcrs��Ҫ�ȴ���Ӧ�õ�Ӧ����Ϣ�Ž���ʵ�ʵ�·���л�����*/
ZENIC_RESULT zcs_register_rte_event(bool needAck)
{
    JID tZcrsJid;
    if(RESULT_ZENIC_SUCCESS!=zcs_constructJID(ZCS_JOB_TYPE_ZCRS,1,tZcrsJid))
    {
        return ERROR_COMMON_ERROR;
    }

    XOS_SendAsynMsg(EV_SYS_ZCS_REGISTER_RTE_CHGOVER_EVENT,(uint8_t *)&needAck,sizeof(bool),0,0,
            &tZcrsJid);
    return RESULT_ZENIC_SUCCESS;
}

/*ע��һ�����ݱ��ݴ���
 * ��Σ�
 * data_type  uint16_t  Ӧ���Զ�����������ͣ�1��ʼ˳����
 * max_record_num  uint32_t   ����¼��
 * resource_key_len  uint16_t  resource_key�ĳ��ȣ����ΪZCS_MAX_RESOURCE_KEY_LEN
 * rec_key_len   uint16_t ���Record_key�������ΪZCS_MAX_RECORD_KEY_LEN
 * needChgOverNotify  bool  �Ƿ���Ҫ�л�֪ͨ*/
ZENIC_RESULT zcs_register_data(uint16_t data_type, uint32_t max_record_num,
        uint16_t resource_key_len, uint16_t rec_key_len,bool needChgOverNotify,uint16_t app_id)
{
    JID tZcpsJid;
    T_EV_ZCS_RGISTER_DATA_REQ tReq;

    if(RESULT_ZENIC_SUCCESS!=zcs_constructJID(ZCS_JOB_TYPE_ZCPS,1,tZcpsJid))
    {
        return ERROR_COMMON_ERROR;
    }

    tReq.app_id = app_id;
    tReq.data_type = data_type;
    tReq.max_record_num = max_record_num;
    tReq.needChgOverNotify = (needChgOverNotify?1:0);
    tReq.record_key_len = rec_key_len;
    tReq.resource_key_len = resource_key_len;

    XOS_SendAsynMsg(EV_SYS_ZCS_REGISTER_DATA_EVENT,(uint8_t *)&tReq,sizeof(T_EV_ZCS_RGISTER_DATA_REQ),
            0,0,&tZcpsJid);
    return RESULT_ZENIC_SUCCESS;
}

/*Ӧ���յ�һ�����ݵ�ChgOverAck�󣬽������ݵ�ȷ��*/
ZENIC_RESULT zcs_data_chgover_ack(T_ZCS_DATA_KEY &tKey)
{
    return RESULT_ZENIC_SUCCESS;
}

/*Ӧ�ö��յ���·��Ԥ�л���Ϣ����ȷ��*/
ZENIC_RESULT zcs_rte_chgover_ack(T_ZCS_CHGOVER_EVENT ev, T_ZCS_CHGOVER_SEG_LIST tSegList)
{
    T_EV_ZCS_RTE_CHG_OVER_ACK tAck;
    JID tZcrsJid;
     if(RESULT_ZENIC_SUCCESS!=zcs_constructJID(ZCS_JOB_TYPE_ZCRS,1,tZcrsJid))
     {
         return ERROR_COMMON_ERROR;
     }
     tAck.event_type = ev;
	 memcpy(&tAck.tSegList,&tSegList,sizeof(T_ZCS_CHGOVER_SEG_LIST));
     XOS_SendAsynMsg(EV_SYS_ZCS_RTE_CHG_OVER_ACK,(uint8_t *)&tAck,sizeof(tAck),0,0,
             &tZcrsJid);

    return RESULT_ZENIC_SUCCESS;
}

/*��Ⱥд��һ������*/
/*tKey  T_ZCS_DATA_KEY      ���ݼ�¼��Ψһ��ʶ�����ڱ�ʾ���ݵĹؼ���
 *op  T_ZCS_DATA_OP         ���ݲ�������
 *version  uint32_t         ���ݼ�¼�İ汾������У������
 *pData   uint8_t *         ������Ϣ�壬NULL��ʾû������
 *data_len   uint16_t       ���ݵĳ���*/
ZENIC_RESULT zcs_put_data(const T_ZCS_DATA_KEY &tKey,  const T_ZCS_RESOURCE_KEY &tResKey,
        T_ZCS_DATA_OP op, uint32_t version, const uint8_t *pData, uint16_t data_len)
{
    XOS_STATUS xos_ret;
    JID tZcpsJid;
    T_DHT_NODES_GROUP tNodes;
    T_EV_ZCS_APP_SYNC_DATA tMsg;
    if (tKey.tRecKey.key_len > ZCS_MAX_RECORD_KEY_LEN || tResKey.key_len>ZCS_MAX_RESOURCE_KEY_LEN)
    {
        return ERROR_INVALID_PARAM;
    }
    if(data_len>ZCS_MAX_MSG_LEN)
    {
        return ERROR_MSG_TOO_LONG;
    }
    if(RESULT_ZENIC_SUCCESS!=zcs_constructJID(ZCS_JOB_TYPE_ZCPS,1,tZcpsJid))
    {
        return ERROR_COMMON_ERROR;
    }
    if(RESULT_ZENIC_SUCCESS != zcs_rte_lookup(tResKey,tNodes)) //û���ҵ�·��
        return ERROR_RECORD_NOT_FOUND;
    
    tZcpsJid.wModule = (tNodes.master_node_id & 0xff);//(tNodes.master_node_id % 255); & operator is more effective. 
    if(tNodes.master_node_id==1)
    {
        tZcpsJid.ucRouteType = ZCS_LEFT_BOARD;
    }
    else if(tNodes.master_node_id==256)
    {
        tZcpsJid.ucRouteType = ZCS_RIGHT_BOARD;
    }
    else
    {
        tZcpsJid.ucRouteType = ZCS_MASTER_BOARD;
    }
    
    memset(&tMsg.tSyncHdr,0,sizeof(tMsg.tSyncHdr));
    tMsg.tSyncHdr.tDataKey.app_id=tKey.app_id;
    tMsg.tSyncHdr.tDataKey.data_type=tKey.data_type;
    tMsg.tSyncHdr.tDataKey.tRecKey.key_len = tKey.tRecKey.key_len;
    memcpy(&tMsg.tSyncHdr.tDataKey.tRecKey.rec_key[0],&tKey.tRecKey.rec_key[0],tKey.tRecKey.key_len);
    tMsg.tSyncHdr.tResKey.key_len = tResKey.key_len;
    memcpy(&tMsg.tSyncHdr.tResKey.res_key[0],&tResKey.res_key[0],tResKey.key_len);
    if(tKey.app_id==0)
    {
        JID tCaller;
        XOS_GetSelfJID(&tCaller);
        tMsg.tSyncHdr.tDataKey.app_id = (tCaller.dwJno>>16);
        tMsg.tSyncHdr.app_id = (tCaller.dwJno>>16);
    }
    else
    {
        tMsg.tSyncHdr.app_id = tKey.app_id;
    }
    tMsg.tSyncHdr.dataop = op;
    tMsg.tSyncHdr.dataversion = version;
    tMsg.tSyncHdr.remote_put = 1;//��SyncData������
    tMsg.copy_data(pData,data_len); //tMsg.tSyncHdr.data_len = data_len; at tMsg.copy_data
    xos_ret = XOS_SendAsynMsg(EV_SYS_ZCS_APP_SYNC_DATA,(uint8_t *)&tMsg,tMsg.getMsgLen(),0,0,&tZcpsJid);
    if(xos_ret != XOS_SUCCESS)
    {
        return ERROR_SEND_MSG_FAIL;
    }
    return RESULT_ZENIC_SUCCESS;
}

/*�����ýڵ���ͬ��һ������*/
/*tKey  T_ZCS_DATA_KEY      ���ݼ�¼��Ψһ��ʶ�����ڱ�ʾ���ݵĹؼ���
 *op  T_ZCS_DATA_OP         ���ݲ�������
 *version  uint32_t         ���ݼ�¼�İ汾������У������
 *pData   uint8_t *         ������Ϣ�壬NULL��ʾû������
 *data_len   uint16_t       ���ݵĳ���*/
ZENIC_RESULT zcs_sync_data(const T_ZCS_DATA_KEY &tKey,  const T_ZCS_RESOURCE_KEY &tResKey,
        T_ZCS_DATA_OP op, uint32_t version, const uint8_t *data, uint16_t data_len)
{
    XOS_STATUS xos_ret;
    JID tZcpsJid;
    T_EV_ZCS_APP_SYNC_DATA tMsg;
    if(tKey.tRecKey.key_len > ZCS_MAX_RECORD_KEY_LEN || tResKey.key_len>ZCS_MAX_RESOURCE_KEY_LEN)
    {
        return ERROR_INVALID_PARAM;
    }
    if(data_len>ZCS_MAX_MSG_LEN)
    {
        return ERROR_MSG_TOO_LONG;
    }
    if(RESULT_ZENIC_SUCCESS!=zcs_constructJID(ZCS_JOB_TYPE_ZCPS,1,tZcpsJid))
    {
        return ERROR_COMMON_ERROR;
    }
    
    memset(&tMsg.tSyncHdr,0,sizeof(tMsg.tSyncHdr));
    tMsg.tSyncHdr.tDataKey.app_id=tKey.app_id;
    tMsg.tSyncHdr.tDataKey.data_type=tKey.data_type;
    tMsg.tSyncHdr.tDataKey.tRecKey.key_len = tKey.tRecKey.key_len;
    memcpy(&tMsg.tSyncHdr.tDataKey.tRecKey.rec_key[0],&tKey.tRecKey.rec_key[0],tKey.tRecKey.key_len);
    tMsg.tSyncHdr.tResKey.key_len = tResKey.key_len;
    memcpy(&tMsg.tSyncHdr.tResKey.res_key[0],&tResKey.res_key[0],tResKey.key_len);
    /*���Ӧ��û����дapp_id������Ϊapp_id����Ӧ�õ�JOB_TYPE*/
    if(tKey.app_id==0)
    {
        JID tCaller;
        XOS_GetSelfJID(&tCaller);
        tMsg.tSyncHdr.tDataKey.app_id = (tCaller.dwJno>>16);
        tMsg.tSyncHdr.app_id = tCaller.dwJno>>16;
    }
    else
    {
        tMsg.tSyncHdr.app_id= tKey.app_id;
    }
    tMsg.tSyncHdr.dataop = op;
    tMsg.tSyncHdr.dataversion = version;
    tMsg.tSyncHdr.remote_put = 0;
    tMsg.copy_data(data, data_len);
    xos_ret = XOS_SendAsynMsg(EV_SYS_ZCS_APP_SYNC_DATA,(uint8_t *)&tMsg,tMsg.getMsgLen(),0,0,&tZcpsJid);
    if(xos_ret != XOS_SUCCESS)
    {
        return ERROR_SEND_MSG_FAIL;
    }
    return RESULT_ZENIC_SUCCESS;
}

/*��ȡ�򴴽�·�ɱ������ڴ�ĺ���*/
ZENIC_RESULT zcs_getRoutingShm(T_DHT_RTE_TABLE **pRtTable,uint32_t entry_num,bool isCreate)
{
    int shm_id1;
    int flag,mode,proto;
    //int err;

    if(isCreate)
    {
        flag = O_CREAT | O_TRUNC | O_RDWR;
        mode = S_IRUSR | S_IWUSR;
        proto = PROT_READ | PROT_WRITE;
    }
    else
    {
        flag = O_RDONLY;
        mode = S_IRUSR;
        proto = PROT_READ;
    }

    shm_id1=shm_open(pDhtRtShmName,flag,mode);
    if(shm_id1<0) return ERROR_ALLOC_MEM_FAIL;

    //�ڱ�������ӳ�䵽ָ�����
    //if(isCreate)
    {
        ftruncate(shm_id1,sizeof(T_DHT_RTE_TABLE));
    }
    *pRtTable = (T_DHT_RTE_TABLE *)mmap(NULL,sizeof(T_DHT_RTE_TABLE),proto,MAP_SHARED,
            shm_id1,0);
    if((intptr_t)(*pRtTable) == -1)
     {
        //err = errno;
        close(shm_id1);
        return ERROR_COMMON_ERROR;
     }

    if(isCreate)
        (*pRtTable)->m_seg_num = entry_num;
    close(shm_id1);
    return RESULT_ZENIC_SUCCESS;

}


/*��ϣ����ʵ�֣�Ӧ�ÿ��Ե��øú�������Hashֵ������·�ɱ�*/
uint16_t zcs_hash_func(const uint8_t *data,uint16_t len)
{
    uint32_t hv=0, tmp=0;
    if(len>128)
        len=128;
    for(size_t i=0,j=len-1;i<len;i++,j--)
    {
            tmp=((data[i]+ data[j])*9+(data[i]^data[j])*11);
            hv+=((tmp & 0xFF)<<16 | (tmp & 0xFF000000)>>16 | (tmp & 0x00FF0000)<<8 | (tmp & 0x0000FF00)>>8);
            hv=hv*7/5;
    }

    return ((hv & 0xFFFF)^(hv>>16));

}

/*����·�ɱ������ؽڵ�
 * ��Σ�
 * resource_key  T_ZCS_RESOURCE_KEY ��Դ�ؼ���
 * ���Σ�
 * tNodes  �ڵ��б�*/
ZENIC_RESULT zcs_rte_lookup(const T_ZCS_RESOURCE_KEY &resource_key, T_DHT_NODES_GROUP &tNodes)
{
    static T_DHT_RTE_TABLE *pRtTable=NULL;
    ZENIC_RESULT ret;

    if(NULL==pRtTable)
    {
        ret =zcs_getRoutingShm(&pRtTable,0,false);
        if(RESULT_ZENIC_SUCCESS!=ret)
        {
            return ret;
        }
    }
    uint16_t hash_v = zcs_hash_func(resource_key.res_key,resource_key.key_len);
    if(pRtTable->m_num_per_seg==0)//û�г�ʼ��
    {
        return ERROR_RECORD_NOT_FOUND;
    }

    uint16_t seg_idx= hash_v / pRtTable->m_num_per_seg;

    tNodes = pRtTable->rtEntry[seg_idx].tNodes;
    if(tNodes.master_node_id==DHT_INVALID_NODE_ID || tNodes.master_node_id==0)
    {
        return ERROR_COMMON_ERROR;
    }
    return RESULT_ZENIC_SUCCESS;
}


/*����·�ɱ������ظ���Դ�Ƿ�Ӧ�ñ��ش���
 * ��Σ�
 * resource_key  T_ZCS_RESOURCE_KEY ��Դ�ؼ���
 * ����ֵ��
 * bool  true��ʾ���ش�����false��ʾ�Ǳ��ش���
 * isMaster   true��ʾ���ڵ���������*/
bool zcs_is_local(const T_ZCS_RESOURCE_KEY &resource_key, bool &isMaster)
{
    static T_DHT_RTE_TABLE *pRtTable=NULL;
    ZENIC_RESULT ret;
    T_DHT_NODES_GROUP *ptNodes;
    if(NULL==pRtTable)
    {
        ret =zcs_getRoutingShm(&pRtTable,0,false);
        if(RESULT_ZENIC_SUCCESS!=ret)
        {
        	   isMaster=false;
            return false;
        }
    }
    if(pRtTable->m_num_per_seg==0)//û�г�ʼ��
    {
    	   isMaster=false;
        return false;
    }
    uint16_t hash_v = zcs_hash_func(resource_key.res_key,resource_key.key_len);
    uint16_t seg_idx= hash_v / pRtTable->m_num_per_seg;
    ptNodes = &pRtTable->rtEntry[seg_idx].tNodes;
    if(ptNodes->master_node_id==pRtTable->m_self_node_id)
    {
        isMaster=true;
    }
    else
        isMaster=false;

    if(isMaster || (ptNodes->backup_nodes_num>0 && ptNodes->backup_nodes[0]==pRtTable->m_self_node_id)
            || (ptNodes->backup_nodes_num>1 && ptNodes->backup_nodes[1]==pRtTable->m_self_node_id))
        return true;
    else
        return false;

}

/*�ڵ��������*/
ZENIC_RESULT zcs_node_mgr(T_ZCS_NODE_MGR_OP node_op, uint16_t node_id)
{
    T_EV_NODE_MGR tNodeReq;
    JID tZcmsJid;
    if(RESULT_ZENIC_SUCCESS!=zcs_constructJID(ZCS_JOB_TYPE_ZCMS,1,tZcmsJid))
    {
        return ERROR_COMMON_ERROR;
    }

    tNodeReq.op = node_op;
    tNodeReq.node_id = node_id;

    XOS_SendAsynMsg(EV_SYS_ZCS_NODE_MGR,(uint8_t *)&tNodeReq,sizeof(tNodeReq),0,0,
            &tZcmsJid);

    return RESULT_ZENIC_SUCCESS;
}

//��device_mgr�жϽ������Ƿ���������ʹ��
bool zcs_is_adjusting(const T_ZCS_RESOURCE_KEY &resource_key)
{
    static T_DHT_RTE_TABLE *pRtTable=NULL;
    ZENIC_RESULT ret;
    if(NULL==pRtTable)
    {
        ret =zcs_getRoutingShm(&pRtTable,0,false);
        if(RESULT_ZENIC_SUCCESS!=ret)
        {
            return true;
        }
    }
    if(pRtTable->m_num_per_seg==0)//û�г�ʼ��
    {
        return true;
    }
    uint16_t hash_v = zcs_hash_func(resource_key.res_key,resource_key.key_len);
    uint16_t seg_idx= hash_v / pRtTable->m_num_per_seg;
    if (!pRtTable->rtEntry[seg_idx].bRejectSwitchAccess)
    {
		return false;
    }

	return true;
}


/*blockһ���ڵ㣬��ZCRS����ʵ�֣�
 * node_id �ڵ��*/
extern "C" {
ZENIC_RESULT zcs_block_node(uint16_t node_id)
{
    ZENIC_RESULT ret;
    T_ZCS_NODE_LIST tNodeList;
    
    memset(&tNodeList, 0, sizeof(tNodeList)); 
    ret = zcs_get_blocked_nodes(tNodeList);
    if(ret != RESULT_ZENIC_SUCCESS || tNodeList.node_num != 0)
    {
        return ERROR_ALREADY_EXIST;
    }
    return zcs_node_mgr(ZCS_NODE_MGR_BLOCK, node_id);
}

/*unblockһ���ڵ㣬��ZCRS����ʵ�֣�
 * node_id �ڵ��*/
ZENIC_RESULT zcs_unblock_node(uint16_t node_id)
{
    return zcs_node_mgr(ZCS_NODE_MGR_UNBLOCK, node_id);
}

/*����һ��ҵ��ڵ㣬��ZCMS����ʵ�֣�
 * node_id �ڵ��*/
ZENIC_RESULT zcs_add_node(uint16_t node_id)
{
    return zcs_node_mgr(ZCS_NODE_MGR_ADD, node_id);
}

/*ɾ��һ��ҵ��ڵ㣬��ZCMS����ʵ��
 * node_id �ڵ��*/
ZENIC_RESULT zcs_remove_node(uint16_t node_id)
{
    return zcs_node_mgr(ZCS_NODE_MGR_REMOVE, node_id);
}

void zcs_rte_lookup_by_deviceid(uint32_t dwDeviceId)
{
	T_ZCS_RESOURCE_KEY tResKey;
	ZENIC_RESULT ret;
	tResKey.key_len= sizeof(dwDeviceId);
	memcpy(&tResKey.res_key, &dwDeviceId, sizeof(dwDeviceId));
	T_DHT_NODES_GROUP tNodes;
	ret = zcs_rte_lookup(tResKey,tNodes);
	if (RESULT_ZENIC_SUCCESS != ret)
	{
		printf("zcs_rte_lookup() fail,ret=%d.\n",ret);
		return;
	}
	printf("dwDeviceId is in master of nodeid=%d.\n",tNodes.master_node_id);
	for (int i=0;i<tNodes.backup_nodes_num;i++)
	{
		printf("dwDeviceId is in slave[%d] of nodeid=%d.\n",i,tNodes.backup_nodes[i]);
	}

	bool isAdj = zcs_is_adjusting(tResKey);
	if (isAdj)
		printf("the device of master:%u is adjusting!.\n",tNodes.master_node_id);
}

/*�����������·�ɱ������طֲ�*/
ZENIC_RESULT zcs_balance_node( void )
{
    uint16_t balance_node_id = ZCS_INVALID_NODEID;       
    return zcs_node_mgr(ZCS_NODE_MGR_BALANCE,balance_node_id);
}
}


