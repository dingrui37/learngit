/*
 * CSyncDeletedDataQueue.cpp
 *
 *  Created on: 2014-9-17
 *      Author: wangjun
 */

#include "CSyncDeletedDataQueue.h"

CSyncDeletedDataQueue::CSyncDeletedDataQueue() {
    // TODO Auto-generated constructor stub

}

CSyncDeletedDataQueue::~CSyncDeletedDataQueue() {
    // TODO Auto-generated destructor stub
}

