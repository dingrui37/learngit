#include "shm_op.h"

#include <sys/mman.h>
#include <sys/stat.h>        /* For mode constants */
#include <fcntl.h>           /* For O_* constants */
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>

typedef int SplitBrainFlag;
#define SHM_SPLIT_BRAIN_RECOVER "SHM_SPLIT_BRAIN"
#define SHM_SPLIT_STRUCT_SIZE  sizeof(SplitBrainFlag)

#ifdef __cplusplus
extern "C"
{
#endif

int MCM_OpShmData(const char*name,int flag,int mode,int proto,void** pData,int dataLen)
{
   int shm_fd = shm_open(name, flag, mode);
   if( shm_fd < 0 )
   {
      return 0;		
   }		
   ftruncate(shm_fd, dataLen);		
   *pData= mmap(NULL,dataLen, proto, MAP_SHARED, shm_fd, 0);
   close(shm_fd);
   return (*pData != (void *)-1);
}

static SplitBrainFlag* pWShmData = (SplitBrainFlag*)-1;
int MCM_OpenWriteShm()
{
   return MCM_OpShmData(SHM_SPLIT_BRAIN_RECOVER,O_CREAT | O_RDWR, S_IRUSR | S_IWUSR,
   	 PROT_READ | PROT_WRITE,(void**)&pWShmData,SHM_SPLIT_STRUCT_SIZE);
}


int MCM_WriteShmRecover(int splitBrainRecover)
{
   if(pWShmData == (SplitBrainFlag*)-1)
   {
	  if(!MCM_OpenWriteShm())
	  {
	    return 0;
	  }
   }
   printf("%s data=%d\n",__func__,splitBrainRecover);
   *pWShmData = splitBrainRecover;
   return 1;
}

static SplitBrainFlag* pRShmData = (SplitBrainFlag*)-1;
int MCM_OpenReadShm()
{
   return MCM_OpShmData(SHM_SPLIT_BRAIN_RECOVER,O_RDONLY, S_IRUSR,PROT_READ,
   	(void**)&pRShmData,SHM_SPLIT_STRUCT_SIZE);
}

int MCM_ReadShmRecover(int* splitBrainRecover)
{	
    if(pRShmData == (SplitBrainFlag*)-1)
	{
	  if(!MCM_OpenReadShm())
	  {
	    return 0;
	  }
	}
    *splitBrainRecover = *pRShmData;
    return 1;
}

void showAllShm()
{
   int recover=0;
   MCM_ReadShmRecover(&recover);
   printf("recover=%d\n",recover);
}
#ifdef __cplusplus
}
#endif


