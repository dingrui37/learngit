/*
 * CZcrsMgr.cpp
 *
 *  Created on: 2014-9-4
 *      Author: kejin
 */

#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/errno.h>

#include "CZcmsMgr.h"


CZcmsMgr::CZcmsMgr()
    : m_wSvcState(0), m_ucBoardPosition(0), m_bIsOMP(false), m_dwChangeOverTimes(0),
      m_dwPoweronTick(0), m_ptSelfNode(NULL)
{
    memset(&m_tSelfNodeInfo, 0, sizeof(m_tSelfNodeInfo));
    memset(&m_tSelfPhyAddr, 0, sizeof(m_tSelfPhyAddr));
}

/*�л�����״̬���������ؽڵ���Ч*/
void CZcmsMgr::switchWorkState()
{	   
    if(m_wSvcState==ZCS_JOB_STATE_MNODE_WORK)
        m_wSvcState = ZCS_JOB_STATE_MNODE_SLAVE;
    else if(m_wSvcState==ZCS_JOB_STATE_MNODE_SLAVE)
        m_wSvcState = ZCS_JOB_STATE_MNODE_WORK;
    
    m_dwChangeOverTimes++;
}

/*��ʼ���ڵ��б�*/
ZENIC_RESULT CZcmsMgr::init(BOOLEAN IsWorking, uint16_t& nextState)
{
    XOS_STATUS ret;
    ZENIC_RESULT zenic_ret;
    char* pState;
    JID tSelfJID;
    
    nextState = m_wSvcState = ZCS_JOB_STATE_INVALID;
    m_tSelfNodeInfo.moduleId= ZCS_INVALID_MODULE;
    m_tSelfNodeInfo.nodeId = ZCS_INVALID_NODEID;
    m_tSelfNodeInfo.state = ZCS_NODE_STATE_INACTIVE; //Ĭ��ȫ����INACTIVE
    m_tSelfNodeInfo.route_type= ZCS_INVALID_BOARD;
    m_ptSelfNode=NULL;
    
    if(IsWorking)
    {
        pState="Working";
    }
    else
    {
        pState="Standby";
    }

    m_dwPoweronTick = XOS_GetCurStdSecs();
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[%s]PoweronTick %u!\n", pState, m_dwPoweronTick);

    memset(&tSelfJID, 0, sizeof(tSelfJID));
    ret = XOS_GetSelfJID((void *)&tSelfJID);
    if(ret != XOS_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "[%s]XOS_GetSelfJID failed ret:%d, Go to invalid state:%d!\n", pState, ret, nextState);
        return ERROR_INVALID_PARAM;

    }
    m_tSelfNodeInfo.moduleId = tSelfJID.wModule;

    memset(&m_tSelfPhyAddr, 0, sizeof(m_tSelfPhyAddr));
    ret = XOS_GetPhysAddress(&m_tSelfPhyAddr);
    if(ret != XOS_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "[%s]XOS_GetPhysAddress failed ret:%d, Go to invalid state:%d!\n", pState, ret, nextState);
        return ERROR_INVALID_PARAM;

    }
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[%s]XOS_GetPhysAddress %d:%d:%d:%d!\n", pState, 
    	                                                                        m_tSelfPhyAddr.ucRackId,
    	                                                                        m_tSelfPhyAddr.ucShelfId,
    	                                                                        m_tSelfPhyAddr.ucSlotId,
    	                                                                        m_tSelfPhyAddr.ucCpuId);


    
    ret = XOS_GetBoardPosition(&m_ucBoardPosition);
    if(ret != XOS_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "[%s]XOS_GetBoardPosition failed ret:%d, Go to invalid state:%d!\n", pState, ret, nextState);
        return ERROR_INVALID_PARAM;

    }

    m_bIsOMP = (bool)XOS_IsOmp();
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[%s]XOS_GetBoardPosition %s, OMP? %s!\n", pState, 
    	                                              (m_ucBoardPosition==XOS_LEFT_BOARD) ? "Left":"Right", m_bIsOMP ? "Yes":"No");
    if(m_ucBoardPosition==XOS_LEFT_BOARD)
    {
        m_tSelfNodeInfo.route_type = ZCS_LEFT_BOARD;
        
    }
    else
    {
        XOS_ASSERT(m_ucBoardPosition==XOS_RIGHT_BOARD);
        m_tSelfNodeInfo.route_type = ZCS_RIGHT_BOARD;
    }
    
    if(ZCS_MASTER_NODE_MODULE_NO == m_tSelfNodeInfo.moduleId)
    {
        if(IsWorking)
        {
            m_wSvcState = ZCS_JOB_STATE_MNODE_WORK;
            #if 0
            m_tSelfNodeInfo.state = ZCS_NODE_STATE_ACTIVE; //����״̬���Լ�����ΪACTIVE
            #endif
        }
        else
        {
            m_wSvcState = ZCS_JOB_STATE_MNODE_SLAVE;
           
        }
        if(ZCS_LEFT_BOARD == m_tSelfNodeInfo.route_type)
        {
            m_tSelfNodeInfo.nodeId= ZCS_MASTER_NODE_ID_1;
        }
        else
        {
            m_tSelfNodeInfo.nodeId= ZCS_MASTER_NODE_ID_2;
        }
    }
    else
    {
        if(IsWorking)
        {
            m_wSvcState = ZCS_JOB_STATE_SNODE_WORK;
            m_tSelfNodeInfo.nodeId = m_tSelfNodeInfo.moduleId;
        }
        else
        {
            XOS_ASSERT(0);
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "[%s]CZcmsMgr SelfModule:%d, NodeId:%d, mRoutType:%d, Go to invalid State:%d!\n", 
            	            pState, m_tSelfNodeInfo.moduleId, m_tSelfNodeInfo.nodeId, m_tSelfNodeInfo.route_type, nextState);
            return ERROR_COMMON_ERROR;
        }
    }
    
    zenic_ret = writeShmSelfNodeInfo();
    if(zenic_ret != RESULT_ZENIC_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "[%s]CZcmsMgr writeShmNodeInfo failed ret:%d, Go to invalid state:%d!\n", pState, zenic_ret, nextState);
        return zenic_ret;

    }
    
    nextState = m_wSvcState;
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "[%s]SelfModule:%d, NodeId:%d, mRoutType:%d, Go to State:%d!\n", pState, 
    	                    m_tSelfNodeInfo.moduleId, m_tSelfNodeInfo.nodeId, m_tSelfNodeInfo.route_type, nextState);
    return RESULT_ZENIC_SUCCESS;

}

uint16_t CZcmsMgr::getSelfSvcState()
{
    return m_wSvcState;
}

ZENIC_RESULT CZcmsMgr::getSelfNodeType(T_ZCS_NODE* tNodeType)
{
    tNodeType->nodeId = m_tSelfNodeInfo.nodeId;
    tNodeType->moduleId = m_tSelfNodeInfo.moduleId;
    tNodeType->state = m_tSelfNodeInfo.state;
    tNodeType->route_type = m_tSelfNodeInfo.route_type;
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CZcmsMgr::setSelfNodeState(T_ZCS_NODE_STATE tState)
{
    m_tSelfNodeInfo.state = tState;
    writeShmSelfNodeInfo();
    return RESULT_ZENIC_SUCCESS;
}

uint16_t CZcmsMgr::getSelfNodeID()
{
    return m_tSelfNodeInfo.nodeId;
}

BYTE CZcmsMgr::getBoardPosition()
{
    return m_ucBoardPosition;
}

bool CZcmsMgr::IsSelfOMP()
{
    return m_bIsOMP;
}

ZENIC_RESULT CZcmsMgr::getSelfPhyAddr(T_PhysAddress* ptPhyAddr)
{
    memcpy(ptPhyAddr, &m_tSelfPhyAddr, sizeof(T_PhysAddress));
    return RESULT_ZENIC_SUCCESS;
}

uint32_t CZcmsMgr::getSelfPowerOnTick()
{
    return m_dwPoweronTick;
}
void CZcmsMgr::setSelfPowerOnTick(uint32_t clusterPoweronTick)
{
    m_dwPoweronTick = clusterPoweronTick;
}

void CZcmsMgr::showSysInfo()
{
    char *stateStr=NULL;
    char *RouteStr=NULL;
    
    printf("Power On Tick:%-10u\n", m_dwPoweronTick);
    if(m_wSvcState==ZCS_JOB_STATE_MNODE_WORK)
    {
        printf("Service State: Center Working\n");
    } 
    else if(m_wSvcState==ZCS_JOB_STATE_MNODE_SLAVE)
    {
        printf("Service State: Center Standby\n");
    }
    else
    {
    	   printf("Service State: Service Working\n");
    }
    
    if(m_tSelfNodeInfo.state==ZCS_NODE_STATE_BLOCKED)
    {
        stateStr="Blocked";
    }
    else if(m_tSelfNodeInfo.state==ZCS_NODE_STATE_ACTIVE)
    {
        stateStr="Active";
    }
    else
    {
        stateStr="Inactive";
    }

    if(m_tSelfNodeInfo.route_type==ZCS_MASTER_BOARD)
    {
        RouteStr="Master";
    }
    else if(m_tSelfNodeInfo.route_type==ZCS_SLAVE_BOARD)
    {
        RouteStr="Slave";
    }
    else if(m_tSelfNodeInfo.route_type==ZCS_LEFT_BOARD)
    {
        RouteStr="Left";
    }
    else if (m_tSelfNodeInfo.route_type==ZCS_RIGHT_BOARD)
    {
        RouteStr="Right";
    }
    else
    {
        RouteStr="Invalid";
    }

    printf("NodeId:%d, ModuleId:%d, State:%s, RouteType:%s, BoardPosition:%s, OMP? %s, ChangeOver Times:%u\n", 
    	      m_tSelfNodeInfo.nodeId, 
    	      m_tSelfNodeInfo.moduleId, 
    	      stateStr, RouteStr, 
    	      (m_ucBoardPosition==XOS_LEFT_BOARD) ? "Left":"Right", 
    	      m_bIsOMP ? "Yes":"No",
    	      m_dwChangeOverTimes);
    
    printf("Physical Address-Rack:Shelf:Slot:Cpu %d:%d:%d:%d\n", 
    	m_tSelfPhyAddr.ucRackId, m_tSelfPhyAddr.ucShelfId,
    	m_tSelfPhyAddr.ucSlotId, m_tSelfPhyAddr.ucCpuId);
}

ZENIC_RESULT CZcmsMgr::writeShmSelfNodeInfo()
{
    if(m_ptSelfNode==NULL || m_ptSelfNode==(T_ZCS_NODE *)-1)
    {
        int flag = O_CREAT | O_RDWR;
        int mode = S_IRUSR | S_IWUSR;
        int proto = PROT_READ | PROT_WRITE;
        int shm_id1 = shm_open(pZcsSelfNodeShmName, flag, mode);
        
        if(shm_id1<0)
        {
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "writeShmSelfNodeInfo ZcsSelfNodeShm shm_open Failed!\n");
        	   return ERROR_FILE_OPEN_FAIL;
        }
        
        ftruncate(shm_id1, sizeof(T_ZCS_NODE));
        m_ptSelfNode = (T_ZCS_NODE *)mmap(NULL,sizeof(T_ZCS_NODE), proto, MAP_SHARED, shm_id1, 0);
        
        if(m_ptSelfNode == (T_ZCS_NODE *)-1)
        {
            int err = errno;
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "writeShmSelfNodeInfo ZcsSelfNodeShm mmap Result:%d!\n", err);
            close(shm_id1);
            return ERROR_ALLOC_MEM_FAIL;
        }
    }
    
    m_ptSelfNode->nodeId = m_tSelfNodeInfo.nodeId;
    m_ptSelfNode->moduleId = m_tSelfNodeInfo.moduleId;
    m_ptSelfNode->state = m_tSelfNodeInfo.state;
    m_ptSelfNode->route_type = m_tSelfNodeInfo.route_type;
    
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "writeShmSelfNodeInfo nodeId:moduleId:state:route_type [%d:%d:%d:%d] Success!\n",
    	                                             m_tSelfNodeInfo.nodeId,
    	                                             m_tSelfNodeInfo.moduleId,
    	                                             m_tSelfNodeInfo.state,
    	                                             m_tSelfNodeInfo.route_type);
    return RESULT_ZENIC_SUCCESS;
}

/*ͳ����Ϣ��ӡ����*/
void CZcmsMgr::print_stats()
{
    showSysInfo();
}


/*��������*/

CZcmsMgr::~CZcmsMgr() {
    // TODO Auto-generated destructor stub
}


