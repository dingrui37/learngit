/*
 * zcps_common.h
 *
 *  Created on: 2014-9-7
 *      Author: wangjun
 */

#ifndef ZCPS_COMMON_H_
#define ZCPS_COMMON_H_
#include <stdint.h>
#include "tulip.h"
#include "tulip_oss.h"
const uint32_t EV_SYS_ZCPS_SCAN_TIMER = EV_SYS_INNER_ZCPS_BEGIN+0;
const uint32_t EV_SYS_ZCPS_SYNC_TIMER = EV_SYS_INNER_ZCPS_BEGIN+1;
/*ͬ����ʱ��ʱ��*/
const uint16_t EV_SYS_ZCRS_WAIT_SYNC_ACK_TIMER = EV_SYS_INNER_ZCPS_BEGIN+2;

const uint32_t ZCPS_INVALID_DATA_INDEX = (uint32_t)-1;
ZENIC_RESULT zcps_send_msg(uint32_t msg_id,const uint8_t *msg,uint16_t len, uint16_t node_id, JID &tJid);
#endif /* ZCPS_COMMON_H_ */
