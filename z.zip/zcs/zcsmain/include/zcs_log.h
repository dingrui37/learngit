
#ifndef _ZCS_LOG_H
#define _ZCS_LOG_H

#include "tulip.h"
#include "tulip_oss.h"

#if ((defined OS_VXWORKS) || ((defined OS_LINUX) ||(defined OS_LINUX_PC)))
#ifndef ZCS_LOG_OPT
#define ZCS_LOG_OPT 1
#endif
#else
#define ZCS_LOG_OPT 0
#endif

#define EXCCODE_BEGIN 0
#define EXCCODE_ZCS_BASE (EXCCODE_BEGIN+10000)

#define PRINT_MODULE_ZCS_BASE           (WORD16)(200)
#define PRINT_ZCS_GNR                 (WORD16)(PRINT_MODULE_ZCS_BASE + 0)
#define PRINT_ZCS_ZCMS                 (WORD16)(PRINT_MODULE_ZCS_BASE + 1)
#define PRINT_ZCS_ZCRS                 (WORD16)(PRINT_MODULE_ZCS_BASE + 1)
#define PRINT_ZCS_ZCPS                 (WORD16)(PRINT_MODULE_ZCS_BASE + 1)
#define PRINT_ZCS_DBCORE                 (WORD16)(PRINT_MODULE_ZCS_BASE + 1)

/*----------------------------������־���� 3GCHG00007501---------------------------*/
/* ��־�������*/
#define ZCS_LOG_ENABLE_ALL          0   /* ��������־��� */
#define ZCS_LOG_TRACE               1   /* PRN_LEVEL_LOW*/
#define ZCS_LOG_DEBUG               2   /* PRN_LEVEL_NORMAL*/
#define ZCS_LOG_INFO                3   /* PRN_LEVEL_HIGH*/
#define ZCS_LOG_WARN                4   /* PRN_LEVEL_HIGH*/
#define ZCS_LOG_ERROR               5   /* PRN_LEVEL_HIGHEST*/
#define ZCS_LOG_DISABLE_ALL         6   /* ��ֹ������־��� */
#define ZCS_LOG_LVL_NUM             5

/* log buffer numbering, start from 0, mainly named after the name of modules by which the buffer is used */
typedef enum
{
    ZCS_LOG_BUF_GNR = 0,    /* 0, for ZCS general purpose, including LA management  */
    ZCS_LOG_BUF_ZCMS,             /* 1, for ZCMS */
    ZCS_LOG_BUF_ZCRS,             /* 2, forZCS_LOG_ZCRS */
    ZCS_LOG_BUF_ZCPS,            /* 3, for ZCPS */
    ZCS_LOG_BUF_DBCORE,         /* 4,for DB core*/
    TOTOAL_BUF_COUNTS           /*  */
}T_log_buffer_numbering;

/* ��־���ģ�� */
typedef enum
{
    ZCS_LOG_MOD_GNR = 0,     /* 0, for ZCS general purpose, including LA management  */
    ZCS_LOG_MOD_ZCMS,           /* 1, for ZCMS */
    ZCS_LOG_MOD_ZCRS,            /* 2, forZCS_LOG_ZCRS */
    ZCS_LOG_MOD_ZCPS,           /* 3, for ZCPS */
    NUM_MODULES                /*  */
} ZCS_MODULE_NAMES;

/* ��־���Ŀ�� */
#define LOG_TARGET_NONE       0x00000000
#define LOG_TARGET_OSS_PRINTF 0x00000001
#define LOG_TARGET_MEM        0x00000002
#define LOG_TARGET_EXC_LOG    0x00000004
#define LOG_TARGET_PRINTF     0x00000008
#define ZCS_LOG_TARGET_ALL    (LOG_TARGET_OSS_PRINTF | LOG_TARGET_MEM \
                               | LOG_TARGET_EXC_LOG | LOG_TARGET_PRINTF)
#define ZCS_LOG_MAX_TRGT      4

#define ZCS_MODULE_NAME_MAX_LEN         32  /* ���ģ�������� */
#define ZCS_TRGT_NAME_MAX_LEN           32  /* ����ӡĿ�������� */

#ifndef ZCS_DUMP_SIGNATURE
#define ZCS_DUMP_SIGNATURE              "ZCS-> " /* ZCSģ���ӡ��־ */
#endif

#define TRACE_CODE2FLAG(code)     (0x00000001<<(code ? (code-1):0)) 
#define TRACE_ALL(code)           (code == 0xff)


#if 0
VOID ZCSLogImpl(INT lvl, INT mod, INT err_no, const CHAR* format, va_list argptr);
#endif

#define ZCS_BUFLEN      0x4000
#define ZCS_MAX_MSGLEN  0x80

typedef struct _t_mem_print_buf
{
    char *debug_buf;
    char *debug_buf_tail;
    WORD32 buflen;/* �����ʣ�೤�� */
    WORD32 wTotalLen; /* buff�ܳ��� */
    BYTE ucLogEntityFlag;              /*�Ƿ��ʼ��*/
}t_mem_print_buf;

/*
 * �ṹ: T_ZCS_Logger
 * ����: ģ���ӡ���ƽṹ
 */
typedef struct tagZCS_Logger
{
    INT iLogLvl;                                    /* ��ģ��Ĵ�ӡ���𣬵��ڴ˼�������󽫱����� */
    CHAR acModuleName[ZCS_MODULE_NAME_MAX_LEN + 1]; /*  ģ���� */
    WORD32 adwTrgt[ZCS_LOG_LVL_NUM + 1];            /*  ���Ŀ������, �ڴ棬�ļ�����׼�����, ��0��� */
    t_mem_print_buf *mem_buf;
    BOOLEAN accessNeedLock;
} T_ZCS_Logger, *P_ZCS_Logger;

/* shutdown ZCS log, to clear any information in all buffers */
#ifdef __cplusplus
extern "C" {
#endif
SWORD32 ZCSInitLogSema(VOID);
VOID ZCSLogShutdown(VOID);
VOID ZCSLogRestoreDefaultSetting(VOID);
VOID ZCSLogSetLvl(const CHAR* pcLogLvl, const CHAR* pcLogMod);
VOID ZCSLogSetTarget(const CHAR* pcLogTrgt, const CHAR* pcLogLvl, const CHAR* pcLogMod);
VOID ZCSLogDisable(const CHAR* pcLogMod);
VOID ZCSLogPrintLvl(VOID);
VOID ZCSLogPrintMod(VOID);
VOID ZCSLogPrintOutputTrgt(VOID);
VOID ZCSLogHelp(VOID);

extern WORD32 ZCS_Mem_Printf(t_mem_print_buf *buf, const CHAR* format, ...);
VOID _ZCS_MemPrintfShow(t_mem_print_buf *buf);
void ZCS_ZCMSMemPrintfClear(VOID);
VOID ZCS_ZCMSMemPrintfShow(VOID);

void ZCS_ZCRSMemPrintfClear(VOID);
VOID ZCS_ZCRSMemPrintfShow(VOID);

void ZCS_ZCPSMemPrintfClear(VOID);
VOID ZCS_ZCPSMemPrintfShow(VOID);

#if !ZCS_LOG_OPT
VOID ZCS_LOG(INT lvl, INT mod, const CHAR* format, ...);

#define PRINT_CUR_SYS_TIME (void)0
/* log��¼ */
#else

#define ZCS_LOG(lvl, mod, args...) ZCSLog((CHAR*)__FUNCTION__, __LINE__,(lvl), (mod), ##args)


typedef char *          ZCS_va_list;

typedef struct tagT_LogTime
{
    WORD32 dwSec_F;                      /* ��һ��log��ʱ��(����)     */
    WORD16 wMiliSec_F;                   /* ��һ��log��ʱ��(������)   */
    WORD16 wMiliSec_E;                   /* ���һ��log��ʱ��(����)   */
    WORD32 dwSec_E;                      /* ���һ��log��ʱ��(������) */
}T_LogTime;


/* ֱ�Ӽ�¼*/
typedef struct tagT_ZCSLogInfo
{
    WORD32 dwSec;                      /* ��*/
    WORD16 wMilliSec;                  /* ����*/
    BYTE      ucPad[2];
}T_ZCSLogInfo;

#define MAX_FUNC_NAMELEN    20           /* ����������󳤶ȣ����������ֻȡǰ�����ֽ�          */
#define MAX_LOG_LEN        0xff

#define INFO_COMP_PCNT             (0.5)  */
#define INFO_COM_LEN(tot)          (tot>>1)            /* ���ñȽ�log�ĳ���Ϊ�ܳ��ȵ�50% */

/* ��Ҫ��Ӧ��ͬ��¼��log */
typedef struct tagT_LogInfo
{
    CHAR        *prev;                              /* ǰһ����¼*/
    CHAR        acFuncName[MAX_FUNC_NAMELEN];       /* Log��¼���ڵĺ����� */
    WORD32      dwLine;                             /* Log��¼���ڵ��к�   */
    T_LogTime   tLogTime;                           /* log��¼ʱ������     */
    WORD16      wLogTimeNum;                /* �ظ���¼�Ĵ���      */
    WORD16      wPad;
    WORD32      dwInstIdx;                           /* ��¼JOB ID       */                           
}T_LogInfo;

/* ������Ϣ��ṹ��ֻ����ʱ��Ͳ���
�Լ���¼��ʽָ��*/
typedef struct tagT_CmptLogInfo
{
    CHAR        *pcFmt;                           /* ֻ��¼��ӡ��ʽָ��  */
    WORD16      wLogLen;                          /* ʵ��log��ĳ���     */
    WORD16      wLvl;                            /* level */
    /*
    union
    {
    T_ZCSLogInfo tZCSLogInfo;
    T_LogInfo    tLogInfo;
    }LogInfo;
    */
}T_CmptLogInfo;

#define log_p(p)          ((T_CmptLogInfo *)(p))
#define log_lvl(p)        (log_p(p)->wLvl)
#define log_ZCS(p)        ((T_ZCSLogInfo *)((T_CmptLogInfo *)(p)+1))
#define log_info(p)       ((T_LogInfo *)((T_CmptLogInfo *)(p)+1))
#define log_ZCS_para(p)   ((CHAR *)(p)+(WORDPTR)ST_ZCSINFO_LEN)
#define log_info_para(p)  ((CHAR *)(p)+(WORDPTR)ST_INFO_LEN)
#define log_fmt(p)        (log_p(p)->pcFmt)
#define log_len(p)        (log_p(p)->wLogLen)
#define log_para_len(p)   (log_len(p)-ST_INFO_LEN)
#define log_sec(p)        (log_ZCS(p)->dwSec)
#define log_milsec(p)     (log_ZCS(p)->wMilliSec)
#define log_prev(p)       (log_info(p)->prev)
#define log_line(p)       (log_info(p)->dwLine)
#define log_time(p)       (log_info(p)->tLogTime)
#define log_func(p)       (log_info(p)->acFuncName)
#define log_same(p)       (log_info(p)->wLogTimeNum)
#define log_inst_idx(p)   (log_info(p)->dwInstIdx)  


/* ��ӡ�ڴ�ؿ��ƽṹ */
typedef struct tagT_CmptLogPool
{
    WORD16      wLen;                           /*  ʣ��ռ�Ĵ�С       */
    WORD        wCmpSize;                        /* �Ƚϵ��ڴ�ռ�            */
    CHAR        *head;
    CHAR        *tail;
    CHAR        *prev;                          /*  ָ��ǰ��¼����һ�� */
    CHAR        *cur;                           /*  ָ��ǰ��¼��λ��*/
    CHAR        *next;                          /*  ָ��ǰ��¼����һ�� */
    CHAR        *last;                          /*  ָ�����һ����¼     */
    BYTE        ucFlag;
    BYTE        ucType;                         /* 1: ��һ�ַ�ʽ��pool�ع���
2: ����Ϣ�Ƚϵ�pool�ع��� */
    BYTE        ucLampFlag;                     /* 0 ��ʾδ����log, 1��ʾ����log*/
    BYTE        ucTrLvl;
}T_CmptLogPool;
/* �ڴ���־�������ڴ沼�����£�
*  | T_CmptLogPool  |      ƽ̹��ʽ��¼���ڴ�سؿ��ƽṹ
*  | ��־��¼��     |
*  | T_CmptLogPool  |      �ظ���Ϣ�ȽϷ�ʽ�ڴ�ؿ��ƽṹ
*  | ��־��¼��     |
*  �������Ͻṹ��˵����
* 1) ƽ̹��ʽ��¼ռ���ڴ��3/4��(�����ڴ�ؿ��ƽṹ) ��1/4�����ظ���־��jioa��¼
* 2) ����ƽ̹��ʽ��¼��־��ÿһ����־�ڴ�ṹ���£�
*               | pcFmt   |  4
*               | wLogLen |  2        T_CmptLogInfo�ṹ
*               | wLvl    |  2
*               | dwSec   |  4
*               | wMilliSec | 2
*               | ucPad   |  2
*               | para    |  ���Ȳ��̶�������֤��һ����־��4�ֽڶ���
* 3) �����ظ���¼�ȽϷ�ʽ��¼��־��ÿһ����־�ڴ�ṹ���£�
*               | pcFmt      |  4
*               | wLogLen    |  2        T_CmptLogInfo�ṹ
*               | wLvl       |  2
*               | prev       |  4
*               | acFuncName |  12
*               | dwLine     |  4
*               | dwSec_F    |  4
*               | wMiliSec_F |  2
*               | wMiliSec_E |  2
*               | dwSec_E    |  4
*               | wLogTimeNum|  2
*               | ucPad      |  2
*               | para       |  ���Ȳ��̶�������֤��һ����־��4�ֽڶ���
*/

#define POOL_INITED           (BYTE)0x01
#define POOL_OVERFLOW         (BYTE)0x02
#define POOL_ZCSLOG_TYP       (BYTE)0x01
#define POOL_LOG_TYP          (BYTE)0x02
#define POOL_IS_ZCSLOG(pl)    ((pl)->ucType == POOL_ZCSLOG_TYP)

#define ST_ZCSINFO_LEN        (sizeof(T_CmptLogInfo)+sizeof(T_ZCSLogInfo))
#define ST_INFO_LEN           (sizeof(T_CmptLogInfo)+sizeof(T_LogInfo))

#define POOL_IS_OVERFLOW(pl)  ((pl)->ucFlag & POOL_OVERFLOW)
#define POOL_IS_EMPTY(pl)     ((pl)->last == (pl)->head && (pl)->cur == (pl)->head)
#define LOG_POOL_SIZE(pl)         ((pl)->tail-(pl)->head+1)
#define IS_LAST_LOG(pl)       (POOL_IS_OVERFLOW(pl) && (pl)->last == (pl)->next)
#define LOG_LEN(p)            (log_len(p))
#define LOG_FRAG_LEN(pl)      ((pl)->next<(pl)->cur ? (pl)->wLen : ((pl)->next-(pl)->cur))

#define LOG_MEM_LOCK          (BYTE)0x01
#define LOG_MEM_UNLOCK        (BYTE)0x00


#define FMT_COPY(pl,fmt,len) \
do\
{\
    (pl)->prev = (pl)->cur;\
    memcpy((pl)->cur,(fmt),(len));\
    if(!POOL_IS_OVERFLOW(pl))\
    {\
        (pl)->last = (pl)->cur;\
    }\
    else\
    {\
        if((pl)->cur+(len) > (pl)->last)\
        {\
            (pl)->last = (pl)->cur;\
        }\
    }\
    (pl)->cur += (len);\
    (pl)->wLen -= (len);\
}while(0)

#define UPD_NEXT_POS(pl, cur)  ((pl)->next = ((pl)->next+LOG_LEN(cur) > (pl)->tail ? (pl)->head:(pl)->next+LOG_LEN(cur)))
#define ZCS_MAX_MSGLEN  0x80


#if 0
VOID ZCSLogImpl(INT lvl, INT mod, INT err_no, const CHAR* format, va_list argptr);
#endif

#define LOG_TIME_SET(pt, p)  ((pt)->dwSec = (p)->dwSecond,(pt)->wMilliSec = (p)->wMilliSec)
#define LOG_TIME_SEC(p)      ((p)->dwSec)
#define LOG_TIME_MILSEC(p)   ((p)->wMilliSec)
#define LOG_TIME_SEQ(p)      ((p)->wTimeSeq)
#define LOG_TIME_NUM_INC(pi) ((pi)->wLogTimeNum++)

#define LOG_TIME(p, pt)            ((pt)->dwSecond = (p)->dwSec,(pt)->wMilliSec = (p)->wMilliSec)
#define LOG_FIRST_TIME_SEC(p)  ((p)->tLogTime.dwSec_F)
#define LOG_FIRST_TIME_MSEC(p) ((p)->tLogTime.wMiliSec_F)
#define LOG_LAST_TIME_SEC(p)   ((p)->tLogTime.dwSec_E)
#define LOG_LAST_TIME_MSEC(p)  ((p)->tLogTime.wMiliSec_E)
#define LOG_FIRST_TIME_GET(p, pt)  \
        do\
        {\
            (pt)->dwSecond = LOG_FIRST_TIME_SEC(p);\
            (pt)->wMilliSec = LOG_FIRST_TIME_MSEC(p);\
        }while(0)
#define LOG_LAST_TIME_GET(p, pt)  \
        do\
        {\
            (pt)->dwSecond = LOG_LAST_TIME_SEC(p);\
            (pt)->wMilliSec = LOG_LAST_TIME_MSEC(p);\
        }while(0)
#define LOG_FIRST_TIME_SET(p, pt)  \
        do\
        {\
            LOG_FIRST_TIME_SEC(p)  = (pt)->dwSecond; \
            LOG_FIRST_TIME_MSEC(p) = (pt)->wMilliSec;\
        }while(0)
#define LOG_LAST_TIME_SET(p, pt)  \
        do\
        {\
            LOG_LAST_TIME_SEC(p)  = (pt)->dwSecond;\
            LOG_LAST_TIME_MSEC(p) = (pt)->wMilliSec;\
        }while(0)


#ifndef MIN
#define MIN(a, b)        (((a)<(b))?(a):(b))
#endif
#define LOG_POOL_INITED  0x01         /* */
#define LOG_SAME_ADPT    0x04         /* �Ƿ�������ͬlog������Ӧ*/
#define LOG_INFO_COMP    0x08         /* �Ƿ���������Ϣ��ıȽ� */

#define POOL_IS_INITED(pl)    ((pl)->ucFlag & POOL_INITED)
#define POOL_INIT(pl)         ((pl)->ucFlag |= LOG_POOL_INITED)

#define LOG_POOL_FLAG_SET(pl, fg) ((pl)->ucFlag |= fg)

#define LOG_SAME_IS_ADPTED(pl)    ((pl)->ucFlag&LOG_SAME_ADPT)

#define GET_COM_SIZE(pl)     ((pl)->wCmpSize)
#define SET_COM_SIZE(pl,n)   ((pl)->wCmpSize = (n))

#define PRINT_SYS_TIME(pt)\
            do\
            {\
                T_SysSoftClock tSysTm;\
                OSS_TimeToClock(pt, &tSysTm);\
                printf("[%02d-%02d %02d:%02d:%02d:%03d]",\
                        tSysTm.ucSysMon, tSysTm.ucSysDay, tSysTm.ucSysHour, tSysTm.ucSysMin, tSysTm.ucSysSec, tSysTm.wMilliSec);\
            }while(0)

#ifdef DEBUG_VERSION
#define PRINT_CUR_SYS_TIME \
            do\
            {\
                T_SysSoftClock tSysTm;\
                OSS_GetSysClock(&tSysTm);\
                printf("System current time:");\
                printf("[%02d-%02d %02d:%02d:%02d:%03d]",\
                        tSysTm.ucSysMon, tSysTm.ucSysDay, tSysTm.ucSysHour, tSysTm.ucSysMin, tSysTm.ucSysSec, tSysTm.wMilliSec);\
                printf("\n");\
            }while(0)
#else
#define PRINT_CUR_SYS_TIME (void)0
#endif

#define LOG_TYPE_PCNT      (0.75)      */
#define ZCSLOG_TYPE_LEN(tot)          ((((tot)<<1)+(tot))>>2)            /* ԭ�е�log��ʽ��ռ�ڴ�ı���75%*/

/*
1)�����������
2)��Ҫ�����;���ƽ̨��¼����
��ڶ��ּ�¼��ʽ,��¼�����ڴ�
*/
#define LOG_POOL(head, mod, type) \
    ((T_CmptLogPool *)LOG_ALIGN((WORDPTR)((head)[mod].mem_buf->debug_buf+\
                                                                    ((type) == POOL_ZCSLOG_TYP||IsModTraceStart(mod)\
        ? 0:(WORD32)ZCSLOG_TYPE_LEN((head)[mod].mem_buf->wTotalLen)))))
#define LOG_POOL_TAIL(head, mod,type) \
    ((CHAR *)((head)[mod].mem_buf->debug_buf+((type) == POOL_ZCSLOG_TYP&&!IsModTraceStart(mod) \
        ? (WORDPTR)(ZCSLOG_TYPE_LEN((head)[mod].mem_buf->wTotalLen) -1) : (head)[mod].mem_buf->wTotalLen-1)))

/* ��int��(4�ֽ�)���� */
#ifndef __ALIGNBYTES
#define __ALIGNBYTES  (sizeof(int) - 1)
#endif
#define LOG_ALIGN(n)    (((n) + __ALIGNBYTES) & ~__ALIGNBYTES)

BOOL IsModTraceStart(INT mod);
void ZCSMemLogInit(INT typ, INT mod);
INT ZCSMemLogTrace(INT mod, INT lvl);            /* ��ģ��Ĵ��������Ϣ�����ڴ��¼*/
void ZCSLogFmt(T_CmptLogPool *pl, char *fmt, int len);
void ZCSLog(char *pcFunc, WORD32 dwLine,  INT lvl, INT mod, const CHAR* format, ...);
void ZCSMemLog(INT lvl, INT32 mod, CHAR *pcFunc, WORD32 dwLine, char *fmt, char *pcLog, INT32 iLogLen);
BOOL IsSameLogInfo(T_CmptLogPool *pl, T_CmptLogInfo *ptSrc, T_CmptLogInfo *ptDst);
SWORD32 ZCS_vsnprintf(CHAR *pcBuffer, WORD32 dwMaxCount, const CHAR  *pcParamFormat, ZCS_va_list vaList);
SWORD32 ZCS_argsprintf(CHAR *pcBuffer, WORD32  dwMaxCount, const CHAR  *pcParamFormat, va_list  vaList);
int ZCS_MemPrintf(INT lvl, INT mod, CHAR *fmt,CHAR *args, INT32 argLen);

INT ZCS_trace(INT mod, INT lvl);
INT ZCS_trace_stop(INT mod);

#endif/* end of ZCS_LOG_OPT */

#ifdef __cplusplus
}
#endif

#endif
