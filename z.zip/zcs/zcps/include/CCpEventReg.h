/*
 * CCpEventReg.h
 *
 *  Created on: 2014-9-3
 *      Author: wangjun
 *      ����ϲ�Ӧ�õ�ע������
 */

#ifndef CCPEVENTREG_H_
#define CCPEVENTREG_H_
#include <stdint.h>
#include "tulip.h"
#include "tulip_oss.h"

#include "zenic_def.h"
#include "CInstMgr.hpp"
#include "CSyncMsg.h"
#include "sdnlock.hpp"

#define DBG_APP_ANY 0xffff
#define DBG_DATA_ANY 0xffff

const uint16_t ZCPS_MAX_REG_APP = 512;
struct T_ZCPS_EVENT_REG_VALUE {
    uint16_t app_id;
    uint16_t data_type;
    uint16_t resource_key_len;
    uint16_t record_key_len;
    uint32_t max_record_num;
    uint32_t used_record_num;
    bool neekChgOver;
    
    uint32_t sent_msg;
    uint32_t sent_msg_tmp;
    uint32_t sent_request_msg;
    uint32_t sent_request_msg_tmp;
    uint32_t zcps_sent_msg[ZCS_MAX_NODE_NUM];
    uint32_t zcps_sent_msg_tmp[ZCS_MAX_NODE_NUM];
    uint32_t recv_ack;
    uint32_t recv_ack_tmp;
    uint32_t recv_msg;
    uint32_t recv_msg_tmp;
    uint32_t sent_notify_msg[4];//add,mod,del,other
    uint32_t sent_notify_msg_tmp[4];
    uint32_t retry_send_msg;
    uint32_t retry_send_msg_tmp;
    uint32_t over_retry_send_msg;
    uint32_t over_retry_send_msg_tmp;
    JID     regJid;
};

struct T_ZCPS_EVENT_REG_KEY {
    uint16_t app_id;
    uint16_t data_type;
}_ZENIC_PACKED;

class CCpEventReg {
    static InstMgr::CInstMgr1<T_ZCPS_EVENT_REG_KEY,T_ZCPS_EVENT_REG_VALUE> m_event_reg;
    static zenic::sdn_mutex m_event_reg_mutex;

public:
    CCpEventReg();
    static T_ZCPS_EVENT_REG_VALUE * findRegInfo(uint16_t app_id, uint16_t data_type);
    /*��ʼ��m_event_reg*/
    static ZENIC_RESULT init();
    /*��������ע��*/
    static ZENIC_RESULT onRegisterData(const uint8_t *msg);
    /*����ע�����ݣ�����������Ϣͳ�Ƽ�����*/
    static ZENIC_RESULT findRegInfoIncCounter(uint16_t app_id,uint16_t data_type, T_ZCPS_EVENT_REG_VALUE &tValue);
    /*����ע�����ݣ������¼�����*/
    static ZENIC_RESULT findRegInfo(uint16_t app_id,uint16_t data_type, T_ZCPS_EVENT_REG_VALUE &tValue);
    /*��ӡͳ����Ϣ*/
    static void print_stats(uint32_t isPrintStats);    
    static void print_app_stats();
    static void clean_reg_stats(uint32_t isCleanAllHistory);    
    static void clean_reg_tmp_stats();    
    static void inc_notify_stats(uint16_t app_id, uint16_t data_type,T_ZCS_DATA_OP dataop);    
    static void inc_ack_stats(uint16_t app_id, uint16_t data_type);
    static void inc_request_stats(uint16_t app_id, uint16_t data_type);
    static void inc_retry_stats(uint16_t app_id, uint16_t data_type);    
    static void inc_over_retry_stats(uint16_t app_id, uint16_t data_type);
    static void print_stats_send(uint16_t nodeId);
    /*֪ͨ�ϲ�Ӧ�ã����¼�����*/
    static ZENIC_RESULT notifyApp(T_ZCPS_MSG &tMsg);

    /*���ӽ��ռ�����*/
    static void incRecvCounter(uint16_t app_id,uint16_t data_type);
    /*���ӷ��ͼ�����*/
    static void incSendCounter(uint16_t app_id, uint16_t data_type, uint16_t node_id);    
    virtual ~CCpEventReg();
};

#endif /* CCPEVENTREG_H_ */
