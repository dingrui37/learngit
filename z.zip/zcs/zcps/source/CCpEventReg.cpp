/*
 * CCpEventReg.cpp
 *
 *  Created on: 2014-9-3
 *      Author: wangjun
 */

#include "CCpEventReg.h"

InstMgr::CInstMgr1<T_ZCPS_EVENT_REG_KEY,T_ZCPS_EVENT_REG_VALUE> CCpEventReg::m_event_reg;
zenic::sdn_mutex CCpEventReg::m_event_reg_mutex;

CCpEventReg::CCpEventReg() {
    // TODO Auto-generated constructor stub

}

/*����ע���ʼ��*/
ZENIC_RESULT CCpEventReg::init() {
    int ret;
    ret = m_event_reg.init(ZCPS_MAX_REG_APP);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        printf("[ZCPS]Init Event Registry failed,ret=%d\n",ret);
    }
    return RESULT_ZENIC_SUCCESS;
}

/*����ע��*/
ZENIC_RESULT CCpEventReg::onRegisterData(const uint8_t *msg)
{
    T_EV_ZCS_RGISTER_DATA_REQ *ptReg=(T_EV_ZCS_RGISTER_DATA_REQ *)msg;
    T_ZCPS_EVENT_REG_KEY tKey;
    uint32_t idx;
    int ret;
    JID tJid;
    XOS_Sender(&tJid);
    if(ptReg->app_id==0)
        tKey.app_id = (tJid.dwJno>>16);
    else
        tKey.app_id = ptReg->app_id;

    tKey.data_type = ptReg->data_type;
    ret = m_event_reg.allocInstByKey1(tKey,idx);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG_SIMPLE(LOG_ERROR,"[ZCRS]Register data fail, jno=0x%x, data_type=%u,ret=%d\n",
                tJid.dwJno,ptReg->data_type,ret);
        return ERROR_ALLOC_INSTANCE_FAIL;
    }

    m_event_reg[idx].app_id = tKey.app_id;
    m_event_reg[idx].data_type = tKey.data_type;
    m_event_reg[idx].max_record_num = ptReg->max_record_num;
    m_event_reg[idx].used_record_num = 0;
    m_event_reg[idx].neekChgOver = ptReg->needChgOverNotify;
    m_event_reg[idx].record_key_len = ptReg->record_key_len;
    m_event_reg[idx].resource_key_len = ptReg->resource_key_len;
    
    m_event_reg[idx].recv_msg = 0;    
    m_event_reg[idx].recv_msg_tmp = 0;
    m_event_reg[idx].recv_ack = 0;    
    m_event_reg[idx].recv_ack_tmp = 0;
    m_event_reg[idx].sent_msg = 0;
    m_event_reg[idx].sent_msg_tmp = 0;
    m_event_reg[idx].sent_request_msg = 0;
    m_event_reg[idx].sent_request_msg_tmp = 0;
    m_event_reg[idx].retry_send_msg = 0;
    m_event_reg[idx].retry_send_msg_tmp = 0;
    m_event_reg[idx].over_retry_send_msg = 0;
    m_event_reg[idx].over_retry_send_msg_tmp = 0;
    memset(m_event_reg[idx].sent_notify_msg,0,sizeof(m_event_reg[idx].sent_notify_msg));
    memset(m_event_reg[idx].sent_notify_msg_tmp,0,sizeof(m_event_reg[idx].sent_notify_msg_tmp));
    memset(m_event_reg[idx].zcps_sent_msg,0,ZCS_MAX_NODE_NUM);
    memset(m_event_reg[idx].zcps_sent_msg_tmp,0,ZCS_MAX_NODE_NUM);
    XOS_Sender(&m_event_reg[idx].regJid);
    return RESULT_ZENIC_SUCCESS;
}

/*����ע�����ݣ�����ֵ�����ҶԷ��ͼ�����+1����*/
ZENIC_RESULT CCpEventReg::findRegInfoIncCounter(uint16_t app_id,
        uint16_t data_type, T_ZCPS_EVENT_REG_VALUE& tValue)
{
    T_ZCPS_EVENT_REG_VALUE *pRegInfo = findRegInfo(app_id,data_type);
    if(NULL==pRegInfo)
        return ERROR_RECORD_NOT_FOUND;

    memcpy(&tValue,pRegInfo,sizeof(T_ZCPS_EVENT_REG_VALUE));
    pRegInfo->sent_msg++;
    pRegInfo->sent_msg_tmp++;
    return RESULT_ZENIC_SUCCESS;
}

/*����һ�����ݼ�¼*/
ZENIC_RESULT CCpEventReg::findRegInfo(uint16_t app_id, uint16_t data_type,
        T_ZCPS_EVENT_REG_VALUE& tValue)
{

    T_ZCPS_EVENT_REG_VALUE *pRegInfo = findRegInfo(app_id,data_type);
    if(NULL==pRegInfo)
        return ERROR_RECORD_NOT_FOUND;

    memcpy(&tValue,pRegInfo,sizeof(T_ZCPS_EVENT_REG_VALUE));
    return RESULT_ZENIC_SUCCESS;
}

void CCpEventReg::print_stats_send(uint16_t nodeId)
{
    bool isSend;
    T_ZCPS_EVENT_REG_VALUE *ptReg;
    printf("---------------------ZCPS_EVENT_SEND_MASSAGE---------------\n");
    printf("app_id   data_type   to_nodeId   sendNum/sendtmp   Jno\n");
    printf("-----------------------------------------------------------\n");
    for(uint32_t i=0;i<m_event_reg.getTotalInstNum();i++)
    {
        isSend = false;
        if(m_event_reg.getInstanceState(i)==InstMgr::INST_STATE_ALLOCATED)
        {
            ptReg = &m_event_reg[i];
            if(ZCS_INVALID_NODEID != nodeId)
            {
                if(0 != ptReg->zcps_sent_msg[nodeId])
                {
                    printf("0x%4x   %8u    %8u   %8u/%-8u   0x%8x\n", ptReg->app_id, ptReg->data_type,
                            nodeId==0?ZCS_MASTER_NODE_ID_2:nodeId, ptReg->zcps_sent_msg[nodeId],ptReg->zcps_sent_msg_tmp[nodeId], ptReg->regJid.dwJno);
                    printf("-----------------------------------------------------------\n");
                }
                continue;
            }
            for(uint32_t j=0;j<ZCS_MAX_NODE_NUM;j++)
            {                
                if(0 != ptReg->zcps_sent_msg[j])
                {
                    printf("0x%4x   %8u    %8u   %8u/%-8u   0x%8x\n", ptReg->app_id, ptReg->data_type,
                            j==0?ZCS_MASTER_NODE_ID_2:j, ptReg->zcps_sent_msg[j],ptReg->zcps_sent_msg_tmp[j], ptReg->regJid.dwJno);
                    isSend = true;
                }
            }
            if(isSend)
            {
                printf("--------------------------------------------------------\n");
            }
        }
    }
    printf("****************************END*****************************\n");
}

void CCpEventReg::clean_reg_stats(uint32_t isCleanAllHistory)
{
    clean_reg_tmp_stats();
    if(0 == isCleanAllHistory)
        return;
    T_ZCPS_EVENT_REG_VALUE *ptReg;
    for(uint32_t i=0;i<m_event_reg.getTotalInstNum();i++)
    {
        if(m_event_reg.getInstanceState(i)==InstMgr::INST_STATE_ALLOCATED)
        {
            ptReg = &m_event_reg[i];
            ptReg->sent_msg = 0;
            ptReg->sent_request_msg = 0;
            ptReg->recv_msg = 0;
            ptReg->recv_ack = 0;  
            ptReg->retry_send_msg = 0;
            ptReg->over_retry_send_msg = 0;
            memset(ptReg->sent_notify_msg,0,sizeof(ptReg->sent_notify_msg));
            memset(ptReg->zcps_sent_msg,0,ZCS_MAX_NODE_NUM);
        }        
    }
}

void CCpEventReg::clean_reg_tmp_stats()
{
    T_ZCPS_EVENT_REG_VALUE *ptReg;
    for(uint32_t i=0;i<m_event_reg.getTotalInstNum();i++)
    {
        if(m_event_reg.getInstanceState(i)==InstMgr::INST_STATE_ALLOCATED)
        {
            ptReg = &m_event_reg[i];
            ptReg->sent_msg_tmp = 0;
            ptReg->sent_request_msg_tmp = 0;
            ptReg->recv_msg_tmp = 0;
            ptReg->recv_ack_tmp = 0;
            ptReg->retry_send_msg_tmp = 0;
            ptReg->over_retry_send_msg_tmp = 0;
            memset(ptReg->sent_notify_msg_tmp,0,sizeof(ptReg->sent_notify_msg_tmp));
            memset(ptReg->zcps_sent_msg_tmp,0,ZCS_MAX_NODE_NUM);
        }        
    }    
}

void CCpEventReg::inc_notify_stats(uint16_t app_id, uint16_t data_type,T_ZCS_DATA_OP dataop)
{
    T_ZCPS_EVENT_REG_VALUE *pRegInfo = findRegInfo(app_id,data_type);    
    if(NULL==pRegInfo)
            return ;
    switch(dataop)
    {
        case ZCS_DATA_OP_ADD:
        {
            pRegInfo->sent_notify_msg[0]++;
            pRegInfo->sent_notify_msg_tmp[0]++;
            break;
        }
        case ZCS_DATA_OP_MODIFY:
        {
            pRegInfo->sent_notify_msg[1]++;
            pRegInfo->sent_notify_msg_tmp[1]++;
            break;
        }
        case ZCS_DATA_OP_DELETE:
        {
            pRegInfo->sent_notify_msg[2]++;
            pRegInfo->sent_notify_msg_tmp[2]++;
            break;
        }
        default:
        {
            pRegInfo->sent_notify_msg[3]++;
            pRegInfo->sent_notify_msg_tmp[3]++;
        }        
    }
}

void CCpEventReg::inc_ack_stats(uint16_t app_id, uint16_t data_type)
{
    T_ZCPS_EVENT_REG_VALUE *pRegInfo = findRegInfo(app_id,data_type);    
    if(NULL==pRegInfo)
            return ;
    pRegInfo->recv_ack++;
    pRegInfo->recv_ack_tmp++;
}

void CCpEventReg::inc_request_stats(uint16_t app_id, uint16_t data_type)
{
    T_ZCPS_EVENT_REG_VALUE *pRegInfo = findRegInfo(app_id,data_type);    
    if(NULL==pRegInfo)
            return ;
    pRegInfo->sent_request_msg++;
    pRegInfo->sent_request_msg_tmp++;
}

void CCpEventReg::inc_retry_stats(uint16_t app_id, uint16_t data_type)
{
    T_ZCPS_EVENT_REG_VALUE *pRegInfo = findRegInfo(app_id,data_type);    
    if(NULL==pRegInfo)
            return ;
    pRegInfo->retry_send_msg++;
    pRegInfo->retry_send_msg_tmp++;
}

void CCpEventReg::inc_over_retry_stats(uint16_t app_id, uint16_t data_type)
{
    T_ZCPS_EVENT_REG_VALUE *pRegInfo = findRegInfo(app_id,data_type);
    if(NULL==pRegInfo)
            return ;
    pRegInfo->over_retry_send_msg++;
    pRegInfo->over_retry_send_msg_tmp++;
}

void CCpEventReg::print_stats(uint32_t isPrintStats)
{
    T_ZCPS_EVENT_REG_VALUE *ptReg;

    printf("-----------------------------------------------ZCPS_EVENT_REGISTRY---------------------------------------------\n");
    printf("AppId      DataType MaxRecNum UsedNum ChgOver ResKLen RecKLen     Jno    Send2AppNotify  Send2AppNotifyDetails \n");
    printf("---------------------------------------------------------------------------------------------------------------\n");
    for(uint32_t i=0;i<m_event_reg.getTotalInstNum();i++)
    {
        if(m_event_reg.getInstanceState(i)==InstMgr::INST_STATE_ALLOCATED)
        {
            ptReg = &m_event_reg[i];
            uint32_t total = 0;
            uint32_t total_tmp = 0;
            for(uint32_t nodeid = 0;nodeid < ZCS_MAX_NODE_NUM;nodeid++)
            {
                total += ptReg->zcps_sent_msg[nodeid];
                total_tmp += ptReg->zcps_sent_msg_tmp[nodeid];
            }
            printf("0x%-8x %-8u %-9u %-7u %-7s %-7u %-7u 0x%-8x %8u/%-8u (%u:%u:%u:%u)/(%u:%u:%u:%u)\n",
                ptReg->app_id,ptReg->data_type,ptReg->max_record_num,ptReg->used_record_num,
                ptReg->neekChgOver?"true":"false",
                ptReg->resource_key_len,ptReg->record_key_len,
                ptReg->regJid.dwJno,
                ptReg->sent_notify_msg[0]+ptReg->sent_notify_msg[1]+ptReg->sent_notify_msg[2]+ptReg->sent_notify_msg[3],
                ptReg->sent_notify_msg_tmp[0]+ptReg->sent_notify_msg_tmp[1]+ptReg->sent_notify_msg_tmp[2]+ptReg->sent_notify_msg_tmp[3],
                ptReg->sent_notify_msg[0],ptReg->sent_notify_msg[1],ptReg->sent_notify_msg[2],ptReg->sent_notify_msg[3],
                ptReg->sent_notify_msg_tmp[0],ptReg->sent_notify_msg_tmp[1],ptReg->sent_notify_msg_tmp[2],ptReg->sent_notify_msg_tmp[3]);
        }
    }

    printf("zcps_event_reg: capactity=%u, registered=%u\n",
            m_event_reg.getTotalInstNum(),m_event_reg.getAllocatedInstNum());
    if(isPrintStats)
        print_app_stats();
}

void CCpEventReg::print_app_stats()
{
    T_ZCPS_EVENT_REG_VALUE *ptReg;
    printf("-----------------------------------------------------------------ZCPS_EVENT_REGISTRY_STATS-------------------------------------------------------------------\n");
    printf("%-10s %-8s %-7s %17s %17s %17s %17s %17s %17s %s\n",
        "AppId","DataType","UsedNum","   RcvAppSync    ","Send2PeerNodeNum ","  RcvPeerNodeAck "," RcvPeerNodeSync ","Send2AppRequest"," Send2PeerRetry  ","Send2PeerOverRetry");
    printf("-------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
    for(uint32_t i=0;i<m_event_reg.getTotalInstNum();i++)
    {
        if(m_event_reg.getInstanceState(i)==InstMgr::INST_STATE_ALLOCATED)
        {
            ptReg = &m_event_reg[i];
            uint32_t total = 0;
            uint32_t total_tmp = 0;
            for(uint32_t nodeid = 0;nodeid < ZCS_MAX_NODE_NUM;nodeid++)
            {
                total += ptReg->zcps_sent_msg[nodeid];
                total_tmp += ptReg->zcps_sent_msg_tmp[nodeid];
            }
            printf("0x%-8x %-8u %-7u %8u/%-8u %8u/%-8u %8u/%-8u %8u/%-8u %8u/%-8u %8u/%-8u %8u/%-8u\n",
                ptReg->app_id,ptReg->data_type,ptReg->used_record_num,
                ptReg->sent_msg,ptReg->sent_msg_tmp, 
                total,total_tmp, 
                ptReg->recv_ack,ptReg->recv_ack_tmp,
                ptReg->recv_msg,ptReg->recv_msg_tmp,
                ptReg->sent_request_msg,ptReg->sent_request_msg_tmp,
                ptReg->retry_send_msg,ptReg->retry_send_msg_tmp,
                ptReg->over_retry_send_msg,ptReg->over_retry_send_msg_tmp);
        }
    }

    printf("**************************************************************************END********************************************************************************\n");
}

/*��Ӧ�÷���һ������ͬ����Ϣ*/
ZENIC_RESULT CCpEventReg::notifyApp(T_ZCPS_MSG& tMsg)
{
    uint8_t buf[ZCS_MAX_MSG_LEN];
    XOS_STATUS ret;
    T_EV_ZCS_SYNC_DATA_NOTIFY *ptDataNotify = (T_EV_ZCS_SYNC_DATA_NOTIFY *)buf;
    T_ZCPS_EVENT_REG_VALUE *pRegInfo = findRegInfo(tMsg.tSyncHdr.app_id,tMsg.tSyncHdr.tDataKey.data_type);
    if(pRegInfo==NULL)
    {
        return ERROR_RECORD_NOT_FOUND;
    }

    /*��������ͬ��֪ͨ��Ϣ*/
    memcpy(&ptDataNotify->tResKey,&tMsg.tSyncHdr.tResKey,sizeof(T_ZCS_RESOURCE_KEY));
    memcpy(&ptDataNotify->tDataKey,&tMsg.tSyncHdr.tDataKey,sizeof(T_ZCS_DATA_KEY));
    ptDataNotify->dataop = tMsg.tSyncHdr.dataop;
    ptDataNotify->dataversion = tMsg.tSyncHdr.dataversion;
    ptDataNotify->data_len = tMsg.tSyncHdr.data_len;
    memcpy(ptDataNotify+1,tMsg.data,tMsg.tSyncHdr.data_len);
    ret = XOS_SendAsynMsg(EV_SYS_ZCS_NOTIFY_SYNC_DATA,buf,sizeof(T_EV_ZCS_SYNC_DATA_NOTIFY)+ptDataNotify->data_len,
            0,0,&pRegInfo->regJid);
    if(XOS_SUCCESS != ret)
    {
        return ERROR_SEND_MSG_FAIL;
    }
    inc_notify_stats(pRegInfo->app_id,pRegInfo->data_type,ptDataNotify->dataop);
    return RESULT_ZENIC_SUCCESS;
}

/*����һ��ע�����ݼ�¼��������ָ��*/
T_ZCPS_EVENT_REG_VALUE* CCpEventReg::findRegInfo(uint16_t app_id,
        uint16_t data_type) {
    T_ZCPS_EVENT_REG_KEY tKey;
     uint32_t idx;
     int ret;
     tKey.app_id = app_id;
     tKey.data_type = data_type;

     zenic::sdn_lock lock(m_event_reg_mutex);
     ret = m_event_reg.findInstByKey1(tKey,idx);
     if(ret!=InstMgr::RESULT_INST_SUCCESS)
     {
         ZCS_LOG_SIMPLE(LOG_ERROR,"[ZCPS]find register app fail, app_id=0x%x, data_type=%u,ret=%d\n",
                 app_id,data_type,ret);
         return NULL;
     }

     return &m_event_reg[idx];
}

/*���ӽ��ռ��������������ݽ��ղ�ͳ��ʹ��*/
void CCpEventReg::incRecvCounter(uint16_t app_id, uint16_t data_type)
{
    T_ZCPS_EVENT_REG_VALUE *pRegInfo = findRegInfo(app_id,data_type);
    if(NULL==pRegInfo)
        return ;
    pRegInfo->recv_msg++;
    pRegInfo->recv_msg_tmp++;
}

/*���ӷ��ͼ��������������ݷ��Ͳ�ͳ��ʹ��*/
void CCpEventReg::incSendCounter(uint16_t app_id, uint16_t data_type, uint16_t node_id)
{
    T_ZCPS_EVENT_REG_VALUE *pRegInfo = findRegInfo(app_id,data_type);
    if(NULL==pRegInfo)
    {
        return ;
    }
    if(ZCS_MASTER_NODE_ID_2 == node_id)
    {
        pRegInfo->zcps_sent_msg[0]++;
        pRegInfo->zcps_sent_msg_tmp[0]++;
    }
    else
    {
        pRegInfo->zcps_sent_msg[node_id]++;
        pRegInfo->zcps_sent_msg_tmp[node_id]++;
    }   
}

CCpEventReg::~CCpEventReg() {
    // TODO Auto-generated destructor stub
}

