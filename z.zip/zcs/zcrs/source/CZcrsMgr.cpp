/*
 * CZcrsMgr.cpp
 *
 *  Created on: 2014-9-4
 *      Author: wangjun
 */
#include <stdio.h>
#include "CZcrsMgr.h"
#include "zcs_common.h"
#include "tulip.h"
#include "tulip_oss.h"
#include "zcrs_common.h"
#include "CZcrsEventReg.h"

CZcrsMgr::CZcrsMgr()
    : m_work_state(0), m_state(E_ZCRS_STATE_IDLE), m_self_node_id(0), m_node_role(0),
      mnode_service(false), m_rte_mgr(), m_cur_chgover_event(0), m_rte_adv_seq(0),
      m_recv_all_app_ack(false), m_isCleaningRteTable(false), m_active_nodes(0),
      m_chgover_timer(0), m_wait_boot_timer(0), m_recved_node_ack_num(0),
      m_clean_rte_table_count(0)
{
    memset(&m_self_Jid, 0, sizeof(m_self_Jid));
    memset(&m_tRteChgOver, 0, sizeof(m_tRteChgOver));
    memset(&m_tConfigNodes, 0, sizeof(m_tConfigNodes));
    memset(&m_tActivesNodes, 0, sizeof(m_tActivesNodes));
    memset(&m_last_node_event, 0, sizeof(m_last_node_event));
}

/*�л�����״̬���������ؽڵ���Ч*/
void CZcrsMgr::switchWorkState()
{
    if(m_work_state==ZCS_JOB_STATE_MNODE_WORK)
    {
    //ɱ����ʱ��
    zcrs_kill_timer(m_chgover_timer);
        m_work_state = ZCS_JOB_STATE_MNODE_SLAVE;
    }
    else if(m_work_state==ZCS_JOB_STATE_MNODE_SLAVE)
    {
        m_work_state = ZCS_JOB_STATE_MNODE_WORK;
    }

}

/*��ʼ���ڵ��б�*/
bool CZcrsMgr::initNodes()
{
    uint16_t active_num;

    m_tConfigNodes.node_num = zcs_inner_get_config_nodes(m_tConfigNodes);
    active_num = zcs_inner_get_active_nodes(m_tActivesNodes);
    m_node_map.clear();
    set_active_nodes(m_tActivesNodes);

    if(active_num==m_tConfigNodes.node_num)
        return true;
    else
        return false;

}

/*���ݶ�ȡ�Ľڵ��б���Ϣ���ýڵ�״̬
 * ��ǰ�ڵ����Ϊ���ؽڵ�*/
void CZcrsMgr::set_active_nodes(T_ZCS_NODE_LIST& tNodes)
{
    T_ZCRS_NODE_STATE tNodeState;
    for(uint16_t i=0;i<tNodes.node_num;i++)
    {
        tNodeState.node_id = tNodes.tNodes[i].nodeId;
        tNodeState.eState = E_ZCRS_NODE_STATE_ACTIVE;
        if(tNodes.tNodes[i].moduleId==1)
        {
            if((m_node_role & ZCS_NODE_ROLE_SERVICE)!=0)
                m_node_map.insert(std::pair<uint16_t, T_ZCRS_NODE_STATE>(tNodeState.node_id,tNodeState));
        }
        else
        {
            m_node_map.insert(std::pair<uint16_t, T_ZCRS_NODE_STATE>(tNodeState.node_id,tNodeState));
        }
    }

}

/*���ݼ�Ⱥ״̬����ʼ��·�ɱ�*/
ZENIC_RESULT CZcrsMgr::initRteTable(T_ZCS_NODE_LIST &tActiveNodes)
{
	
    ZENIC_RESULT ret;
    T_DHT_RTE_TABLE tRteTable;
    ret= m_rte_mgr.init(m_self_node_id,m_work_state,tActiveNodes);
    if(ret!=RESULT_ZENIC_SUCCESS)
    {
        ZCS_LOG_SIMPLE(LOG_ERROR,"[ZCRS]Error while init rte manager,ret=%d\n",ret);
        return ret;
    }
	printf("[ZCRS]Routing Table init success,tActiveNodes.node_num=%d.\n",tActiveNodes.node_num);

    //û�нڵ㣬����ͨ��·��
    if(tActiveNodes.node_num==0)
        return RESULT_ZENIC_SUCCESS;
    //todo ��Ҫ��������ͬ����·��ͨ�棬Ŀǰ���������⴦��
    m_rte_mgr.getNewRteTable(&tRteTable);
    ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCRS]Synchronized Routing Table to all nodes, entry=%u,size=%u bytes\n",
            tRteTable.m_rte_entry_num, sizeof(tRteTable));
    if(m_work_state==ZCS_JOB_STATE_MNODE_WORK)
        advertiseRteTable(tRteTable,ZCS_EV_CHGOVER_NOOP);
    return RESULT_ZENIC_SUCCESS;

}

/*�ȴ�������ɵĶ�ʱ������*/
void CZcrsMgr::onBootTimer()
{
    NODE_ITERATOR it;
    T_ZCS_NODE_LIST tActiveNodes;
    m_wait_boot_timer = INVALID_TIMER_ID;
    if(m_state!=E_ZCRS_STATE_WAIT_CLUSTER_BOOT)
        return ;
    memset(&tActiveNodes,0,sizeof(T_ZCS_NODE_LIST));
    for(it=m_node_map.begin();it!=m_node_map.end();++it)
    {
        tActiveNodes.tNodes[tActiveNodes.node_num++].nodeId = it->first;
    }
    initRteTable(tActiveNodes);
    m_state = E_ZCRS_STATE_IDLE;
}

/*�ڵ��¼��ĺ������������²��裺
 * 1��������ҵ��ڵ㷢��·�ɱ�ͬ����Ϣ
 * 2��������Ӧ�÷�����Ϣ*/
void CZcrsMgr::postNodeEventProcess()
{
    T_DHT_RTE_TABLE tDhtRtTable;
    m_rte_mgr.getNewRteTable(&tDhtRtTable);
    advertiseRteTable(tDhtRtTable,ZCS_EV_CHGOVER_FINISH);

    m_tRteChgOver.event_type = ZCS_EV_CHGOVER_FINISH;
    CZcrsEventReg::notifyMessage(EV_SYS_ZCS_RTE_CHGOVER_NOTIFY,(uint8_t *)&m_tRteChgOver,
            sizeof(m_tRteChgOver),false);
    zcrs_kill_timer(m_chgover_timer);

}

/*�����нڵ�ͨ��·�ɱ�*/
bool CZcrsMgr::advertiseRteTable(T_DHT_RTE_TABLE& rtTable, T_ZCS_CHGOVER_EVENT event)
{

    JID tJid;
    T_EV_ZCS_RTE_ADVERTISE_EVENT tEvent;
    tJid = m_self_Jid;

    /*ZCS_EV_CHGOVER_FINISH֮�����Ϣ����Ҫȷ�ϣ����һ�ڵ�Ӧ����ǰ���Ѿ���ȡ�����β��ܸı�*/
    m_active_nodes = zcs_inner_get_active_nodes(m_tActivesNodes);
    m_recved_node_ack_num = 1;//���ڵ��������·�ɱ�ȷ��
    if(m_active_nodes==1)
          return true;

    tEvent.event_type =event;
    tEvent.seq = m_rte_adv_seq++;

    memcpy(&tEvent.tRteTable,&rtTable,sizeof(T_DHT_RTE_TABLE));
    /*������ڵ��б�������·��ͨ��*/
    for(uint16_t i=0;i<m_active_nodes;i++)
    {
        if(m_tActivesNodes.tNodes[i].nodeId==m_self_node_id)
            continue;
        tJid.wModule = m_tActivesNodes.tNodes[i].moduleId;
        tJid.ucRouteType = m_tActivesNodes.tNodes[i].route_type;
        zcrs_send_msg(EV_SYS_ZCS_RTE_CHG_ADVERTISE,(uint8_t *)&tEvent,(uint16_t)sizeof(T_EV_ZCS_RTE_ADVERTISE_EVENT),
                m_tActivesNodes.tNodes[i].nodeId,tJid);
        ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCRS]Advertise routing table, evet=%u, destModule=%u\n",
                event,tJid.wModule);

    }
    return false;
}


/*�ڵ��¼���Ԥ�������������²��裺
 * 1��������ҵ��ڵ㷢��·�ɱ��л������Ϣ
 */
void CZcrsMgr::preNodeEventProcess()
{
    T_DHT_RTE_TABLE tDhtRtTable;
    m_rte_mgr.getNewRteTable(&tDhtRtTable);
    advertiseRteTable(tDhtRtTable,ZCS_EV_PRE_CHGOVER);
}

//����·��ͨ��ȷ����Ϣ��ʼ�ո�1������ģ�鷢��
void CZcrsMgr::sendRteAdvAck(T_ZCS_CHGOVER_EVENT ev, uint16_t seq)
{
    T_EV_ZCS_RTE_CHG_ADVERTISE_ACK tAckMsg;
    tAckMsg.event_type = ev;
    tAckMsg.seq = seq;
    JID tJid=m_self_Jid;
    tJid.wModule = ZCS_MASTER_NODE_MODULE_NO;
    tJid.ucRouteType = ZCS_MASTER_BOARD;
    ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCRS]Send Routing Ack msg, Event=%u,seq=%u,dst_module=%u,dst_jno=0x%x\n",
            ev,seq,tJid.wModule,tJid.dwJno);
    XOS_SendAsynMsg(EV_SYS_ZCS_RTE_CHG_ADVERTISE_ACK,(uint8_t *)&tAckMsg,sizeof(tAckMsg),0,0,
            &tJid);
}

/*���ؽڵ��ж�·���л����֮��Ĵ���*/
void CZcrsMgr::mnodeChgoverFinish()
{
    ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCRS]Routing ChangOver Complete,pre_state=%u,node_event=%u,node_id=%u\n",
            m_state,m_last_node_event.event_type,m_last_node_event.tNode.nodeId);
    postNodeEventProcess();
    /*�л�·�ɱ�*/
    m_rte_mgr.commit();
    /*��ZCMSȷ����Ϣ*/
    zcs_ack_node_event(m_last_node_event.tNode.nodeId,m_last_node_event.event_type);
    m_recved_node_ack_num = 0;
    m_recv_all_app_ack = false;
    m_state = E_ZCRS_STATE_IDLE;
}

/*��ȡ·�ɹ���ʵ��*/
const CZcrsRteMgr& CZcrsMgr::getRteMgrInstance()
{
    return m_rte_mgr;
}

/*�ڵ��¼�����*/
void CZcrsMgr::onNodeEvent(const T_EV_ZCS_NODE_EVENT* ptNodeEv)
{
    if(m_work_state!=ZCS_JOB_STATE_MNODE_WORK )
    {
        ZCS_LOG_SIMPLE(LOG_ERROR,"[ZCRS]recv node leave event in invalid state, work_state=%d, state=%d\n",
                        m_work_state,m_state);
         return ;
    }
    ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCRS]recv node event, event=%u,node_id=%u,state=%d\n",
                            ptNodeEv->event_type,ptNodeEv->tNode.nodeId,m_state);

    /*���ڵȴ���Ⱥ�����Ĵ�������������ڵ��б�*/
    if(m_state != E_ZCRS_STATE_IDLE)
    {
         if(m_state == E_ZCRS_STATE_WAIT_CLUSTER_BOOT)
         {
              T_ZCRS_NODE_STATE tState;
              tState.node_id = ptNodeEv->tNode.nodeId;
              tState.eState=E_ZCRS_NODE_STATE_ACTIVE;
              if(ptNodeEv->event_type==EV_ZCS_NODE_JOIN)
                  m_node_map.insert(std::make_pair(ptNodeEv->tNode.nodeId,tState));
              else if(ptNodeEv->event_type==EV_ZCS_NODE_LEAVE)
                  m_node_map.erase(tState.node_id);
              zcs_ack_node_event(ptNodeEv->tNode.nodeId,ptNodeEv->event_type);
         }
         else
         {
            m_chgover_timer = XOS_SetRelativeTimer(EV_SYS_ZCRS_WAIT_RTE_CHGOVER_ACK_TIMER,
                                                    ZCRS_CHGOVER_TIMER_MNODE,PARAM_NULL);
         }
         m_last_node_event = *ptNodeEv;
         return ;
    }
    CZcrsEventReg::reset();
    switch(ptNodeEv->event_type)
    {     
        case EV_ZCS_NODE_JOIN:
        {
             m_tRteChgOver.rte_num = m_rte_mgr.addNode(ptNodeEv->tNode.nodeId,ZCS_MAX_RTE_ENTRY,m_tRteChgOver.tChgRte);
             break;
        }
        case EV_ZCS_NODE_LEAVE:
        {
             m_tRteChgOver.rte_num = m_rte_mgr.removeNode(ptNodeEv->tNode.nodeId,ZCS_MAX_RTE_ENTRY,m_tRteChgOver.tChgRte);
             break;
        }
        case EV_ZCS_NODE_BLOCKED:
        {
             m_tRteChgOver.rte_num = m_rte_mgr.blockNode(ptNodeEv->tNode.nodeId,ZCS_MAX_RTE_ENTRY,m_tRteChgOver.tChgRte);
             break;
        }
        case EV_ZCS_NODE_UNBLOCKED:
        {
             m_tRteChgOver.rte_num = m_rte_mgr.unblockNode(ptNodeEv->tNode.nodeId,ZCS_MAX_RTE_ENTRY,m_tRteChgOver.tChgRte);
             break;
        }
        case EV_ZCS_NODE_BALANCE:
        {
             m_tRteChgOver.rte_num = m_rte_mgr.balanceNode(ZCS_MAX_RTE_ENTRY,m_tRteChgOver.tChgRte);
             break;
        }
        default:
             ZCS_LOG_SIMPLE(LOG_ERROR,"[ZCRS]recv node event, but with wrong event_type=%u\n",
                 ptNodeEv->event_type);
         return ;
     }

    if(m_tRteChgOver.rte_num==0)
    {
        zcs_ack_node_event(ptNodeEv->tNode.nodeId,ptNodeEv->event_type);
        return ;
    }

    m_last_node_event = *ptNodeEv;

    /*�����нڵ�ͨ��·�ɱ仯*/
    preNodeEventProcess();
    m_tRteChgOver.event_type = ZCS_EV_PRE_CHGOVER;
    /*���ؽڵ��Ͽ���Ҳ��Ӧ�ã���Ҫ������ע��Ӧ��ͨ���¼��仯*/
    m_recv_all_app_ack = CZcrsEventReg::notifyMessage(EV_SYS_ZCS_RTE_CHGOVER_NOTIFY,(uint8_t *)&m_tRteChgOver,sizeof(m_tRteChgOver),true);

    if(this->m_active_nodes==1 && m_recv_all_app_ack)
    {
        this->mnodeChgoverFinish();
    }
    else
    {
        m_state = E_ZCRS_STATE_WAIT_RTE_CHOVER_ACK;
        m_chgover_timer = XOS_SetRelativeTimer(EV_SYS_ZCRS_WAIT_RTE_CHGOVER_ACK_TIMER,
            ZCRS_CHGOVER_TIMER_MNODE,PARAM_NULL);
    }
}

void CZcrsMgr::cleanNodeidFromRteTable(T_DHT_RTE_TABLE& tRteTable, uint16_t nodeId)
{
    for(uint32_t i=0;i<DHT_MAX_RTE_ENTRY;i++)
    {
        if(nodeId == tRteTable.rtEntry[i].tNodes.master_node_id)
            tRteTable.rtEntry[i].tNodes.master_node_id = DHT_INVALID_NODE_ID;
        else if(nodeId == tRteTable.rtEntry[i].tNodes.backup_nodes[0])
            tRteTable.rtEntry[i].tNodes.backup_nodes[0] = DHT_INVALID_NODE_ID;
        else if(nodeId == tRteTable.rtEntry[i].tNodes.backup_nodes[1])
            tRteTable.rtEntry[i].tNodes.backup_nodes[1] = DHT_INVALID_NODE_ID;                       
    }
}

void CZcrsMgr::onCleanRteTable(void)
{
    if(E_ZCRS_STATE_WAIT_RTE_SYNC == m_state)
    {
        return ;
    }
    m_isCleaningRteTable = true;
    m_clean_rte_table_count++;
    
    T_DHT_RTE_TABLE tRteTable;    
    m_rte_mgr.getCurRteTable(&tRteTable);
    uint16_t my_node_id = tRteTable.m_self_node_id;
    cleanNodeidFromRteTable(tRteTable,my_node_id);

    bool isPreChgOverFinish = preChgOver(tRteTable, 0);//seq Ҫ����һ��!
    for(uint32_t i=0;i<DHT_MAX_RTE_ENTRY;i++)
    {
        tRteTable.rtEntry[i].tNodes.master_node_id = DHT_INVALID_NODE_ID;
        tRteTable.rtEntry[i].tNodes.backup_nodes[0] = DHT_INVALID_NODE_ID;
        tRteTable.rtEntry[i].tNodes.backup_nodes[1] = DHT_INVALID_NODE_ID;
    }
    m_rte_mgr.setRteTable(tRteTable);
    if(isPreChgOverFinish)
    {
         chgOverFinish();
    }
}

void CZcrsMgr::onAdjustEvent( void )
{
    m_tRteChgOver.rte_num = m_rte_mgr.balanceNode(ZCS_MAX_RTE_ENTRY,m_tRteChgOver.tChgRte );

    if(m_tRteChgOver.rte_num==0)
    {
        return ;
    }

    /*�����нڵ�ͨ��·�ɱ仯*/
    preNodeEventProcess();
    m_tRteChgOver.event_type = ZCS_EV_PRE_CHGOVER;
    /*���ؽڵ��Ͽ���Ҳ��Ӧ�ã���Ҫ������ע��Ӧ��ͨ���¼��仯*/
    m_recv_all_app_ack = CZcrsEventReg::notifyMessage(EV_SYS_ZCS_RTE_CHGOVER_NOTIFY,(uint8_t *)&m_tRteChgOver,sizeof(m_tRteChgOver),true);

    if(this->m_active_nodes==1 && m_recv_all_app_ack)
    {
        this->mnodeChgoverFinish();
    }
    else
    {
        m_state = E_ZCRS_STATE_WAIT_RTE_CHOVER_ACK;
        m_chgover_timer = XOS_SetRelativeTimer(EV_SYS_ZCRS_WAIT_RTE_CHGOVER_ACK_TIMER,
            ZCRS_CHGOVER_TIMER_MNODE,PARAM_NULL);
    }

}

/*��ʾ·�ɱ�״̬*/
void CZcrsMgr::printRteTable()
{
    m_rte_mgr.print_stats();
}

/*��������*/

CZcrsMgr::~CZcrsMgr() {
    // TODO Auto-generated destructor stub
}

/*�ڵ�������������Ҫ��������
 * 1����ʼ��״̬��
 * 2����ʼ���ڵ��б�*/
void CZcrsMgr::onStartup(uint16_t work_state, T_ZCS_NODE_ROLE node_role, uint16_t self_node_id)
{
    bool bootSuccess;
    m_work_state =work_state;
    m_node_role = node_role;
    m_self_node_id = self_node_id;
    m_cur_chgover_event = ZCS_EV_CHGOVER_NOOP;
    m_clean_rte_table_count = 0;
    m_isCleaningRteTable = false;
    
    ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCRS]onStartup() Cur_state=%u,Node_role=%u,Node_id=%u\n",
            work_state,node_role,self_node_id);
    XOS_GetSelfJID(&m_self_Jid);
	//���������ڴ�
	ZENIC_RESULT ret = m_rte_mgr.createRoutingShm();
	if (RESULT_ZENIC_SUCCESS != ret)
	{
		printf("[ZCRS]onStartup() create routing shm failed.\n");
		return;
	}
	
    switch(work_state)
    {
        case ZCS_JOB_STATE_MNODE_WORK:
        {
            m_state = E_ZCRS_STATE_WAIT_CLUSTER_BOOT;
            /*��ʼ���ڵ㣬����ڵ��Ѿ�ȫ�����������ʼ��·�ɱ�����������ȴ���ʱ��*/
            bootSuccess = initNodes();
            m_rte_adv_seq = 1;
            if(bootSuccess)
            {
                initRteTable(m_tActivesNodes);
                m_state = E_ZCRS_STATE_IDLE;
            }
            else
                XOS_SetRelativeTimer(EV_SYS_ZCRS_BOOT_WAIT_TIMER,ZCRS_BOOT_TIMER_PERIOD,PARAM_NULL);
            break;
        }
        case ZCS_JOB_STATE_MNODE_SLAVE:
        {
            m_tActivesNodes.node_num=0;
            initRteTable(m_tActivesNodes);
            m_state = E_ZCRS_STATE_WAIT_RTE_SYNC;
            break;
        }
        case ZCS_JOB_STATE_SNODE_WORK:
        {
            m_tActivesNodes.node_num=0;
            initRteTable(m_tActivesNodes);
            m_state = E_ZCRS_STATE_WAIT_RTE_SYNC;
            break;
        }
    }
}

bool CZcrsMgr::preChgOver(T_DHT_RTE_TABLE rteTable, uint16_t seq)
{
    bool isPreChgOverFinish = false;
    //����·�ɱ�����ȡ�仯��·�ɱ���
    m_tRteChgOver.rte_num = m_rte_mgr.updateRoutingTable(rteTable, m_tRteChgOver.tChgRte, ZCS_MAX_RTE_ENTRY);
    m_tRteChgOver.event_type = ZCS_EV_PRE_CHGOVER;

    //���ֻ���������ĳ�ʼ��״̬����ֻ����·�ɱ�����֪ͨӦ��
    if(E_ZCRS_STATE_WAIT_RTE_SYNC==m_state)
    {
        isPreChgOverFinish = true;
        //sendRteAdvAck(ZCS_EV_PRE_CHGOVER, seq);
    }
    else
    {
        m_recv_all_app_ack=CZcrsEventReg::notifyMessage(EV_SYS_ZCS_RTE_CHGOVER_NOTIFY,(uint8_t *)&m_tRteChgOver,
                                            sizeof(m_tRteChgOver),true);

        /*���û���ϲ�Ӧ�ã���ֱ�ӷ��سɹ�*/
        if(m_recv_all_app_ack)
        {   //todo ����·��ȷ����Ϣ
            isPreChgOverFinish = true;
            //sendRteAdvAck(ZCS_EV_PRE_CHGOVER, seq);
        }
        else
        {
            m_state = E_ZCRS_STATE_WAIT_RTE_CHOVER_ACK;
            isPreChgOverFinish = false;
        }
    }
    return isPreChgOverFinish;
}

void CZcrsMgr::chgOverFinish()
{
    m_tRteChgOver.event_type = ZCS_EV_CHGOVER_FINISH;
    CZcrsEventReg::notifyMessage(EV_SYS_ZCS_RTE_CHGOVER_NOTIFY,(uint8_t *)&m_tRteChgOver,
                 sizeof(m_tRteChgOver),false);
    m_rte_mgr.commit();
    m_recved_node_ack_num = 0;
    m_recv_all_app_ack = false;
    m_isCleaningRteTable = false;
    m_state = E_ZCRS_STATE_IDLE;
    m_active_nodes = zcs_inner_get_active_nodes(m_tActivesNodes);
}

/*�յ�·��ͨ��Ĵ������ڳ����ؽڵ�������������ڵ�����Ч
 * 1�����µ�ǰ��ǰ·�ɱ�������仯·�ɱ�����֪ͨӦ��*/
void CZcrsMgr::onRecvRteAdvertise(const uint8_t* msg, uint16_t msg_len)
{

    T_EV_ZCS_RTE_ADVERTISE_EVENT *pRteEv = (T_EV_ZCS_RTE_ADVERTISE_EVENT *)msg;
    JID tmpJid;

    XOS_Sender(&tmpJid);
    if(m_work_state!=ZCS_JOB_STATE_MNODE_SLAVE && m_work_state!=ZCS_JOB_STATE_SNODE_WORK)
    {
        ZCS_LOG_SIMPLE(LOG_ERROR,"[ZCRS]Recved RTE advertise under unexpected state=%u,sender_module=%u\n",
                m_work_state,tmpJid.wModule);
         return ;
    }

    ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCRS]Recv Routing Advertise Msg, sender_module=%u,cur_state=%u,Event=%u,Seq=%u,rte_entry_num=%u,msg_len=%u\n",
            tmpJid.wModule,
            m_state,pRteEv->event_type,pRteEv->seq,
            pRteEv->tRteTable.m_rte_entry_num,msg_len);

    if(tmpJid.wModule!=ZCS_MASTER_NODE_MODULE_NO) //��1��ģ���ͨ�治���Դ���
        return ;
    m_cur_chgover_event = pRteEv->event_type;
    m_rte_adv_seq = pRteEv->seq;
    switch(pRteEv->event_type)
    {
        case ZCS_EV_CHGOVER_NOOP:
        {
            m_tRteChgOver.rte_num = m_rte_mgr.updateRoutingTable(pRteEv->tRteTable,
                     m_tRteChgOver.tChgRte,ZCS_MAX_RTE_ENTRY);

             //���ֻ���������ĳ�ʼ��״̬����ֻ����·�ɱ�����֪ͨӦ��
            m_rte_mgr.commit();
              sendRteAdvAck(pRteEv->event_type, pRteEv->seq);
              m_state = E_ZCRS_STATE_IDLE;
              break;
        }
        case ZCS_EV_PRE_CHGOVER:
        {
            bool isPreChgOverFinish = preChgOver(pRteEv->tRteTable, pRteEv->seq);
            if(isPreChgOverFinish)
            {
                sendRteAdvAck(ZCS_EV_PRE_CHGOVER, pRteEv->seq);
            }
            break;
        }
        case ZCS_EV_CHGOVER_FINISH:
        {
            chgOverFinish();
            break;
        }
        case ZCS_EV_CHGOVER_ROLLBACK:
        {
            m_tRteChgOver.event_type = ZCS_EV_CHGOVER_ROLLBACK;
            CZcrsEventReg::notifyMessage(EV_SYS_ZCS_RTE_CHGOVER_NOTIFY,(uint8_t *)&m_tRteChgOver,
                             sizeof(m_tRteChgOver),false);
            m_state = E_ZCRS_STATE_IDLE;
            m_rte_mgr.rollback();
            zcrs_kill_timer(m_chgover_timer);
            break;
        }
    }

}


/*�յ�·��ͨ��Ĵ����������ؽڵ�����Ч*/
void CZcrsMgr::onRecvRteAdvertiseAck(const uint8_t* msg, uint16_t msg_len)
{
    if(m_work_state!=ZCS_JOB_STATE_MNODE_WORK || m_state!=E_ZCRS_STATE_WAIT_RTE_CHOVER_ACK)
    {
        ZCS_LOG_SIMPLE(LOG_ERROR,"[ZCRS]Recved routing adv ack, but this node is not MNode_Work_state, curState=%u\n",
                m_work_state);
        return;
    }
    T_EV_ZCS_RTE_CHG_ADVERTISE_ACK *ptAck = (T_EV_ZCS_RTE_CHG_ADVERTISE_ACK *)msg;
    JID tJid;
    XOS_Sender(&tJid);

    ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCRS]Recv Routing Advertise Ack Msg from module(%d), cur_state=%u,Event=%u,Seq=%u,msg_len=%u\n",
            tJid.wModule,m_state,ptAck->event_type,ptAck->seq,msg_len);

    m_recved_node_ack_num++;

    /*�������е�·��ͨ����Ӧ��Ϣ�����к���*/
    if(m_recved_node_ack_num>=m_active_nodes && m_recv_all_app_ack)
    {
        mnodeChgoverFinish();
    }
}

/*�յ��ϲ�Ӧ�õ�ȷ�ϣ���ҵ��ڵ��Լ���ҵ��ڵ��������ؽڵ�����Ч*/
void CZcrsMgr::onRecvRteChgOverAck(const uint8_t* msg, uint16_t msg_len)
{
    JID tJid;
    XOS_Sender(&tJid);
	T_EV_ZCS_RTE_CHG_OVER_ACK *ptAck = (T_EV_ZCS_RTE_CHG_OVER_ACK *)msg;

    m_recv_all_app_ack = CZcrsEventReg::onRecvAck(msg,msg_len);

	//�Ѿ�ɾ���˽���������ʱ�������ٰѸý������ӽ���
	if (ptAck->tSegList.wSegNum > 0)
	{
		m_rte_mgr.setSwitchRteTable(ptAck->tSegList);
	}

    ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCRS]Recv App routing Chgover Ack Msg, SenderJno=0x%x,cur_state=%u\n",
            tJid.dwJno,m_state);
    if(!m_recv_all_app_ack)
        return ;

    if(m_isCleaningRteTable)
    {
        chgOverFinish();
        return;
    }
    
    /*�����ؽڵ㣬��Ҫ�����ؽڵ����ȷ��*/
    if(m_work_state!=ZCS_JOB_STATE_MNODE_WORK)
    {
        sendRteAdvAck(m_cur_chgover_event, m_rte_adv_seq);
        return ;
    }

    /*���غ�ҵ�����ڵ�Ĵ���*/
    if(m_recved_node_ack_num>=m_active_nodes)
    {
        mnodeChgoverFinish();
    }

}

/*����������ʱ����ʱ�����������غ�ҵ��ڵ�����Ч
 * �����ֲ��ԣ�1����ǿ����Ϊ������ɣ���2���ǻع�
 * �ع����ƶ�������ͬ��������Ը��ӣ�Ŀǰ�Ȳ��õ�һ�ֲ��ԣ���Ϊ��ʱ���ǵ������*/
void CZcrsMgr::onChgOverTimer()
{
	//���ػ�ҵ��ڵ㶼��Ҫ������
    zcrs_kill_timer(m_chgover_timer);	
    m_tRteChgOver.event_type = ZCS_EV_CHGOVER_FINISH;
	//֪ͨzcps���л����
    CZcrsEventReg::notifyMessage(EV_SYS_ZCS_RTE_CHGOVER_NOTIFY,(uint8_t *)&m_tRteChgOver,
            sizeof(m_tRteChgOver),false);


    if(m_work_state==ZCS_JOB_STATE_MNODE_WORK)
    {
		T_DHT_RTE_TABLE tDhtRtTable;
	    m_rte_mgr.getNewRteTable(&tDhtRtTable);
	    advertiseRteTable(tDhtRtTable,ZCS_EV_CHGOVER_FINISH);
		/*�л�·�ɱ�*/
    	m_rte_mgr.commit();
        zcs_ack_node_event(m_last_node_event.tNode.nodeId,m_last_node_event.event_type);
        m_state = E_ZCRS_STATE_IDLE;
    }
    else
    {
        sendRteAdvAck(m_cur_chgover_event, m_rte_adv_seq);
    }
}

/*ͳ����Ϣ��ӡ����*/
void CZcrsMgr::print_stats()
{
    if(m_work_state==ZCS_JOB_STATE_SNODE_WORK)
    {
        printf("ZCRS_STATS: self_node_id=%u, work_state=%u, state=%d\n            last_Chgover_event=%u, recv_all_app_ack=%s, recv_rte_ack=%u, m_clean_rte_table_count=%u, isCleaningRteTable=%s\n",
            m_self_node_id, m_work_state,m_state,
            m_cur_chgover_event,m_recv_all_app_ack?"true":"false",
            m_recved_node_ack_num,m_clean_rte_table_count,m_isCleaningRteTable?"true":"false");
    }
    else
    {
        printf("ZCRS_STATS: self_node_id=%u, work_state=%u, state=%d, m_active_nodes=%d, last_node=%u, last_event=%d\n            last_Chgover_event=%u, recv_all_app_ack=%s, recv_rte_ack=%u, m_clean_rte_table_count=%u, isCleaningRteTable=%s\n",
            m_self_node_id, m_work_state,m_state,m_active_nodes,m_last_node_event.tNode.nodeId,m_last_node_event.event_type,
            m_cur_chgover_event,m_recv_all_app_ack?"true":"false",
            m_recved_node_ack_num,m_clean_rte_table_count,m_isCleaningRteTable?"true":"false");
    }
    if(m_state==E_ZCRS_STATE_WAIT_RTE_CHOVER_ACK)
    {
        printf("ChgOver Event:Entry_num=%u, Event=%u\n",m_tRteChgOver.rte_num,m_tRteChgOver.event_type);
    }
}


/*ɱ����ʱ��������������ʱ����Ϊ��Чֵ*/
void zcrs_kill_timer(uint32_t &timer_id)
{
    if(INVALID_TIMER_ID!=timer_id)
    {
        XOS_KillTimerByTimerId(timer_id);
        timer_id = INVALID_TIMER_ID;
    }
}

/*������Ϣ����NodeId����ת������*/
ZENIC_RESULT zcrs_send_msg(uint32_t msg_id,const uint8_t *msg,uint16_t len, uint16_t node_id, JID &tJid)
{
    XOS_STATUS ret;
    switch(node_id)
    {
    case 1:
        tJid.ucRouteType = ZCS_LEFT_BOARD;
        tJid.wModule = 1;
        break;
    case 256:
        tJid.ucRouteType = ZCS_RIGHT_BOARD;
        tJid.wModule = 1;
        break;
    default:
        tJid.wModule = node_id;
        tJid.ucRouteType = ZCS_MASTER_BOARD;
        break;
    }

    ret = XOS_SendAsynMsg(msg_id,(uint8_t *)msg,len,0,0,&tJid);
    if(ret!=XOS_SUCCESS)
    {
        ZCS_LOG_SIMPLE(LOG_ERROR,"[ZCRS]Send Msg Error(%u),msg_id=%u,msg_len=%u,dst_module=%u,Jno=0x%x\n",
                ret,msg_id,len,tJid.wModule,tJid.dwJno);
    }
    return RESULT_ZENIC_SUCCESS;
}
