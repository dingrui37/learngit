/*
 * CZcmsMgr.h
 *
 *  Created on: 2014-9-4
 *  
 *      Author: kejin
 */

#ifndef CZCMSMGR_H_
#define CZCMSMGR_H_

#include "zcms_common.h"


class CZcmsMgr {
public:
    uint16_t m_wSvcState;
    T_ZCS_NODE m_tSelfNodeInfo;
    BYTE m_ucBoardPosition;
    bool m_bIsOMP;
    T_PhysAddress m_tSelfPhyAddr;
    uint32_t m_dwChangeOverTimes;
    uint32_t m_dwPoweronTick;
    T_ZCS_NODE *m_ptSelfNode;
    
public:
    CZcmsMgr();
    ZENIC_RESULT init(BOOLEAN IsWorking, uint16_t& nextState);
    uint16_t getSelfSvcState();
    ZENIC_RESULT getSelfNodeType(T_ZCS_NODE* tNodeType);
    ZENIC_RESULT setSelfNodeState(T_ZCS_NODE_STATE tState);
    uint16_t getSelfNodeID();
    BYTE getBoardPosition();
    bool IsSelfOMP();
    ZENIC_RESULT getSelfPhyAddr(T_PhysAddress* ptPhyAddr);
    uint32_t getSelfPowerOnTick();
	void setSelfPowerOnTick(uint32_t clusterPoweronTick);
    void showSysInfo();
    ZENIC_RESULT writeShmSelfNodeInfo();
    void switchWorkState();
    //���ؽڵ�ĵ�����ɴ���
    void mnodeChgoverFinish();
    void print_stats();
    virtual ~CZcmsMgr();
};


#endif /* CZCMSMGR_H_ */
