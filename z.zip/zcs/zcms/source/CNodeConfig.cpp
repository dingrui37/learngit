/*
 * CNodeConfig.cpp
 *
 *  Created on: 2014-8-31
 *      Author: wangjun
 */

#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/errno.h>

#include "zcms_common.h"
#include "CNodeConfig.h"

char* myitoa(int num, char*str, int radix);

static char ZCSConfigFilePath[] = "./zcs_config.ini";//zcs�������ļ�·��

const static int16_t  ZCS_MAX_LINE_STR_LEN=256;             /* ÿ������ַ��� */
const static int16_t  ZCS_MAX_LINES=20;             /* ������� */
const static int16_t  ZCS_MAX_COMMENT_LINES=10;             /* ������� */
#define ZCS_CONF_SEPERATOR ','
#define ZCS_CONF_COMMENTS_INDICATOR '#'

static char sLine[ZCS_MAX_LINES][ZCS_MAX_LINE_STR_LEN];

CNodeConfig::CNodeConfig()
    : m_self_role(0), m_alive_timer(0), m_alive_count(0), m_replica_copy(0),
      m_reserved(0), m_conf_node_num(0), m_ptShmConf(0)
{
    memset(m_tNodes, 0, sizeof(m_tNodes));
}

ZENIC_RESULT CNodeConfig::getNode(uint16_t node_id, T_ZCS_NODE& tNode)
{
    if(node_id >= ZCS_MAX_NODE_NUM)
    {
        tNode.nodeId = ZCS_INVALID_NODEID;
        tNode.moduleId = ZCS_INVALID_MODULE;
        tNode.state = ZCS_NODE_STATE_INACTIVE;
        tNode.route_type= ZCS_INVALID_BOARD;
        XOS_ASSERT(0);
        return ERROR_INVALID_INDEX;
    }
    
    tNode.nodeId = m_tNodes[node_id].nodeId;
    tNode.moduleId = m_tNodes[node_id].moduleId;
    tNode.state = m_tNodes[node_id].state;
    tNode.route_type = m_tNodes[node_id].route_type;
    return RESULT_ZENIC_SUCCESS;
}

uint16_t CNodeConfig::getNodeIDbyIndex(uint16_t NodeIdx)
{
    if(NodeIdx >= ZCS_MAX_NODE_NUM)
    {
        return ZCS_INVALID_NODEID;
    }
    
    return m_tNodes[NodeIdx].nodeId;
}

void CNodeConfig::skipStringSpaceAndReturn(char* pucBuf, size_t size)
{
    char ctemp[ZCS_MAX_LINE_STR_LEN]={0};
    char* pTempBuf = pucBuf;
    uint16_t i=0;
    if(pucBuf == NULL)
    {
        return;
    }
    while('\0' != *pTempBuf && i < sizeof(ctemp)-1)
    {
    	   /* need to also remove '\r', which is sign of return on Windows system */
        if((' ' == *pTempBuf)||('\r' == *pTempBuf)||('\n' == *pTempBuf))
        {
            pTempBuf++;
            continue;
        }

        ctemp[i++]=*pTempBuf;
        pTempBuf++;
    }
    ctemp[i++]=0;
    
    XOS_ASSERT(i<=size);
    memcpy(pucBuf, ctemp, (size_t)i);
    memset(pucBuf+i, 0, size-i);
}

bool CNodeConfig::isComments(char* pucBuf)
{
    if(pucBuf != NULL && (ZCS_CONF_COMMENTS_INDICATOR == *pucBuf))
    {
        return TRUE;
    }
    return FALSE;
}

ZENIC_RESULT CNodeConfig::init()
{
    uint16_t node_i = 0;
    ZENIC_RESULT ret;
    
    this->m_alive_timer = ZCMS_DEFAULT_ALIVE_TIMER;
    this->m_alive_count = ZCMS_DEFAULT_ALIVE_COUNT;
    this->m_replica_copy = ZCMS_DEFAULT_REPLICA_COPY;
    this->m_self_role = ZCS_NODE_ROLE_INVALID;    
    memset(m_tNodes, 0, sizeof(m_tNodes));
    for(node_i = 0; node_i < ZCS_MAX_NODE_NUM; node_i++)
    {
        m_tNodes[node_i].nodeId = ZCS_INVALID_NODEID;
        m_tNodes[node_i].moduleId = ZCS_INVALID_MODULE;
        m_tNodes[node_i].state = ZCS_NODE_STATE_INACTIVE;
        m_tNodes[node_i].route_type = ZCS_INVALID_BOARD;
    }
    this->m_conf_node_num = ZCS_MAX_NODE_NUM;
    ret = loadConfigFile();
    if(ret != RESULT_ZENIC_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "loadConfigFile failed %d!\n", ret);
        return ret;
    }
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "loadConfigFile Success!\n");

    ret = verifyNodeConf();
    if(ret != RESULT_ZENIC_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "verifyNodeConf failed %d!\n", ret);
        return ret;
    }

    m_ptShmConf = NULL;
    return writeShmConfInfo();
}

ZENIC_RESULT CNodeConfig::verifyNodeConf()
{
    BOOLEAN isOmp = XOS_IsOmp();
    if(!(getConfSelfNodeRole()& ZCS_NODE_ROLE_ALL))
    {
        return ERROR_INVALID_PARAM;
    }
    if((((getConfSelfNodeRole() & ZCS_NODE_ROLE_MASTER)) && !isOmp)
    	|| ((ZCS_NODE_ROLE_SERVICE==getConfSelfNodeRole()) && isOmp))
    {
        return ERROR_INVALID_PARAM;
    }
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeConfig::setConfSelfNodeRole(uint32_t tRole_num)
{
    if(tRole_num == 1)
    {
        this->m_self_role = ZCS_NODE_ROLE_MASTER;
    }
    else if(tRole_num == 2)
    {
        this->m_self_role = ZCS_NODE_ROLE_SERVICE;
    }
    else if(tRole_num == 3)
    {
        this->m_self_role = ZCS_NODE_ROLE_ALL;
    }
    else
    {
        XOS_ASSERT(0);
        this->m_self_role = ZCS_NODE_ROLE_INVALID;
        return ERROR_INVALID_PARAM;
    }
    return RESULT_ZENIC_SUCCESS;
}

T_ZCS_NODE_ROLE CNodeConfig::getConfSelfNodeRole()
{
    return m_self_role;
}

ZENIC_RESULT CNodeConfig::setConfReplicaMode(uint16_t rMode)
{
    this->m_replica_copy = rMode;
    return RESULT_ZENIC_SUCCESS;
}

/*  ��������,2��ʾ1+1��3��ʾ1+2��255��ʾȫ����*/
uint16_t CNodeConfig::getConfReplicaMode()
{
    return m_replica_copy;
}

ZENIC_RESULT CNodeConfig::setConfKeepAliveHBTimer(uint32_t timer)
{
    this->m_alive_timer = timer;
    return RESULT_ZENIC_SUCCESS;
}

uint32_t CNodeConfig::getConfKeepAliveHBTimer()
{
    return m_alive_timer;
}

ZENIC_RESULT CNodeConfig::setConfKeepAliveHBCount(uint16_t cnt)
{
    this->m_alive_count = cnt;
    return RESULT_ZENIC_SUCCESS;
}

uint16_t CNodeConfig::getConfKeepAliveHBCount()
{
    return m_alive_count;
}

ZENIC_RESULT CNodeConfig::setConfNodeListAndNum(char* pucBuf)
{
    uint16_t Nid = 0;
    uint16_t i = 0;
    char NodeStr[ZCS_MAX_LINE_STR_LEN];
    char* pTempBuf = pucBuf;
    
    if(pucBuf == NULL)
    {
        return ERROR_NULL_POINTER;
    }

    memset(NodeStr, 0, sizeof(NodeStr));
    while(('\0' != *pTempBuf) && (i < sizeof(NodeStr)) && (Nid < ZCS_MAX_NODE_NUM))
    {
        if(ZCS_CONF_SEPERATOR != *pTempBuf)
        {
            NodeStr[i++]=*pTempBuf;
            pTempBuf++;
            continue;
        }

        if(NodeStr[0] != 0)
        {
            m_tNodes[Nid].nodeId=(uint16_t)atoi(NodeStr);
            m_tNodes[Nid].moduleId=m_tNodes[Nid].nodeId;
            m_tNodes[Nid].route_type=ZCS_MASTER_BOARD;
            if(m_tNodes[Nid].nodeId == ZCMS_VIRTUAL_RIGHT_OMP_NODE_ID)
            {
                m_tNodes[Nid].moduleId = ZCS_MASTER_NODE_MODULE_NO;
                m_tNodes[Nid].route_type = ZCS_RIGHT_BOARD;
            }
            else if (m_tNodes[Nid].nodeId == ZCS_MASTER_NODE_ID_1)
            {
                m_tNodes[Nid].moduleId = ZCS_MASTER_NODE_MODULE_NO;
                m_tNodes[Nid].route_type = ZCS_LEFT_BOARD;
            }
            Nid++;
        }
        memset(NodeStr, 0, sizeof(NodeStr));
        i=0;
        pTempBuf++;
    }

    if((NodeStr[0] != 0) && (Nid < ZCS_MAX_NODE_NUM))
    {
        m_tNodes[Nid].nodeId = (uint16_t)atoi(NodeStr);
        m_tNodes[Nid].moduleId = m_tNodes[Nid].nodeId;
        m_tNodes[Nid].route_type=ZCS_MASTER_BOARD;
        if(m_tNodes[Nid].nodeId == ZCMS_VIRTUAL_RIGHT_OMP_NODE_ID)
        {
            m_tNodes[Nid].moduleId = ZCS_MASTER_NODE_MODULE_NO;
            m_tNodes[Nid].route_type = ZCS_RIGHT_BOARD;
        }
        else if (m_tNodes[Nid].nodeId == ZCS_MASTER_NODE_ID_1)
        {
            m_tNodes[Nid].moduleId = ZCS_MASTER_NODE_MODULE_NO;
            m_tNodes[Nid].route_type = ZCS_LEFT_BOARD;
        }
        Nid++;
    }

    m_conf_node_num = Nid;
    
    XOS_ASSERT(m_conf_node_num <= ZCS_MAX_NODE_NUM);
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeConfig::getConfNodeListAndNum(T_ZCS_NODE* pNodes, uint16_t& node_num)
{
    uint16_t Nid = 0;
    if(pNodes == NULL)
    {
        return ERROR_NULL_POINTER;
    }

    for(Nid = 0; Nid < m_conf_node_num; Nid++)
    {
        memcpy(&pNodes[Nid], &m_tNodes[Nid], sizeof(T_ZCS_NODE));
    }

    node_num = m_conf_node_num;
    return RESULT_ZENIC_SUCCESS;
}

uint16_t CNodeConfig::getConfNodeNum()
{
    return m_conf_node_num;
}

void CNodeConfig::showConf()
{
    T_ZCS_NODE Nodes[ZCS_MAX_NODE_NUM];
    uint16_t node_num=0;
    uint16_t node_i;

    printf("================ZCS Configuration================\n");
    printf("SelfNodeRole %u\n", getConfSelfNodeRole());
    printf("ReplicaMode %d\n", getConfReplicaMode());
    printf("KeepAliveHBTimer %u\n", getConfKeepAliveHBTimer());
    printf("KeepAliveHBCount %d\n", getConfKeepAliveHBCount());
    getConfNodeListAndNum(Nodes, node_num);
    printf("Total Node Number: %d\n", node_num);
    for(node_i=0; node_i< node_num; node_i++)
    {
        printf("[No.%03d]: NodeId %3d, ModuleId %3d, RouteType %d\n", 
        	         node_i+1, Nodes[node_i].nodeId, Nodes[node_i].moduleId, Nodes[node_i].route_type);
    }
    printf("================ZCS Configuration================\n");
}

ZENIC_RESULT CNodeConfig::loadConfigFile()
{
    FILE *fp=NULL;
    char *pcTemp;
    char acLine[ZCS_MAX_LINE_STR_LEN];
    int ret = (int)RESULT_ZENIC_SUCCESS;

    fp = fopen(ZCSConfigFilePath, "r");
    if (NULL == fp)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "LoadConf: Open Local config file %s Error.\n", ZCSConfigFilePath);
        return ERROR_FILE_OPEN_FAIL;
    }

    while (0 == feof(fp))
    {
        memset(acLine, 0, sizeof(acLine));
        if (NULL == fgets(acLine, (sizeof(acLine)-1), fp))
        {
            break;
        }

        if(isComments(acLine))
        {
            continue;
        }
        
        skipStringSpaceAndReturn(acLine, sizeof(acLine));
        
        if (0 == strncmp(acLine, "node_role=", strlen("node_role=")))
        {
            pcTemp = acLine + strlen("node_role=");
            ret |= (int)setConfSelfNodeRole((T_ZCS_NODE_ROLE)atoi(pcTemp));
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "LoadConf SelfNodeRole Result:%d, node_role=[%s]\n", ret, pcTemp);
        }
        else if (0 == strncmp(acLine, "replica_copy=", strlen("replica_copy=")))
        {
            pcTemp = acLine + strlen("replica_copy=");
            ret |= (int)setConfReplicaMode((uint16_t)atoi(pcTemp));
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "LoadConf ReplicaMode Result:%d, replica_copy=[%s]\n", ret, pcTemp);
        }
        else if (0 == strncmp(acLine, "alive_timer=", strlen("alive_timer=")))
        {
            pcTemp = acLine + strlen("alive_timer=");
            ret |= (int)setConfKeepAliveHBTimer((uint32_t)atoi(pcTemp));
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "LoadConf KeepAliveHBTimer Result:%d, alive_timer=[%s]\n", ret, pcTemp);
        }
        else if (0 == strncmp(acLine, "alive_count=", strlen("alive_count=")))
        {
            pcTemp = acLine + strlen("alive_count=");
            ret |= (int)setConfKeepAliveHBCount((uint16_t)atoi(pcTemp));
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "LoadConf KeepAliveHBCount Result:%d, alive_count=[%s]\n", ret, pcTemp);
        }
        else if (0 == strncmp(acLine, "node_list=", strlen("node_list=")))
        {
            pcTemp = acLine + strlen("node_list=");
            ret |= (int)setConfNodeListAndNum(pcTemp);
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "LoadConf NodeListAndNum Result:%d, node_list=[%s]\n", ret, pcTemp);
        }
    }
    
    fclose(fp);
    fp = NULL;
    showConf();
    return (ZENIC_RESULT)ret;
}

ZENIC_RESULT CNodeConfig::writeShmConfInfo()
{
    if(NULL==m_ptShmConf || (T_ZCS_CONFIG_INFO *)-1==m_ptShmConf)
    {
        int flag = O_CREAT | O_RDWR;
        int mode = S_IRUSR | S_IWUSR;
        int proto = PROT_READ | PROT_WRITE;
    
        int shm_id1 = shm_open(pZcsConfigShmName, flag, mode);
        
        if(shm_id1<0)
        {
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "writeShmConfInfo ZcsConfigShm shm_open Failed!\n");
            return ERROR_FILE_OPEN_FAIL;
        }
    
        ftruncate(shm_id1, sizeof(T_ZCS_CONFIG_INFO));
        m_ptShmConf = (T_ZCS_CONFIG_INFO *)mmap(NULL,sizeof(T_ZCS_CONFIG_INFO), proto, MAP_SHARED, shm_id1, 0);
        
        if(m_ptShmConf == (T_ZCS_CONFIG_INFO *)-1)
        {
            int err = errno;
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "writeShmConfInfo ZcsConfigShm mmap Result:%d!\n", err);
            close(shm_id1);
            return ERROR_ALLOC_MEM_FAIL;
        }
        close(shm_id1);
        memset(m_ptShmConf, 0, sizeof(T_ZCS_CONFIG_INFO));
    }
    
    m_ptShmConf->node_role = getConfSelfNodeRole();
    m_ptShmConf->replica_num = getConfReplicaMode();
    getConfNodeListAndNum(m_ptShmConf->tNodeList.tNodes, m_ptShmConf->tNodeList.node_num);
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "writeShmConfInfo Success!\n");
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeConfig::addConfNode(uint16_t node_id)
{
	   uint16_t node_i;

    for(node_i = 0; node_i < m_conf_node_num; node_i++)
    {
        if(m_tNodes[node_i].nodeId == node_id)
        {
            return ERROR_ALREADY_EXIST;
        }
    }
    
    if(m_conf_node_num == ZCS_MAX_NODE_NUM)
    {
        return ERROR_BUFFER_OVERFLOW;
    }
    
    m_tNodes[m_conf_node_num].nodeId = node_id;
    m_tNodes[m_conf_node_num].moduleId=node_id;
    m_tNodes[m_conf_node_num].route_type=ZCS_MASTER_BOARD;
    if(m_tNodes[m_conf_node_num].nodeId == ZCMS_VIRTUAL_RIGHT_OMP_NODE_ID)
    {
        m_tNodes[m_conf_node_num].moduleId = ZCS_MASTER_NODE_MODULE_NO;
        m_tNodes[m_conf_node_num].route_type = ZCS_RIGHT_BOARD;
    }
    else if (m_tNodes[m_conf_node_num].nodeId == ZCS_MASTER_NODE_ID_1)
    {
        m_tNodes[m_conf_node_num].moduleId = ZCS_MASTER_NODE_MODULE_NO;
        m_tNodes[m_conf_node_num].route_type = ZCS_LEFT_BOARD;
    }
    m_conf_node_num++;
    
	   writeShmConfInfo();
	   saveConf();
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeConfig::removeConfNode(uint16_t node_id)
{
	   uint16_t node_i;

    for(node_i = 0; node_i < m_conf_node_num; node_i++)
    {
        if(m_tNodes[node_i].nodeId == node_id)
        {
            break;
        }
    }

    if(node_i == m_conf_node_num)
    {
        return ERROR_RECORD_NOT_FOUND;
    }

    XOS_ASSERT(m_conf_node_num <= ZCS_MAX_NODE_NUM);
    
    for(; node_i < m_conf_node_num-1 && node_i < ZCS_MAX_NODE_NUM-1; node_i++)
    {
        m_tNodes[node_i] = m_tNodes[node_i+1];
    }
    memset(&m_tNodes[node_i], 0, sizeof(T_ZCS_NODE));

    XOS_ASSERT(m_conf_node_num-1==node_i);    
    m_conf_node_num--;
    
	   writeShmConfInfo();
	   saveConf();
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeConfig::saveConf()
{
    FILE *fp=NULL;
    char *pcTemp;
    char NumStr[ZCS_MAX_LINE_STR_LEN];
    int ret = (int)RESULT_ZENIC_SUCCESS;
    uint16_t node_i = 0;
    uint16_t wTotalLineNum = 0;
    uint16_t wTotalCommentLineNum = 0;
    uint16_t wLineNum = 0;
    
    fp = fopen(ZCSConfigFilePath, "r");
    if (NULL == fp)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "saveConf: Open Local config file %s r Error.\n", ZCSConfigFilePath);
        return ERROR_FILE_OPEN_FAIL;
    }

    memset(sLine, 0, sizeof(sLine));
    while (0 == feof(fp))
    {
    	   if(wTotalLineNum>=ZCS_MAX_LINES)
    	   {
        	   ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "saveConf: Open file Error: too more lines.\n");
            break;
    	   }
        
        if (NULL == fgets(sLine[wTotalLineNum], (sizeof(sLine[wTotalLineNum])-1), fp))
        {
            break;
        }

        if(isComments(sLine[wTotalLineNum]))
        {
            if(wTotalCommentLineNum<ZCS_MAX_COMMENT_LINES)
            {
            	   wTotalCommentLineNum++;
                wTotalLineNum++;
            }
            else
            {
            	   wTotalCommentLineNum++;
                memset(sLine[wTotalLineNum], 0, sizeof(sLine[wTotalLineNum]));
                ZCS_LOG(ZCS_LOG_WARN, ZCS_LOG_MOD_ZCMS, "saveConf: Open file: too more comment lines:%d.\n", wTotalCommentLineNum);
            }
            continue;
        }
        wTotalLineNum++;
    }

    fclose(fp);
    
    fp = fopen(ZCSConfigFilePath, "w");
    if (NULL == fp)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "saveConf: Open Local config file %s w Error.\n", ZCSConfigFilePath);
        return ERROR_FILE_OPEN_FAIL;
    }
    for(wLineNum = 0; wLineNum < wTotalLineNum; wLineNum++)
    {
        memset(NumStr, 0, sizeof(NumStr));

        if(isComments(sLine[wLineNum]))
        {
        	   fputs(sLine[wLineNum], fp);
            continue;
        }

        skipStringSpaceAndReturn(sLine[wLineNum], sizeof(sLine[wLineNum]));
        
        if (0 == strncmp(sLine[wLineNum], "node_role=", strlen("node_role=")))
        {
            pcTemp = sLine[wLineNum] + strlen("node_role=");
            strncpy(pcTemp, myitoa(getConfSelfNodeRole(), NumStr, 10), (sizeof(sLine[wLineNum])-1+sLine[wLineNum]-pcTemp));
            pcTemp = pcTemp+strlen(NumStr);
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "saveConf SelfNodeRole Result:%d, %s\n", ret, sLine[wLineNum]);
        }
        else if (0 == strncmp(sLine[wLineNum], "replica_copy=", strlen("replica_copy=")))
        {
            pcTemp = sLine[wLineNum] + strlen("replica_copy=");
            strncpy(pcTemp, myitoa(getConfReplicaMode(), NumStr, 10), (sizeof(sLine[wLineNum])-1+sLine[wLineNum]-pcTemp));
            pcTemp = pcTemp+strlen(NumStr);
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "saveConf ReplicaMode Result:%d, %s\n", ret, sLine[wLineNum]);
        }
        else if (0 == strncmp(sLine[wLineNum], "alive_timer=", strlen("alive_timer=")))
        {
            pcTemp = sLine[wLineNum] + strlen("alive_timer=");
            strncpy(pcTemp, myitoa(getConfKeepAliveHBTimer(), NumStr, 10), (sizeof(sLine[wLineNum])-1+sLine[wLineNum]-pcTemp));
            pcTemp = pcTemp+strlen(NumStr);
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "saveConf KeepAliveHBTimer Result:%d, %s\n", ret, sLine[wLineNum]);
        }
        else if (0 == strncmp(sLine[wLineNum], "alive_count=", strlen("alive_count=")))
        {
            pcTemp = sLine[wLineNum] + strlen("alive_count=");
            strncpy(pcTemp, myitoa(getConfKeepAliveHBCount(), NumStr, 10), (sizeof(sLine[wLineNum])-1+sLine[wLineNum]-pcTemp));
            pcTemp = pcTemp+strlen(NumStr);
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "saveConf KeepAliveHBCount Result:%d, %s\n", ret, sLine[wLineNum]);
        }
        else if (0 == strncmp(sLine[wLineNum], "node_list=", strlen("node_list=")))
        {
            pcTemp = sLine[wLineNum] + strlen("node_list=");
            for(node_i=0; node_i<getConfNodeNum(); node_i++)
            {
                strncpy(pcTemp, myitoa((int)m_tNodes[node_i].nodeId, NumStr, 10), (sizeof(sLine[wLineNum])-1+sLine[wLineNum]-pcTemp));
                pcTemp = pcTemp+strlen(NumStr);
                if(node_i!=getConfNodeNum()-1)
                {
                    *pcTemp=ZCS_CONF_SEPERATOR;
                    pcTemp++;
                }
            }
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "saveConf NodeList Result:%d, %s\n", ret, sLine[wLineNum]);
        }
        else
        {
        	   ZCS_LOG(ZCS_LOG_WARN, ZCS_LOG_MOD_ZCMS, "saveConf Result:%d, Unrecognized String %s\n", ret, sLine[wLineNum]);
            continue;
        }

        *pcTemp++='\n';
        *pcTemp++='\0';
        fputs(sLine[wLineNum], fp);
    }

    fflush(fp);
    fdatasync(fileno(fp));
    fclose(fp);
    fp = NULL;
    #if ZCMS_DEBUG
    showConf();
    #endif
    return (ZENIC_RESULT)ret;
}

ZENIC_RESULT CNodeConfig::onSyncData(void* data, uint32_t len)
{
	   uint16_t node_i = 0;
	   T_ZCMS_CONFIG_INFO* pConfInfo = (T_ZCMS_CONFIG_INFO*)data;
	   
	   XOS_ASSERT(len == sizeof(T_ZCMS_CONFIG_INFO));
    /*  role�����޸� */
   	//m_self_role = pConfInfo->tSelfRole;
    setConfKeepAliveHBTimer(pConfInfo->tAliveTimer);
    setConfKeepAliveHBCount(pConfInfo->tAliveCount);
   	//setConfReplicaMode(pConfInfo->tReplica_Mode);
    m_conf_node_num = pConfInfo->tConfNodeNum;
    memset(m_tNodes, 0, sizeof(m_tNodes));
    for(node_i = 0; node_i < m_conf_node_num; node_i++)
    {
        m_tNodes[node_i] = pConfInfo->tNodes[node_i];
    }

    writeShmConfInfo();
    saveConf();
    return RESULT_ZENIC_SUCCESS;
}

CNodeConfig::~CNodeConfig() {
    // TODO Auto-generated destructor stub
}

char* myitoa(int num, char*str, int radix) 
{
	char index[]="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"; 
	unsigned unum;/*�м����*/
	int i=0, j, k; 
	
	/*ȷ��unum��ֵ*/
	if(radix==10&&num<0)
		/*ʮ���Ƹ���*/
	{ 
		unum=(unsigned)-num;
		str[i++]='-'; 
	} 
	else
		unum=(unsigned)num;
	/*�������*//*ת��*/
	do{ 
		str[i++]=index[unum%(unsigned)radix];
	 unum/=radix; 
	}while(unum); 
	str[i]='\0';
	/*����*/
	if(str[0]=='-')k=1;
	/*ʮ���Ƹ���*/
	else
	k=0; 
	char temp; 
	
	for(j=k;j<=(i-1)/2;j++) 
	{ 
		  temp=str[j]; 
	  str[j]=str[i-1+k-j]; 
	  str[i-1+k-j]=temp; 
	} 
	
		return str;
} 



