/*
 * CSyncDataPool.h
 *
 *  Created on: 2014-9-3
 *      Author: wangjun
 */

#ifndef CSYNCDATAPOOL_H_
#define CSYNCDATAPOOL_H_
#include <stdint.h>
#include "tulip.h"
#include "tulip_oss.h"
#include "zenic_def.h"
#include "zcs_types.h"
#include "CInstMgr.hpp"
#include "CSyncMsg.h"

#define ZCPS_TMR_INIT_INTERVAL         0xffffffff
#define ZCPS_ITEM_IDLE_SND_INTERVAL    200         // no data filling at ZCPS_ITEM_FILLING state ticks
#define ZCPS_ITEM_RETRY_INTERVAL       1000        // retransmit period ticks
/* ״̬ */
#define ZCPS_ITEM_INIT           0   /* ��ʼ̬ */
#define ZCPS_ITEM_FILLING        1   /* �����ڵȴ������������״̬ */
#define ZCPS_ITEM_READY4SEND     2   /* �����Ѿ�׼�������� */
#define ZCPS_ITEM_SENT           3   /* �����ѷ��� */

const uint32_t ZCPS_SYNC_POOL_SIZE = 10240;
const uint32_t ZCPS_SYNC_MAX_NODE_NUM = ZCS_MAX_NODE_NUM-1;  //129
const uint32_t ZCPS_MAX_SYNC_COUNT_PER_ROUND = 768;
const uint32_t ZCPS_MIN_SYNC_COUNT_PER_ROUND = 64;
const uint32_t ZCPS_MAX_SYNC_RETRY_COUNT = 3;

const uint32_t ZCPS_MAX_SYNC_OBJ = 16;
const uint32_t ZCPS_MAX_SYNC_ACK = ZCPS_MAX_SYNC_OBJ;

struct T_ZCPS_SYNC_POOL_DATA {
    uint32_t retry_count;
    uint32_t cookie;//�ϲ㷢�ʹ����Cookie������ͬ����Դ�ض�λ
    bool isChgOverData;
    uint16_t dst_node_id;
    T_ZCPS_MSG tMsg;
};

struct T_ZCPS_ITEMOBJ_INFO{
    uint32_t cookie;//�ϲ㷢�ʹ����Cookie������ͬ����Դ�ض�λ
    uint16_t offset;
    bool     isChgOverData;
    uint8_t  pad;
    T_ZCS_APP_SYNC_MSG_HDR tSyncHdr;
    uint8_t data[0];
}_ZENIC_PACKED;

struct T_ZCPS_ITEM_OBJ{
    T_ZCS_APP_SYNC_MSG_HDR tObjHdr;
    uint8_t ucObjData[0];
};

struct T_ZCPS_ITEM_HEAD{
    uint32_t dwTsn;
    uint16_t wObjLen;
    uint16_t wObjCnt;
    T_ZCPS_ITEM_OBJ tItemData[0];
};

struct T_ZCPS_SYNC_ACK{
    uint32_t dwTsn;
    uint16_t wNodeId;  //Acker's Node ID
    uint16_t wObjAckCnt;
    T_EV_ZCS_INNNER_DATA_SYNC_ACK tObjAck[ZCPS_MAX_SYNC_ACK];
};
struct T_ZCPS_SYNC_ITEM {
    uint8_t  ucState;
    uint8_t  ucRetryCnt;
    uint16_t wPad;
    uint16_t wDataLen;
    uint16_t wCookieCnt;
    uint32_t dwCookie[ZCPS_MAX_SYNC_OBJ];
    bool     bIsChgOverData[ZCPS_MAX_SYNC_OBJ];
    uint8_t* pObjBuff;
    /* --real sync data get sent from here-- */
    T_ZCPS_ITEM_HEAD tItemHdr;            //syncdata head
    uint8_t  data[ZCS_MAX_SYNCITEM_LEN];  //syncdata body
};
struct T_ZCPS_SYNC_QUEUE {
    uint16_t wDstNodeId;
    uint8_t  ucPad[2];
    uint32_t dwCounter;
    uint32_t ini_seq;
    uint32_t snd_new;
    uint32_t snd_wnd; //todo
    uint32_t rexmit_cnt;
    uint32_t item_snt_suc;
    uint32_t item_snt_fail;
    uint32_t obj_snt_suc;
    uint32_t obj_snt_fail;
    uint32_t item_state_err;
    uint32_t zero_wnd;
    T_ZCPS_SYNC_ITEM tItem;
};

class CSyncDataPool {
    InstMgr::CValPoolMgr<T_ZCPS_SYNC_POOL_DATA> m_sync_data_pool;//��ͨ����
    InstMgr::CInstMgr1<uint16_t,T_ZCPS_SYNC_QUEUE> m_syncQueue;//Node_id�Լ�ͳ������
    uint32_t m_cur_scan_index;
    uint32_t m_chgover_data_count;
    uint16_t m_self_node_id;
    uint32_t m_max_sync_count;
    uint32_t m_send_data_count;
    uint32_t m_recv_ack_count;
    uint32_t m_recv_ack_invalid;
    //���Դ���
    uint32_t m_send_sync_retry;
    uint32_t m_over_retry_count;
    uint32_t m_sync_pool_alloc_fail;
    uint32_t m_sync_queue_alloc_fail;
    JID m_self_jid;
    JID m_recv_jid;
    void clear();
    ZENIC_RESULT sendSyncMsg(uint16_t QueueIdx, T_ZCPS_SYNC_ITEM* pSndItem);
    void flushQueue(uint16_t dst_node_id);
    void flushAllQueue();
    T_ZCPS_SYNC_ITEM* getNewSyncItem(uint16_t node_id);
    inline int getQueue(uint16_t node_id, uint32_t& idx);
    
    /*��Ӳ��������ض��г���*/
    uint32_t enQueue(uint16_t node_id, uint32_t data_idx);
    /*���Ӳ��������ض��г���*/
    uint32_t deQueue(uint16_t node_id, uint32_t data_idx);
    uint32_t getSendWindowSize();
public:
    CSyncDataPool();
    ZENIC_RESULT init(uint16_t self_node_id);
    //ͬ��һ�����ݣ�ָ��Ŀ��ģ�顣Cookie������ȷ��ʱ�Ĺ�������
    ZENIC_RESULT syncData(const T_ZCPS_MSG &tMsg, uint16_t dest_node,uint32_t cookie, bool isChgOverData);
    //�յ�����ͬ��Ӧ����Ϣ
    ZENIC_RESULT onSyncAck(const T_EV_ZCS_INNNER_DATA_SYNC_ACK &tAck, uint32_t &cookie);
    //ͬ����ʱ����Ϣ����
    void onSyncTimerEvent(uint32_t param);
    //��ȡ���г���
    uint32_t getQueueLen(uint16_t node_id);
    //��ȡ��Դ������
    uint32_t getPoolDataNum();
    /*��ȡ��ǰ���������ж���*/
    uint32_t getFreeLen();
    /*��ȡChangeOver��������*/
    uint32_t getChgOverDataNum();
    /*��ӡ������Ϣ*/
    void print_stats();	
    void showInstMgrStats();	
	void cleanDataPoolStats();
    uint32_t getSendRetryCount();      
    void resetSendRetryCount();
    uint32_t getSyncPoolAllocFailCount();
    void resetSyncPoolAllocFailCount();
    virtual ~CSyncDataPool();
};

#endif /* CSYNCDATAPOOL_H_ */
