/*
 * CRteTableStats.h
 *
 *  Created on: 2014-9-12
 *      Author: wangjun
 */

#ifndef CRTETABLESTATS_H_
#define CRTETABLESTATS_H_
#include "zcs_rte_def.h"
#include <map>
struct T_RTE_STATS {
    uint16_t master_counter;
    uint16_t backup1_counter;
    uint16_t backup2_counter;
}_ZENIC_PACKED;

enum E_RTE_STATS_TYPE {
    E_RTE_STATS_MASTER = 1,
    E_RTE_STATS_BACKUP1 = 2,
    E_RTE_STATS_BACKUP2 = 3
};

const uint8_t RTAB_ADJ_MASTER=E_RTE_STATS_MASTER;
const uint8_t RTAB_ADJ_BACKUP1=1<<E_RTE_STATS_BACKUP1;
const uint8_t RTAB_ADJ_BACKUP2=1<<E_RTE_STATS_BACKUP2;

class CRteTableStats {
    std::map<uint16_t,T_RTE_STATS> m_table_stats;
    typedef std::map<uint16_t,T_RTE_STATS>::iterator STATS_IT;
    T_RTE_STATS m_to_be_changed;
    uint16_t m_seg_num;
    uint16_t m_backup_copy, m_real_backup_copy;
    bool isInNodesGrp(uint16_t node_id,const T_DHT_NODES_GROUP &tNodes);
    //void adjustCounter(const T_DHT_NODES_GROUP &NewGrp,const T_DHT_NODES_GROUP &tOldGrp);
    uint16_t getCounter(E_RTE_STATS_TYPE type,uint16_t node_id);
    void calc_real_backup_copy();
public:
    CRteTableStats();
    /*���ؼ������ٵĽڵ㣬���ȷ���node_id*/
    uint16_t min(E_RTE_STATS_TYPE type,uint16_t node_id,const T_DHT_NODES_GROUP &exclude_node_id);

    uint16_t max(E_RTE_STATS_TYPE type,uint16_t node_id,const T_DHT_NODES_GROUP &exclude_node_id);

    /*����ָ���ڵ�ļ�����*/
     uint16_t get_real_backup_copy()
    {
        return m_real_backup_copy;
    }
    void increase(E_RTE_STATS_TYPE type,uint16_t node_id);
    void decrease(E_RTE_STATS_TYPE type,uint16_t node_id);
    ZENIC_RESULT addNode(uint16_t node_id);
    ZENIC_RESULT removeNode(uint16_t node_id);
    ZENIC_RESULT AdjustAfterDeleteNode(uint16_t node_id, T_DHT_NODES_GROUP &tOldGrp, T_DHT_NODES_GROUP &tNewGrp,bool &bM2S);
    ZENIC_RESULT AdjustAfterAddNode(uint16_t node_id, T_DHT_NODES_GROUP &tOldGrp, T_DHT_NODES_GROUP &tNewGrp);
    ZENIC_RESULT allocateNodes(T_DHT_NODES_GROUP &tNodes);
    void init(T_DHT_RTE_TABLE &rteTable);
    void init(T_DHT_NODE_LIST &tNodes,uint16_t backup_copy, uint16_t seg_num);
    void clear();
    void print_stats();
    uint16_t getNodeCount();
    virtual ~CRteTableStats();
    void adjustCounter(const T_DHT_NODES_GROUP &NewGrp,const T_DHT_NODES_GROUP &tOldGrp);
};

#endif /* CRTETABLESTATS_H_ */
