/*
 * zcrs_common.h
 *
 *  Created on: 2014-9-4
 *      Author: wangjun
 */

//#define ZCRS_RTE_TABLE_OPT

#ifndef ZCRS_COMMON_H_
#define ZCRS_COMMON_H_
#include <stdint.h>
#include "zcs_common.h"

/*����ʱ�ȴ�ҵ����������ɹ��Ķ�ʱ��*/
const uint16_t EV_SYS_ZCRS_BOOT_WAIT_TIMER = EV_SYS_INNER_ZCRS_BEGIN+0;

/*����������ʱ��*/
const uint16_t EV_SYS_ZCRS_WAIT_RTE_CHGOVER_ACK_TIMER = EV_SYS_INNER_ZCRS_BEGIN+1;

enum E_ZCRS_NODE_STATE {
    E_ZCRS_NODE_STATE_PENDING = 0,
    E_ZCRS_NODE_STATE_ACTIVE = 1,
    E_ZCRS_NODE_STATE_INACTIVE = 2,
    E_ZCRS_NODE_STATE_BLOCKED = 4
};

struct T_ZCRS_NODE_STATE {
    uint16_t node_id;
    E_ZCRS_NODE_STATE eState;
};

struct T_ZCRS_NODE_LIST {
    uint16_t node_num;
    uint16_t active_num;
    T_ZCRS_NODE_STATE node_state[ZCS_MAX_NODE_NUM];
    T_ZCRS_NODE_LIST &operator=(T_ZCS_NODE_LIST &nodes)
    {
        uint16_t num=nodes.node_num;
        node_num = nodes.node_num;
        active_num = 0;
        for(uint16_t i=0;i<num;i++)
        {
            node_state[i].node_id=nodes.tNodes[i].nodeId;
            node_state[i].eState = E_ZCRS_NODE_STATE_PENDING;
        }

        return *this;
    }
};

/*ɱ����ʱ��������������ʱ����Ϊ��Чֵ*/
void zcrs_kill_timer(uint32_t &timer_id);

ZENIC_RESULT zcrs_send_msg(uint32_t msg_id,const uint8_t *msg,uint16_t len, uint16_t node_id, JID &tJid);
#endif /* ZCRS_COMMON_H_ */
