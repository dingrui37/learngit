/*
 * CNodeMgr.h
 *
 *  Created on: 2014-8-31
 *      Author: wangjun
 */

#ifndef ZCSTEST_H_
#define ZCSTEST_H_
#include "zcs_job_def.h"

#define ZCS_TES
#ifdef ZCS_TEST
#ifdef __cplusplus
extern "C" {
#endif

#define ZCS_JOB_TYPE_TEST              (ZCS_JOB_TYPE_BEGIN+100)

#define ZCS_TEST_JOB_STATE_MWORK  254
#define ZCS_TEST_JOB_STATE_SWORK  255

void zcs_test_entry(WORD16 wState, WORD32 dwMsgId, void *pMsgBody, void *pPData, BOOLEAN bSame);
#ifdef __cplusplus
}
#endif

#endif
#endif /* ZCSTEST_H_ */

