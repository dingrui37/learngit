/*
 * CNodeMgr.cpp
 *
 *  Created on: 2014-8-31
 *      Author: wangjun
 */

#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/errno.h>

#include "../../../plat/include/scs_global.h"
#include "CNodeMgr.h"
//#include "CHdTimer.hpp"

/* ���кűȽϹ��ܺꡣ���в���Ϊuint32_t�� */
#ifndef SEQ_COMPARE
#define SEQ_COMPARE
#define SEQ_GE(x, y)    (!(((x) - (y)) & 0x80000000L))
#define SEQ_LE(x, y)    (SEQ_GE(y, x))
#define SEQ_LT(x, y)    (!SEQ_GE(x, y))
#define SEQ_GT(x, y)    (!SEQ_LE(x, y))
#define SEQ_EQ(x, y)    ((x) == (y))
#define SEQ_NE(x, y)    (!SEQ_EQ(x, y))
#endif

#define HB_TIMEOUT_ALARM_THRESHOLD 3
#define OAM_WORKER_JNO 0x47230001

/* ���ķ����ʱ��,0xffffffff��ʾ��Զ��Ч */
#define SUBSCRIBE_TIMEOUT_NEVER       (uint32_t)0xffffffff

extern void constrConfInfo(T_ZCMS_CONFIG_INFO &tConf, CNodeConfig *pCNodeConf);
extern ZENIC_RESULT zcs_constructJID(uint16_t job_type, uint16_t instance,JID &tJid);

static T_EV_ZCMS_DATA_SYNC stSyncData;
static T_EV_ZCMS_MULTICAST_SYNC stMultiSyncData;

const static char *pNodeLinkState[]={
    "Init",
    "Queueing",
    "Registering",
    "Active",
    "Inactive"
};


CNodeMgr::CNodeMgr()
    : m_pConfig(NULL), m_pZcmsMgr(NULL), m_isMgrWorking(0),
      m_dwQueueClntCnt(0), m_dwMultiCastClntCnt(0), m_dwSyncSeq(0),
      m_ClientHBCheckTimerID(0), m_SlaveMgrSyncReqTimerID(0),
      m_MasterMgrMSSyncTimerID(0), m_NotifyUPLWaitACKTimerID(0),  m_MSMgrSyncFlag(0),
      m_MasterMgrMultiCastSyncTimerID(0), m_dwChgOverFlag(0), m_ChgOverTimerID(0),
      m_bIsMateOnline(false), m_ptActiveNodeList(NULL)
{
    memset(&m_MateJID, 0, sizeof(m_MateJID));
    memset(&o_tMgrStt, 0, sizeof(o_tMgrStt));
}

ZENIC_RESULT CNodeMgr::init(CNodeConfig *ptNodeConf, CZcmsMgr *pZcmsMgr, uint16_t wWorkState)
{
    int ret;
    ZENIC_RESULT zenic_ret;
    uint16_t wNodeIdx;
    T_ZCS_NODE tZCSNode;

    XOS_ASSERT(ptNodeConf);
    XOS_ASSERT(pZcmsMgr);
    
    m_pConfig = ptNodeConf;
    m_pZcmsMgr = pZcmsMgr;
    m_isMgrWorking = FALSE;
    
    if(!(ptNodeConf->getConfSelfNodeRole() & ZCS_NODE_ROLE_MASTER))
    {
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_BUF_ZCMS,"CNodeMgr init, I'm Not NodeMgr Node!\n");
        return RESULT_ZENIC_SUCCESS;
    }

    m_dwQueueClntCnt = ZCMS_QUEUE_ID_NUMBER_FIRST-1;
    m_dwMultiCastClntCnt = 0;
    m_dwSyncSeq = ZCMS_INIT_SYNC_SEQ;
    
    zenic_ret = onLAPoolinit();
    if(RESULT_ZENIC_SUCCESS != zenic_ret)
    {
        return zenic_ret;
    }

    memset(&o_tMgrStt,0, sizeof(o_tMgrStt));
    
    ret = m_tAllCNodesInfo.init(ZCS_MAX_NODE_NUM);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"m_tAllCNodesInfo.init Failed ret=%d", ret);
        return ERROR_ALLOC_MEM_FAIL;
    }
    for(wNodeIdx = 0; wNodeIdx < m_pConfig->getConfNodeNum(); wNodeIdx++)
    {
        memset(&tZCSNode, 0, sizeof(tZCSNode));
        zenic_ret = m_pConfig->getNode(wNodeIdx, tZCSNode);
        if(zenic_ret != RESULT_ZENIC_SUCCESS)
        {
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"m_pConfig->getNode by wNodeIdx %d, Failed ret=%d\n", 
            	                wNodeIdx, zenic_ret);
            return zenic_ret;
        }
        
        zenic_ret = initNodeInfo(tZCSNode.nodeId);
        if(zenic_ret != RESULT_ZENIC_SUCCESS)
        {
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"initNodeInfo NodeID[%d] Failed ret=%d\n", 
            	                tZCSNode.nodeId, zenic_ret);
            return zenic_ret;
        }
    }
    
    zenic_ret = NodeEventSubinit();
    if(RESULT_ZENIC_SUCCESS != zenic_ret)
    {
        return zenic_ret;
    }
    
    zenic_ret = subMateOnlineState();
    if(RESULT_ZENIC_SUCCESS != zenic_ret)
    {
        return zenic_ret;
    }
    
    ret = m_tActiveNodes.init(ZCS_MAX_NODE_NUM);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"m_tActiveNodes.init Failed ret=%d", ret);
        return ERROR_ALLOC_MEM_FAIL;
    }

    /* Only master center node init the check timer */
    if(ZCS_JOB_STATE_MNODE_WORK == wWorkState)
    {
        m_ClientHBCheckTimerID = zcms_set_looptimer(EV_SYS_ZCMS_MGR_CHECK_HBTO_TIMER, m_pConfig->getConfKeepAliveHBTimer(), PARAM_NULL);
    }
    else
    {
        zcms_init_timer(m_ClientHBCheckTimerID);
    }

    zcms_init_timer(m_MasterMgrMSSyncTimerID);
    zcms_init_timer(m_SlaveMgrSyncReqTimerID);
    zcms_init_timer(m_MasterMgrMultiCastSyncTimerID);
    zcms_init_timer(m_ChgOverTimerID);
    zcms_init_timer(m_NotifyUPLWaitACKTimerID);
    m_dwChgOverFlag = 0;
    m_MSMgrSyncFlag = 0;
    m_ptActiveNodeList = NULL;
    
    m_isMgrWorking = TRUE;
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::onLAPoolinit()
{
    int ret;
    uint32_t idx;
    uint16_t wNodeIdx;
    T_ACS_PHY_ADDR tPhyAKey;

    ret = m_tNodePool.init(sizeof(g_tSysNodeLa)/sizeof(T_LOGIC_ADDR_ALLOC));
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"m_tNodePool.init Failed ret=%d", ret);
        return ERROR_ALLOC_MEM_FAIL;
    }
    
    for(wNodeIdx = 0; wNodeIdx < sizeof(g_tSysNodeLa)/sizeof(T_LOGIC_ADDR_ALLOC); wNodeIdx++)
    {
        tPhyAKey.ucRackId = g_tSysNodeLa[wNodeIdx].ucRackId;
        tPhyAKey.ucShelfId = g_tSysNodeLa[wNodeIdx].ucShelfId;
        tPhyAKey.ucSlotId = g_tSysNodeLa[wNodeIdx].ucSlotId;
        tPhyAKey.ucCpuId = g_tSysNodeLa[wNodeIdx].ucCpuId;
        ret = m_tNodePool.allocInstByKey1(tPhyAKey, idx);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"m_tNodePool.allocInstByKey1 %d:%d:%d:%d, Failed ret=%d\n", 
            	                tPhyAKey.ucRackId, tPhyAKey.ucShelfId, tPhyAKey.ucSlotId, tPhyAKey.ucCpuId, ret);
            return ERROR_ALLOC_INSTANCE_FAIL;
        }

        ret = m_tNodePool.setInstByIndex(idx, g_tSysNodeLa[wNodeIdx]);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"m_tNodePool.setInstByIndex %d:%d:%d:%d, Failed ret=%d\n", 
            	                tPhyAKey.ucRackId, tPhyAKey.ucShelfId, tPhyAKey.ucSlotId, tPhyAKey.ucCpuId, ret);
            return ERROR_INSERT_RECORD_FAIL;
        }
    }
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::onAppLAReq(void *pMsg, uint16_t msg_len)
{
	   int ret;
	   XOS_STATUS xos_ret;
	   uint32_t idx;
	   T_ACS_PHY_ADDR tPhyAKey;
	   T_LOGIC_ADDR_ALLOC tLogAddr;
	   T_BoardLogicAddrInfo tBrdLaInfo;
	   T_PhysAddress tPa;
	   
	   T_BOARD_PHY_INFO* pBrd = (T_BOARD_PHY_INFO*)pMsg;
	   T_SCS_BRDCTRL_PHYADDR_INFO* pBrdPhyInfo = &(pBrd->tBoardPhyAddrInfo);

    XOS_ASSERT(sizeof(T_BOARD_PHY_INFO) == msg_len);
    tPhyAKey.ucRackId = tPa.ucRackId = pBrdPhyInfo->ucRackId;
    tPhyAKey.ucShelfId = tPa.ucShelfId = pBrdPhyInfo->ucShelfId;
    tPhyAKey.ucSlotId = tPa.ucSlotId = pBrdPhyInfo->ucSlotId;
    tPhyAKey.ucCpuId = tPa.ucCpuId = pBrdPhyInfo->ucCpuDspId;

    ret = m_tNodePool.findInstByKey1(tPhyAKey, idx);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"onAppLAReq find PA[%d:%d:%d:%d], Failed ret=%d\n", 
        	                tPhyAKey.ucRackId, tPhyAKey.ucShelfId, tPhyAKey.ucSlotId, tPhyAKey.ucCpuId, ret);
        return ERROR_ALLOC_INSTANCE_FAIL;
    }
    
    ret = m_tNodePool.getInstByIndex(idx, tLogAddr);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"onAppLAReq get LA idx:%d, Failed ret=%d\n", idx, ret);
        return ERROR_ALLOC_INSTANCE_FAIL;
    }

    memset(&tBrdLaInfo, 0, sizeof(tBrdLaInfo));
    tBrdLaInfo.dwRetCode = SCS_OK;
    tBrdLaInfo.atLAConfigInfo[0].dwRetCode = SCS_OK;
    tBrdLaInfo.atLAConfigInfo[0].tLeftOmpPhyAddr.ucRackId = OMP_RACK;
    tBrdLaInfo.atLAConfigInfo[0].tLeftOmpPhyAddr.ucShelfId = OMP_SHELF;
    tBrdLaInfo.atLAConfigInfo[0].tLeftOmpPhyAddr.ucSlotId = OMP_LEFT_SLOT;
    tBrdLaInfo.atLAConfigInfo[0].tLeftOmpPhyAddr.ucCpuId = OMP_CPUID;
    tBrdLaInfo.atLAConfigInfo[0].tRightOmpPhyAddr = tBrdLaInfo.atLAConfigInfo[0].tLeftOmpPhyAddr;
    tBrdLaInfo.atLAConfigInfo[0].tRightOmpPhyAddr.ucSlotId = OMP_RIGHT_SLOT;
    tBrdLaInfo.atLAConfigInfo[0].tSysLAMask.wModuleMask     = MAX_MODULE_VALUE;
    tBrdLaInfo.atLAConfigInfo[0].tSysLAMask.wUnitMask       = MAX_UNIT_VALUE;
    tBrdLaInfo.atLAConfigInfo[0].tSysLAMask.ucSUnitMask     = MAX_SUNIT_VALUE;
    tBrdLaInfo.atLAConfigInfo[0].tSysLAMask.ucSubSystemMask = MAX_SUBSYSTEM_VALUE;
    /*������ģʽ*/
    tBrdLaInfo.atLAConfigInfo[0].ucBackUpMode = BOARD_BACKUP_MODE_NONE;
    /*����������ַ*/
    tBrdLaInfo.atLAConfigInfo[0].tMatePhyAddr.ucRackId = tLogAddr.ucRackId;
    tBrdLaInfo.atLAConfigInfo[0].tMatePhyAddr.ucShelfId = tLogAddr.ucShelfId;
    tBrdLaInfo.atLAConfigInfo[0].tMatePhyAddr.ucSlotId = tLogAddr.ucSlotId;
    tBrdLaInfo.atLAConfigInfo[0].tMatePhyAddr.ucCpuId = tLogAddr.ucCpuId;

    /*OMP�߼���ַ*/
    tBrdLaInfo.atLAConfigInfo[0].tLOmpLogicAddr.wModule = OMP_MODULE;
    tBrdLaInfo.atLAConfigInfo[0].tLOmpLogicAddr.wUnit= OMP_UNIT;
    tBrdLaInfo.atLAConfigInfo[0].tLOmpLogicAddr.ucSUnit= OMP_SUNIT;
    tBrdLaInfo.atLAConfigInfo[0].tLOmpLogicAddr.ucSubSystem= OMP_SUBSYSTEM;

    /*�����߼���ַ*/
    tBrdLaInfo.atLAConfigInfo[0].tBoardLogicAddr.wSystem=0;
    tBrdLaInfo.atLAConfigInfo[0].tBoardLogicAddr.ucSubSystem = 0xFF;
    tBrdLaInfo.atLAConfigInfo[0].tBoardLogicAddr.wModule = tLogAddr.wModule;
    tBrdLaInfo.atLAConfigInfo[0].tBoardLogicAddr.wUnit=0xFFFF;
    tBrdLaInfo.atLAConfigInfo[0].tBoardLogicAddr.ucSUnit=0xFF;
    tBrdLaInfo.atLAConfigInfo[0].ucLogCpuNo = tLogAddr.ucCpuId;
    tBrdLaInfo.ucCurrLogCpuNum=tLogAddr.ucCpuId;
    tBrdLaInfo.ucTotLogCpuNum=1;

    if(tLogAddr.wModule==OMP_MODULE)
    {
        tBrdLaInfo.atLAConfigInfo[0].tBoardLogicAddr.wUnit= OMP_UNIT;
        tBrdLaInfo.atLAConfigInfo[0].tBoardLogicAddr.ucSUnit= OMP_SUNIT;
        tBrdLaInfo.atLAConfigInfo[0].tBoardLogicAddr.ucSubSystem= OMP_SUBSYSTEM;
        tBrdLaInfo.atLAConfigInfo[0].ucBackUpMode = BOARD_BACKUP_MODE_MASTERSLAVE;
        if(tBrdLaInfo.atLAConfigInfo[0].tMatePhyAddr.ucSlotId%2==0)
        {
            tBrdLaInfo.atLAConfigInfo[0].tMatePhyAddr.ucSlotId-=1;
            tBrdLaInfo.atLAConfigInfo[0].ucLeftOrRight=BOARD_RIGHT;
        }
        else
        {
            tBrdLaInfo.atLAConfigInfo[0].tMatePhyAddr.ucSlotId+=1;
            tBrdLaInfo.atLAConfigInfo[0].ucLeftOrRight=BOARD_LEFT;
        }
    }

    xos_ret= XOS_SendToTask(EV_BOARD_LOGIC_ADDR_ACK,
                           (BYTE *)&tBrdLaInfo,
                            sizeof(T_BoardLogicAddrInfo),
                           XOS_MSG_VER0,
                           XOS_MSG_HIGH,
                           SCS_MCM_CONFIG,
                           &tPa);
    
    if (XOS_SUCCESS!=xos_ret)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS, "onAppLAReq Send EV_BOARD_LOGIC_ADDR_ACK to PA[%d:%d:%d:%d] Failed.\n", 
        	                                  tPhyAKey.ucRackId, tPhyAKey.ucShelfId, tPhyAKey.ucSlotId, tPhyAKey.ucCpuId);
        return ERROR_COMMON_ERROR;
    }

    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_BUF_ZCMS, "onAppLAReq Send EV_BOARD_LOGIC_ADDR_ACK to PA[%d:%d:%d:%d].\n", 
        	                                  tPhyAKey.ucRackId, tPhyAKey.ucShelfId, tPhyAKey.ucSlotId, tPhyAKey.ucCpuId);
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::subMateOnlineState()
{
	   XOS_STATUS xos_ret;
	   ZENIC_RESULT zenic_ret;
	   
    setMateOnlineState(FALSE);
    zenic_ret = constructMateJID(m_MateJID);
    if(RESULT_ZENIC_SUCCESS != zenic_ret)
    {
        return zenic_ret;
    }
    
	   xos_ret = XOS_RequestSubScrEx((VOID*)&m_MateJID, SUBSCRIBE_TIMEOUT_NEVER, SUBSCR_LAWORK_STATE|SUBSCR_NOTCARE_MS);
	   if(XOS_SUCCESS != xos_ret)
	   {
	   	   ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"subMateOnlineState Failed ret=%d", xos_ret);
        return ERROR_COMMON_ERROR;
	   }
    return RESULT_ZENIC_SUCCESS;
}

void CNodeMgr::onHandleTipcSubscribe(void *pMsg, uint16_t msg_len)
{
    T_SUBSCR_EVENT_TOAPP *ptEvent = (T_SUBSCR_EVENT_TOAPP *)pMsg;
    	
    if(sizeof(T_SUBSCR_EVENT_TOAPP) != msg_len || pMsg==NULL)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "onHandleTipcSubscribe rcv Error Msg:length %d should be:%d, pMsg: %p!\n", 
        	        msg_len, sizeof(T_SUBSCR_EVENT_TOAPP), pMsg);
        XOS_ASSERT(0);
        return;
    }

    XOS_ASSERT((ptEvent->event == TIPC_PUBLISHED) || (ptEvent->event == TIPC_WITHDRAWN));
    
    if(!XOS_CompareJID(&ptEvent->tSubscrptJID, &m_MateJID))
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "onHandleTipcSubscribe XOS_CompareJID Failed!\n");
        return;
    }

    if(ptEvent->event == TIPC_PUBLISHED)
    {
        setMateOnlineState(TRUE);
    }
    else if(ptEvent->event == TIPC_WITHDRAWN)
    {
        setMateOnlineState(FALSE);
    }

    return;
}

ZENIC_RESULT CNodeMgr::setMateOnlineState(bool isOnline)
{
    m_bIsMateOnline = isOnline;
    return RESULT_ZENIC_SUCCESS;
}

bool CNodeMgr::isMateOnlineState()
{
	   ZCS_LOG(ZCS_LOG_DEBUG, ZCS_LOG_MOD_ZCMS, "IsMateBoardAtPos:%d, m_bIsMateOnline:%d!\n", IsMateBoardAtPos(), m_bIsMateOnline);
    return m_bIsMateOnline;
}

ZENIC_RESULT CNodeMgr::NodeEventSubinit()
{
    int ret;

    ret = m_tNodeEventSubscriber.init(ZCMS_MAX_NODE_EVENT_SUBSCRIBER_NUM);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"m_tNodeEventSubscriber.init Failed ret=%d", ret);
        return ERROR_ALLOC_MEM_FAIL;
    }

    m_tNodeEventQueue.init(ZCMS_MAX_NODE_EVENT_NUM);
    
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::getSelfNodeType(T_ZCS_NODE &tSelfNode)
{
    m_pZcmsMgr->getSelfNodeType(&tSelfNode);  

    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::getSelfPhyAddr(T_PhysAddress &tSelfPhyAddr)
{
    m_pZcmsMgr->getSelfPhyAddr(&tSelfPhyAddr);  

    return RESULT_ZENIC_SUCCESS;
}

uint32_t CNodeMgr::getMgrPowerOnTick()
{
    return m_pZcmsMgr->getSelfPowerOnTick();
}

uint32_t CNodeMgr::getQingClientCnt()
{
    return m_dwQueueClntCnt;
}

ZENIC_RESULT CNodeMgr::increaseQingClientCnt()
{
    m_dwQueueClntCnt++;
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::decreaseQingClientCnt()
{
    XOS_ASSERT(m_dwQueueClntCnt > ZCMS_QUEUE_ID_NUMBER_FIRST-1);
    if(m_dwQueueClntCnt > ZCMS_QUEUE_ID_NUMBER_FIRST-1)
    {
        m_dwQueueClntCnt--;
    }
    return RESULT_ZENIC_SUCCESS;
}

uint32_t CNodeMgr::getMultiCastClientCnt()
{
    return m_dwMultiCastClntCnt;
}

ZENIC_RESULT CNodeMgr::increaseMultiCastClientCnt()
{
    m_dwMultiCastClntCnt++;
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::decreaseMultiCastClientCnt()
{
    XOS_ASSERT(m_dwMultiCastClntCnt > 0);
    if(m_dwMultiCastClntCnt > 0)
    {
        m_dwMultiCastClntCnt--;
    }
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::saveCNodeInfo(uint32_t idx, T_ZCMS_CNODE_INFO* ptCNodeInfo)
{
    int ret;
    T_ZCMS_NODE_INFO tLinkNInfo;
    XOS_ASSERT(ptCNodeInfo);
    
    ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::saveCNodeInfo getInstByIndex %d, Failed ret=%d\n", idx, ret);
        return ERROR_FOREIGN_KEY_NOT_EXIST;
    }
    #if 0
    tLinkNInfo.tCNodeData.wNodeId = ptCNodeInfo->tNodeType.nodeId;
    tLinkNInfo.tCNodeData.wModule= ptCNodeInfo->tNodeType.moduleId;
    #endif
    //route type ������֮ǰ�Ĳ�һ����Ҫ����
    tLinkNInfo.tCNodeData.wRouteType= ptCNodeInfo->tNodeType.route_type;
    //ptCNodeInfo->tNodeType.state; //state�����棬�������ϵ�stateΪ�����ͻ��˴���������Ч
    
    memcpy(&tLinkNInfo.tCNodeData.tPhyAddrInfo, &ptCNodeInfo->tPhyAddrInfo, sizeof(T_PhysAddress));
    tLinkNInfo.tCNodeData.dwCNodePoweronTick = ptCNodeInfo->dwCNodePoweronTick;
    tLinkNInfo.tCNodeData.wCSvcState = ptCNodeInfo->wCSvcState;
    ret = m_tAllCNodesInfo.setInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::setCNodeLinkState setInstByIndex %d, Failed ret=%d\n", idx, ret);
        return ERROR_INSERT_RECORD_FAIL;
    }
    
    return RESULT_ZENIC_SUCCESS;
}

bool CNodeMgr::checkCNodeInfo(uint32_t idx, T_ZCMS_CNODE_INFO* ptCNodeInfo)
{
    int ret;
    T_ZCMS_NODE_INFO tLinkNInfo;
    XOS_ASSERT(ptCNodeInfo);
    
    ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::checkCNodeInfo getInstByIndex %d, Failed ret=%d\n", idx, ret);
        return FALSE;
    }

    if((tLinkNInfo.tCNodeData.wNodeId != ptCNodeInfo->tNodeType.nodeId)
     || (tLinkNInfo.tCNodeData.wModule != ptCNodeInfo->tNodeType.moduleId)
     || (tLinkNInfo.tCNodeData.wRouteType != ptCNodeInfo->tNodeType.route_type)
     || (!XOS_ComparePhyAdd(&tLinkNInfo.tCNodeData.tPhyAddrInfo, &ptCNodeInfo->tPhyAddrInfo))
     || tLinkNInfo.tCNodeData.dwCNodePoweronTick != ptCNodeInfo->dwCNodePoweronTick)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"checkCNodeInfo N:M:R[%d:%d:%d] PA[%d:%d:%d:%d] PowerOn[%u] differs prev N:M:R[%d:%d:%d] PA[%d:%d:%d:%d] PowerOn[%u]!\n",
        	ptCNodeInfo->tNodeType.nodeId, ptCNodeInfo->tNodeType.moduleId, ptCNodeInfo->tNodeType.route_type,
        	ptCNodeInfo->tPhyAddrInfo.ucRackId, ptCNodeInfo->tPhyAddrInfo.ucShelfId,
        	ptCNodeInfo->tPhyAddrInfo.ucSlotId, ptCNodeInfo->tPhyAddrInfo.ucCpuId, 
        	ptCNodeInfo->dwCNodePoweronTick,
         tLinkNInfo.tCNodeData.wNodeId, tLinkNInfo.tCNodeData.wModule, tLinkNInfo.tCNodeData.wRouteType,
        	tLinkNInfo.tCNodeData.tPhyAddrInfo.ucRackId, tLinkNInfo.tCNodeData.tPhyAddrInfo.ucShelfId,
        	tLinkNInfo.tCNodeData.tPhyAddrInfo.ucSlotId, tLinkNInfo.tCNodeData.tPhyAddrInfo.ucCpuId,
        	tLinkNInfo.tCNodeData.dwCNodePoweronTick);
        return FALSE;
    }
    
    return TRUE;
}

uint32_t CNodeMgr::getTotalNodeNum()
{
    return m_tAllCNodesInfo.getAllocatedInstNum();
}

ZENIC_RESULT CNodeMgr::initNodeInfo(uint16_t node_id)
{
	   int ret;
    uint32_t idx;
    T_ZCMS_NODE_INFO tLinkNInfo;
    
    ret = m_tAllCNodesInfo.allocInstByKey1(node_id, idx);
    
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"initNodeInfo m_tAllCNodesInfo.allocInstByKey1 NodeID[%d] Failed ret=%d\n", 
        	                node_id, ret);
        return ERROR_ALLOC_INSTANCE_FAIL;
    }
    
    memset(&tLinkNInfo, 0, sizeof(tLinkNInfo));

    tLinkNInfo.dwSyncSeq = ZCMS_INVALID_SYNC_SEQ;
    
    tLinkNInfo.tCNodeData.wNodeId = node_id;
    tLinkNInfo.tCNodeData.wModule = node_id;
    tLinkNInfo.tCNodeData.wRouteType = ZCS_MASTER_BOARD;
    
    if(ZCMS_VIRTUAL_RIGHT_OMP_NODE_ID == node_id)
    {
        tLinkNInfo.tCNodeData.wModule = ZCS_MASTER_NODE_MODULE_NO;
        tLinkNInfo.tCNodeData.wRouteType = ZCS_RIGHT_BOARD;
    }
    else if(ZCS_MASTER_NODE_ID_1 == node_id)
    {
        tLinkNInfo.tCNodeData.wModule = ZCS_MASTER_NODE_MODULE_NO;
        tLinkNInfo.tCNodeData.wRouteType = ZCS_LEFT_BOARD;
    }    

    tLinkNInfo.tCNodeData.tManageStatus = ZCS_NODE_STATE_INACTIVE;
    tLinkNInfo.tCNodeData.eLinkState = E_ZCMS_NODE_STATE_INIT;
    tLinkNInfo.tCNodeData.dwNodeHBeatTOCnt = 0;
    tLinkNInfo.tCNodeData.dwQueueID = ZCMS_INVALID_QUEUEID;
    tLinkNInfo.tCNodeData.wCSvcState = ZCS_JOB_STATE_INVALID;
    
    ret = m_tAllCNodesInfo.setInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"initNodeInfo m_tAllCNodesInfo.setInstByIndex insert NodeID[%d] Failed ret=%d\n", 
        	                node_id, ret);
        return ERROR_INSERT_RECORD_FAIL;
    }
    o_tMgrStt.dwInitClientCnt++;
    o_tMgrStt.dwTotalCnt++;
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::clearCNodeInfo(uint32_t idx)
{
    int ret;
    T_ZCMS_NODE_INFO tLinkNInfo;
    ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::saveCNodeInfo getInstByIndex %d, Failed ret=%d\n", idx, ret);
        return ERROR_FOREIGN_KEY_NOT_EXIST;
    }
    //ֻ���wCSvcState
    #if 0
    tLinkNInfo.tCNodeData.wNodeId = 0;
    tLinkNInfo.tCNodeData.wModule = 0;
    tLinkNInfo.tCNodeData.wRouteType = 0;
    //ptCNodeInfo->tNodeType.state; 
    #endif

    tLinkNInfo.dwSyncSeq = ZCMS_INVALID_SYNC_SEQ;
    
    memset(&tLinkNInfo.tCNodeData.tPhyAddrInfo, 0, sizeof(T_PhysAddress));

    tLinkNInfo.tCNodeData.eLinkState = E_ZCMS_NODE_STATE_INACTIVE;
    if(ZCS_NODE_STATE_BLOCKED != tLinkNInfo.tCNodeData.tManageStatus)
    {
        tLinkNInfo.tCNodeData.tManageStatus = ZCS_NODE_STATE_INACTIVE;
    }
    tLinkNInfo.tCNodeData.dwNodeHBeatTOCnt = 0;
    tLinkNInfo.tCNodeData.dwQueueID = ZCMS_INVALID_QUEUEID;
    tLinkNInfo.tCNodeData.wCSvcState = ZCS_JOB_STATE_INVALID;

    memset(&tLinkNInfo.tCNodeStt, 0, sizeof(tLinkNInfo.tCNodeStt));
    ret = m_tAllCNodesInfo.setInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::clearCNodeInfo setInstByIndex %d, Failed ret=%d\n", idx, ret);
        return ERROR_INSERT_RECORD_FAIL;
    }
    return RESULT_ZENIC_SUCCESS;
}

T_ZCS_NODE_STATE CNodeMgr::getCNodeManageStatus(uint32_t idx)
{
    int ret;
    T_ZCMS_NODE_INFO tLinkNInfo;
    ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::saveCNodeInfo getInstByIndex %d, Failed ret=%d\n", idx, ret);
        return ERROR_FOREIGN_KEY_NOT_EXIST;
    }

    return tLinkNInfo.tCNodeData.tManageStatus;
}

ZENIC_RESULT CNodeMgr::setCNodeManageStatus(uint32_t idx, T_ZCS_NODE_STATE tManageStatus)
{
    int ret;
    T_ZCMS_NODE_INFO tLinkNInfo;
    ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::setCNodeLinkState getInstByIndex %d, Failed ret=%d\n", idx, ret);
        return ERROR_FOREIGN_KEY_NOT_EXIST;
    }

    tLinkNInfo.tCNodeData.tManageStatus = tManageStatus;
    ret = m_tAllCNodesInfo.setInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::setCNodeManageStatus setInstByIndex %d, status:%u Failed ret=%d\n", idx, tManageStatus, ret);
        return ERROR_INSERT_RECORD_FAIL;
    }
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::setCNodeLinkState(uint32_t idx, E_ZCMS_NODE_LINK_STATE tLinkState)
{
    int ret;
    T_ZCMS_NODE_INFO tLinkNInfo;
    ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::setCNodeLinkState getInstByIndex %d, Failed ret=%d\n", idx, ret);
        return ERROR_FOREIGN_KEY_NOT_EXIST;
    }
    tLinkNInfo.tCNodeData.eLinkState = tLinkState;
    ret = m_tAllCNodesInfo.setInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::setCNodeLinkState setInstByIndex %d, LinkState:%d Failed ret=%d\n", idx, tLinkState, ret);
        return ERROR_INSERT_RECORD_FAIL;
    }

    return RESULT_ZENIC_SUCCESS;
}

E_ZCMS_NODE_LINK_STATE CNodeMgr::getCNodeLinkState(uint32_t idx)
{    	  
    int ret;
    T_ZCMS_NODE_INFO tLinkNInfo;
    ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::getCNodeLinkState getInstByIndex %d, Failed ret=%d\n", idx, ret);
        return m_tAllCNodesInfo[idx].tCNodeData.eLinkState;
    }
    return tLinkNInfo.tCNodeData.eLinkState;
}


ZENIC_RESULT CNodeMgr::increaseCNodeHBTOCnt(uint32_t idx)
{
    int ret;
    T_ZCMS_NODE_INFO tLinkNInfo;
    ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::setCNodeHBTOCnt getInstByIndex %d, Failed ret=%d\n", idx, ret);
        return ERROR_FOREIGN_KEY_NOT_EXIST;
    }
    tLinkNInfo.tCNodeData.dwNodeHBeatTOCnt++;
    ret = m_tAllCNodesInfo.setInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::setCNodeHBTOCnt setInstByIndex %d, Failed ret=%d\n", idx, ret);
        return ERROR_INSERT_RECORD_FAIL;
    }
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::alarm2OamWorker(T_ZCMS_NODE_INFO node)
{
    T_EV_ZCS_NODE_EVENT tNodeEv;        
    tNodeEv.event_type = EV_ZCS_NODE_NET_WARNING;
    tNodeEv.tNode.nodeId = node.tCNodeData.wNodeId;
    tNodeEv.tNode.moduleId = node.tCNodeData.wModule;
    tNodeEv.tNode.state = node.tCNodeData.tManageStatus;
    tNodeEv.tNode.route_type = node.tCNodeData.wRouteType;
    JID tRegJID;
    XOS_GetSelfJID(&tRegJID);
    tRegJID.dwJno = OAM_WORKER_JNO;
    XOS_STATUS ret = XOS_SendAsynMsg(EV_SYS_ZCS_NODE_EVENT_NOTIFY,(uint8_t *)&tNodeEv,
                             sizeof(tNodeEv), XOS_MSG_VER0, XOS_MSG_HIGH, &tRegJID);
    return (ZENIC_RESULT)ret;
}

ZENIC_RESULT CNodeMgr::clearCNodeHBTOCnt(uint32_t idx)
{
    int ret;
    T_ZCMS_NODE_INFO tLinkNInfo;
    ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::setCNodeHBTOCnt getInstByIndex %d, Failed ret=%d\n", idx, ret);
        return ERROR_FOREIGN_KEY_NOT_EXIST;
    }
    if(tLinkNInfo.tCNodeData.dwNodeHBeatTOCnt > HB_TIMEOUT_ALARM_THRESHOLD) //���Ը�Ϊ3����������ֵ
    {
        tLinkNInfo.tCNodeStt.tCurStt.dwHBToGtExpect++;
        alarm2OamWorker(tLinkNInfo);
    }
    if(tLinkNInfo.tCNodeData.dwNodeHBeatTOCnt > tLinkNInfo.tCNodeStt.tCurStt.dwHBToMax) //���Ը�Ϊ3����������ֵ
    {
        tLinkNInfo.tCNodeStt.tCurStt.dwHBToMax=tLinkNInfo.tCNodeData.dwNodeHBeatTOCnt;
    }
    tLinkNInfo.tCNodeData.dwNodeHBeatTOCnt= 0;
    ret = m_tAllCNodesInfo.setInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::setCNodeHBTOCnt setInstByIndex %d, Failed ret=%d\n", idx, ret);
        return ERROR_INSERT_RECORD_FAIL;
    }
    return RESULT_ZENIC_SUCCESS;
}

uint32_t CNodeMgr::getCNodeHBTOCnt(uint32_t idx)
{    	  
    int ret;
    T_ZCMS_NODE_INFO tLinkNInfo;
    ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::getCNodeHBTOCnt getInstByIndex %d, Failed ret=%d\n", idx, ret);
        return m_tAllCNodesInfo[idx].tCNodeData.dwNodeHBeatTOCnt;
    }
    return tLinkNInfo.tCNodeData.dwNodeHBeatTOCnt;
}

ZENIC_RESULT CNodeMgr::setCNodeQueueID(uint32_t idx, uint32_t dwQID)
{
    int ret;
    T_ZCMS_NODE_INFO tLinkNInfo;
    ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::setCNodeQueueID getInstByIndex %d, Failed ret=%d\n", idx, ret);
        return ERROR_FOREIGN_KEY_NOT_EXIST;
    }
    tLinkNInfo.tCNodeData.dwQueueID = dwQID;
    ret = m_tAllCNodesInfo.setInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::setCNodeQueueID setInstByIndex %d, QID:%u,Failed ret=%d\n", idx, dwQID, ret);
        return ERROR_INSERT_RECORD_FAIL;
    }
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::decreaseCNodeQueueID(uint32_t idx)
{
    int ret;
    T_ZCMS_NODE_INFO tLinkNInfo;
    ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::setCNodeQueueID getInstByIndex %d, Failed ret=%d\n", idx, ret);
        return ERROR_FOREIGN_KEY_NOT_EXIST;
    }
    
    XOS_ASSERT(tLinkNInfo.tCNodeData.dwQueueID > 0);
    if(tLinkNInfo.tCNodeData.dwQueueID > 0)
    {
        tLinkNInfo.tCNodeData.dwQueueID--;

        ret = m_tAllCNodesInfo.setInstByIndex(idx, tLinkNInfo);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            XOS_ASSERT(0);
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::setCNodeQueueID setInstByIndex %d, Failed ret=%d\n", idx, ret);
            return ERROR_INSERT_RECORD_FAIL;
        }
    }
    return RESULT_ZENIC_SUCCESS;
}

uint32_t CNodeMgr::getCNodeQueueID(uint32_t idx)
{    	  
    int ret;
    T_ZCMS_NODE_INFO tLinkNInfo;
    ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::getCNodeQueueID getInstByIndex %d, Failed ret=%d\n", idx, ret);
        return m_tAllCNodesInfo[idx].tCNodeData.dwQueueID;
    }
    return tLinkNInfo.tCNodeData.dwQueueID;
}

ZENIC_RESULT CNodeMgr::setCNodeSvcState(uint32_t idx, uint16_t wSState)
{
    int ret;
    T_ZCMS_NODE_INFO tLinkNInfo;
    ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::setCNodeSvcState getInstByIndex %d, Failed ret=%d\n", idx, ret);
        return ERROR_FOREIGN_KEY_NOT_EXIST;
    }
    tLinkNInfo.tCNodeData.wCSvcState = wSState;
    ret = m_tAllCNodesInfo.setInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::setCNodeSvcState setInstByIndex %d, SvcState:%d, Failed ret=%d\n", idx, wSState, ret);
        return ERROR_INSERT_RECORD_FAIL;
    }
    return RESULT_ZENIC_SUCCESS;
}

uint16_t CNodeMgr::getCNodeSvcState(uint32_t idx)
{    	  
    int ret;
    T_ZCMS_NODE_INFO tLinkNInfo;
    ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"CNodeMgr::getCNodeSvcState getInstByIndex %d, Failed ret=%d\n", idx, ret);
        return m_tAllCNodesInfo[idx].tCNodeData.wCSvcState;
    }
    return tLinkNInfo.tCNodeData.wCSvcState;
}

void CNodeMgr::removeCNodefromQApplyQueue(uint32_t dwCurQID)
{
    T_ZCMS_NODE_INFO tLinkNInfo;
    int isFindQElement=0;
    uint32_t idx = 0;
    int ret;
    
    while (idx < m_tAllCNodesInfo.getTotalInstNum())
    {
        if(m_tAllCNodesInfo.getInstanceState(idx)!=InstMgr::INST_STATE_ALLOCATED)
        {
            idx++;
            continue;
        }
        ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            XOS_ASSERT(0);
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS, "removeCNodefromQueue getInstByIndex %d, Failed ret=%d\n", idx, ret);
            idx++;
            continue;
        }

        if(((getCNodeLinkState(idx)== E_ZCMS_NODE_STATE_QUEUEING)
        	 ||(getCNodeLinkState(idx)== E_ZCMS_NODE_STATE_REGISTERING))
        	      && (getCNodeQueueID(idx) >= dwCurQID))
        {
            decreaseCNodeQueueID(idx);
            isFindQElement = 1;
        }

        idx++;
    }

    if(isFindQElement)
    {
        decreaseQingClientCnt();
    }

}

void CNodeMgr::checkLinkNodeTimeOut()
{
    int ret;
    uint32_t idx = 0;
    T_ZCMS_NODE_INFO tLinkNInfo;
    uint32_t dwNodeHBeatTOCnt;

    /* ���������в���⣬������ɺ��ټ��*/
	   if(isChangingOver())
	   {
        return;
	   }
	   
    while (idx < m_tAllCNodesInfo.getTotalInstNum())
    {
        if(m_tAllCNodesInfo.getInstanceState(idx)!=InstMgr::INST_STATE_ALLOCATED)
        {
            idx++;
            continue;
        }
        ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            XOS_ASSERT(0);
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS, "checkLinkNodeTimeOut getInstByIndex %d, Failed ret=%d\n", idx, ret);
            idx++;
            continue;
        }
        /*���ӱ����ڹ���״̬*/
        if (getCNodeLinkState(idx)== E_ZCMS_NODE_STATE_INACTIVE || getCNodeLinkState(idx)== E_ZCMS_NODE_STATE_INIT)
        {
            idx++;
            continue;
        }

        /*  ���м����� */
        increaseCNodeHBTOCnt(idx);

        dwNodeHBeatTOCnt = getCNodeHBTOCnt(idx);
        if (dwNodeHBeatTOCnt >= m_pConfig->getConfKeepAliveHBCount())
        {
        	   o_tMgrStt.dwNodeHBTimeOutCnt++;
            ZCS_LOG(ZCS_LOG_WARN, ZCS_LOG_BUF_ZCMS,
                    "checkLinkNodeTimeOut: Node[%d] Module[%d] RouteType[%d] CSvcState[%d] LinkState[%d] is down, NodeHBeatTOCnt[%u]\n",
                    tLinkNInfo.tCNodeData.wNodeId,
                    tLinkNInfo.tCNodeData.wModule,
                    tLinkNInfo.tCNodeData.wRouteType,
                    tLinkNInfo.tCNodeData.wCSvcState,
                    tLinkNInfo.tCNodeData.eLinkState,
                    dwNodeHBeatTOCnt);


            removeNode(tLinkNInfo.tCNodeData.wNodeId);
            //Todo: �Ƿ�����ע����Ϣ���ͻ���?�ݲ����ͣ�һ����ߺ���Ϣ���Ͷ�����516 ����
            #if 0
            sendResetMsgToClient(E_ZCMS_RESET_LINK_ECHO_TIMEOUT);
            #endif
        }
        idx++;
    }
    
    return;
}

ZENIC_RESULT CNodeMgr::constructMateJID(JID &MateJID)
{
	   T_ZCS_NODE tSelfNode;
    if(RESULT_ZENIC_SUCCESS!= zcs_constructJID(ZCS_JOB_TYPE_ZCMS, 1, MateJID))
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "constructMateJID Failed!\n");
        
        return ERROR_COMMON_ERROR;
    }

    getSelfNodeType(tSelfNode);

    if(tSelfNode.route_type == ZCS_LEFT_BOARD)
    {
        MateJID.ucRouteType = COMM_RIGHT_CONTROL; 
    }
    else
    {
    	   XOS_ASSERT(tSelfNode.route_type == ZCS_RIGHT_BOARD);
        MateJID.ucRouteType = COMM_LEFT_CONTROL; 
    }

    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::constructClientJID(uint16_t wModule, uint16_t wRouteType, JID &CJID)
{
    if(RESULT_ZENIC_SUCCESS!= zcs_constructJID(ZCS_JOB_TYPE_ZCMS,1, CJID))
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "constructClientJID Module:%d, RouteType:%d Failed!\n", wModule, wRouteType);
        
        return ERROR_COMMON_ERROR;
    }
    
    CJID.wModule = wModule;
    if(wRouteType == ZCS_LEFT_BOARD)
    {
        CJID.ucRouteType = COMM_LEFT_CONTROL; 
    }
    else if(wRouteType == ZCS_RIGHT_BOARD)
    {
        CJID.ucRouteType = COMM_RIGHT_CONTROL; 
    }
    else if(wRouteType == ZCS_MASTER_BOARD)
    {
        CJID.ucRouteType = COMM_MASTER_SERVICE;
    }
    else
    {
        CJID.ucRouteType = COMM_MASTER_SERVICE; //Ĭ������1����ģ�鷢����������
        XOS_ASSERT(0);
    }
    return RESULT_ZENIC_SUCCESS;
}
	
void CNodeMgr::printQueueApplyMsg(ZCMS_QUEUE_REQ_MSG *pQueueReq)
{
	   XOS_ASSERT(pQueueReq);
    printf("New Node QueueApply:\n");
    printf("==========Here is his NodeInfo:=========\n");
    printCNodeInfo(&pQueueReq->tCNodeInfo);
    printf("================NodeInfo================\n");
    
    return;
}

void CNodeMgr::printQueueAckMsg(ZCMS_QUEUE_ACK_MSG *pQueueAck)
{
	   XOS_ASSERT(pQueueAck);
    printf("Mgr QueueAck:\n");
    printf("=========Mgr NodeInfo:========\n");
    printMgrNodeInfo(&pQueueAck->tCurMGRInfo);
    printf("=========Your QueueID:%u========\n", pQueueAck->dwYourQueueID);
    
    return;
}

void CNodeMgr::printFormallyRegMsg(ZCMS_REG_REQ_MSG *pFReq)
{
	   XOS_ASSERT(pFReq);
    printf("New Node Formally Reg:\n");
    printf("==========Here is his NodeInfo:=========\n");
    printCNodeInfo(&pFReq->tCNodeInfo);
    printf("================NodeInfo================\n");
    
    return;
}

void CNodeMgr::printCEchoMsg(ZCMS_HEART_BEAT_MSG *pEcho)
{
	   XOS_ASSERT(pEcho);
    printf("Node HeartBeat:\n");
    printf("==========Here is his NodeInfo:=========\n");
    printCNodeInfo(&pEcho->tCNodeInfo);
    printf("================NodeInfo================\n");
    
    return;
}

ZENIC_RESULT CNodeMgr::findConfClientNode(uint16_t wNodeId, uint32_t& idx)
{
    int ret;
    ret = m_tAllCNodesInfo.findInstByKey1(wNodeId, idx);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_DEBUG, ZCS_LOG_BUF_ZCMS, "[ZCMS]CNodeMgr::findConfClientNode %d Failed ret=%d\n", wNodeId, ret);
        return ERROR_RECORD_NOT_FOUND;
    }

    return RESULT_ZENIC_SUCCESS;
}

void CNodeMgr::onQueueApplyAck(void *pMsg, uint16_t msg_len)
{
    XOS_STATUS xos_ret;
    ZENIC_RESULT ret;
    uint32_t idx;
    uint16_t thisNodeID;
    E_ZCMS_NODE_LINK_STATE eState;
    ZCMS_QUEUE_REQ_MSG *pQueueReq = (ZCMS_QUEUE_REQ_MSG *)pMsg;
    ZCMS_QUEUE_ACK_MSG tQReqAck;
    JID tSnderJid;
    
    if(sizeof(ZCMS_QUEUE_REQ_MSG) != msg_len || pMsg==NULL)
    {
    	   o_tMgrStt.dwErrorMsgRcv++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "onQueueApplyAck rcv Error Msg:length %d should be:%d, pMsg:%p!\n", 
        	        msg_len, sizeof(ZCMS_QUEUE_REQ_MSG), pMsg);
        XOS_ASSERT(0);
        return;
    }
    
    memset(&tSnderJid, 0, sizeof(tSnderJid));
    XOS_Sender(&tSnderJid);
    if(tSnderJid.wModule != pQueueReq->tCNodeInfo.tNodeType.moduleId)
    {
        o_tMgrStt.dwErrorMsgRcv++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, 
        	        "onQueueApplyAck Error: XOS_Sender get Module %d, but In Msg Module=%d !\n", 
        	        tSnderJid.wModule, pQueueReq->tCNodeInfo.tNodeType.moduleId);
        XOS_ASSERT(0);
        return;
    }

    o_tMgrStt.dwQApplyRcvCnt++;
    #if ZCMS_DEBUG
    printQueueApplyMsg(pQueueReq);
    #endif

    thisNodeID = pQueueReq->tCNodeInfo.tNodeType.nodeId;
    
	   if(isChangingOver())
	   {
	   	   o_tMgrStt.dwQApplyRcvCntInChgOver++;
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onQueueApplyAck rcv NodeID[%d] QueueApply but Mgr isChangingOver!\n", thisNodeID);
        sendResetMsgToClient(thisNodeID, E_ZCMS_RESET_MGR_CHG_OVER);
        return;
	   }
	   
    ret = findConfClientNode(thisNodeID, idx);
    if(ret != RESULT_ZENIC_SUCCESS)
    {
        o_tMgrStt.dwNodeNotFound++;
        ZCS_LOG(ZCS_LOG_DEBUG, ZCS_LOG_MOD_ZCMS, 
                "onQueueApplyAck rcv NodeID[%d] QueueApply, but it's Non-Configed, Ignore!\n", thisNodeID);
        sendResetMsgToClient(thisNodeID, E_ZCMS_RESET_UNAUTHORIZED);
        return;
    }

    m_tAllCNodesInfo[idx].tCNodeStt.tCurStt.dwQApplyRcvCnt++;

    /* ����ϴε�Register ״̬û��ȫ�������м����LEAVE �¼���
     * PreAdd ��ʱ����JOIN �¼����ǰ���JOIN �¼��ظ���
     * ����һ��ȷ�Ϻ�����Ҳ����ڵ�������⣬
     * �ʴ�ʱ�����ýڵ��ٴ�ע��*/
	   if(findNodeEvent(thisNodeID, EV_ZCS_NODE_JOIN))
	   {
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onQueueApplyAck rcv NodeID[%d] QueueApply but Last Register is Not finished yet!\n", thisNodeID);
        sendResetMsgToClient(thisNodeID, E_ZCMS_RESET_LINK_COMMON_REASON);
        return;
	   }
	   
    m_tAllCNodesInfo[idx].tCNodeData.tSender = tSnderJid;
    eState = getCNodeLinkState(idx);
    if(eState== E_ZCMS_NODE_STATE_INACTIVE || eState== E_ZCMS_NODE_STATE_INIT)
    {
        saveNode(thisNodeID, &pQueueReq->tCNodeInfo);
    }
    else if(E_ZCMS_NODE_STATE_ACTIVE == eState || E_ZCMS_NODE_STATE_REGISTERING == eState)    //ҵ��ڵ����������������������Ҫ�ָ�����Ч״̬
    {
    	   o_tMgrStt.dwNodeErrState++;
        ZCS_LOG(ZCS_LOG_WARN, ZCS_LOG_MOD_ZCMS, "onQueueApplyAck rcv NodeID[%d] QueueApply with Unexpected Status:%d!\n", thisNodeID, eState);
        removeNode(thisNodeID);
        sendResetMsgToClient(thisNodeID, E_ZCMS_RESET_LINK_ERROR_STATE);
        return;
    }
    else
    {
        XOS_ASSERT(E_ZCMS_NODE_STATE_QUEUEING == eState);
    }
	   
    memset(&tQReqAck, 0, sizeof(tQReqAck));
    getSelfNodeType(tQReqAck.tCurMGRInfo.tCurMgrNodeInfo);
    getSelfPhyAddr(tQReqAck.tCurMGRInfo.tCurMgrPhyAddrInfo);
    tQReqAck.tCurMGRInfo.dwCurMgrPowerOnTick = getMgrPowerOnTick();
    tQReqAck.dwHBPeriod = m_pConfig->getConfKeepAliveHBTimer();
    tQReqAck.dwYourQueueID = getCNodeQueueID(idx); //addnode�����Ѿ�����

    #if ZCMS_DEBUG
    printQueueAckMsg(&tQReqAck);
    #endif
    
    xos_ret = XOS_SendAsynMsg(EV_SYS_ZCMS_QUEUE_ACK, (uint8_t *)&tQReqAck, (uint16_t)sizeof(ZCMS_QUEUE_ACK_MSG),
    	                                                   XOS_MSG_VER0, XOS_MSG_LOW, (void *)&tSnderJid);
    o_tMgrStt.dwQAckSndCnt++;
    m_tAllCNodesInfo[idx].tCNodeStt.tCurStt.dwQAckSndCnt++;
    if (XOS_SUCCESS != xos_ret)
    {
        o_tMgrStt.dwMsgSndFailed++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, 
        	      "onQueueApplyAck Snd EV_SYS_ZCMS_QUEUE_ACK To JID[Jno:0x%x,Module:%d,RouteType:%d] XOS_SendAsynMsg Failed:%d!\n",
        	      tSnderJid.dwJno, tSnderJid.wModule, tSnderJid.ucRouteType, xos_ret);
        return;
    }

    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onQueueApplyAck rcv NodeID[%d] QueueApply: No.%u!\n", thisNodeID, tQReqAck.dwYourQueueID);
    return;
}

void CNodeMgr::onNodeJoinAck(void *pMsg, uint16_t msg_len)
{
    ZENIC_RESULT ret;
    uint32_t idx;
    uint16_t thisNodeID;
    ZCMS_REG_REQ_MSG *pFReg = (ZCMS_REG_REQ_MSG *)pMsg;
    E_ZCMS_NODE_LINK_STATE eLinkState;
    uint32_t dwQID;
    
    if(msg_len != sizeof(ZCMS_REG_REQ_MSG) || pMsg==NULL)
    {
        o_tMgrStt.dwErrorMsgRcv++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, 
        	        "onNodeJoinAck rcv Error Msg:length %d should be:%d, pMsg:%p!\n", 
        	        msg_len, sizeof(ZCMS_REG_REQ_MSG), pMsg);
        XOS_ASSERT(0);
        return;
    }
    
    JID tSnderJid;
    XOS_Sender(&tSnderJid);
    if(tSnderJid.wModule != pFReg->tCNodeInfo.tNodeType.moduleId)
    {
        o_tMgrStt.dwErrorMsgRcv++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, 
        	        "onNodeJoinAck Error: XOS_Sender get Module %d, but In Msg Module=%d !\n", 
        	        tSnderJid.wModule, pFReg->tCNodeInfo.tNodeType.moduleId);
        XOS_ASSERT(0);
        return;
    }
     
    o_tMgrStt.dwRegRcvCnt++;

    #if ZCMS_DEBUG
    printFormallyRegMsg(pFReg);
    #endif

    thisNodeID = pFReg->tCNodeInfo.tNodeType.nodeId;
    
    /* ���������в��������������ٴ���*/
	   if(isChangingOver())
	   {
	   	   o_tMgrStt.dwRegRcvCntInChgOver++;
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onNodeJoinAck rcv NodeID[%d] FormallyReg but Mgr isChangingOver!\n", thisNodeID);
        return;
	   }
    
    ret = findConfClientNode(thisNodeID, idx);
    if(ret != RESULT_ZENIC_SUCCESS)
    {
        o_tMgrStt.dwNodeNotFound++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, 
        	              "onNodeJoinAck rcv NodeID[%d] FormallyReg, but it's Non-Configed, Ignore!\n", thisNodeID);
        sendResetMsgToClient(thisNodeID, E_ZCMS_RESET_UNAUTHORIZED);
        return;
    }

	   m_tAllCNodesInfo[idx].tCNodeStt.tCurStt.dwRegRcvCnt++;
	   
    eLinkState = getCNodeLinkState(idx);
    dwQID = getCNodeQueueID(idx);

    if(!checkCNodeInfo(idx, &pFReg->tCNodeInfo))
    {
    	   o_tMgrStt.dwNodeInfoDiff++;
    	   ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "onNodeJoinAck rcv NodeID[%d] FormallyReg with diffient NodeInfo!\n", thisNodeID);
        removeNode(thisNodeID);
        sendResetMsgToClient(thisNodeID, E_ZCMS_RESET_DIFF_NODEINFO);
        return;
    }
    
    if(eLinkState == E_ZCMS_NODE_STATE_REGISTERING)
    {
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, 
        	   "onNodeJoinAck rcv NodeID[%d] duplicate FormallyReg at Registering state, Ignore!\n", thisNodeID);
        return;
    }
    
    if(eLinkState == E_ZCMS_NODE_STATE_ACTIVE)
    {
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, 
        	   "onNodeJoinAck rcv NodeID[%d] duplicate FormallyReg at Active state, already Register Success, resend Ack and Ignore!\n", thisNodeID);
        addNode(thisNodeID);
        return;
    }
    
    if(eLinkState != E_ZCMS_NODE_STATE_QUEUEING || dwQID != ZCMS_QUEUE_ID_NUMBER_FIRST)
    {
    	   o_tMgrStt.dwNodeErrState++;
        removeNode(thisNodeID);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "onNodeJoinAck rcv NodeID[%d] FormallyReg with Unexpected Status:%d, dwQID:%d!\n", 
        	                                                      thisNodeID, eLinkState, dwQID);
        sendResetMsgToClient(thisNodeID, E_ZCMS_RESET_LINK_ERROR_STATE);
        return;
    }
	   
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onNodeJoinAck rcv NodeID[%d] FormallyReg!\n", thisNodeID);
    preAddNode(thisNodeID);

    return;
}
	
void CNodeMgr::onHandleClientHeartBeat(void *pMsg, uint16_t msg_len)
{
    ZENIC_RESULT ret;
    uint32_t idx;
    uint16_t thisNodeID;
    ZCMS_HEART_BEAT_MSG *pEcho = (ZCMS_HEART_BEAT_MSG *)pMsg;
    E_ZCMS_NODE_LINK_STATE eLinkState;
    JID tSnderJid;

    if(msg_len != sizeof(ZCMS_HEART_BEAT_MSG) || pMsg==NULL)
    {
        o_tMgrStt.dwErrorMsgRcv++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, 
        	        "onHandleClientHeartBeat rcv Error Msg:length %d should be:%d, pMsg:%p!\n", 
        	        msg_len, sizeof(ZCMS_HEART_BEAT_MSG), pMsg);
        XOS_ASSERT(0);
        return;
    }
    
    XOS_Sender(&tSnderJid);
    if(tSnderJid.wModule != pEcho->tCNodeInfo.tNodeType.moduleId)
    {
        o_tMgrStt.dwErrorMsgRcv++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, 
        	        "onHandleClientHeartBeat Error: XOS_Sender get Module %d, but In Msg Module=%d !\n", 
        	        tSnderJid.wModule, pEcho->tCNodeInfo.tNodeType.moduleId);
        XOS_ASSERT(0);
        return;
    }

    o_tMgrStt.dwHBRcvCnt++;
    #if ZCMS_DEBUG
    printCEchoMsg(pEcho);
    #endif

    thisNodeID = pEcho->tCNodeInfo.tNodeType.nodeId;
    
    /* ���������в��������������ٴ���*/
	   if(isChangingOver())
	   {
	   	   o_tMgrStt.dwHBRcvCntInChgOver++;
        ZCS_LOG(ZCS_LOG_DEBUG, ZCS_LOG_MOD_ZCMS, "onHandleClientHeartBeat rcv NodeID[%d] HeartBeat but Mgr isChangingOver!\n", thisNodeID);
        return;
	   }
	   
    ret = findConfClientNode(thisNodeID, idx);
    if(ret != RESULT_ZENIC_SUCCESS)
    {
        o_tMgrStt.dwNodeNotFound++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, 
        	      "onHandleClientHeartBeat rcv NodeID[%d] HeartBeat, but it's Non-Configed, Ignore!\n", thisNodeID);
        sendResetMsgToClient(thisNodeID, E_ZCMS_RESET_UNAUTHORIZED);
        return;
    }

    m_tAllCNodesInfo[idx].tCNodeStt.tCurStt.dwHBRcvCnt++;
    
    /* �ȼ��״̬�������INACTIVE ״̬checkCNodeInfo ��PA Ϊ��*/
    eLinkState = getCNodeLinkState(idx);
    if(eLinkState == E_ZCMS_NODE_STATE_INIT)
    {
        o_tMgrStt.dwNodeErrState++;
        ZCS_LOG(ZCS_LOG_WARN, ZCS_LOG_MOD_ZCMS, 
        	      "onHandleClientHeartBeat rcv NodeID[%d] HeartBeat with Unexpected Status:%d!\n", thisNodeID, eLinkState);
        sendResetMsgToClient(thisNodeID, E_ZCMS_RESET_LINK_ERROR_STATE);
        return;
    }
    
    if(eLinkState == E_ZCMS_NODE_STATE_INACTIVE)
    {
        o_tMgrStt.dwRcvNodeHBTOCnt++;
        ZCS_LOG(ZCS_LOG_WARN, ZCS_LOG_MOD_ZCMS, 
        	      "onHandleClientHeartBeat rcv NodeID[%d] HeartBeat with Unexpected Status:%d!\n", thisNodeID, eLinkState);
        sendResetMsgToClient(thisNodeID, E_ZCMS_RESET_LINK_ECHO_TIMEOUT);
        return;
    }
    
    if(!checkCNodeInfo(idx, &pEcho->tCNodeInfo))
    {
    	   o_tMgrStt.dwNodeInfoDiff++;
    	   ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "onHandleClientHeartBeat rcv NodeID[%d] HeartBeat with diffient NodeInfo!\n", thisNodeID);
        removeNode(thisNodeID);
        sendResetMsgToClient(thisNodeID, E_ZCMS_RESET_DIFF_NODEINFO);
        return;
    }

    /*  ˳�����һ�·���״̬�����ؿͻ�������������״̬���ͱ仯 */
    if(getCNodeSvcState(idx) != pEcho->tCNodeInfo.wCSvcState)
    {
        setCNodeSvcState(idx, pEcho->tCNodeInfo.wCSvcState);
        ++m_dwSyncSeq;
        onZcsMSSync(SYNC_NODES);
    }
    
    clearCNodeHBTOCnt(idx);
    return;
}

ZENIC_RESULT CNodeMgr::saveNode(uint16_t node_id, T_ZCMS_CNODE_INFO *ptCNodeInfo)
{
    ZENIC_RESULT ret;
    uint32_t idx;
    E_ZCMS_NODE_LINK_STATE eState;
    XOS_ASSERT(ptCNodeInfo);
    
    ret = findConfClientNode(node_id, idx);
    if(ret != RESULT_ZENIC_SUCCESS)
    {
        o_tMgrStt.dwNodeNotFound++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, 
        	        "saveNode findConfClientNode NodeID[%d] Failed!\n", node_id);
        return ret;
    }
    
    eState = getCNodeLinkState(idx);
    if(eState== E_ZCMS_NODE_STATE_INACTIVE || eState== E_ZCMS_NODE_STATE_INIT)
    {
        saveCNodeInfo(idx, ptCNodeInfo);
        if(eState== E_ZCMS_NODE_STATE_INIT)
        {
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "New ClientNode First QueueApply, his NodeID[%d]!\n", node_id);
            o_tMgrStt.dwInitClientCnt--;
        }
        else
        {
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "New ClientNode QueueApply, his NodeID[%d]!\n", node_id);
            o_tMgrStt.dwInactiveClientCnt--;
        }
        o_tMgrStt.dwQingClientCnt++;
        setCNodeLinkState(idx, E_ZCMS_NODE_STATE_QUEUEING);
        clearCNodeHBTOCnt(idx);
        increaseQingClientCnt();
        setCNodeQueueID(idx, getQingClientCnt());
    }
    
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::preAddNode(uint16_t node_id)
{
    ZENIC_RESULT ret;
    uint32_t idx;
    E_ZCMS_NODE_LINK_STATE eState;
    ret = findConfClientNode(node_id, idx);
    if(ret != RESULT_ZENIC_SUCCESS)
    {
        o_tMgrStt.dwNodeNotFound++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, 
        	        "preAddNode findConfClientNode %d Failed ret:%d!\n", node_id, ret);
        return ret;
    }
    
    eState = getCNodeLinkState(idx);
    if(eState== E_ZCMS_NODE_STATE_QUEUEING) 
    {
        //Todo: ֪ͨ�ϲ�
        o_tMgrStt.dwQingClientCnt--;
        o_tMgrStt.dwRegisteringClientCnt++;
        setCNodeLinkState(idx, E_ZCMS_NODE_STATE_REGISTERING);
        if(getCNodeManageStatus(idx) != ZCS_NODE_STATE_BLOCKED)
        {
            setCNodeManageStatus(idx, ZCS_NODE_STATE_ACTIVE);
            writeShmActiveNodes();
        }
        insertNodeEvent(node_id, EV_ZCS_NODE_JOIN);
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "preAddNode NodeID[%d] Join Success!\n", node_id);
    }
    else
    {
        XOS_ASSERT(0);
        return ERROR_COMMON_ERROR;
    }

    ++m_dwSyncSeq;
    onZcsMSSync(SYNC_NODES|SYNC_EVENTS);
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::addNode(uint16_t node_id)
{
    ZENIC_RESULT ret;
    XOS_STATUS xos_ret;
    uint32_t idx;
    E_ZCMS_NODE_LINK_STATE eState;
    T_ZCS_NODE_STATE state;
    ZCMS_REG_ACK_MSG tFRegAck;
    
    ret = findConfClientNode(node_id, idx);
    if(ret != RESULT_ZENIC_SUCCESS)
    {
        o_tMgrStt.dwNodeNotFound++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, 
        	        "addNode rcv QueueApply msg from Non-Configed NodeID[%d]!\n", node_id);
        return ret;
    }
    
    eState = getCNodeLinkState(idx);
    if(eState== E_ZCMS_NODE_STATE_REGISTERING) 
    {
        o_tMgrStt.dwRegisteringClientCnt--;
        o_tMgrStt.dwActiveClientCnt++;
        XOS_ASSERT(ZCMS_QUEUE_ID_NUMBER_FIRST == getCNodeQueueID(idx));
        removeCNodefromQApplyQueue(ZCMS_QUEUE_ID_NUMBER_FIRST);
        setCNodeLinkState(idx, E_ZCMS_NODE_STATE_ACTIVE);
        addMultiCastClient(node_id);
        
        state = getCNodeManageStatus(idx);
        if(state != ZCS_NODE_STATE_BLOCKED && state != ZCS_NODE_STATE_ACTIVE)
        {
            XOS_ASSERT(0);
            setCNodeManageStatus(idx, ZCS_NODE_STATE_ACTIVE);
            writeShmActiveNodes();
        }
        
        ++m_dwSyncSeq;
        onZcsMSSync(SYNC_NODES|SYNC_EVENTS);
        onZcsMultiCastSync();
    }
    else if(eState== E_ZCMS_NODE_STATE_ACTIVE)
    {
        //do nothing but just send an ack
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS,
        	      "Resend ZCMS_REG_ACK_MSG To JID[Jno:0x%x,Module:%d,RouteType:%d] Node at Active state!\n",
        	      m_tAllCNodesInfo[idx].tCNodeData.tSender.dwJno, m_tAllCNodesInfo[idx].tCNodeData.tSender.wModule, m_tAllCNodesInfo[idx].tCNodeData.tSender.ucRouteType);
    }
    else
    {
    	   ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "addNode NodeID[%d] at State[%d] Failed!\n", node_id, eState);
        return ERROR_INVALID_PARAM;
    }
    
    memset(&tFRegAck, 0, sizeof(tFRegAck));
    getSelfNodeType(tFRegAck.tCurMGRInfo.tCurMgrNodeInfo);
    getSelfPhyAddr(tFRegAck.tCurMGRInfo.tCurMgrPhyAddrInfo);
    tFRegAck.tCurMGRInfo.dwCurMgrPowerOnTick = getMgrPowerOnTick();
    
    tFRegAck.dwRegStatus = ZCMS_REG_RESULT_SUCCESS;
    xos_ret = XOS_SendAsynMsg(EV_SYS_ZCMS_REG_ACK, (uint8_t *)&tFRegAck, (uint16_t)sizeof(ZCMS_REG_ACK_MSG),
    	                                                   XOS_MSG_VER0, MSG_ASYN_HIGH, (void *)&m_tAllCNodesInfo[idx].tCNodeData.tSender);
    o_tMgrStt.dwRegAckSndCnt++;
    m_tAllCNodesInfo[idx].tCNodeStt.tCurStt.dwRegAckSndCnt++;
    if (XOS_SUCCESS != xos_ret)
    {
        o_tMgrStt.dwMsgSndFailed++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS,
        	      "Snd ZCMS_REG_ACK_MSG To JID[Jno:0x%x,Module:%d,RouteType:%d] XOS_SendAsynMsg Failed:%d!\n",
        	      m_tAllCNodesInfo[idx].tCNodeData.tSender.dwJno, m_tAllCNodesInfo[idx].tCNodeData.tSender.wModule, m_tAllCNodesInfo[idx].tCNodeData.tSender.ucRouteType, xos_ret);
        return ERROR_SEND_MSG_FAIL;
    }

    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "addNode NodeID[%d] Join Success!\n", node_id);
    
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::removeNode(uint16_t node_id)
{
    uint32_t idx;
    ZENIC_RESULT ret;
    E_ZCMS_NODE_LINK_STATE eState;
    uint32_t dwCurQID;
    
    ret = findConfClientNode(node_id, idx);
    if(ret != RESULT_ZENIC_SUCCESS)
    {
        o_tMgrStt.dwNodeNotFound++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, 
        	        "removeNode findConfClientNode Failed NodeID[%d]!\n", node_id);
        return ret;
    }

    eState = getCNodeLinkState(idx);
    dwCurQID = getCNodeQueueID(idx);
    //Registering ״̬�����ϻ���Queueing ״̬����Ҫ��ǰ�ƶ��Ŷ�����һ
    if(eState == E_ZCMS_NODE_STATE_QUEUEING || eState == E_ZCMS_NODE_STATE_REGISTERING)
    {
        if(dwCurQID > 0)
        {
            removeCNodefromQApplyQueue(dwCurQID);
        }
        else
        {
            XOS_ASSERT(0);
        }
    }
    
    clearCNodeInfo(idx);
    o_tMgrStt.dwInactiveClientCnt++;
    
    if(eState == E_ZCMS_NODE_STATE_INIT)
    {
        o_tMgrStt.dwInitClientCnt--;
    }
    else if(eState == E_ZCMS_NODE_STATE_QUEUEING) 
    {
        o_tMgrStt.dwQingClientCnt--;
    }
    else if(eState == E_ZCMS_NODE_STATE_REGISTERING)
    {
        o_tMgrStt.dwRegisteringClientCnt--;
        if(findNodeEventNotNotified(node_id, EV_ZCS_NODE_JOIN))
        {
            removeNodeEvent(node_id, EV_ZCS_NODE_JOIN);     //��ֹ��
        }
        else
        {
            insertNodeEvent(node_id, EV_ZCS_NODE_LEAVE);
        }
    }
    else if(eState == E_ZCMS_NODE_STATE_ACTIVE)
    {
        o_tMgrStt.dwActiveClientCnt--;
        /* ���ܸýڵ���û�б�block ������Ҫ֪ͨLEAVE ��Ϣ*/
        insertNodeEvent(node_id, EV_ZCS_NODE_LEAVE);
        removeMultiCastClient(node_id);
        ZCS_LOG(ZCS_LOG_DEBUG, ZCS_LOG_MOD_ZCMS, "removeNode insertNodeEvent NodeID[%d] Leave Success!\n", node_id);
    }
    else
    {
        XOS_ASSERT(eState == E_ZCMS_NODE_STATE_INACTIVE);
        o_tMgrStt.dwInactiveClientCnt--;
        /* sometimes, receiving Heartbeat at E_ZCMS_NODE_STATE_INACTIVE status will goes here */
    }
    
    writeShmActiveNodes();
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "removeNode NodeID[%d] Success!\n", node_id);

    if(eState == E_ZCMS_NODE_STATE_ACTIVE || eState == E_ZCMS_NODE_STATE_REGISTERING)
    {
        ++m_dwSyncSeq;
        onZcsMSSync(SYNC_NODES|SYNC_EVENTS);
        if(eState == E_ZCMS_NODE_STATE_ACTIVE)
        {
            onZcsMultiCastSync();
        }
    }
    return RESULT_ZENIC_SUCCESS;
}

void CNodeMgr::sendResetMsgToClient(uint16_t NodeID, E_ZCMS_RESET_LINK_REASON eRSTReason)
{
    XOS_STATUS xos_ret;
    int ret;
    uint32_t idx;
    ZCMS_RESET_LINK_MSG tResetMsg;
    JID ClientJid;
    uint16_t wModule;
    uint16_t wRouteType;
    
    if(findConfClientNode(NodeID, idx) != RESULT_ZENIC_SUCCESS)
    {
        if(eRSTReason==E_ZCMS_RESET_UNAUTHORIZED)
        {
            if(NodeID==ZCS_MASTER_NODE_ID_1)
            {
                wModule=ZCS_MASTER_NODE_MODULE_NO;
                wRouteType=ZCS_LEFT_BOARD;
            }
            else if(NodeID == ZCS_MASTER_NODE_ID_2)
            {
                wModule=ZCS_MASTER_NODE_MODULE_NO;
                wRouteType=ZCS_RIGHT_BOARD;
            }
            else
            {
                wModule=NodeID;
                wRouteType=ZCS_MASTER_BOARD;
            }
        }
        else
        {
            o_tMgrStt.dwNodeNotFound++;
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "sendResetMsgToClient findConfClientNode NodeID[%d] Failed!\n", NodeID);
            return;
        }
    }
    else
    {
        T_ZCMS_NODE_INFO tLinkNInfo;
        ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,
                             "sendResetMsgToClient m_tAllCNodesInfo.getInstByKey1 idx:%d, Failed ret=%d\n", idx, ret);
            return;
        }
        wModule = tLinkNInfo.tCNodeData.wModule;
        wRouteType = tLinkNInfo.tCNodeData.wRouteType;
    }
    
    if(RESULT_ZENIC_SUCCESS != constructClientJID(wModule, wRouteType, ClientJid))
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "sendResetMsgToClient constructClientJID by Module:%d, Route:%d Failed!\n", 
                                            wModule, wRouteType);
        return;
    }

    tResetMsg.eRSTLinkReason = (E_ZCMS_RESET_LINK_REASON)eRSTReason;
    xos_ret = XOS_SendAsynMsg(EV_SYS_ZCMS_RESET_LINK, (uint8_t *)&tResetMsg, (uint16_t)sizeof(ZCMS_RESET_LINK_MSG),
                                                      XOS_MSG_VER0, XOS_MSG_LOW, (void *)&ClientJid);
    
    if (XOS_SUCCESS != xos_ret)
    {
        o_tMgrStt.dwMsgSndFailed++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "sendResetMsgToClient JID[Jno:0x%x,Module:%d, RouteType:%d] Failed:%d, Reason:(%u,%s)!\n",
               ClientJid.dwJno, ClientJid.wModule, ClientJid.ucRouteType, xos_ret, eRSTReason, zcmsRstReasonToStr(eRSTReason));
        return;
    }
    
    o_tMgrStt.dwRstSndCnt++;
    m_tAllCNodesInfo[idx].tCNodeStt.tCurStt.dwRstSndCnt++;
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "sendResetMsgToClient JID[Jno:0x%x,Module:%d, RouteType:%d] Success, Reason:%u[%s]!\n",
            ClientJid.dwJno, ClientJid.wModule, ClientJid.ucRouteType, eRSTReason, zcmsRstReasonToStr(eRSTReason));
    return;
}

ZENIC_RESULT CNodeMgr::addMultiCastClient(uint16_t node_id)
{
	   int ret;
    uint32_t ActiveIdx;
    T_ACTIVE_NODE tMCClient;
    
    ret = m_tActiveNodes.allocInstByKey1(node_id, ActiveIdx);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"m_tActiveNodes.allocInstByKey1 NodeID[%d], Failed ret=%d\n", node_id, ret);
        return ERROR_ALLOC_INSTANCE_FAIL;
    }

    tMCClient.wNodeID = node_id;
    tMCClient.dwLastAckSeq = m_dwSyncSeq;
    tMCClient.dwAckRcvCount = 0;
    
    ret = m_tActiveNodes.setInstByIndex(ActiveIdx, tMCClient);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"m_tActiveNodes.setInstByIndex insert NodeID[%d], Failed ret=%d\n", node_id, ret);
        return ERROR_INSERT_RECORD_FAIL;
    }
    
    increaseMultiCastClientCnt();
    
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::updateMultiCastClientAckSeq(uint16_t node_id, uint32_t newAckedSeq)
{
	   int ret;
    uint32_t ActiveIdx;
    T_ACTIVE_NODE tMCClient;
    
    ret = m_tActiveNodes.findInstByKey1(node_id, ActiveIdx);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"m_tActiveNodes.findInstByKey1 NodeID[%d], Failed ret=%d\n", node_id, ret);
        return ERROR_RECORD_NOT_FOUND;
    }

    ret = m_tActiveNodes.getInstByIndex(ActiveIdx, tMCClient);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"m_tActiveNodes.getInstByIndex ActiveIdx:%d, Failed ret=%d\n", ActiveIdx, ret);
        return ERROR_ALLOC_INSTANCE_FAIL;
    }

    XOS_ASSERT(tMCClient.wNodeID == node_id);

    if(SEQ_LT(tMCClient.dwLastAckSeq, newAckedSeq) && SEQ_GE(m_dwSyncSeq, newAckedSeq))
    {
        tMCClient.dwLastAckSeq = newAckedSeq;
        ZCS_LOG(ZCS_LOG_DEBUG, ZCS_LOG_BUF_ZCMS, "updateMultiCastClientAckSeq NodeID[%d], LastAckSeq=%d\n", node_id, newAckedSeq);
    }
    
    tMCClient.dwAckRcvCount++;
    ret = m_tActiveNodes.setInstByIndex(ActiveIdx, tMCClient);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"m_tActiveNodes.setInstByIndex insert NodeID[%d], Failed ret=%d\n", node_id, ret);
        return ERROR_INSERT_RECORD_FAIL;
    }

    return RESULT_ZENIC_SUCCESS;
}

bool CNodeMgr::checkMultiCastAckedByAllClients()
{
    int ret;
    uint32_t idx = 0;
    T_ACTIVE_NODE tMCClient;
    
    while (idx < m_tActiveNodes.getTotalInstNum())
    {
        if(m_tActiveNodes.getInstanceState(idx)!=InstMgr::INST_STATE_ALLOCATED)
        {
            idx++;
            continue;
        }
        ret = m_tActiveNodes.getInstByIndex(idx, tMCClient);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            XOS_ASSERT(0);
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS, "checkMultiCastAckedByAllClients getInstByIndex %d, Failed ret=%d\n", idx, ret);
            idx++;
            continue;
        }
        
        /* ����tRegister.bIsCurEventSnd �ɲ�Ҫ*/
        /* if ((tRegister.bIsCurEventSnd) && (!tRegister.bIsCurEventAcked)) */
        if (tMCClient.dwLastAckSeq != m_dwSyncSeq)
        {
            ZCS_LOG(ZCS_LOG_DEBUG, ZCS_LOG_BUF_ZCMS, "checkMultiCastAckedByAllClients, False!\n");
            return FALSE;
        }
        idx++;
    }

    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_BUF_ZCMS, "checkMultiCastAckedByAllClients, True!\n");
    return TRUE;
}

ZENIC_RESULT CNodeMgr::removeMultiCastClient(uint16_t node_id)
{
	   int ret;
    
    ret = m_tActiveNodes.releaseInstByKey1(node_id);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"m_tActiveNodes.releaseInstByKey1 remove NodeID[%d], Failed ret=%d\n", node_id, ret);
        return ERROR_RECORD_NOT_FOUND;
    }
    
    decreaseMultiCastClientCnt();
    return RESULT_ZENIC_SUCCESS;
}

void CNodeMgr::onNodeEventAck(void *pMsg, uint16_t msg_len)
{
    int ret;
    uint32_t idx = 0;
    T_Node_Event_Register tRegister;
    JID tSnderJid;
    T_EV_ZCS_NODE_EVENT_ACK *pAck;
    XOS_STATUS xos_ret;
    
    if(msg_len != sizeof(T_EV_ZCS_NODE_EVENT_ACK) || pMsg==NULL)
    {
        o_tMgrStt.dwErrorMsgRcv++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, 
        	        "onNodeEventAck rcv Error Msg:length %d should be:%d, pMsg:%p!\n", 
        	        msg_len, sizeof(T_EV_ZCS_NODE_EVENT_ACK), pMsg);
        XOS_ASSERT(0);
        return;
    }
    
    xos_ret = XOS_Sender(&tSnderJid);
    if(XOS_SUCCESS != xos_ret)
    {
    	   o_tMgrStt.dwErrorMsgRcv++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, 
        	        "onNodeEventAck get XOS_Sender Failed ret=%d!\n", xos_ret);
        return;
    }
    
    ret = m_tNodeEventSubscriber.findInstByKey1(tSnderJid.dwJno, idx);

    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"onNodeEventAck findInstByKey1 [Jno:0x%x], Failed ret=%d\n", 
        	                tSnderJid.dwJno, ret);
        return;
    }
    
    ret = m_tNodeEventSubscriber.getInstByIndex(idx, tRegister);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS, "onNodeEventAck getInstByIndex %d, Failed ret=%d\n", idx, ret);
        return;
    }
    
    pAck = (T_EV_ZCS_NODE_EVENT_ACK*)pMsg;
    XOS_ASSERT(tRegister.dwJNO==tSnderJid.dwJno);
    XOS_ASSERT(tRegister.bNeedAck);
    
    recordAllNodeUPLEventAckStats(pAck->node_id, pAck->event_type);
    	
    if(tRegister.bNeedAck)
    {
   	    tRegister.bIsCurEventAcked = TRUE;
    }
   	tRegister.dwAckRcv++;
   	
    ret = m_tNodeEventSubscriber.setInstByIndex(idx, tRegister);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"m_tNodeEventSubscriber.setInstByIndex [Jno:0x%x], NeedAck:%d Failed ret=%d\n", 
        	                tRegister.dwJNO, tRegister.bNeedAck, ret);
        return;
    }

    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "EV_SYS_ZCS_NODE_EVENT_ACK msg NodeID[%d] event:%d[%s]!\n", 
    	                    pAck->node_id, pAck->event_type, zcmsEventToStr(pAck->event_type));

    if(!verifyNodeEvent(pAck->node_id, pAck->event_type))
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "EV_SYS_ZCS_NODE_EVENT_ACK msg NodeID[%d] event:%d[%s] checked error!\n", 
        	                pAck->node_id, pAck->event_type, zcmsEventToStr(pAck->event_type));
        return;
    }
    
   	if(checkNodeEventAckedByAllSubs())
   	{
   	    if(pAck->event_type == EV_ZCS_NODE_JOIN)
   	    {
            addNode(pAck->node_id);
   	    }
   	    else
   	    {
            XOS_ASSERT((pAck->event_type == EV_ZCS_NODE_LEAVE)
            	       || (pAck->event_type == EV_ZCS_NODE_BLOCKED)
            	       || (pAck->event_type ==  EV_ZCS_NODE_UNBLOCKED)
            	       || (pAck->event_type ==  EV_ZCS_NODE_BALANCE) ); // do nothing
   	    }
   	    
        removeNodeEvent(pAck->node_id, pAck->event_type);
   	}
   	
   	onZcsMSSync(SYNC_EVENTS);
    return;
}

void CNodeMgr::onSelfTriggerNodeEventAck(void *pMsg, uint16_t msg_len)
{
    T_EV_ZCS_NODE_EVENT_ACK *pAck;

    if(msg_len != sizeof(T_EV_ZCS_NODE_EVENT_ACK) || pMsg==NULL)
    {
        o_tMgrStt.dwErrorMsgRcv++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, 
        	        "onSelfTriggerNodeEventAck rcv Error Msg:length %d should be:%d, pMsg:%p!\n", 
        	        msg_len, sizeof(T_EV_ZCS_NODE_EVENT_ACK), pMsg);
        XOS_ASSERT(0);
        return;
    }

    pAck = (T_EV_ZCS_NODE_EVENT_ACK*)pMsg;
   	if(checkNodeEventAckedByAllSubs())
   	{
   	    if(pAck->event_type == EV_ZCS_NODE_JOIN)
   	    {
            addNode(pAck->node_id);
   	    }
   	    else
   	    {
            XOS_ASSERT((pAck->event_type == EV_ZCS_NODE_LEAVE)
            	       || (pAck->event_type == EV_ZCS_NODE_BLOCKED)
            	       || (pAck->event_type ==  EV_ZCS_NODE_UNBLOCKED)
            	       || (pAck->event_type ==  EV_ZCS_NODE_BALANCE) ); // do nothing
   	    }
   	    
        removeNodeEvent(pAck->node_id, pAck->event_type);
   	}
   	
   	onZcsMSSync(SYNC_EVENTS);
    return;
}

void CNodeMgr::onNodeEventSubscribe(void *pMsg, uint16_t msg_len)
{
    int ret;
    uint32_t idx;
    bool NeedAck;
    T_Node_Event_Register tRegister;
    JID tSnderJid;
    XOS_STATUS xos_ret;

    if(msg_len != sizeof(bool) || pMsg==NULL)
    {
        o_tMgrStt.dwErrorMsgRcv++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, 
        	        "onNodeEventSubscribe rcv Error Msg:length %d should be:%d, pMsg:%p!\n", 
        	        msg_len, sizeof(bool), pMsg);
        XOS_ASSERT(0);
        return;
    }
    
    memset(&tSnderJid, 0, sizeof(tSnderJid));
    xos_ret = XOS_Sender(&tSnderJid);
    if(XOS_SUCCESS != xos_ret)
    {
    	   o_tMgrStt.dwErrorMsgRcv++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, 
        	        "onNodeEventSubscribe get XOS_Sender Failed ret=%d!\n", xos_ret);
        return;
    }
    
    ret = m_tNodeEventSubscriber.findInstByKey1(tSnderJid.dwJno, idx);
    if(ret==InstMgr::RESULT_INST_SUCCESS)
    {
        //ZCS_LOG(ZCS_LOG_WARN, ZCS_LOG_BUF_ZCMS,"onNodeEventSubscribe find [Jno:0x%x] already subscribed!\n", tSnderJid.dwJno, ret);
        return;
    }
    
    ret = m_tNodeEventSubscriber.allocInstByKey1(tSnderJid.dwJno, idx);

    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"onNodeEventSubscribe allocInstByKey1 [Jno:0x%x], Failed ret=%d\n", 
        	                tSnderJid.dwJno, ret);
        return;
    }
    
    NeedAck = *(bool*)pMsg;

    memset(&tRegister, 0, sizeof(tRegister));
    tRegister.dwJNO = tSnderJid.dwJno;
    tRegister.bNeedAck = NeedAck;
    tRegister.bIsCurEventSnd = TRUE;  //��������� TRUE����ǰ���������¼�֪ͨ��
    tRegister.bIsCurEventAcked = TRUE;

    ret = m_tNodeEventSubscriber.setInstByIndex(idx, tRegister);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"onNodeEventSubscribe setInstByIndex [Jno:0x%x], NeedAck:%d Failed ret=%d\n", 
        	                tSnderJid.dwJno, NeedAck, ret);
        return;
    }
    
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_BUF_ZCMS,"onNodeEventSubscribe [Jno:0x%x] set REGISTER_NODE_EVENT NeedAck:%d Success!\n", 
    	                tSnderJid.dwJno, NeedAck);
    return;
}

void CNodeMgr::insertNodeEvent(uint16_t wNodeID, T_ZCS_NODE_EVENT event)
{
    T_ZCMS_NODE_OP_EVENT_KEY tKeyEvent;
    T_ZCMS_NODE_OP_EVENT tEvent;
    NODEEVENTINSTIT it;
    bool IsFirst = FALSE;
    
    tKeyEvent.node_id = wNodeID;
    tKeyEvent.node_op = event;
    tEvent.wNodeId = wNodeID;
    tEvent.tNodeOp = event;
    
    m_tNodeEventQueue.insert(std::pair<T_ZCMS_NODE_OP_EVENT_KEY, T_ZCMS_NODE_OP_EVENT>(tKeyEvent, tEvent));
    
    /* triger send msg */
    it = m_tNodeEventQueue.find(tKeyEvent);
    if(it == m_tNodeEventQueue.begin())
    {
        IsFirst = TRUE;
    }

    if(IsFirst)
    {
    	   ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "insertNodeEvent NodeID[%d] event:%d[%s] is first element, should notify UPL!\n",
    	   	                                     wNodeID, event, zcmsEventToStr(event));
        notifyUPLNodeEvent(true);
    }
    else
    {
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "insertNodeEvent NodeID[%d] event:%d[%s] is NOT first element!\n", 
        	                                     wNodeID, event, zcmsEventToStr(event));
    }
}

bool CNodeMgr::findNodeEvent(uint16_t wNodeID, T_ZCS_NODE_EVENT event)
{
    T_ZCMS_NODE_OP_EVENT_KEY tKeyEvent;
    NODEEVENTINSTIT it;
    
    tKeyEvent.node_id = wNodeID;
    tKeyEvent.node_op = event;

    it = m_tNodeEventQueue.find(tKeyEvent);
    if(it == m_tNodeEventQueue.end())
    {
        return FALSE;
    }

    return TRUE;
}

bool CNodeMgr::findNodeEventNotNotified(uint16_t wNodeID, T_ZCS_NODE_EVENT event)
{
    T_ZCMS_NODE_OP_EVENT_KEY tKeyEvent;
    NODEEVENTINSTIT it;
    
    tKeyEvent.node_id = wNodeID;
    tKeyEvent.node_op = event;

    it = m_tNodeEventQueue.find(tKeyEvent);
    if(it == m_tNodeEventQueue.end() || it == m_tNodeEventQueue.begin())
    {
        return FALSE;
    }

    return TRUE;
}

bool CNodeMgr::verifyNodeEvent(uint16_t wNodeID, T_ZCS_NODE_EVENT event)
{    
	   NODEEVENTINSTIT it;

	   it = m_tNodeEventQueue.begin();

    if(m_tNodeEventQueue.end()==it)
    {
    	   XOS_ASSERT(0==m_tNodeEventQueue.size());
        ZCS_LOG(ZCS_LOG_WARN, ZCS_LOG_MOD_ZCMS, "verifyNodeEvent Failed! Rcv NodeEventAck NodeID[%d] event:%d[%s], but NodeEventQueue is NULL\n",
        	                                      wNodeID, event, zcmsEventToStr(event));
        return FALSE;
    }
    
	   if((wNodeID != it->first.node_id) || (event != it->first.node_op))
	   {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "verifyNodeEvent Failed! msg NodeID[%d] event:%d[%s], but mine is [%d]:%d\n",
        	                                      wNodeID, event, zcmsEventToStr(event), it->first.node_id, it->first.node_op);
        XOS_ASSERT(0);
        return FALSE;
	   }

    return TRUE;
}

void CNodeMgr::removeNodeEvent(uint16_t wNodeID, T_ZCS_NODE_EVENT event)
{
    T_ZCMS_NODE_OP_EVENT_KEY tKeyEvent;
    tKeyEvent.node_id = wNodeID;
    tKeyEvent.node_op = event;
    NODEEVENTINSTIT it;
    
    it = m_tNodeEventQueue.find(tKeyEvent);
    if(it != m_tNodeEventQueue.begin())
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "NodeID[%d], event:%d[%s] to removeNodeEvent is NOT first!\n", 
        	                                      wNodeID, event, zcmsEventToStr(event));
        XOS_ASSERT(0);
        return;
    }    
    
    m_tNodeEventQueue.erase(tKeyEvent);
    
    if(isChangingOver())
    {
        ZCS_LOG(ZCS_LOG_WARN, ZCS_LOG_MOD_ZCMS, "removeNodeEvent and find Mgr isChangingOver, stop notifyUPLNodeEvent\n");
        return;
    }

	   ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "removeNodeEvent and continue notifyUPLNodeEvent\n");
    notifyUPLNodeEvent(true);
    return;
}

ZENIC_RESULT CNodeMgr::notifyUPLNodeEvent(bool isFirstSend)
{
    int ret;
    XOS_STATUS xos_ret;
    uint32_t idx = 0;
    uint16_t wNodeID;
    T_ZCS_NODE_EVENT event;
    T_EV_ZCS_NODE_EVENT tNodeEv;
    T_Node_Event_Register tRegister;
    JID tRegJID;
    bool isSendMsgSuc = TRUE;
    bool NeedSelfMsgTrigger = TRUE;
    NODEEVENTINSTIT it;

   it = m_tNodeEventQueue.begin();

   if(it == m_tNodeEventQueue.end())
   {
       XOS_ASSERT(0==m_tNodeEventQueue.size());
       ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "notifyUPLNodeEvent:NodeEventQueue is NULL\n");
       return RESULT_ZENIC_SUCCESS;
   }

    wNodeID = it->first.node_id;
    event = it->first.node_op;
    
    while (idx < m_tNodeEventSubscriber.getTotalInstNum())
    {
        if(m_tNodeEventSubscriber.getInstanceState(idx)!=InstMgr::INST_STATE_ALLOCATED)
        {
            idx++;
            continue;
        }
        ret = m_tNodeEventSubscriber.getInstByIndex(idx, tRegister);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            XOS_ASSERT(0);
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS, "notifyUPLNodeEvent getInstByIndex %d, Failed ret=%d\n", idx, ret);
            idx++;
            continue;
        }

        if(isFirstSend)
        {
            tRegister.bIsCurEventSnd = FALSE;
            tRegister.bIsCurEventAcked = FALSE;       
        }
        else
        {
            if(tRegister.bIsCurEventSnd)
            {            
                ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_BUF_ZCMS, "notifyUPLNodeEvent register.jno=0x%x already send\n",tRegister.dwJNO);
                idx++;
                continue;
            }
        }

        fillNotifyNodeEvent(tNodeEv, wNodeID, event);
        
        //tNodeEv.event_type = event;
        //tNodeEv.tNode.nodeId = wNodeID; 

        XOS_GetSelfJID(&tRegJID);
        tRegJID.dwJno = tRegister.dwJNO;        
        xos_ret =  XOS_SendAsynMsg(EV_SYS_ZCS_NODE_EVENT_NOTIFY,(uint8_t *)&tNodeEv,
                                  sizeof(tNodeEv), XOS_MSG_VER0, XOS_MSG_HIGH, &tRegJID);

        if (XOS_SUCCESS != xos_ret)
        {
            isSendMsgSuc = FALSE;
            tRegister.dwNotifySndFailed++;
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, 
                   "notifyUPLNodeEvent NodeID[%d][%d:%d:%d] event:%d[%s] To [Jno:0x%x] Failed:%d!\n",
                   tNodeEv.tNode.nodeId,
                   tNodeEv.tNode.moduleId,
                   tNodeEv.tNode.state,
                   tNodeEv.tNode.route_type,
                   tNodeEv.event_type,
                   zcmsEventToStr(tNodeEv.event_type),
                   tRegJID.dwJno,
                   xos_ret);
            tRegister.bIsCurEventSnd = FALSE;
            tRegister.bIsCurEventAcked = FALSE;
            m_NotifyUPLWaitACKTimerID = zcms_set_timer(EV_SYS_ZCMS_NOTIFY_UPL_WAIT_ACK_TIMER, ZCMS_NOTIFY_UPL_WAIT_ACK_PERIOD, 0);
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_BUF_ZCMS, "EV_SYS_ZCMS_NOTIFY_UPL_WAIT_ACK_TIMER !,NeedSelfMsgTrigger= %s\n",NeedSelfMsgTrigger?"true":"false");

        }
        else
        {
            tRegister.bIsCurEventSnd = TRUE;
            if (!tRegister.bNeedAck)
            {
                tRegister.bIsCurEventAcked = TRUE;
            }
            else
            {
                NeedSelfMsgTrigger = FALSE;
            }
            tRegister.dwNotifySnd++;
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, 
                   "notifyUPLNodeEvent NodeID[%d][%d:%d:%d] event:%d[%s] To [Jno:0x%x] Success!\n",
                   tNodeEv.tNode.nodeId,
                   tNodeEv.tNode.moduleId,
                   tNodeEv.tNode.state,
                   tNodeEv.tNode.route_type,
                   tNodeEv.event_type,
                   zcmsEventToStr(tNodeEv.event_type),
                   tRegJID.dwJno);
        }
        ret = m_tNodeEventSubscriber.setInstByIndex(idx, tRegister);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"m_tNodeEventSubscriber.setInstByIndex [Jno:0x%x], NeedAck:%d Failed ret=%d\n", 
            	                tRegister.dwJNO, tRegister.bNeedAck, ret);
            return ERROR_INSERT_RECORD_FAIL;
        }
        idx++;
    }
    
    recordAllNodeUPLEventStats(wNodeID, event, isSendMsgSuc);
    
    if(NeedSelfMsgTrigger)
    {
        JID tZcmsJid;
        XOS_STATUS ret;
        T_EV_ZCS_NODE_EVENT_ACK tAck;
        if(XOS_SUCCESS!=XOS_GetSelfJID(&tZcmsJid))
        {
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_BUF_ZCMS,"notifyUPLNodeEvent XOS_GetSelfJID Failed\n");
            return ERROR_COMMON_ERROR;
        }
        tAck.event_type = event;
        tAck.node_id = wNodeID;
        ret = XOS_SendAsynMsg(EV_SYS_ZCMS_SELF_TRIGGER_MSG,(uint8_t *)&tAck,sizeof(T_EV_ZCS_NODE_EVENT_ACK), 0, 0, &tZcmsJid);
        if (XOS_SUCCESS == ret)
        {
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_BUF_ZCMS,"notifyUPLNodeEvent SelfMsgTrigger Send Msg Success!\n");
        }
        else
        {
            ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_BUF_ZCMS,"notifyUPLNodeEvent SelfMsgTrigger Send Msg Failed:%d!\n", ret);
        }
    }
    
    return RESULT_ZENIC_SUCCESS;
}

bool CNodeMgr::checkNodeEventAckedByAllSubs()
{
    int ret;
    uint32_t idx = 0;
    T_Node_Event_Register tRegister;
    
    while (idx < m_tNodeEventSubscriber.getTotalInstNum())
    {
        if(m_tNodeEventSubscriber.getInstanceState(idx)!=InstMgr::INST_STATE_ALLOCATED)
        {
            idx++;
            continue;
        }
        ret = m_tNodeEventSubscriber.getInstByIndex(idx, tRegister);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            XOS_ASSERT(0);
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS, "checkNodeEventAckedByAllSubs getInstByIndex %d, Failed ret=%d\n", idx, ret);
            idx++;
            continue;
        }
        
        /* ����tRegister.bIsCurEventSnd �ɲ�Ҫ*/
        /* if ((tRegister.bIsCurEventSnd) && (!tRegister.bIsCurEventAcked)) */
        if (!tRegister.bIsCurEventAcked)
        {
            ZCS_LOG(ZCS_LOG_DEBUG, ZCS_LOG_BUF_ZCMS, "checkNodeEventAckedByAllSubs, False!\n");
            return FALSE;
        }
        idx++;
    }

    zcms_cancel_timer(m_NotifyUPLWaitACKTimerID);
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_BUF_ZCMS, "checkNodeEventAckedByAllSubs, True!\n");
    return TRUE;
}

ZENIC_RESULT CNodeMgr::writeShmActiveNodes()
{
    uint32_t TotalCnt;
    uint16_t DataNum = 0;
    uint32_t idx = 0;
    T_ZCS_NODE_LIST tTmpList;

#if 0
    if(m_pConfig->getConfSelfNodeRole() & ZCS_NODE_ROLE_SERVICE)
    {
        return RESULT_ZENIC_SUCCESS;
    }
#endif

    if(NULL==m_ptActiveNodeList || (T_ZCS_NODE_LIST *)-1==m_ptActiveNodeList)
    {    
        int flag = O_CREAT | O_RDWR;
        int mode = S_IRUSR | S_IWUSR;
        int proto = PROT_READ | PROT_WRITE;
    
        int shm_id1 = shm_open(pZcsMgrNodesShmName, flag, mode);
    
        if(shm_id1<0)
        {
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "writeShmActiveNodes ZcsMgrNodesShm shm_open Failed!\n");
            return ERROR_FILE_OPEN_FAIL;
        }
    
        ftruncate(shm_id1, sizeof(T_ZCS_NODE_LIST));
        m_ptActiveNodeList = (T_ZCS_NODE_LIST *)mmap(NULL,sizeof(T_ZCS_NODE_LIST), proto, MAP_SHARED, shm_id1, 0);
        
        if(m_ptActiveNodeList == (T_ZCS_NODE_LIST *)-1)
        {
            int err = errno;
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS, "writeShmActiveNodes ZcsMgrNodesShm mmap Result:%d!\n", err);
            close(shm_id1);
            return ERROR_ALLOC_MEM_FAIL;
        }
        close(shm_id1);
    }

    memset(&tTmpList, 0, sizeof(tTmpList));
    TotalCnt = m_tAllCNodesInfo.getTotalInstNum();
    while(idx < TotalCnt)
    {
    	   int ret;
        T_ZCMS_NODE_INFO tLinkNInfo;

        if(m_tAllCNodesInfo.getInstanceState(idx)!=InstMgr::INST_STATE_ALLOCATED)
        {
            idx++;
            continue;
        }
        ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            idx++;
            continue;
        }
        
        tTmpList.tNodes[DataNum].nodeId = tLinkNInfo.tCNodeData.wNodeId;
        tTmpList.tNodes[DataNum].moduleId = tLinkNInfo.tCNodeData.wModule;
        tTmpList.tNodes[DataNum].state = tLinkNInfo.tCNodeData.tManageStatus;
        tTmpList.tNodes[DataNum].route_type = tLinkNInfo.tCNodeData.wRouteType;
        DataNum++;
        idx++;
    }

    tTmpList.node_num = DataNum;

    memcpy(m_ptActiveNodeList, &tTmpList, sizeof(tTmpList));
    return RESULT_ZENIC_SUCCESS;
}

void CNodeMgr::fillNotifyNodeEvent(T_EV_ZCS_NODE_EVENT &tNodeEv, uint16_t wNodeId, T_ZCS_NODE_EVENT tEvent)
{
    uint32_t idx;
    tNodeEv.event_type = tEvent;
    tNodeEv.tNode.nodeId = wNodeId;
    ZENIC_RESULT ret = findConfClientNode(wNodeId, idx);
    if(RESULT_ZENIC_SUCCESS==ret)
    {
        tNodeEv.tNode.moduleId = m_tAllCNodesInfo[idx].tCNodeData.wModule;
        tNodeEv.tNode.state = m_tAllCNodesInfo[idx].tCNodeData.tManageStatus;
        tNodeEv.tNode.route_type = m_tAllCNodesInfo[idx].tCNodeData.wRouteType;
    }
    else
    {
        tNodeEv.tNode.moduleId = 0;
        tNodeEv.tNode.state = ZCS_NODE_STATE_INACTIVE;
        tNodeEv.tNode.route_type = ZCS_INVALID_BOARD;
    }
    return;
}

void CNodeMgr::recordAllNodeUPLEventAckStats(uint16_t wNodeId, T_ZCS_NODE_EVENT tEvent)
{
	   uint32_t idx;
    if(EV_ZCS_NODE_JOIN == tEvent)
    {
        o_tMgrStt.dwJoinNotifyAck++;
    }
    else if(EV_ZCS_NODE_LEAVE == tEvent)
    {
        o_tMgrStt.dwLeaveNotifyAck++;
    }
    else if(EV_ZCS_NODE_BLOCKED == tEvent)
    {
        o_tMgrStt.dwBlockNotifyAck++;
    }
    else if(EV_ZCS_NODE_UNBLOCKED == tEvent)
    {
        o_tMgrStt.dwUnblockNotifyAck++;
    }
    else if(EV_ZCS_NODE_BALANCE == tEvent)
    {
       o_tMgrStt.dwBalanceNotifyAck++;
       return;
    }
    else
    {
         XOS_ASSERT(0);
    }
    ZENIC_RESULT ret = findConfClientNode(wNodeId, idx);
    if(RESULT_ZENIC_SUCCESS==ret)
    {
        if(EV_ZCS_NODE_JOIN == tEvent)
        {
            m_tAllCNodesInfo[idx].tCNodeStt.tCurStt.dwUPLJoinAck++;
        }
        else if(EV_ZCS_NODE_LEAVE == tEvent)
        {
            m_tAllCNodesInfo[idx].tCNodeStt.tCurStt.dwUPLQuitAck++;
        }
        else if(EV_ZCS_NODE_BLOCKED == tEvent)
        {
            m_tAllCNodesInfo[idx].tCNodeStt.tCurStt.dwUPLBlockAck++;
        }
        else if(EV_ZCS_NODE_UNBLOCKED == tEvent)
        {
            m_tAllCNodesInfo[idx].tCNodeStt.tCurStt.dwUPLUnblockAck++;
        }
    }
    else /* �˴����ܶ��ԣ�ɾ���ڵ�����յ�remove ȷ����Ϣ���ߵ�����*/
    {
        o_tMgrStt.dwEventAckNodeNotFound++;
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_BUF_ZCMS, 
        	   "recordAllNodeUPLEventAckStats findConfClientNode NodeID[%d] event:%d Failed ret=%d\n", wNodeId, tEvent, ret);
    }   
    return;
}

void CNodeMgr::recordAllNodeUPLEventStats(uint16_t wNodeId, T_ZCS_NODE_EVENT tEvent, bool isSuccess)
{
	   uint32_t idx;
    if(EV_ZCS_NODE_BALANCE == tEvent)
    {
        if(isSuccess)
        {
            o_tMgrStt.dwBalanceNotify++;
        }
        else
        {
            o_tMgrStt.dwBalanceNotifyFailed++;
        }
        return;
    }
    ZENIC_RESULT ret = findConfClientNode(wNodeId, idx);
    if(RESULT_ZENIC_SUCCESS==ret)
    {
    	   if(isSuccess)
    	   {
        	   if(EV_ZCS_NODE_JOIN == tEvent)
        	   {
                m_tAllCNodesInfo[idx].tCNodeStt.tCurStt.dwUPLJoinNotify++;
                o_tMgrStt.dwJoinNotify++;
        	   }
        	   else if(EV_ZCS_NODE_LEAVE == tEvent)
        	   {
                m_tAllCNodesInfo[idx].tCNodeStt.tCurStt.dwUPLQuitNotify++;
                o_tMgrStt.dwLeaveNotify++;
        	   }
        	   else if(EV_ZCS_NODE_BLOCKED == tEvent)
        	   {
                m_tAllCNodesInfo[idx].tCNodeStt.tCurStt.dwUPLBlockNotify++;
                o_tMgrStt.dwBlockNotify++;
        	   }
        	   else
        	   {
                XOS_ASSERT(EV_ZCS_NODE_UNBLOCKED == tEvent);
                m_tAllCNodesInfo[idx].tCNodeStt.tCurStt.dwUPLUnblockNotify++;
                o_tMgrStt.dwUnblockNotify++;
        	   }
    	   }
    	   else
    	   {
        	   if(EV_ZCS_NODE_JOIN == tEvent)
        	   {
                m_tAllCNodesInfo[idx].tCNodeStt.tCurStt.dwUPLJoinNotifyFailed++;
                o_tMgrStt.dwJoinNotifyFailed++;
        	   }
        	   else if(EV_ZCS_NODE_LEAVE == tEvent)
        	   {
                m_tAllCNodesInfo[idx].tCNodeStt.tCurStt.dwUPLQuitNotifyFailed++;
                o_tMgrStt.dwLeaveNotifyFailed++;
        	   }
        	   else if(EV_ZCS_NODE_BLOCKED == tEvent)
        	   {
                m_tAllCNodesInfo[idx].tCNodeStt.tCurStt.dwUPLBlockNotifyFailed++;
                o_tMgrStt.dwBlockNotifyFailed++;
        	   }
        	   else
        	   {
                XOS_ASSERT(EV_ZCS_NODE_UNBLOCKED == tEvent);
                m_tAllCNodesInfo[idx].tCNodeStt.tCurStt.dwUPLUnblockNotifyFailed++;
                o_tMgrStt.dwUnblockNotifyFailed++;
        	   }
    	   }
    }
    else
    {
    	   o_tMgrStt.dwEventNodeNotFound++;
    	   ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS, 
    	   	   "recordAllNodeUPLEventStats findConfClientNode NodeID[%d] event:%d Failed ret=%d\n", wNodeId, tEvent, ret);
        XOS_ASSERT(0);
    }
}

void CNodeMgr::saveAllCNodesStt()
{
    int ret;
    uint32_t idx = 0;
    uint32_t TotalCnt = 0;
    T_ZCMS_NODE_INFO tLinkNInfo;
    
    TotalCnt = m_tAllCNodesInfo.getTotalInstNum();
    while (idx < TotalCnt)
    {
        if(m_tAllCNodesInfo.getInstanceState(idx)!=InstMgr::INST_STATE_ALLOCATED)
        {
            idx++;
            continue;
        }
        ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            idx++;
            continue;
        }

    	   tLinkNInfo.tCNodeStt.tHistoryStt.dwQApplyRcvCnt += tLinkNInfo.tCNodeStt.tLastStt.dwQApplyRcvCnt;
    	   tLinkNInfo.tCNodeStt.tHistoryStt.dwRegRcvCnt += tLinkNInfo.tCNodeStt.tLastStt.dwRegRcvCnt;
    	   tLinkNInfo.tCNodeStt.tHistoryStt.dwHBRcvCnt += tLinkNInfo.tCNodeStt.tLastStt.dwHBRcvCnt;
    	   tLinkNInfo.tCNodeStt.tHistoryStt.dwQAckSndCnt += tLinkNInfo.tCNodeStt.tLastStt.dwQAckSndCnt;
    	   tLinkNInfo.tCNodeStt.tHistoryStt.dwRegAckSndCnt += tLinkNInfo.tCNodeStt.tLastStt.dwRegAckSndCnt;
    	   tLinkNInfo.tCNodeStt.tHistoryStt.dwRstSndCnt += tLinkNInfo.tCNodeStt.tLastStt.dwRstSndCnt;
    	   tLinkNInfo.tCNodeStt.tHistoryStt.dwHBToGtExpect += tLinkNInfo.tCNodeStt.tLastStt.dwHBToGtExpect;
    	   tLinkNInfo.tCNodeStt.tHistoryStt.dwUPLJoinNotify += tLinkNInfo.tCNodeStt.tLastStt.dwUPLJoinNotify;
    	   tLinkNInfo.tCNodeStt.tHistoryStt.dwUPLJoinAck += tLinkNInfo.tCNodeStt.tLastStt.dwUPLJoinAck;
    	   tLinkNInfo.tCNodeStt.tHistoryStt.dwUPLQuitNotify += tLinkNInfo.tCNodeStt.tLastStt.dwUPLQuitNotify;
    	   tLinkNInfo.tCNodeStt.tHistoryStt.dwUPLQuitAck += tLinkNInfo.tCNodeStt.tLastStt.dwUPLQuitAck;
    	   tLinkNInfo.tCNodeStt.tHistoryStt.dwUPLBlockNotify += tLinkNInfo.tCNodeStt.tLastStt.dwUPLBlockNotify;
    	   tLinkNInfo.tCNodeStt.tHistoryStt.dwUPLBlockAck += tLinkNInfo.tCNodeStt.tLastStt.dwUPLBlockAck;
    	   tLinkNInfo.tCNodeStt.tHistoryStt.dwUPLUnblockNotify += tLinkNInfo.tCNodeStt.tLastStt.dwUPLUnblockNotify;
    	   tLinkNInfo.tCNodeStt.tHistoryStt.dwUPLUnblockAck += tLinkNInfo.tCNodeStt.tLastStt.dwUPLUnblockAck;
    	   tLinkNInfo.tCNodeStt.tHistoryStt.dwUPLJoinNotifyFailed += tLinkNInfo.tCNodeStt.tLastStt.dwUPLJoinNotifyFailed;
    	   tLinkNInfo.tCNodeStt.tHistoryStt.dwUPLQuitNotifyFailed += tLinkNInfo.tCNodeStt.tLastStt.dwUPLQuitNotifyFailed;
    	   tLinkNInfo.tCNodeStt.tHistoryStt.dwUPLBlockNotifyFailed += tLinkNInfo.tCNodeStt.tLastStt.dwUPLBlockNotifyFailed;
    	   tLinkNInfo.tCNodeStt.tHistoryStt.dwUPLUnblockNotifyFailed += tLinkNInfo.tCNodeStt.tLastStt.dwUPLUnblockNotifyFailed;
    	   if(tLinkNInfo.tCNodeStt.tHistoryStt.dwHBToMax < tLinkNInfo.tCNodeStt.tLastStt.dwHBToMax)
    	   {
    	   	   tLinkNInfo.tCNodeStt.tHistoryStt.dwHBToMax = tLinkNInfo.tCNodeStt.tLastStt.dwHBToMax;
    	   }

    	   tLinkNInfo.tCNodeStt.tLastStt = tLinkNInfo.tCNodeStt.tCurStt;
        memset(&tLinkNInfo.tCNodeStt.tCurStt, 0, sizeof(T_ZCMS_NODE_REG_STT));
        ret = m_tAllCNodesInfo.setInstByIndex(idx, tLinkNInfo);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
        	   ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "saveAllCNodesStt setInstByIndex idx:%d Failed!\n", idx);
            idx++;
            continue;
        }
        idx++;
    }

    return;
}

void CNodeMgr::showLAPool()
{
    int ret;
    uint32_t idx;
    uint32_t TotalCnt;
    T_ACS_PHY_ADDR tPhyAKey;
    T_LOGIC_ADDR_ALLOC tLogAddr;

    printf("  Physical Address       Logical Address\n");
    printf("[Rack:Shelf:Slot:Cpu]  [Module:Unit :Node]\n");
    TotalCnt = m_tNodePool.getTotalInstNum();
    for(idx = 0; idx < TotalCnt; idx++)
    {
        ret = m_tNodePool.getInstByIndex(idx, tLogAddr);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            printf("showLAPool get LA idx:%d, Failed ret=%d\n", idx, ret);
            return;
        }
        ret = m_tNodePool.getKey1(idx, tPhyAKey);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            printf("showLAPool get PA idx:%d, Failed ret=%d\n", idx, ret);
            return;
        }
        printf("[%-4d:%-5d:%-4d:%-3d]  [%-6d:%-5d:%-4d]\n", 
        	tPhyAKey.ucRackId, tPhyAKey.ucShelfId, tPhyAKey.ucSlotId, tPhyAKey.ucCpuId,
        	tLogAddr.wModule, tLogAddr.wUnit, tLogAddr.wNodeID);
    }
    printf("Total Count:%u\n", TotalCnt);
    return;
}

void CNodeMgr::showGeneralStt()
{
    printf("Node Manager is %s on this node.\n", m_isMgrWorking ? "working":"NOT working");
    if(!m_isMgrWorking)
    {
        return;
    }

    printf("QueueIDtobeAllocate:    %-10u  SyncSequence:           %-10u\n", m_dwQueueClntCnt, m_dwSyncSeq);
    printf("MultiCastClientCount:   %-10u  MultiCastTimer:         0x%08x\n", m_dwMultiCastClntCnt, m_MasterMgrMultiCastSyncTimerID);
    printf("SlaveSyncReqTimer:      0x%08x  HBCheckTimer:           0x%08x\n", m_SlaveMgrSyncReqTimerID, m_ClientHBCheckTimerID);
    printf("MasterMSSyncTimer:      0x%08x  MSMgrSyncFlag:          %-10u\n", m_MasterMgrMSSyncTimerID, m_MSMgrSyncFlag);
    printf("ChangOverTimer:         0x%08x  ChangeOverFlag:         %-10u\n", m_ChgOverTimerID, m_dwChgOverFlag);
    printf("IsMateOnline:           %-10s\n", m_bIsMateOnline ? "Yes":"No");
    
    printf("Node Count Statistics:\n");
    printf("Init:                   %-10u  Queueing:               %-10u\n", o_tMgrStt.dwInitClientCnt, o_tMgrStt.dwQingClientCnt);
    printf("Registering:            %-10u  Active:                 %-10u\n", o_tMgrStt.dwRegisteringClientCnt, o_tMgrStt.dwActiveClientCnt);
    printf("Inactive:               %-10u  Total:                  %-10u\n", o_tMgrStt.dwInactiveClientCnt, o_tMgrStt.dwTotalCnt);
    
    printf("Message Statistics:\n");
    printf("QueueApplyReceivedCount:%-10u  QueueAckSendCount:      %-10u\n", o_tMgrStt.dwQApplyRcvCnt, o_tMgrStt.dwQAckSndCnt);
    printf("RegisterReceivedCount:  %-10u  RegisterAckSendCount:   %-10u\n", o_tMgrStt.dwRegRcvCnt, o_tMgrStt.dwRegAckSndCnt);
    printf("HeartBeatReceivedCount: %-10u  ResetSendCount:         %-10u\n", o_tMgrStt.dwHBRcvCnt, o_tMgrStt.dwRstSndCnt);

    printf("Admin Operation Statistics:\n");
    printf("Add:                    %-10u  Remove:                 %-10u\n", o_tMgrStt.dwAdminAdd, o_tMgrStt.dwAdminRemove);
    printf("Block:                  %-10u  Unblock:                %-10u\n", o_tMgrStt.dwAdminBlock, o_tMgrStt.dwAdminUnblock);
    printf("Balance:                %-10u\n", o_tMgrStt.dwAdminBalance);
    
    printf("Event Notify UPL Statistics:\n");
    printf("JoinNotify:             %-10u  JoinNotifyAck:          %-10u\n", o_tMgrStt.dwJoinNotify, o_tMgrStt.dwJoinNotifyAck);
    printf("LeaveNotify:            %-10u  LeaveNotifyAck:         %-10u\n", o_tMgrStt.dwLeaveNotify, o_tMgrStt.dwLeaveNotifyAck);
    printf("BlockNotify:            %-10u  BlockNotifyAck:         %-10u\n", o_tMgrStt.dwBlockNotify, o_tMgrStt.dwBlockNotifyAck);
    printf("UnblockNotify:          %-10u  UnblockNotifyAck:       %-10u\n", o_tMgrStt.dwUnblockNotify, o_tMgrStt.dwUnblockNotifyAck);
    printf("BalanceNotify:          %-10u  BalanceNotifyAck:       %-10u\n", o_tMgrStt.dwBalanceNotify, o_tMgrStt.dwBalanceNotifyAck);
    
    printf("ChangeOver Statistics:\n");
    printf("QApplyRcvCntInChgOver:  %-10u  RegRcvCntInChgOver:     %-10u\n", o_tMgrStt.dwQApplyRcvCntInChgOver, o_tMgrStt.dwRegRcvCntInChgOver);
    printf("HBRcvCntInChgOver:      %-10u  BlockNodeInChgOver:     %-10u\n", o_tMgrStt.dwHBRcvCntInChgOver, o_tMgrStt.dwBlockNodeInChgOver);
    printf("UnblockNodeInChgOver:   %-10u  RemoveNodeInChgOver:    %-10u\n", o_tMgrStt.dwUnblockNodeInChgOver, o_tMgrStt.dwRemoveNodeInChgOver);
    printf("BalanceNodeInChgOver:   %-10u\n", o_tMgrStt.dwBalanceNodeInChgOver);
     
    printf("Error Statistics:\n");
    printf("NodeHBTimeOutCnt:       %-10u  RcvNodeHBTOCnt:         %-10u\n", o_tMgrStt.dwNodeHBTimeOutCnt, o_tMgrStt.dwRcvNodeHBTOCnt);
    printf("NodeNotFound:           %-10u  NodeErrState:           %-10u\n", o_tMgrStt.dwNodeNotFound, o_tMgrStt.dwNodeErrState);
    printf("NodeInfoDiff:           %-10u  MsgSndFailed:           %-10u\n", o_tMgrStt.dwNodeInfoDiff, o_tMgrStt.dwMsgSndFailed);
    printf("MCastMsgFailed:         %-10u  ErrorMsgRcv:            %-10u\n", o_tMgrStt.dwMCastMsgFailed, o_tMgrStt.dwErrorMsgRcv);
    printf("JoinNotifyFailed:       %-10u  LeaveNotifyFailed:      %-10u\n", o_tMgrStt.dwJoinNotifyFailed, o_tMgrStt.dwLeaveNotifyFailed);
    printf("BlockNotifyFailed:      %-10u  UnblockNotifyFailed:    %-10u\n", o_tMgrStt.dwBlockNotifyFailed, o_tMgrStt.dwUnblockNotifyFailed);
    printf("BalanceNotifyFailed:    %-10u\n", o_tMgrStt.dwBalanceNotifyFailed);
    printf("EventNodeNotFound:      %-10u  EventAckNodeNotFound:   %-10u\n", o_tMgrStt.dwEventNodeNotFound, o_tMgrStt.dwEventAckNodeNotFound);
    printf("AdminAddFailed:         %-10u  AdminRemoveFailed:      %-10u\n", o_tMgrStt.dwAdminAddFailed, o_tMgrStt.dwAdminRemoveFailed);
    printf("AdminBlockFailed:       %-10u  AdminUnblockFailed:     %-10u\n", o_tMgrStt.dwAdminBlockFailed, o_tMgrStt.dwAdminUnblockFailed);
    printf("AdminBalanceFailed:     %-10u\n", o_tMgrStt.dwAdminBalanceFailed);
    printf("OpNodeNotFound:         %-10u  AdminOpDup:             %-10u\n", o_tMgrStt.dwAdminOpNodeNotFound, o_tMgrStt.dwAdminOpDup);
	printf("dwErrorPoweronTickCnt:  %-10u\n",o_tMgrStt.dwErrorPoweronTickCnt);
}

void CNodeMgr::showRegStt(T_ZCMS_NODE_REG_STT *pRegStt)
{
	   XOS_ASSERT(pRegStt);
    printf("QueueApplyReceivedCount:%-10u QueueAckSendCount:     %-10u\n", pRegStt->dwQApplyRcvCnt, pRegStt->dwQAckSndCnt);
    printf("RegisterReceivedCount:  %-10u RegisterAckSendCount:  %-10u\n", pRegStt->dwRegRcvCnt, pRegStt->dwRegAckSndCnt);
    printf("HeartBeatReceivedCount: %-10u ResetSendCount:        %-10u\n", pRegStt->dwHBRcvCnt, pRegStt->dwRstSndCnt);
    printf("HeartBeatTimeOutGTExp:  %-10u HeartBeatTimeOutMax:   %-10u\n", pRegStt->dwHBToGtExpect, pRegStt->dwHBToMax);
    printf("JoinNotifyToUPLayer:    %-10u JoinAckFromUPLayer:    %-10u\n", pRegStt->dwUPLJoinNotify, pRegStt->dwUPLJoinAck);
    printf("QuitNotifyToUPLayer:    %-10u QuitAckFromUPLayer:    %-10u\n", pRegStt->dwUPLQuitNotify, pRegStt->dwUPLQuitAck);
    printf("UPLBlockNotify:         %-10u UPLBlockAck:           %-10u\n", pRegStt->dwUPLBlockNotify, pRegStt->dwUPLBlockAck);
    printf("UPLUnblockNotify:       %-10u UPLUnblockAck:         %-10u\n", pRegStt->dwUPLUnblockNotify, pRegStt->dwUPLUnblockAck);
    printf("UPLJoinNotifyFailed:    %-10u UPLQuitNotifyFailed:   %-10u\n", pRegStt->dwUPLJoinNotifyFailed, pRegStt->dwUPLQuitNotifyFailed);
    printf("UPLBlockNotifyFailed:   %-10u UPLUnblockNotifyFailed:%-10u\n", pRegStt->dwUPLBlockNotifyFailed, pRegStt->dwUPLUnblockNotifyFailed);
}

void CNodeMgr::showAllCNodesStt(int NotshowAll)
{
    int ret;
    uint32_t idx = 0;
    uint32_t TotalCnt = 0;
    uint32_t TotalShowNode = 0;
    char *stateStr = NULL;
    char *RouteStr = NULL;
    char *CSvcStateStr = NULL;
    T_ZCMS_NODE_INFO tLinkNInfo;
    
    if(!m_isMgrWorking)
    {
        return;
    }
    
    if(0==NotshowAll)
    {
        printf("\nAll Nodes Statistics:\n");
    }
    else if(1==NotshowAll)
    {
        printf("\nAlive Nodes Statistics:\n");
    }
    else if(2==NotshowAll)
    {
        printf("\nUnblocked Alive Nodes Statistics:\n");
    }
    else
    {
        printf("\nActive Nodes Statistics:\n");
    }
    TotalCnt = m_tAllCNodesInfo.getTotalInstNum();
    while (idx < TotalCnt)
    {
        if(m_tAllCNodesInfo.getInstanceState(idx)!=InstMgr::INST_STATE_ALLOCATED)
        {
            idx++;
            continue;
        }
        ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            idx++;
            continue;
        }

        if(NotshowAll)
        {
            if(NotshowAll==1)
            {
                if((tLinkNInfo.tCNodeData.eLinkState == E_ZCMS_NODE_STATE_INIT || tLinkNInfo.tCNodeData.eLinkState == E_ZCMS_NODE_STATE_INACTIVE)
                  && (tLinkNInfo.tCNodeData.tManageStatus != ZCS_NODE_STATE_BLOCKED))
                {
                    idx++;
                    continue;
                }
            }
            else if(NotshowAll==2)
            {
                if((tLinkNInfo.tCNodeData.eLinkState == E_ZCMS_NODE_STATE_INIT || tLinkNInfo.tCNodeData.eLinkState == E_ZCMS_NODE_STATE_INACTIVE))
                {
                    idx++;
                    continue;
                }
            }
            else
            {
                if(tLinkNInfo.tCNodeData.eLinkState == E_ZCMS_NODE_STATE_ACTIVE)
                {
                    idx++;
                    continue;
                }
            }
        }
        
        if(tLinkNInfo.tCNodeData.tManageStatus==ZCS_NODE_STATE_BLOCKED)
        {
            stateStr="Blocked";
        }
        else if(tLinkNInfo.tCNodeData.tManageStatus==ZCS_NODE_STATE_ACTIVE)
        {
            stateStr="Active";
        }
        else
        {
            stateStr="Inactive";
        }
    
        if(tLinkNInfo.tCNodeData.wRouteType==ZCS_MASTER_BOARD)
        {
            RouteStr="Master";
        }
        else if(tLinkNInfo.tCNodeData.wRouteType==ZCS_SLAVE_BOARD)
        {
            RouteStr="Slave";
        }
        else if(tLinkNInfo.tCNodeData.wRouteType==ZCS_LEFT_BOARD)
        {
            RouteStr="Left";
        }
        else if (tLinkNInfo.tCNodeData.wRouteType==ZCS_RIGHT_BOARD)
        {
            RouteStr="Right";
        }
        else
        {
            RouteStr="Invalid";
        }

        printf("-----------------------\n");
        printf("NodeId:%d, ModuleId:%d, State:%s, RouteType:%s\n", 
        	      tLinkNInfo.tCNodeData.wNodeId, tLinkNInfo.tCNodeData.wModule, stateStr, RouteStr);
        
        printf("Physical Address, Rack:Shelf:Slot:Cpu %d:%d:%d:%d\n", 
        	tLinkNInfo.tCNodeData.tPhyAddrInfo.ucRackId, tLinkNInfo.tCNodeData.tPhyAddrInfo.ucShelfId,
        	tLinkNInfo.tCNodeData.tPhyAddrInfo.ucSlotId, tLinkNInfo.tCNodeData.tPhyAddrInfo.ucCpuId);
        
        if(tLinkNInfo.tCNodeData.wCSvcState==ZCS_JOB_STATE_MNODE_WORK)
        {
            CSvcStateStr="Center Master";
        } 
        else if(tLinkNInfo.tCNodeData.wCSvcState==ZCS_JOB_STATE_MNODE_SLAVE)
        {
            CSvcStateStr="Center Slave";
        }
        else if(tLinkNInfo.tCNodeData.wCSvcState==ZCS_JOB_STATE_SNODE_WORK)
        {
        	   CSvcStateStr="Service Master";
        }
        else
        {
        	   XOS_ASSERT(tLinkNInfo.tCNodeData.wCSvcState==ZCS_JOB_STATE_INVALID);
            CSvcStateStr="Invalid";
        }
        
        printf("LinkState:%s, HeartBeatTimeOutCount:%u, QueueID:%u, ServiceState:%s\n", 
        	           pNodeLinkState[tLinkNInfo.tCNodeData.eLinkState], tLinkNInfo.tCNodeData.dwNodeHBeatTOCnt, tLinkNInfo.tCNodeData.dwQueueID, CSvcStateStr);
        
        printf("Current Statistics:\n");
    	   showRegStt(&tLinkNInfo.tCNodeStt.tCurStt);
    	   printf("\nLasttime Statistics:\n");
    	   showRegStt(&tLinkNInfo.tCNodeStt.tLastStt);
    	   printf("\nHistory Statistics:\n");
    	   showRegStt(&tLinkNInfo.tCNodeStt.tHistoryStt);
    	   TotalShowNode++;
        idx++;
    }
    printf("==========Total Show Nodes:%u==========\n", TotalShowNode);
    return;
}

void CNodeMgr::showNodeEventSub()
{
    int ret;
    uint32_t idx = 0;
    uint32_t count = 0;
    uint32_t TotalCnt = 0;
    T_Node_Event_Register tRegister;

    printf("All Node Event Subscribers:\n");
    TotalCnt = m_tNodeEventSubscriber.getTotalInstNum();
    while (idx < TotalCnt)
    {
        if(m_tNodeEventSubscriber.getInstanceState(idx)!=InstMgr::INST_STATE_ALLOCATED)
        {
            idx++;
            continue;
        }
        ret = m_tNodeEventSubscriber.getInstByIndex(idx, tRegister);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            idx++;
            continue;
        }

        printf("No.%-10u               Jno:        0x%-10x        NeedAck:%d\n", count+1, tRegister.dwJNO, tRegister.bNeedAck);
        printf("CurEventSnd:    %-10d  CurEventAcked:%-10d\n", tRegister.bIsCurEventSnd, tRegister.bIsCurEventAcked);
        printf("NotifySnd:      %-10u  AckRcv:       %-10u\n", tRegister.dwNotifySnd, tRegister.dwAckRcv);
        printf("NotifySndFailed:%-10u\n", tRegister.dwNotifySndFailed);

        idx++;
        count++;
    }
    printf("Total Node Event Subscriber counts: %u\n", count);
    return;
}

void CNodeMgr::showNodeEventQueue()
{
    NODEEVENTINSTIT it;
    uint32_t count=0;

    printf("Current Node Event Queue:\n");
    it = m_tNodeEventQueue.begin();
    while(it != m_tNodeEventQueue.end())
    {
        printf("No.%-10u NodeID:%-5d event:%-5d\n", count+1, it->first.node_id, it->first.node_op);
        ++it;
        count++;
    }

    printf("Total Node Event Subscriber counts: %u\n", count);
    return;
}

void CNodeMgr::constrNodeDataSyncInfo(T_ZCMS_NODE_SYNC_INFO &tNodeSync)
{
	   int ret;
    uint32_t TotalCnt;
    uint32_t idx = 0;
    uint16_t DataNum = 0;
    T_ZCMS_NODE_INFO tLinkNInfo;

    memset(&tNodeSync,0, sizeof(T_ZCMS_NODE_SYNC_INFO));
    
    TotalCnt = m_tAllCNodesInfo.getTotalInstNum();
    while(idx < TotalCnt)
    {
        if(m_tAllCNodesInfo.getInstanceState(idx)!=InstMgr::INST_STATE_ALLOCATED)
        {
            idx++;
            continue;
        }
        ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            idx++;
            continue;
        }

        tNodeSync.tNodeData[DataNum] = tLinkNInfo.tCNodeData;
        DataNum++;
        idx++;
    }

    tNodeSync.tNodeDataNum = DataNum;
    if(m_dwSyncSeq == ZCMS_INVALID_SYNC_SEQ)
    {
    	   m_dwSyncSeq++;
    }
    tNodeSync.dwSyncSeq = m_dwSyncSeq;
    return;
}

void CNodeMgr::onSaveNodeDataSyncInfo(void *data, uint32_t len)
{
    uint32_t SyncTimes = 0;
	   int ret;
    uint32_t idx = 0;
    uint16_t DataNum = 0;
    uint16_t wNodeId;
    T_ZCMS_NODE_INFO tLinkNInfo;
    uint32_t dwTotalCnt;
    uint32_t dwFound = 0;
    T_ZCMS_NODE_SYNC_INFO *ptNodeSync = (T_ZCMS_NODE_SYNC_INFO *)data;

    XOS_ASSERT(data);
    XOS_ASSERT(sizeof(T_ZCMS_NODE_SYNC_INFO) == len);
    /* �ȱ�֤����ͬ������һ�£������󲻻������*/
    m_dwSyncSeq = ptNodeSync->dwSyncSeq;
    
    SyncTimes = ptNodeSync->dwSyncSeq;
    while(DataNum < ptNodeSync->tNodeDataNum)
    {
    	   idx = 0;
    	   wNodeId = ptNodeSync->tNodeData[DataNum].wNodeId;

    	   if(findConfClientNode(wNodeId, idx)!=RESULT_ZENIC_SUCCESS)
    	   {
            if(initNodeInfo(wNodeId)!=RESULT_ZENIC_SUCCESS)
            {
                ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,
                	                "onSaveNodeDataSyncInfo initNodeInfo NodeID[%d], Failed\n", wNodeId);
                DataNum++;
                continue;
            }
            else if(findConfClientNode(wNodeId, idx)!=RESULT_ZENIC_SUCCESS)
            {
                ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,
                	                "onSaveNodeDataSyncInfo findConfClientNode NodeID[%d], Failed\n", wNodeId);
                DataNum++;
                continue;
            }
    	   }
    	   
        ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,
            	                "onSaveNodeDataSyncInfo m_tAllCNodesInfo.getInstByKey1 idx:%d, Failed ret=%d\n", 
            	                idx, ret);
            DataNum++;
            continue;
        }
        if(tLinkNInfo.tCNodeData.eLinkState == E_ZCMS_NODE_STATE_INIT)
        {
            o_tMgrStt.dwInitClientCnt--;
        }
        else if(tLinkNInfo.tCNodeData.eLinkState == E_ZCMS_NODE_STATE_QUEUEING)
        {
            o_tMgrStt.dwQingClientCnt--;
            decreaseQingClientCnt();
        }
        else if(tLinkNInfo.tCNodeData.eLinkState == E_ZCMS_NODE_STATE_REGISTERING)
        {
            o_tMgrStt.dwRegisteringClientCnt--;
            decreaseQingClientCnt();
        }
        else if(tLinkNInfo.tCNodeData.eLinkState == E_ZCMS_NODE_STATE_ACTIVE)
        {
            o_tMgrStt.dwActiveClientCnt--;
            removeMultiCastClient(wNodeId);
        }
        else
        {
            o_tMgrStt.dwInactiveClientCnt--;
        }
        o_tMgrStt.dwTotalCnt--;

        tLinkNInfo.tCNodeData = ptNodeSync->tNodeData[DataNum];
        tLinkNInfo.dwSyncSeq = SyncTimes;
        ret = m_tAllCNodesInfo.setInstByIndex(idx, tLinkNInfo);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,
            	               "onSaveNodeDataSyncInfo m_tAllCNodesInfo.setInstByIndex insert idx:%d, Failed ret=%d\n", 
            	                idx, ret);
            DataNum++;
            continue;
        }
        if(ptNodeSync->tNodeData[DataNum].eLinkState == E_ZCMS_NODE_STATE_INIT)
        {
            o_tMgrStt.dwInitClientCnt++;
        }
        else if(ptNodeSync->tNodeData[DataNum].eLinkState == E_ZCMS_NODE_STATE_QUEUEING)
        {
            o_tMgrStt.dwQingClientCnt++;
            increaseQingClientCnt();
        }
        else if(ptNodeSync->tNodeData[DataNum].eLinkState == E_ZCMS_NODE_STATE_REGISTERING)
        {
            o_tMgrStt.dwRegisteringClientCnt++;
            increaseQingClientCnt();
        }
        else if(ptNodeSync->tNodeData[DataNum].eLinkState == E_ZCMS_NODE_STATE_ACTIVE)
        {
            o_tMgrStt.dwActiveClientCnt++;
            addMultiCastClient(wNodeId);
        }
        else
        {
            o_tMgrStt.dwInactiveClientCnt++;
        }
        o_tMgrStt.dwTotalCnt++;
        DataNum++; 
    }

    idx = 0;
    dwTotalCnt = m_tAllCNodesInfo.getTotalInstNum();
    while (idx < dwTotalCnt)
    {
    	   dwFound = 0;
        if(m_tAllCNodesInfo.getInstanceState(idx)!=InstMgr::INST_STATE_ALLOCATED)
        {
            idx++;
            continue;
        }
        
        ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            idx++;
            continue;
        }

        if(tLinkNInfo.dwSyncSeq != SyncTimes)
        {
            if(tLinkNInfo.tCNodeData.eLinkState == E_ZCMS_NODE_STATE_INIT)
            {
                o_tMgrStt.dwInitClientCnt--;
            }
            else if(tLinkNInfo.tCNodeData.eLinkState == E_ZCMS_NODE_STATE_QUEUEING)
            {
                o_tMgrStt.dwQingClientCnt--;
                decreaseQingClientCnt();
            }
            else if(tLinkNInfo.tCNodeData.eLinkState == E_ZCMS_NODE_STATE_REGISTERING)
            {
                o_tMgrStt.dwRegisteringClientCnt--;
                decreaseQingClientCnt();
            }
            else if(tLinkNInfo.tCNodeData.eLinkState == E_ZCMS_NODE_STATE_ACTIVE)
            {
                o_tMgrStt.dwActiveClientCnt--;
                removeMultiCastClient(tLinkNInfo.tCNodeData.wNodeId);
            }
            else
            {
                o_tMgrStt.dwInactiveClientCnt--;
            }
    
            clearCNodeInfo(idx);
            o_tMgrStt.dwInactiveClientCnt++;
            
            ret = m_tAllCNodesInfo.releaseInst(idx);
            if(ret!=InstMgr::RESULT_INST_SUCCESS)
            {
                o_tMgrStt.dwAdminRemoveFailed++;
                idx++;
                continue;
            }

            o_tMgrStt.dwInactiveClientCnt--;
            o_tMgrStt.dwTotalCnt--;
        }

        idx++;
    }
    
    writeShmActiveNodes();
    return;
}

void CNodeMgr::constrNodeEventSyncInfo(T_ZCMS_NODE_EVENT_SYNC &tEventSync)
{
    NODEEVENTINSTIT it;
    uint32_t count=0;
    uint32_t TotalSubCnt;
    uint32_t idx = 0;
    uint32_t DataNum = 0;
    T_Node_Event_Register tSubscriber;
    
    memset(&tEventSync,0, sizeof(T_ZCMS_NODE_EVENT_SYNC));
    
    it = m_tNodeEventQueue.begin();
    while(it != m_tNodeEventQueue.end())
    {
    	   /*  ����ڵ����Ϣ��ͬ���������������ýڵ��Լ��������߼������� */
     	  tEventSync.tEventUnit[count].node_id=it->first.node_id;
        tEventSync.tEventUnit[count].node_op=it->first.node_op;
    	   ++it;
        count++;
    }
    tEventSync.dwEventNum = count;

    TotalSubCnt = m_tNodeEventSubscriber.getTotalInstNum();
    while(idx < TotalSubCnt)
    {
        if(m_tNodeEventSubscriber.getInstanceState(idx)!=InstMgr::INST_STATE_ALLOCATED)
        {
            idx++;
            continue;
        }

        if(m_tNodeEventSubscriber.getInstByIndex(idx, tSubscriber)!=InstMgr::RESULT_INST_SUCCESS)
        {
            idx++;
            continue;
        }

        tEventSync.tEventSubscriber[DataNum].dwRegJNO = tSubscriber.dwJNO;
        tEventSync.tEventSubscriber[DataNum].bNeedAck = tSubscriber.bNeedAck;
        tEventSync.tEventSubscriber[DataNum].bIsCurEventSnd = tSubscriber.bIsCurEventSnd;
        tEventSync.tEventSubscriber[DataNum].bIsCurEventAcked = tSubscriber.bIsCurEventAcked;
        
        DataNum++;
        idx++;
    }
    tEventSync.dwSubscriberNum = DataNum;
    
    return;
}

void CNodeMgr::onSaveNodeEventSyncInfo(void *data, uint32_t len)
{
    uint32_t count=0;
    T_ZCMS_NODE_OP_EVENT_KEY tKeyEvent;
    T_ZCMS_NODE_OP_EVENT tEvent;
    uint32_t idx = 0;
    uint32_t DataNum = 0;
    T_Node_Event_Register tRegister;
    int ret;
    
    T_ZCMS_NODE_EVENT_SYNC *ptEventSync = (T_ZCMS_NODE_EVENT_SYNC *)data;

    XOS_ASSERT(data);
    XOS_ASSERT(sizeof(T_ZCMS_NODE_EVENT_SYNC) == len);
    XOS_ASSERT(ptEventSync->dwEventNum<=ZCMS_MAX_NODE_EVENT_NUM);

    m_tNodeEventQueue.clear();
    
    while(count < ptEventSync->dwEventNum)
    {
        tKeyEvent.node_id = ptEventSync->tEventUnit[count].node_id;
        tKeyEvent.node_op = ptEventSync->tEventUnit[count].node_op;
        tEvent.wNodeId = ptEventSync->tEventUnit[count].node_id;
        tEvent.tNodeOp = ptEventSync->tEventUnit[count].node_op;
        m_tNodeEventQueue.insert(std::pair<T_ZCMS_NODE_OP_EVENT_KEY, T_ZCMS_NODE_OP_EVENT>(tKeyEvent, tEvent));
        count++;
    }

    while(DataNum < ptEventSync->dwSubscriberNum)
    {
    	   ret = m_tNodeEventSubscriber.getInstByKey1(ptEventSync->tEventSubscriber[DataNum].dwRegJNO, tRegister, idx);
        if(ret==InstMgr::RESULT_INST_SUCCESS)
        {
            XOS_ASSERT(tRegister.dwJNO==ptEventSync->tEventSubscriber[DataNum].dwRegJNO);
            XOS_ASSERT(tRegister.bNeedAck==ptEventSync->tEventSubscriber[DataNum].bNeedAck);
            tRegister.bIsCurEventSnd = ptEventSync->tEventSubscriber[DataNum].bIsCurEventSnd;
            tRegister.bIsCurEventAcked = ptEventSync->tEventSubscriber[DataNum].bIsCurEventAcked;
            ret = m_tNodeEventSubscriber.setInstByIndex(idx, tRegister);
            if(ret!=InstMgr::RESULT_INST_SUCCESS)
            {
                ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"onSaveNodeEventSyncInfo setInstByIndex [Jno:0x%x] Failed ret=%d\n", 
                	                ptEventSync->tEventSubscriber[DataNum].dwRegJNO, ret);
            }
        }
        else
        {
            ret = m_tNodeEventSubscriber.allocInstByKey1(ptEventSync->tEventSubscriber[DataNum].dwRegJNO, idx);
            if(ret!=InstMgr::RESULT_INST_SUCCESS)
            {
                ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"onSaveNodeEventSyncInfo allocInstByKey1 [Jno:0x%x] Failed ret=%d\n", 
                	                ptEventSync->tEventSubscriber[DataNum].dwRegJNO, ret);
            }
            else
            {
            	   memset(&tRegister, 0, sizeof(tRegister));
                tRegister.dwJNO=ptEventSync->tEventSubscriber[DataNum].dwRegJNO;
                tRegister.bNeedAck=ptEventSync->tEventSubscriber[DataNum].bNeedAck;
                tRegister.bIsCurEventSnd = ptEventSync->tEventSubscriber[DataNum].bIsCurEventSnd;
                tRegister.bIsCurEventAcked = ptEventSync->tEventSubscriber[DataNum].bIsCurEventAcked;
                ret = m_tNodeEventSubscriber.setInstByIndex(idx, tRegister);
                if(ret!=InstMgr::RESULT_INST_SUCCESS)
                {
                    ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"onSaveNodeEventSyncInfo allocInstByKey1 and setInstByIndex [Jno:0x%x] Failed ret=%d\n", 
                    	                ptEventSync->tEventSubscriber[DataNum].dwRegJNO, ret);
                }
            }
        }
        
        DataNum++;
    }

    return;
}

void CNodeMgr::onZcsMSSyncReq()
{
	   XOS_STATUS xos_ret;
	   
	   XOS_ASSERT(ZCS_JOB_STATE_MNODE_SLAVE == m_pZcmsMgr->m_wSvcState);

    xos_ret = XOS_SendAsynMsg(EV_SYS_ZCMS_MSSYNC_REQ, (uint8_t *)NULL, (uint16_t)0,
    	                                                   XOS_MSG_VER0, XOS_MSG_LOW, (void *)&m_MateJID);

    if (XOS_SUCCESS != xos_ret)
    {
        o_tMgrStt.dwMsgSndFailed++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "onZcsMSSyncReq Snd EV_SYS_ZCMS_MSSYNC_REQ To MasterNodeMgr JID[Jno:0x%x,Module:%d,RouteType:%d] XOS_SendAsynMsg Failed:%d!\n",
        	      m_MateJID.dwJno, m_MateJID.wModule, m_MateJID.ucRouteType, xos_ret);
        return;
    }

    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onZcsMSSyncReq Snd EV_SYS_ZCMS_MSSYNC_REQ To MasterNodeMgr Success!\n");
    
    m_SlaveMgrSyncReqTimerID = zcms_set_timer(EV_SYS_ZCMS_SLAVEMGR_SYNC_REQ_TIMER, ZCMS_SLAVEMGR_SYNC_REQ_PERIOD, PARAM_NULL);
}

void CNodeMgr::onZcsMSSync(uint32_t SyncType)
{
	   XOS_STATUS xos_ret;
	   
	   XOS_ASSERT(ZCS_JOB_STATE_MNODE_WORK == m_pZcmsMgr->m_wSvcState);

    if(!isMateOnlineState())
    {
        ZCS_LOG(ZCS_LOG_DEBUG, ZCS_LOG_MOD_ZCMS, "onZcsMSSync Find No Mate!\n");
        return;
    }

    if(!((SYNC_CONFIG|SYNC_NODES|SYNC_EVENTS)&SyncType) || ((~(SYNC_CONFIG|SYNC_NODES|SYNC_EVENTS))&SyncType))
    {
    	   ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "onZcsMSSync SyncType:0x%x Error!\n", SyncType);
        XOS_ASSERT(0);
        return;
    }
    
    m_MSMgrSyncFlag |= SyncType;

    memset(&stSyncData, 0, sizeof(stSyncData));
    
    stSyncData.dwCurMgrPoweronTick = this->getMgrPowerOnTick();

    if(SYNC_CONFIG & SyncType)
    {
    	   stSyncData.dwSyncType |= ZCMS_SYNC_TYPE_CONFIG;
        constrConfInfo(stSyncData.tConfInfo, m_pConfig);
    }

    if(SYNC_NODES & SyncType)
    {
    	   stSyncData.dwSyncType |= ZCMS_SYNC_TYPE_ACTIVENODE;
        constrNodeDataSyncInfo(stSyncData.tNodeSync);
    }

    if(SYNC_EVENTS & SyncType)
    {
    	   stSyncData.dwSyncType |= ZCMS_SYNC_TYPE_EVENT;
        constrNodeEventSyncInfo(stSyncData.tNodeEvent);
    }
    
    xos_ret = XOS_SendAsynMsg(EV_SYS_ZCMS_MSSYNC, (uint8_t *)&stSyncData, (uint16_t)sizeof(stSyncData),
    	                                                   XOS_MSG_VER0, XOS_MSG_LOW, (void *)&m_MateJID);

    if (XOS_SUCCESS != xos_ret)
    {
        o_tMgrStt.dwMsgSndFailed++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "onZcsMSSync Snd EV_SYS_ZCMS_MSSYNC To SlaverNodeMgr JID[Jno:0x%x,Module:%d,RouteType:%d] XOS_SendAsynMsg Failed:%d!\n",
        	      m_MateJID.dwJno, m_MateJID.wModule, m_MateJID.ucRouteType, xos_ret);
    }
    else
    {
        ZCS_LOG(ZCS_LOG_DEBUG, ZCS_LOG_MOD_ZCMS, "onZcsMSSync Snd EV_SYS_ZCMS_MSSYNC To SlaverNodeMgr Success!\n");
    }
    
    m_MasterMgrMSSyncTimerID = zcms_set_timer(EV_SYS_ZCMS_MASTERMGR_MSSYNC_TIMER, ZCMS_MASTERMGR_MS_SYNC_PERIOD, m_MSMgrSyncFlag);
}

void CNodeMgr::onZcsMSSyncAck(void *pMsg, uint16_t msg_len)
{
	   XOS_STATUS xos_ret;
	   T_EV_ZCMS_DATA_SYNC* ptSyncData = (T_EV_ZCMS_DATA_SYNC*)pMsg;
	   
	   XOS_ASSERT(ZCS_JOB_STATE_MNODE_SLAVE == m_pZcmsMgr->m_wSvcState);
	   
	   if(msg_len != sizeof(T_EV_ZCMS_DATA_SYNC) || pMsg==NULL)
    {
        o_tMgrStt.dwErrorMsgRcv++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, 
        	        "onZcsMSSyncAck rcv Error Msg:length %d should be:%d, pMsg:%p!\n", 
        	        msg_len, sizeof(T_EV_ZCMS_DATA_SYNC), pMsg);
        XOS_ASSERT(0);
        return;
    }
    if(ptSyncData->dwCurMgrPoweronTick != this->getMgrPowerOnTick())
    {
       o_tMgrStt.dwErrorPoweronTickCnt++;
       return ;
    }
    if(ZCMS_SYNC_TYPE_CONFIG & ptSyncData->dwSyncType)
    {
        m_pConfig->onSyncData((void *)&ptSyncData->tConfInfo, sizeof(T_ZCMS_CONFIG_INFO));
    }

    if(ZCMS_SYNC_TYPE_ACTIVENODE & ptSyncData->dwSyncType)
    {
        onSaveNodeDataSyncInfo((void *)&ptSyncData->tNodeSync, sizeof(T_ZCMS_NODE_SYNC_INFO));
        writeShmActiveNodes();
    }

    if(ZCMS_SYNC_TYPE_EVENT & ptSyncData->dwSyncType)
    {
        onSaveNodeEventSyncInfo((void *)&ptSyncData->tNodeEvent, sizeof(T_ZCMS_NODE_EVENT_SYNC));
    }

    xos_ret = XOS_SendAsynMsg(EV_SYS_ZCMS_MSSYNC_ACK, (uint8_t *)NULL, (uint16_t)0,
    	                                                   XOS_MSG_VER0, XOS_MSG_LOW, (void *)&m_MateJID);

    if (XOS_SUCCESS != xos_ret)
    {
        o_tMgrStt.dwMsgSndFailed++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "onZcsMSSyncAck Snd EV_SYS_ZCMS_MSSYNC_ACK To MasterNodeMgr JID[Jno:0x%x,Module:%d,RouteType:%d] XOS_SendAsynMsg Failed:%d!\n",
        	      m_MateJID.dwJno, m_MateJID.wModule, m_MateJID.ucRouteType, xos_ret);
        return;
    }

    ZCS_LOG(ZCS_LOG_DEBUG, ZCS_LOG_MOD_ZCMS, "onZcsMSSyncAck Snd EV_SYS_ZCMS_MSSYNC_ACK To MasterNodeMgr Success!\n");
    
    zcms_cancel_timer(m_SlaveMgrSyncReqTimerID);
}

void CNodeMgr::onZcsHandleMSSyncAck()
{
    zcms_cancel_timer(m_MasterMgrMSSyncTimerID);
    m_MSMgrSyncFlag = 0;
}

void CNodeMgr::constrMultiCastSyncInfo(T_ZCS_NODE_LIST &tNodeSync)
{
	   int ret;
    uint32_t TotalCnt;
    uint32_t idx = 0;
    uint16_t DataNum = 0;
    T_ZCMS_NODE_INFO tLinkNInfo;

    memset(&tNodeSync, 0, sizeof(T_ZCS_NODE_LIST));
    
    TotalCnt = m_tAllCNodesInfo.getTotalInstNum();
    while(idx < TotalCnt)
    {
        if(m_tAllCNodesInfo.getInstanceState(idx)!=InstMgr::INST_STATE_ALLOCATED)
        {
            idx++;
            continue;
        }
        ret = m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            idx++;
            continue;
        }

        tNodeSync.tNodes[DataNum].nodeId = tLinkNInfo.tCNodeData.wNodeId;
        tNodeSync.tNodes[DataNum].moduleId = tLinkNInfo.tCNodeData.wModule;
        tNodeSync.tNodes[DataNum].state = tLinkNInfo.tCNodeData.tManageStatus;
        tNodeSync.tNodes[DataNum].route_type = tLinkNInfo.tCNodeData.wRouteType;
	
        DataNum++;
        idx++;
    }

    tNodeSync.node_num = DataNum;
    return;
}

void CNodeMgr::onZcsMultiCastSync()
{
	   XOS_STATUS xos_ret;
	   uint32_t dwZcmsJNO = XOS_ConstructJNO(ZCS_JOB_TYPE_ZCMS, 1);
	   
	   XOS_ASSERT(ZCS_JOB_STATE_MNODE_WORK == m_pZcmsMgr->m_wSvcState);

    memset(&stMultiSyncData, 0, sizeof(stMultiSyncData));
    
    stMultiSyncData.dwCurMgrPoweronTick = m_pZcmsMgr->getSelfPowerOnTick();
    stMultiSyncData.dwSyncSeq = m_dwSyncSeq;
    constrMultiCastSyncInfo(stMultiSyncData.tMultiNodeSync);

    if(0 == getMultiCastClientCnt())
    {
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onZcsMultiCastSync Find No Group Member!\n");
        return;
    }

    xos_ret = XOS_MulticastMsg(dwZcmsJNO, ZCMS_MULTICAST_GROUPID, EV_SYS_ZCMS_MULTISYNC,
                         (uint8_t *)&stMultiSyncData, (uint16_t)sizeof(stMultiSyncData), XOS_MSG_VER0, XOS_MSG_LOW);
    if (XOS_SUCCESS != xos_ret)
    {
        o_tMgrStt.dwMCastMsgFailed++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "onZcsMultiCastSync Snd EV_SYS_ZCMS_MULTISYNC Failed:%d!\n", xos_ret);
        return;
    }

    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onZcsMultiCastSync Snd EV_SYS_ZCMS_MULTISYNC To Group Success!\n");
    m_MasterMgrMultiCastSyncTimerID = zcms_set_timer(EV_SYS_ZCMS_MASTERMGR_MULTICAST_TIMER, ZCMS_MASTERMGR_MULTICAST_PERIOD, PARAM_NULL);
    return;
}

void CNodeMgr::onHandleMultiCastSyncAck(void *pMsg, uint16_t msg_len)
{
    T_EV_ZCMS_MULTICAST_ACK *pAck = (T_EV_ZCMS_MULTICAST_ACK *)pMsg;

    if(sizeof(T_EV_ZCMS_MULTICAST_ACK) != msg_len || pMsg==NULL)
    {
        o_tMgrStt.dwErrorMsgRcv++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, 
        	        "onHandleMultiCastSyncAck rcv Error Msg:length %d should be:%d, pMsg:%p!\n", 
        	        msg_len, sizeof(T_EV_ZCMS_MULTICAST_ACK), pMsg);
        XOS_ASSERT(0);
        return;
    }
    
	   ZCS_LOG(ZCS_LOG_DEBUG, ZCS_LOG_MOD_ZCMS, 
	   	           "onHandleMultiCastSyncAck Rcv EV_SYS_ZCMS_MULTISYNC_ACK, NodeID[%d], seq:%u!\n", pAck->wNodeID, pAck->dwSeqAcked);

    if(pAck->dwCurMgrPoweronTick !=  m_pZcmsMgr->getSelfPowerOnTick())
    {
       o_tMgrStt.dwErrorPoweronTickCnt++;
       return ;
    }
    updateMultiCastClientAckSeq(pAck->wNodeID, pAck->dwSeqAcked);

    if(checkMultiCastAckedByAllClients())
    {
        zcms_cancel_timer(m_MasterMgrMultiCastSyncTimerID);
    }
    
    return;
}

void CNodeMgr::onNodeAdminManage(void *pMsg, uint16_t msg_len)
{
    T_EV_NODE_MGR *tNodeReq = (T_EV_NODE_MGR *)pMsg;
    ZENIC_RESULT ret;
    uint32_t idx;
    	
    if(sizeof(T_EV_NODE_MGR) != msg_len || pMsg==NULL)
    {
        o_tMgrStt.dwErrorMsgRcv++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, 
        	        "onNodeAdminManage rcv Error Msg:length %d should be:%d, pMsg:%p!\n", 
        	        msg_len, sizeof(T_EV_NODE_MGR), pMsg);
        XOS_ASSERT(0);
        return;
    }

    XOS_ASSERT((tNodeReq->op == ZCS_NODE_MGR_ADD)
    	         || (tNodeReq->op == ZCS_NODE_MGR_REMOVE)
    	         || (tNodeReq->op == ZCS_NODE_MGR_BLOCK)
    	         || (tNodeReq->op == ZCS_NODE_MGR_UNBLOCK)
    	         || (tNodeReq->op == ZCS_NODE_MGR_BALANCE) );
	   ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onNodeStateManage Rcv EV_SYS_ZCS_NODE_MGR, NodeID[%d], op:%d[%s]!\n", 
	   	                     tNodeReq->node_id, tNodeReq->op, zcmsAdminOpToStr(tNodeReq->op));

    /*��������·�ɱ������طֲ�*/
    if( (tNodeReq->op == ZCS_NODE_MGR_BALANCE) )
    {
        onNodeAdminbBalance(tNodeReq->node_id);
        return;
    }

    ret = findConfClientNode(tNodeReq->node_id, idx);
    if(ret != RESULT_ZENIC_SUCCESS)
    {
        if(tNodeReq->op == ZCS_NODE_MGR_ADD)
        {
            onNodeAdminAdd(tNodeReq->node_id);
        }
        else
        {
        	   o_tMgrStt.dwAdminOpNodeNotFound++;
	           ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onNodeStateManage findConfClientNode NodeID[%d], op:%d[%s] NOT exist!\n", 
	   	                     tNodeReq->node_id, tNodeReq->op, zcmsAdminOpToStr(tNodeReq->op));
        }
    }
    else
    {
        if(tNodeReq->op == ZCS_NODE_MGR_BLOCK)
        {
            onNodeAdminBlock(tNodeReq->node_id);
        }
        else if(tNodeReq->op == ZCS_NODE_MGR_UNBLOCK)
        {
            onNodeAdminUnblock(tNodeReq->node_id);
        }
        else if(tNodeReq->op == ZCS_NODE_MGR_REMOVE)
        {
            onNodeAdminRemove(tNodeReq->node_id);
        }
        else
        {
        	   o_tMgrStt.dwAdminOpDup++;
        	   XOS_ASSERT(tNodeReq->op == ZCS_NODE_MGR_ADD);
	           ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onNodeStateManage add NodeID[%d], op:%d[%s] already exist!\n", 
	   	                     tNodeReq->node_id, tNodeReq->op, zcmsAdminOpToStr(tNodeReq->op));
        }
    }
 
    return;
}

ZENIC_RESULT CNodeMgr::onNodeAdminbBalance(uint16_t node_id)
{
    if(isChangingOver())
    {
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onNodeAdminBalance NodeID[%d] Mgr isChangingOver, ignore!\n", node_id);
        o_tMgrStt.dwBalanceNodeInChgOver++;
        return ERROR_TIME_OUT;
    }

    insertNodeEvent(node_id, EV_ZCS_NODE_BALANCE);//����ڵ��¼�������
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onNodeAdminbBalance insertNodeEvent NodeID[%d]  Success!\n", node_id);

    o_tMgrStt.dwAdminBalance++;
    
    onZcsMSSync(SYNC_EVENTS);
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::onNodeAdminAdd(uint16_t node_id)
{
    ZENIC_RESULT zenic_ret;
    
    zenic_ret = initNodeInfo(node_id);
    if(zenic_ret != RESULT_ZENIC_SUCCESS)
    {
    	   o_tMgrStt.dwAdminAddFailed++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"onNodeAdminAdd initNodeInfo NodeID[%d] Failed ret=%d\n", 
        	                node_id, zenic_ret);
        return ERROR_COMMON_ERROR;
    }
    
    zenic_ret = m_pConfig->addConfNode(node_id);
    if(zenic_ret != RESULT_ZENIC_SUCCESS)
    {
    	   o_tMgrStt.dwAdminAddFailed++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"onNodeAdminAdd addConfNode NodeID[%d] Failed ret=%d\n", 
        	                node_id, zenic_ret);
        return ERROR_COMMON_ERROR;
    }
    
    o_tMgrStt.dwAdminAdd++;
    	
    ++m_dwSyncSeq;
    onZcsMSSync(SYNC_NODES|SYNC_CONFIG);
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::onNodeAdminRemove(uint16_t node_id)
{
    int ret;
    ZENIC_RESULT zenic_ret;
    
    if(isChangingOver())
    {
        o_tMgrStt.dwRemoveNodeInChgOver++;
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onNodeAdminRemove NodeID[%d] Mgr isChangingOver, ignore!\n", node_id);
        return ERROR_TIME_OUT;
    }

    sendResetMsgToClient(node_id, E_ZCMS_RESET_UNAUTHORIZED);
	   
    zenic_ret = removeNode(node_id);
    if(zenic_ret != RESULT_ZENIC_SUCCESS)
    {
    	   o_tMgrStt.dwAdminRemoveFailed++;
        return zenic_ret;
    }
    
    ret = m_tAllCNodesInfo.releaseInstByKey1(node_id);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
    	   o_tMgrStt.dwAdminRemoveFailed++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"onNodeAdminRemove m_tAllCNodesInfo.releaseInstByKey1 NodeID[%d] Failed ret=%d\n", 
        	                node_id, ret);
        return ERROR_RECORD_NOT_FOUND;
    }

    writeShmActiveNodes();
    o_tMgrStt.dwInactiveClientCnt--;
    o_tMgrStt.dwTotalCnt--;

    zenic_ret = m_pConfig->removeConfNode(node_id);
    if(zenic_ret != RESULT_ZENIC_SUCCESS)
    {
    	   o_tMgrStt.dwAdminRemoveFailed++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"onNodeAdminRemove removeConfNode NodeID[%d] Failed ret=%d\n", 
        	                node_id, zenic_ret);
        return ERROR_COMMON_ERROR;
    }

    o_tMgrStt.dwAdminRemove++;
    
    ++m_dwSyncSeq;
    onZcsMSSync(SYNC_NODES|SYNC_CONFIG);
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::onNodeAdminBlock(uint16_t node_id)
{
    ZENIC_RESULT zenic_ret;
    uint32_t idx;
    T_ZCS_NODE_STATE state;
    //printf("onNodeAdminBlock: %llu\n", zenic::CHdTimer::getCurTime());
    zenic_ret = findConfClientNode(node_id, idx);
    if(zenic_ret != RESULT_ZENIC_SUCCESS)
    {
    	   o_tMgrStt.dwAdminOpNodeNotFound++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"onNodeAdminBlock findConfClientNode NodeID[%d] Failed ret=%d\n", 
        	                node_id, zenic_ret);
        return ERROR_RECORD_NOT_FOUND;
    }

	   if(isChangingOver())
	   {
	   	   o_tMgrStt.dwBlockNodeInChgOver++;
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onNodeAdminBlock NodeID[%d] Mgr isChangingOver, ignore!\n", node_id);
        return ERROR_TIME_OUT;
	   }
	   
    state = getCNodeManageStatus(idx);
    if(state == ZCS_NODE_STATE_BLOCKED)
    {
    	   o_tMgrStt.dwAdminOpDup++;
        ZCS_LOG(ZCS_LOG_WARN, ZCS_LOG_BUF_ZCMS,"onNodeAdminBlock NodeID[%d] already Blocked!\n", 
                	                node_id);
        return RESULT_ZENIC_SUCCESS;
    }

    if(getTotalNodeNum()==1)
    {
    	   o_tMgrStt.dwAdminBlockFailed++;
        ZCS_LOG(ZCS_LOG_WARN, 
        	    ZCS_LOG_BUF_ZCMS,"onNodeAdminBlock find totally only 1 node, NodeID[%d] cannot be Blocked!\n", node_id);
        return ERROR_NOT_IMPLEMENTED;
    }

    zenic_ret = setCNodeManageStatus(idx, ZCS_NODE_STATE_BLOCKED);
    if(zenic_ret!=RESULT_ZENIC_SUCCESS)
    {
    	   o_tMgrStt.dwAdminBlockFailed++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"onNodeAdminBlock setCNodeManageStatus NodeID[%d] Failed ret=%d\n", 
        	                node_id, zenic_ret);
        return ERROR_INSERT_RECORD_FAIL;
    }

    writeShmActiveNodes();
    if(findNodeEventNotNotified(node_id, EV_ZCS_NODE_UNBLOCKED))
    {
        removeNodeEvent(node_id, EV_ZCS_NODE_UNBLOCKED);     //��ֹ��
    }
    else
    {
        insertNodeEvent(node_id, EV_ZCS_NODE_BLOCKED);
    }

    o_tMgrStt.dwAdminBlock++;
    
    ++m_dwSyncSeq;
    onZcsMSSync(SYNC_NODES|SYNC_EVENTS);
    onZcsMultiCastSync();
    
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::onNodeAdminUnblock(uint16_t node_id)
{
    ZENIC_RESULT zenic_ret;
    uint32_t idx;
    T_ZCS_NODE_STATE state;
    
    zenic_ret = findConfClientNode(node_id, idx);
    if(zenic_ret != RESULT_ZENIC_SUCCESS)
    {
    	   o_tMgrStt.dwNodeNotFound++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"onNodeAdminUnblock findConfClientNode NodeID[%d] Failed ret=%d\n", 
        	                node_id, zenic_ret);
        return ERROR_RECORD_NOT_FOUND;
    }

	   if(isChangingOver())
	   {
	   	   o_tMgrStt.dwUnblockNodeInChgOver++;
        ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "onNodeAdminUnblock NodeID[%d] Mgr isChangingOver, ignore!\n", node_id);
        return ERROR_TIME_OUT;
	   }
	   
    state = getCNodeManageStatus(idx);
    if(state != ZCS_NODE_STATE_BLOCKED)
    {
    	   o_tMgrStt.dwAdminUnblockFailed++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"onNodeAdminUnblock NodeID[%d] with NOT Blocked state=%d\n", 
                	                node_id, state);
        return ERROR_INVALID_PARAM;
    }

    if(getCNodeLinkState(idx)==E_ZCMS_NODE_STATE_ACTIVE || getCNodeLinkState(idx)==E_ZCMS_NODE_STATE_REGISTERING)
    {
        zenic_ret = setCNodeManageStatus(idx, ZCS_NODE_STATE_ACTIVE); 
    }
    else
    {
        zenic_ret = setCNodeManageStatus(idx, ZCS_NODE_STATE_INACTIVE);
    }
    writeShmActiveNodes();
    if(zenic_ret!=RESULT_ZENIC_SUCCESS)
    {
    	   o_tMgrStt.dwAdminUnblockFailed++;
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS,"onNodeAdminUnblock setCNodeManageStatus NodeID[%d] Failed ret=%d\n", 
        	                node_id, zenic_ret);
        return ERROR_INSERT_RECORD_FAIL;
    }

    if(findNodeEventNotNotified(node_id, EV_ZCS_NODE_BLOCKED))
    {
        removeNodeEvent(node_id, EV_ZCS_NODE_BLOCKED);     //��ֹ��
    }
    else
    {
        insertNodeEvent(node_id, EV_ZCS_NODE_UNBLOCKED);
    }

    o_tMgrStt.dwAdminUnblock++;
    
    ++m_dwSyncSeq;
    onZcsMSSync(SYNC_NODES|SYNC_EVENTS);
    onZcsMultiCastSync();
    
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::preChangeOver()
{
	   //printf("preChangeOver: %llu\n", zenic::CHdTimer::getCurTime());
    if(m_isMgrWorking == FALSE)
    {    
        return RESULT_ZENIC_SUCCESS;
    }
    
    m_dwChgOverFlag = ZCMS_PRE_CHANGEOVER;
    if(m_pZcmsMgr->getSelfSvcState()==ZCS_JOB_STATE_MNODE_WORK || m_pZcmsMgr->getSelfSvcState()==ZCS_JOB_STATE_MNODE_SLAVE)
    {
        m_ChgOverTimerID = zcms_set_timer(EV_SYS_ZCMS_CHG_OVER_TIMER, ZCMS_MS_CHGOVER_TIMER_PERIOD, PARAM_NULL);
    }
    return RESULT_ZENIC_SUCCESS;
}

uint32_t CNodeMgr::getChangeOverState()
{
    return m_dwChgOverFlag;
}

bool CNodeMgr::isChangingOver()
{
	   if(m_dwChgOverFlag)
	   {
        return TRUE;
	   }
	   
	   return FALSE;
}

bool CNodeMgr::metSndChgOverAckCondition()
{
	   if(m_pZcmsMgr->getSelfSvcState()==ZCS_JOB_STATE_MNODE_SLAVE)
	   {
	   	   zcms_cancel_timer(m_ChgOverTimerID);
        return TRUE;
	   }
	   
    if(checkNodeEventAckedByAllSubs() && m_MSMgrSyncFlag==0 && zcms_timer_invalid(m_MasterMgrMSSyncTimerID))
    {
    	   zcms_cancel_timer(m_ChgOverTimerID);
        return TRUE;
    }
    
    return FALSE;
}

ZENIC_RESULT CNodeMgr::changeOver()
{    
	   //printf("changeOver: %llu\n", zenic::CHdTimer::getCurTime());
    if(m_isMgrWorking == FALSE)
    {    
        return RESULT_ZENIC_SUCCESS;
    }

    m_dwChgOverFlag = ZCMS_MS_CHANGEOVER;
    if(m_pZcmsMgr->getSelfSvcState()==ZCS_JOB_STATE_MNODE_WORK)
    {
        m_dwQueueClntCnt = ZCMS_QUEUE_ID_NUMBER_FIRST-1;
    	   
        zcms_cancel_timer(m_ClientHBCheckTimerID);
        /* �ͻ��˵�ͬ�����Ե�����֮���ټ���������������ͬ������ͬ������ܵ���*/
        zcms_cancel_timer(m_MasterMgrMultiCastSyncTimerID);
    }
    else
    {
        /*  ����֮ǰ��ͳ�ƣ���ת�������ͳ�� */
    	   saveAllCNodesStt();
        zcms_cancel_timer(m_SlaveMgrSyncReqTimerID);
    }

    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::postChangeOver()
{
	   //printf("postChangeOver: %llu\n", zenic::CHdTimer::getCurTime());
    if(m_isMgrWorking == FALSE)
    {    
        return RESULT_ZENIC_SUCCESS;
    }

    m_dwChgOverFlag = 0;
    ZCS_LOG(ZCS_LOG_INFO, ZCS_LOG_MOD_ZCMS, "CNodeMgr postChangeOver and start working\n");
	   m_pZcmsMgr->switchWorkState();
	   
	   if(m_pZcmsMgr->getSelfSvcState()==ZCS_JOB_STATE_MNODE_WORK)
    {
        notifyUPLNodeEvent(true);
    	   m_ClientHBCheckTimerID = zcms_set_looptimer(EV_SYS_ZCMS_MGR_CHECK_HBTO_TIMER, m_pConfig->getConfKeepAliveHBTimer(), PARAM_NULL);
        /* ���������ͬ��һ��*/
    	   ++m_dwSyncSeq;
        onZcsMSSync(SYNC_ALL);
        onZcsMultiCastSync();
	   }
	   
    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CNodeMgr::shutdown()
{
    int ret;
    
    if(m_isMgrWorking == FALSE)
    {    
        return RESULT_ZENIC_SUCCESS;
    }

    #if 0 /* ���ú�ϵͳ������Ϣ���ܻ���Ҫ���ʣ����ر�*/
    m_pConfig = NULL;
    m_pZcmsMgr = NULL;
    #endif
    
    m_dwQueueClntCnt = ZCMS_QUEUE_ID_NUMBER_FIRST-1;

    // ��������ͳ����Ϣo_tMgrStt������0
    o_tMgrStt.dwInitClientCnt = 0;
    o_tMgrStt.dwQingClientCnt = 0;
    o_tMgrStt.dwRegisteringClientCnt = 0;
    o_tMgrStt.dwActiveClientCnt = 0;
    o_tMgrStt.dwInactiveClientCnt = 0;
    o_tMgrStt.dwTotalCnt = 0;

    ret = m_tAllCNodesInfo.clearAllInstance();
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "CNodeMgr::shutdown m_tAllCNodesInfo.clearAllInstance Failed:%d!\n", ret);
    }
    
    ret = m_tNodePool.clearAllInstance();
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "CNodeMgr::shutdown m_tNodePool.clearAllInstance Failed:%d!\n", ret);
    }

    m_tNodeEventQueue.clear();
    
    ret = m_tNodeEventSubscriber.clearAllInstance();
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "CNodeMgr::shutdown m_tNodeEventSubscriber.clearAllInstance Failed:%d!\n", ret);
    }

    ret = m_tActiveNodes.clearAllInstance();
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_MOD_ZCMS, "CNodeMgr::shutdown m_tActiveNodes.clearAllInstance Failed:%d!\n", ret);
    }
    
    zcms_cancel_timer(m_ClientHBCheckTimerID);
    zcms_cancel_timer(m_SlaveMgrSyncReqTimerID);
    zcms_cancel_timer(m_MasterMgrMSSyncTimerID);
    zcms_cancel_timer(m_MasterMgrMultiCastSyncTimerID);
    zcms_cancel_timer(m_ChgOverTimerID);
    m_dwChgOverFlag = 0;
    m_MSMgrSyncFlag = 0;
    
    m_isMgrWorking = FALSE;
    return RESULT_ZENIC_SUCCESS;
}
CNodeMgr::~CNodeMgr() {
    // TODO Auto-generated destructor stub
}

