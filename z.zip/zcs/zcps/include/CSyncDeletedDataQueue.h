/*
 * CSyncDeletedDataQueue.h
 *
 *  Created on: 2014-9-17
 *      Author: wangjun
 */

#ifndef CSYNCDELETEDDATAQUEUE_H_
#define CSYNCDELETEDDATAQUEUE_H_

class CSyncDeletedDataQueue {
public:
    CSyncDeletedDataQueue();
    bool OnScanData();
    virtual ~CSyncDeletedDataQueue();
};

#endif /* CSYNCDELETEDDATAQUEUE_H_ */
