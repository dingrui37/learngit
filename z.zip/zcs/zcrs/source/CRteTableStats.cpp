/*
 * CRteTableStats.cpp
 *
 *  Created on: 2014-9-12
 *      Author: wangjun
 */

#include "CRteTableStats.h"
#include <stdio.h>

CRteTableStats::CRteTableStats()
    : m_seg_num(0), m_backup_copy(0), m_real_backup_copy(0)
{
    memset(&m_to_be_changed, 0, sizeof(m_to_be_changed));
}

/*���ؼ������ٵĽڵ㣬�����ȣ��򷵻�node_id*/
uint16_t CRteTableStats::min(E_RTE_STATS_TYPE type, uint16_t node_id,const T_DHT_NODES_GROUP &exclude_node_id)
{
    uint16_t min_count=0xFFFF;
    uint16_t min_node=DHT_INVALID_NODE_ID;
    uint16_t node_count=0xFFFF;
    uint16_t count1;
    STATS_IT it;

    for(it=m_table_stats.begin();it!=m_table_stats.end();++it)
    {

        switch(type)
        {
        case E_RTE_STATS_MASTER:
                count1=it->second.master_counter;
                break;
            case E_RTE_STATS_BACKUP1:
                count1=it->second.backup1_counter;
                break;
            case E_RTE_STATS_BACKUP2:
                count1=it->second.backup2_counter;
                break;
            default:
                return DHT_INVALID_NODE_ID;
                break;
        }
        if(count1<min_count && !isInNodesGrp(it->first,exclude_node_id))
        {
            min_count = count1;
            min_node = it->first;
        }
        if(it->first==node_id)
        {
            node_count = count1;
        }
    }

    if(node_id==DHT_INVALID_NODE_ID)
        return min_node;
    else
        return node_count<=min_count?node_id:min_node;
}

/*��ָ���ڵ���м���*/
void CRteTableStats::increase(E_RTE_STATS_TYPE type, uint16_t node_id)
{
    STATS_IT it;
    it = m_table_stats.find(node_id);

    if(it==m_table_stats.end())
        return;
    switch(type)
    {
    case E_RTE_STATS_MASTER:
        it->second.master_counter++;
        break;
    case E_RTE_STATS_BACKUP1:
        it->second.backup1_counter++;
        break;
    case E_RTE_STATS_BACKUP2:
        it->second.backup2_counter++;
        break;
    default:
		break;
    }
}

void CRteTableStats::decrease(E_RTE_STATS_TYPE type, uint16_t node_id)
{
    STATS_IT it;
    it = m_table_stats.find(node_id);

    if(it==m_table_stats.end())
        return;
    switch(type)
    {
    case E_RTE_STATS_MASTER:
        if(it->second.master_counter>0)
            it->second.master_counter--;
        break;
    case E_RTE_STATS_BACKUP1:
        if(it->second.backup1_counter>0)
                    it->second.backup1_counter--;
        break;
    case E_RTE_STATS_BACKUP2:
        if(it->second.backup2_counter>0)
                    it->second.backup2_counter--;
        break;
    default:
		break;
    }
}

ZENIC_RESULT CRteTableStats::addNode(uint16_t node_id)
{
    T_RTE_STATS tStats;
    uint16_t prev_nodes_num = m_table_stats.size();
    uint16_t cur_nodes_num;

    m_to_be_changed.backup1_counter=m_to_be_changed.backup2_counter=0;
    memset(&tStats,0,sizeof(tStats));
    m_table_stats.insert(std::make_pair(node_id,tStats));
    cur_nodes_num = m_table_stats.size();
    if(prev_nodes_num==0)
    {
        m_to_be_changed.master_counter= m_seg_num;
    }
    else
    {
        m_to_be_changed.master_counter= m_seg_num/cur_nodes_num;

    }
    calc_real_backup_copy();
    if(m_real_backup_copy>0)
    {
        m_to_be_changed.backup1_counter = m_to_be_changed.master_counter+m_seg_num%cur_nodes_num;
    }
    if(m_real_backup_copy>1)
    {
        m_to_be_changed.backup2_counter = m_to_be_changed.master_counter;
    }

    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CRteTableStats::removeNode(uint16_t node_id)
{

    m_table_stats.erase(node_id);
    calc_real_backup_copy();
    return RESULT_ZENIC_SUCCESS;
}

/*����·�ɱ���ʼ��ͳ��ֵ*/
void CRteTableStats::init(T_DHT_RTE_TABLE& rteTable)
{
    T_RTE_STATS tStats;
    STATS_IT it;

    m_table_stats.clear();
    m_backup_copy = rteTable.backup_copy;
    memset(&m_to_be_changed,0,sizeof(T_RTE_STATS));
    this->m_seg_num = rteTable.m_seg_num;
    calc_real_backup_copy();
    if(rteTable.tActiveNodes.node_num==0)
        return;
    memset(&tStats,0,sizeof(tStats));
    //����ڵ��¼
    for(uint16_t i=0;i<rteTable.tActiveNodes.node_num;i++)
    {
        m_table_stats.insert(std::make_pair(rteTable.tActiveNodes.nodes[i].node_id,tStats));
    }

    for(uint16_t i=0;i<rteTable.m_rte_entry_num;i++)
    {
        it = m_table_stats.find(rteTable.rtEntry[i].tNodes.master_node_id);
         if(it!=m_table_stats.end())
         {
             it->second.master_counter++;
         }

        if(rteTable.rtEntry[i].tNodes.backup_nodes_num>0)
        {
            it = m_table_stats.find(rteTable.rtEntry[i].tNodes.backup_nodes[0]);
            if(it!=m_table_stats.end())
            {
                it->second.backup1_counter++;
            }
        }
        if(rteTable.rtEntry[i].tNodes.backup_nodes_num>1)
        {
            it = m_table_stats.find(rteTable.rtEntry[i].tNodes.backup_nodes[1]);
            if(it!=m_table_stats.end())
            {
                it->second.backup2_counter++;
            }
        }
    }
}

/*ȡ���ֵ*/
uint16_t CRteTableStats::max(E_RTE_STATS_TYPE type, uint16_t node_id,const T_DHT_NODES_GROUP &exclude_node_id)
{
    uint16_t max_count=0;
    uint16_t max_node=DHT_INVALID_NODE_ID;
    uint16_t node_count=0;
    uint16_t count1;
    STATS_IT it;

    for(it=m_table_stats.begin();it!=m_table_stats.end();++it)
    {
        switch(type)
        {
        case E_RTE_STATS_MASTER:
                count1=it->second.master_counter;
                break;
            case E_RTE_STATS_BACKUP1:
                count1=it->second.backup1_counter;
                break;
            case E_RTE_STATS_BACKUP2:
                count1=it->second.backup2_counter;
                break;
            default:
                return DHT_INVALID_NODE_ID;
                break;
        }
        if(count1>max_count && !isInNodesGrp(it->first,exclude_node_id))
        {
            max_count = count1;
            max_node = it->first;
        }
        if(it->first==node_id)
        {
            node_count = count1;
        }
    }

    if(node_id==DHT_INVALID_NODE_ID)
        return max_node;
    else
        return node_count>=max_count?node_id:max_node;
}

void CRteTableStats::init(T_DHT_NODE_LIST& tNodes,uint16_t backup_copy, uint16_t seg_num)
{
    T_RTE_STATS tStats;
    memset(&tStats,0,sizeof(tStats));
    this->m_backup_copy = backup_copy;
    memset(&m_to_be_changed,0,sizeof(T_RTE_STATS));
    m_seg_num = seg_num;
    m_table_stats.clear();
    for(uint16_t i=0;i<tNodes.node_num;i++)
    {
        m_table_stats.insert(std::make_pair(tNodes.nodes[i].node_id,tStats));
    }
    calc_real_backup_copy();
}

void CRteTableStats::print_stats()
{
    STATS_IT it;
    uint16_t m_count=0,b_count1=0,b_count2=0;
    printf("---------------------Routing Table Stats-------------------\n");
    printf("node_id  Master_counter   Backup_counter1    Backup_Count2\n");
    for(it=m_table_stats.begin();it!=m_table_stats.end();++it)
    {
        printf("%8u\t%8u     %8u        %8u  \n",it->first,it->second.master_counter,
                it->second.backup1_counter,it->second.backup2_counter);
        m_count+=it->second.master_counter;
        b_count1+=it->second.backup1_counter;
        b_count2+=it->second.backup2_counter;
    }
    printf("Total   %8u   %8u  %8u\n",m_count,b_count1,b_count2);
    printf("Routing Table Nodes_num=%u\n",(uint32_t)m_table_stats.size());
}

/*ɾ��һ���ڵ��Ĳ��������е���
 * ���ɾ�����ڵ㣬�򱸽ڵ�ǰ��*/
ZENIC_RESULT CRteTableStats::AdjustAfterDeleteNode(uint16_t node_id,
        T_DHT_NODES_GROUP& tOldGrp, T_DHT_NODES_GROUP& tNewGrp,bool &bM2S)
{

    memcpy(&tNewGrp,&tOldGrp,sizeof(T_DHT_NODES_GROUP));
    tNewGrp.backup_nodes_num = m_real_backup_copy;

    if(tOldGrp.master_node_id==node_id)
    {
        tNewGrp.master_node_id = tOldGrp.backup_nodes[0];
        if(tOldGrp.backup_nodes_num>1)
        {
            tNewGrp.backup_nodes[0] = tNewGrp.backup_nodes[1];
        }
        else
        {
            tNewGrp.backup_nodes[0] = min(E_RTE_STATS_BACKUP1,DHT_INVALID_NODE_ID,tOldGrp);
        }
        if(m_real_backup_copy>1)
        {
            tNewGrp.backup_nodes[1]=this->min(E_RTE_STATS_BACKUP2,DHT_INVALID_NODE_ID,tOldGrp);
        }
   }
    else if(tOldGrp.backup_nodes_num>0 && tOldGrp.backup_nodes[0]==node_id)
    {
        if(tOldGrp.backup_nodes_num>1)
        {
               tNewGrp.backup_nodes[0] = tNewGrp.backup_nodes[1];
        }
         else
        {
              tNewGrp.backup_nodes[0] = min(E_RTE_STATS_BACKUP1,DHT_INVALID_NODE_ID,tOldGrp);
              			 //���remove�ڵ㵱ǰ�Ѿ���block������Ҫ��M2S��־λ��λ
			 if (bM2S)
			 {
				bM2S = false;				   
			 }
        }
        if(m_real_backup_copy>1)
        {
             tNewGrp.backup_nodes[1]=this->min(E_RTE_STATS_BACKUP2,DHT_INVALID_NODE_ID,tOldGrp);
        }
    }
    else if(tOldGrp.backup_nodes_num>1 && tOldGrp.backup_nodes[1]==node_id)
    {
        tNewGrp.backup_nodes[1]=this->min(E_RTE_STATS_BACKUP2,DHT_INVALID_NODE_ID,tOldGrp);
     }

    /*����Ч�Ľڵ������λ����*/
    for(uint16_t i=tNewGrp.backup_nodes_num;i<ZCS_MAX_BACKUP_NODE_NUM;i++)
    {
        tNewGrp.backup_nodes[i]=DHT_INVALID_NODE_ID;
    }
    adjustCounter(tNewGrp,tOldGrp);
    return RESULT_ZENIC_SUCCESS;
}

/*����һ���ڵ��Ĳ�����ÿ���ڵ�����ݼ����������޸�
 * �������Ա�֤������
 * ɾ����ľ�������α�֤��*/
ZENIC_RESULT CRteTableStats::AdjustAfterAddNode(uint16_t node_id,
        T_DHT_NODES_GROUP& tOldGrp, T_DHT_NODES_GROUP& tNewGrp)
{

    uint16_t c1=0,c2=0,c3=0;
    uint16_t avg = m_seg_num/m_table_stats.size();
	uint16_t backup_avg = avg;
	if (m_seg_num%m_table_stats.size() != 0)
		avg++;
    bool addbackup=false;

    E_RTE_STATS_TYPE adjust_type;
    memcpy(&tNewGrp,&tOldGrp,sizeof(T_DHT_NODES_GROUP));

    /*���������ϣ����������*/
    if(m_to_be_changed.master_counter+m_to_be_changed.backup1_counter+m_to_be_changed.backup2_counter==0)
        return RESULT_ZENIC_SUCCESS;

    tNewGrp.backup_nodes_num = m_real_backup_copy;

    /*���ȼ����ϵĽڵ��б������������������������ֵ����Ϊ��������*/
    c1= getCounter(E_RTE_STATS_MASTER,tOldGrp.master_node_id);

    if(m_real_backup_copy>0)
        c2= getCounter(E_RTE_STATS_BACKUP1,tOldGrp.backup_nodes[0]);

    if(m_real_backup_copy>1)
        c3= getCounter(E_RTE_STATS_BACKUP2,tOldGrp.backup_nodes[1]);

    if(m_real_backup_copy>tOldGrp.backup_nodes_num)
    {
        if(m_real_backup_copy==1 && m_to_be_changed.backup1_counter>0)
        {
            adjust_type = E_RTE_STATS_BACKUP1;
            addbackup = true;
        }
        else if(m_real_backup_copy==2 && m_to_be_changed.backup2_counter>0)
        {
            adjust_type = E_RTE_STATS_BACKUP2;
            addbackup = true;
        }
    }

    if(!addbackup)
    {
        if(c1>=c2 && c1>=c3 && c1>avg)
        {
            adjust_type = E_RTE_STATS_MASTER;
        }
        else if(c2>=c1 && c2>=c3 && c2>backup_avg)
        {
            adjust_type = E_RTE_STATS_BACKUP1;
        }
        else if(c3>=c1 && c3>=c2 && c3>avg)
        {
            adjust_type = E_RTE_STATS_BACKUP2;
        }
        else
            return RESULT_ZENIC_SUCCESS;
    }

    /*������ļ������������ӵĽڵ�ļ����������Ե����������ʾ������λ*/
    switch(adjust_type)
    {
    case E_RTE_STATS_MASTER:
        if(c1>getCounter(E_RTE_STATS_MASTER,node_id))
        {
            tNewGrp.master_node_id =node_id;
            m_to_be_changed.master_counter--;
        }
        break;
    case E_RTE_STATS_BACKUP1:
        if(addbackup || (m_real_backup_copy>0 && c2>=getCounter(E_RTE_STATS_BACKUP1,node_id)))
        {
            tNewGrp.backup_nodes[0] = node_id;
            m_to_be_changed.backup1_counter--;
        }
        break;
    case E_RTE_STATS_BACKUP2:
        if(addbackup || (m_real_backup_copy>1 && c3>getCounter(E_RTE_STATS_BACKUP2,node_id)))
        {
            tNewGrp.backup_nodes[1] = node_id;
            m_to_be_changed.backup2_counter--;
        }
        break;
    default:
		break;
    }

    adjustCounter(tNewGrp,tOldGrp);
    return RESULT_ZENIC_SUCCESS;
}


/*����һ���ڵ��Ƿ��ڽڵ��б���*/
bool CRteTableStats::isInNodesGrp(uint16_t node_id,
        const T_DHT_NODES_GROUP& tNodes) {
    if(node_id==tNodes.master_node_id)
        return true;
    for(uint16_t i=0;i<tNodes.backup_nodes_num;i++)
    {
        if(tNodes.backup_nodes[i]==node_id)
            return true;
    }
    return false;
}

/*��������*/
void CRteTableStats::adjustCounter(const T_DHT_NODES_GROUP& tNewGrp,
        const T_DHT_NODES_GROUP& tOldGrp)
{
    uint16_t backup_copy = tNewGrp.backup_nodes_num>tOldGrp.backup_nodes_num?tNewGrp.backup_nodes_num:tOldGrp.backup_nodes_num;

    if(tNewGrp.master_node_id!=tOldGrp.master_node_id)
    {
        this->decrease(E_RTE_STATS_MASTER,tOldGrp.master_node_id);
        increase(E_RTE_STATS_MASTER,tNewGrp.master_node_id);
    }

    if(backup_copy>0)
    {
        if(tNewGrp.backup_nodes[0]!=tOldGrp.backup_nodes[0])
        {
            this->decrease(E_RTE_STATS_BACKUP1,tOldGrp.backup_nodes[0]);
            increase(E_RTE_STATS_BACKUP1,tNewGrp.backup_nodes[0]);
        }
        if(backup_copy>1 && tNewGrp.backup_nodes[1]!=tOldGrp.backup_nodes[1])
          {
              this->decrease(E_RTE_STATS_BACKUP2,tOldGrp.backup_nodes[1]);
             increase(E_RTE_STATS_BACKUP2,tNewGrp.backup_nodes[1]);
          }
    }
}

/*����ڵ�*/
ZENIC_RESULT CRteTableStats::allocateNodes(T_DHT_NODES_GROUP& tNodes)
{
    tNodes.master_node_id=DHT_INVALID_NODE_ID;
    tNodes.backup_nodes[0]=DHT_INVALID_NODE_ID;
    tNodes.backup_nodes[1]=DHT_INVALID_NODE_ID;
    tNodes.backup_nodes_num = m_real_backup_copy;
    if(m_table_stats.size()==0)
    {
        return RESULT_ZENIC_SUCCESS;;
    }
    tNodes.master_node_id = this->min(E_RTE_STATS_MASTER,DHT_INVALID_NODE_ID,tNodes);
    increase(E_RTE_STATS_MASTER,tNodes.master_node_id);
    if(m_real_backup_copy>0)
    {
        tNodes.backup_nodes[0] =  min(E_RTE_STATS_BACKUP1,DHT_INVALID_NODE_ID,tNodes);
        increase(E_RTE_STATS_BACKUP1,tNodes.backup_nodes[0]);
    }
    if(m_real_backup_copy>1)
    {
        tNodes.backup_nodes[1] =  min(E_RTE_STATS_BACKUP2,DHT_INVALID_NODE_ID,tNodes);
        increase(E_RTE_STATS_BACKUP2,tNodes.backup_nodes[1]);
    }
    return RESULT_ZENIC_SUCCESS;
}

void CRteTableStats::calc_real_backup_copy()
{
    uint16_t nodes_num = m_table_stats.size();

    if(nodes_num>m_backup_copy)
    {
        m_real_backup_copy = m_backup_copy;
    }
    else
    {
        nodes_num<=1?m_real_backup_copy=0:m_real_backup_copy=nodes_num-1;
    }
}

/*��ȡ������*/
uint16_t CRteTableStats::getCounter(E_RTE_STATS_TYPE type, uint16_t node_id)
{
    STATS_IT it;
    uint16_t count = 0;
    it = m_table_stats.find(node_id);
    if(it!=m_table_stats.end())
    {
        switch(type)
        {
        case E_RTE_STATS_MASTER:
        {
            count = it->second.master_counter;
            break;
        }
        case E_RTE_STATS_BACKUP1:
            count = it->second.backup1_counter;
            break;
        case E_RTE_STATS_BACKUP2:
            count = it->second.backup2_counter;
            break;
       default:
	   	    break;
        }
    }

    return count;
}

void CRteTableStats::clear()
{
    m_table_stats.clear();
    memset(&m_to_be_changed,0,sizeof(m_to_be_changed));
    m_real_backup_copy = 0;
}

uint16_t CRteTableStats::getNodeCount()
{
    return m_table_stats.size();
}

CRteTableStats::~CRteTableStats() {
    // TODO Auto-generated destructor stub
}

