/*
 * zcms_common.cpp
 *
 *  Created on: 2014-8-31
 *      Author: kejin
 */

#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/errno.h>

#include "zcms_common.h"
#include "CNodeConfig.h"

#include "CZcmsMgr.h"
#include "CNodeMgr.h"
#include "CNodeClient.h"

extern CZcmsMgr tCZcmsMgr;
extern CNodeConfig tCNodeConfig;
extern CNodeMgr tCNodeMgr;
extern CNodeClient tCNodeClient;

char rstReason[E_ZCMS_RESET_LINK_REASON_MAXCOUNT][20]={
    "Unkown Reason",
    "Error State", 
    "HB Timeout",
    "Diff Node",
    "Unauthorized",
    "Mgr ChangeOver",
    "Common Reason",
};

#ifdef __cplusplus
extern "C" {
#endif
void help()
{
        uint32_t index =1;
        printf("%-10s%-20s%-30s\n","Index","Function Name","Description");
        printf("%-10d%-20s%-30s\n",index++,"zcs_help()","Show zcs module debug function information");
        printf("%-10d%-20s%-30s\n",index++,"zcms_help()","Show zcms module debug function information");
        printf("%-10d%-20s%-30s\n",index++,"zcrs_help()","Show zcrs module debug function information");
        printf("%-10d%-20s%-30s\n",index++,"zcps_help()","Show zcps module debug function information");
        printf("%-10d%-20s%-30s\n",index++,"zcs_log_help()","Show zcs log module debug function information");
}
/* Debug Functions */
void zcs_log_help()
{
           printf("show log details:"
            "\n\tZCSLogSetLvl()----->help"
           "\n\tZCSLogSetLvl(level,moduleName)---->ZCSLogSetLvl(\"TRACE\",\"ZCMS\")"
           "\ndisable zcs log:"
           "\n\tZCSLogDisable()----->help"
           "\n\tZCSLogDisable(\"moduleName\")---->ZCSLogDisable(\"ZCMS\")"
           "\nshow zcs log:"
           "\n\tZCSShowLog()----->help"
           "\n\tZCSShowLog(\"moduleName\")---->ZCSShowLog(\"ZCMS\")"
            "\nclear zcs log:"
            "\n\tZCSClearLog()----->help"
           "\n\tZCSClearLog(\"moduleName\")---->ZCSClearLog(\"ZCMS\")"
           "\n");
}
void zcps_help()
{
           printf("show zcps :"
            "\n\tzcps_show(appid,datatype) ---->appid,datatype see:zcps_show_event_reg(),0xffff for all"
            "\nunshow zcps :"
           "\n\tzcps_unshow()"
           "\nshow zcps stats:"
           "\n\tzcps_show_stats()"
           "\nshow event reg(1 for details):"
           "\n\tzcps_show_event_reg(uint32 isPrintStats)"
           "\nshow data nums send to peer nodes"
           "\n\tzcps_show_send_detail(uint16_t nodeId)"
           "\nshow unsync data "
           "\n\tzcps_show_unsync_detail(uint16_t start, uint16_t total)"
           "\nclean reg stats(1 for clean all history stats)"
           "\n\tzcps_clean_reg_stat(uint32_t isCleanAllHistory)"
            "\nclean pull&push stats data:"
           "\n\tzcps_clean_st_data()"
            "\nshow pull&push stats:"
           "\n\tzcps_show_st_stats()"
           "\n");
}
void zcrs_help()
{
        printf("show zcrs stats:"
           "\n\tzcrs_show_stats()"
           "\nshow rte table:"
           "\n\tzcrs_show_rte_table()"
            "\nshow event reg:"
           "\n\tzcrs_show_event_reg()"
           "\n");
}
void zcs_help()
{
        printf("block node:"
           "\n\tzcs_block_node(node_id)"
           "\nunblock node:"
           "\n\tzcs_unblock_node(node_id)"
           "\nadd node:"
           "\n\tzcs_add_node(node_id)"
           "\nremove node:"
           "\n\tzcs_remove_node(node_id)"
            "\nlookup rte:"
           "\n\tzcs_rte_lookup_by_deviceid(device_id)"
           "\nbalance node:"
           "\n\tzcs_balance_node()"
           "\n");
}
void zcms_help()
{
    printf("Zcms Help Infomation:\n");
    printf("zcms_show_all_info()               --Show overall nodes information.\n");
    printf("zcms_show_config()                 --Show configuration file information.\n");
    printf("zcms_show_sys_info()               --Show system information.\n");
    printf("zcms_show_la_pool()                --Show logical address pool.\n");
    printf("zcms_show_mgr_stats()              --Show manager node statistics.\n");
    printf("zcms_show_all_nodes(int type)      --Show all nodes information(0-->all nodes,1-->active nodes,2-->unblocked nodes).\n");
    printf("zcms_show_clnt_stats()             --Show client node statistics.\n");
    printf("zcms_show_log()                    --Show zcms memory log.\n");
    printf("zcms_show_all_shm()                --Show nodes info(logic addr,state in shm) .\n");
    printf("zcms_reset_client(int)             --reset clients in cluster 1-->graceful,2-->force.\n");
    printf("zcms_changeover()                  --changeover\n");
}

void zcms_show_config()
{
    printf("This Node Configuration File Information:\n");
    tCNodeConfig.showConf();
}

void zcms_show_sys_info()
{
    printf("This Node System Information:\n");
    tCZcmsMgr.showSysInfo();
}

void zcms_show_la_pool()
{
    tCNodeMgr.showLAPool();
}

void zcms_show_mgr_stats()
{
    printf("Node Manager Information:\n");
    tCNodeMgr.showGeneralStt();
    printf("\n");
    tCNodeMgr.showNodeEventSub();
    printf("\n");
    tCNodeMgr.showNodeEventQueue();
    printf("\n");
    tCNodeMgr.showAllCNodesStt(1);
}

void zcms_show_all_nodes(int type)
{
    tCNodeMgr.showAllCNodesStt(type);
}

void zcms_show_all_shm()
{
    T_ZCS_NODE_LIST tMgrList;
    T_ZCS_NODE_LIST tList;
    if(RESULT_ZENIC_SUCCESS == zcsmgr_get_all_nodes(tMgrList))
    {
        printf("zcsmgr_get_all_nodes: node_num=%d\n", tMgrList.node_num);
        for(uint16_t i = 0; i < tMgrList.node_num; i++)
        {
            printf("[Node:Module:State:RouteType][%03d:%03d:%d:%d]\n",
                tMgrList.tNodes[i].nodeId, tMgrList.tNodes[i].moduleId, tMgrList.tNodes[i].state, tMgrList.tNodes[i].route_type);
        }
    }
    else
    {
        printf("zcsmgr_get_all_nodes Failed!\n");
    }
    
    if(RESULT_ZENIC_SUCCESS == zcs_get_active_nodes(tList))
    {
        printf("zcs_get_active_nodes: node_num=%d\n", tList.node_num);
        for(uint16_t i = 0; i < tList.node_num; i++)
        {
            printf("[Node:Module:State:RouteType][%03d:%03d:%d:%d]\n",
                tList.tNodes[i].nodeId, tList.tNodes[i].moduleId, tList.tNodes[i].state, tList.tNodes[i].route_type);
        }
    }
    else
    {
        printf("zcs_get_active_nodes Failed!\n");
    }
}

void zcms_show_clnt_stats()
{
    printf("Node Client Information:\n");
    tCNodeClient.showStt();
}

void zcms_show_all_info()
{
    zcms_show_config();
    printf("\n");
    zcms_show_sys_info();
    printf("\n");
    zcms_show_mgr_stats();
    printf("\n");
    zcms_show_clnt_stats();
    printf("\n");
}

void zcms_show_log()
{
    ZCS_ZCMSMemPrintfShow();
}

void zcms_reset_client(int type)
{
    JID tZcmsJid;
    uint8_t bSent = (uint8_t)type;
    
    if(bSent!= TYPE_CLIENT_ELEGANT_RESET && bSent!= TYPE_CLIENT_FORCE_RESET)
    {
        printf("zcms_reset_client help:\n");
        printf("zcms_reset_client(int type)\n");
        printf("type=%d: Administratively elegant reset client\n", TYPE_CLIENT_ELEGANT_RESET);
        printf("type=%d: Administratively force reset client\n", TYPE_CLIENT_FORCE_RESET);
        return;
    }
    
    XOS_GetJIDByJNO(XOS_ConstructJNO(ZCS_JOB_TYPE_ZCMS, 1), &tZcmsJid);

    if(RESULT_ZENIC_SUCCESS!=XOS_GetJIDByJNO(XOS_ConstructJNO(ZCS_JOB_TYPE_ZCMS, 1), &tZcmsJid))
    {
    	   printf("XOS_GetJIDByJNO Failed!\n");
        return;
    }
    
    if(RESULT_ZENIC_SUCCESS!=
    	      XOS_SendAsynMsgNJ(EV_SYS_ZCMS_CLIENT_RESET,(uint8_t *)&bSent,sizeof(bSent), XOS_MSG_VER0, XOS_MSG_LOW, NULL, &tZcmsJid))
    {
    	   printf("XOS_SendAsynMsgNJ Failed!\n");
    }
    return;
}

void zcms_changeover()
{
    T_CmdToMcm tCmdToMcm;
    XOS_STATUS dwXOStet = 0;
    memset(&tCmdToMcm, 0, sizeof(T_CmdToMcm));    
    tCmdToMcm.ucCmdSrcType = CMD_SRC_TYPE_TASK;
    tCmdToMcm.wCmdType = CMD_LA_MS_CHANGEOVER;
    XOS_GetLogicAddress(&tCmdToMcm.tLogicAddr);
    
    dwXOStet = XOS_SendCmdToMcm(&tCmdToMcm);
    if(XOS_SUCCESS == dwXOStet)
    {
        printf("zcms_changeover Success!\n");
    }
    else
    {
        printf("zcms_changeover Failed!\n");;
    }
    
    return;
}

#ifdef __cplusplus
}
#endif

void constrConfInfo(T_ZCMS_CONFIG_INFO &tConf, CNodeConfig *pCNodeConf)
{
    uint16_t wConfNodeNum = 0;
    if(NULL == pCNodeConf)
    {
        XOS_ASSERT(0);
        return;
    }

    memset(&tConf,0, sizeof(T_ZCMS_CONFIG_INFO));

    tConf.tSelfRole = pCNodeConf->getConfSelfNodeRole();
    tConf.tAliveTimer = pCNodeConf->getConfKeepAliveHBTimer();
    tConf.tAliveCount = pCNodeConf->getConfKeepAliveHBCount();
    tConf.tReplica_Mode = pCNodeConf->getConfReplicaMode();
    //tConf.tReserved = pCNodeConf->m_reserved;
    pCNodeConf->getConfNodeListAndNum(tConf.tNodes, wConfNodeNum); //cannot use tConf.tConfNodeNum as reference directly because of gcc compiler problem
    tConf.tConfNodeNum = wConfNodeNum;
    return;
}

void printConfInfo(T_ZCMS_CONFIG_INFO *ptConf)
{
    uint16_t node_i;

    printf("NodeRole[%u], ReplicaMode[%d], KeepAliveHBTimer[%u], KeepAliveHBCount[%d]\n", 
                        ptConf->tSelfRole, ptConf->tReplica_Mode, ptConf->tAliveTimer, ptConf->tAliveCount);
    
    printf("NodeListAndNum, Total Node Number [%d]\n", ptConf->tConfNodeNum);
    for(node_i=0; node_i< ptConf->tConfNodeNum; node_i++)
    {
        printf("Node[%d]: nodeId %d, moduleId %d, route_type %d\n", node_i, 
                        ptConf->tNodes[node_i].nodeId, ptConf->tNodes[node_i].moduleId, ptConf->tNodes[node_i].route_type);
    }
    
    return;
}

void printMgrNodeInfo(T_ZCMS_MGRNODE_INFO *ptCurMGRInfo)
{
    printf("N:M:RType[%d:%d:%d], Rack:Shelf:Slot:CpuId[%d:%d:%d:%d], CurMgrPowerOnTick[%u]\n",
                        ptCurMGRInfo->tCurMgrNodeInfo.nodeId, 
                        ptCurMGRInfo->tCurMgrNodeInfo.moduleId, 
                        ptCurMGRInfo->tCurMgrNodeInfo.route_type, 
                        ptCurMGRInfo->tCurMgrPhyAddrInfo.ucRackId, ptCurMGRInfo->tCurMgrPhyAddrInfo.ucShelfId,
                        ptCurMGRInfo->tCurMgrPhyAddrInfo.ucSlotId, ptCurMGRInfo->tCurMgrPhyAddrInfo.ucCpuId,
                        ptCurMGRInfo->dwCurMgrPowerOnTick);

}

void printCNodeInfo(T_ZCMS_CNODE_INFO *ptNodeInfo)
{  
    printf("N:M:RType[%d:%d:%d], Rack:Shelf:Slot:CpuId[%d:%d:%d:%d], PoweronTick[%u], LinkState[%d], CServiceState[%d]\n",
                        ptNodeInfo->tNodeType.nodeId, ptNodeInfo->tNodeType.moduleId, ptNodeInfo->tNodeType.route_type, 
                        ptNodeInfo->tPhyAddrInfo.ucRackId, ptNodeInfo->tPhyAddrInfo.ucShelfId,
                        ptNodeInfo->tPhyAddrInfo.ucSlotId, ptNodeInfo->tPhyAddrInfo.ucCpuId,
                        ptNodeInfo->dwCNodePoweronTick, ptNodeInfo->eLinkState, ptNodeInfo->wCSvcState);
    
    return;
}

char* zcmsRstReasonToStr(E_ZCMS_RESET_LINK_REASON eReason)
{
    if(eReason < E_ZCMS_RESET_LINK_REASON_MAXCOUNT)
    {
        return rstReason[eReason];
    }
    
    return rstReason[0];
}

char* zcmsAdminOpToStr(T_ZCS_NODE_MGR_OP op)
{
    switch (op)
    {
        case ZCS_NODE_MGR_ADD:
        {
            return "ADD";
        }
        case ZCS_NODE_MGR_REMOVE:
        {
            return "REMOVE";
        }
        case ZCS_NODE_MGR_BLOCK:
        {
            return "BLOCK";
        }
        case ZCS_NODE_MGR_UNBLOCK:
        {
            return "UNBLOCK";
        }
        default:
        return "UNKOWN OP";
    }
}

char* zcmsEventToStr(T_ZCS_NODE_EVENT event)
{
    switch (event)
    {
        case EV_ZCS_NODE_JOIN:
        {
            return "Join";
        }
        case EV_ZCS_NODE_LEAVE:
        {
            return "Leave";
        }
        case EV_ZCS_NODE_BLOCKED:
        {
            return "Block";
        }
        case EV_ZCS_NODE_UNBLOCKED:
        {
            return "UnBlock";
        }
        default:
        return "Unkown Event";
    }
}

uint32_t zcms_set_timer(uint32_t dwTimerNo, int32_t sdwDuration, uint32_t dwParam)
{
    return XOS_SetRelativeTimer(dwTimerNo, sdwDuration, dwParam);
}

uint32_t zcms_set_looptimer(uint32_t dwTimerNo, int32_t sdwDuration, uint32_t dwParam)
{
    return XOS_SetLoopTimer(dwTimerNo, sdwDuration, dwParam);
}

/*ɱ����ʱ��������������ʱ����Ϊ��Чֵ*/
void zcms_cancel_timer(uint32_t &timer_id)
{
    if(INVALID_TIMER_ID!=timer_id)
    {
        XOS_KillTimerByTimerId(timer_id);
        timer_id = INVALID_TIMER_ID;
    }
}

void zcms_init_timer(uint32_t &timer_id)
{
    timer_id = INVALID_TIMER_ID;
}

bool zcms_timer_invalid(uint32_t &timer_id)
{
    return INVALID_TIMER_ID == timer_id;
}

uint16_t zcs_inner_get_config_nodes(T_ZCS_NODE_LIST &tNodesList)
{
    int ret;
    uint32_t TotalCnt;
    uint32_t idx = 0;
    T_ZCMS_NODE_INFO tLinkNInfo;
    
    memset(&tNodesList, 0, sizeof(tNodesList));
    if(!tCNodeMgr.m_isMgrWorking)
    {
        return 0;
    }
    
    TotalCnt = tCNodeMgr.m_tAllCNodesInfo.getTotalInstNum();
    
    while (idx < TotalCnt)
    {
        if(tCNodeMgr.m_tAllCNodesInfo.getInstanceState(idx)!=InstMgr::INST_STATE_ALLOCATED)
        {
            idx++;
            continue;
        }
        ret = tCNodeMgr.m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            XOS_ASSERT(0);
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS, "zcs_inner_get_config_nodes getInstByIndex %d, Failed ret=%d\n", idx, ret);
            idx++;
            continue;
        }
        
        tNodesList.tNodes[tNodesList.node_num].nodeId = tLinkNInfo.tCNodeData.wNodeId;
        tNodesList.tNodes[tNodesList.node_num].moduleId = tLinkNInfo.tCNodeData.wModule;
        tNodesList.tNodes[tNodesList.node_num].state = tLinkNInfo.tCNodeData.tManageStatus;
        tNodesList.tNodes[tNodesList.node_num].route_type = tLinkNInfo.tCNodeData.wRouteType;
        tNodesList.node_num++;
        
        idx++;
    }
    return tNodesList.node_num;
}

uint16_t zcs_inner_get_active_nodes(T_ZCS_NODE_LIST &tNodesList)
{
    int ret;
    uint32_t TotalCnt;
    uint32_t idx = 0;
    T_ZCMS_NODE_INFO tLinkNInfo;
    
    memset(&tNodesList, 0, sizeof(tNodesList));
    if(!tCNodeMgr.m_isMgrWorking)
    {
        return 0;
    }
    
    TotalCnt = tCNodeMgr.m_tAllCNodesInfo.getTotalInstNum();
    
    while (idx < TotalCnt)
    {
        if(tCNodeMgr.m_tAllCNodesInfo.getInstanceState(idx)!=InstMgr::INST_STATE_ALLOCATED)
        {
            idx++;
            continue;
        }
        ret = tCNodeMgr.m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            XOS_ASSERT(0);
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS, "zcs_inner_get_active_nodes getInstByIndex %d, Failed ret=%d\n", idx, ret);
            idx++;
            continue;
        }
        
        if (tLinkNInfo.tCNodeData.eLinkState == E_ZCMS_NODE_STATE_ACTIVE || tLinkNInfo.tCNodeData.eLinkState == E_ZCMS_NODE_STATE_REGISTERING)
        {
            tNodesList.tNodes[tNodesList.node_num].nodeId = tLinkNInfo.tCNodeData.wNodeId;
            tNodesList.tNodes[tNodesList.node_num].moduleId = tLinkNInfo.tCNodeData.wModule;
            tNodesList.tNodes[tNodesList.node_num].state = tLinkNInfo.tCNodeData.tManageStatus;
            tNodesList.tNodes[tNodesList.node_num].route_type = tLinkNInfo.tCNodeData.wRouteType;
            tNodesList.node_num++;
        }
        
        idx++;
    }
    
    return tNodesList.node_num;
}

uint16_t zcs_inner_get_nodes(T_ZCS_NODE_LIST &tNodesList, T_ZCS_NODE_STATE tState)
{
    int ret;
    uint32_t TotalCnt;
    uint32_t idx = 0;
    T_ZCMS_NODE_INFO tLinkNInfo;
    
    memset(&tNodesList, 0, sizeof(tNodesList));
    if(!tCNodeMgr.m_isMgrWorking)
    {
        return 0;
    }
    
    TotalCnt = tCNodeMgr.m_tAllCNodesInfo.getTotalInstNum();
    
    while (idx < TotalCnt)
    {
        if(tCNodeMgr.m_tAllCNodesInfo.getInstanceState(idx)!=InstMgr::INST_STATE_ALLOCATED)
        {
            idx++;
            continue;
        }
        ret = tCNodeMgr.m_tAllCNodesInfo.getInstByIndex(idx, tLinkNInfo);
        if(ret!=InstMgr::RESULT_INST_SUCCESS)
        {
            XOS_ASSERT(0);
            ZCS_LOG(ZCS_LOG_ERROR, ZCS_LOG_BUF_ZCMS, "zcs_inner_get_active_nodes getInstByIndex %d, Failed ret=%d\n", idx, ret);
            idx++;
            continue;
        }
        
        if(tLinkNInfo.tCNodeData.tManageStatus & tState)
        {
            tNodesList.tNodes[tNodesList.node_num].nodeId = tLinkNInfo.tCNodeData.wNodeId;
            tNodesList.tNodes[tNodesList.node_num].moduleId = tLinkNInfo.tCNodeData.wModule;
            tNodesList.tNodes[tNodesList.node_num].state = tLinkNInfo.tCNodeData.tManageStatus;
            tNodesList.tNodes[tNodesList.node_num].route_type = tLinkNInfo.tCNodeData.wRouteType;
            tNodesList.node_num++;
        }
        
        idx++;
    }
    
    return tNodesList.node_num;
}


