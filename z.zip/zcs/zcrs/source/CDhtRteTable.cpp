/*
 * CDhtRteTable.cpp
 *
 *  DHT·�ɱ�ά���࣬ά��һ���ɱ���Ƭ������·�ɱ���
 *  ֧��Block�������򵥵���������ϵ
 *  Created on: 2014-7-2
 *      Author: wangjun
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include "CDhtRteTable.h"
#include "zcs_api.h"

#include <map>

//��ĳ��RESOURCE_ID����������Ƭ��ʶ�ĸ���ģ��
uint16_t CDhtRteTable::getSuccessorBySegment(uint16_t seg_idx,uint16_t prev_node)
{
    uint16_t node_idx = (seg_idx*5/7 % m_rte_table.tActiveNodes.node_num);

    uint16_t succ_node;
    if(m_rte_table.tActiveNodes.nodes[node_idx].node_id!=prev_node)
       succ_node = m_rte_table.tActiveNodes.nodes[node_idx].node_id;
    else
        succ_node = successor(m_rte_table.tActiveNodes.nodes[node_idx].node_id,prev_node);

    return succ_node;
}

//��ĳ���ڵ�ĺ�̽ڵ�
uint16_t CDhtRteTable::successor(uint16_t node_id,uint16_t exclude_node)
{
    uint16_t node_idx;
    uint16_t idx;
    bool found =false;
    //�����ҵ��ýڵ��ڱ��е�λ��
    for(idx=0;idx<m_rte_table.tActiveNodes.node_num;idx++)
    {
        if(node_id==m_rte_table.tActiveNodes.nodes[idx].node_id)
            break;
    }
    if(idx>=m_rte_table.tActiveNodes.node_num)
        return DHT_INVALID_NODE_ID;

    //�������û�У����֮ǰ���в���
    node_idx = (idx+1) % m_rte_table.tActiveNodes.node_num;
    while(node_idx!=idx)
    {
        if(m_rte_table.tActiveNodes.nodes[node_idx].node_id!=exclude_node)
        {
            found = true;
            break;
        }
        else
        {
            node_idx = (node_idx+1) %m_rte_table.tActiveNodes.node_num;
        }
    }

    if(found)
    {
        return m_rte_table.tActiveNodes.nodes[node_idx].node_id;
    }
    else
       return DHT_INVALID_NODE_ID;

}

//����·�ɱ������ʼ��Ϊ���ʵ�·����Ŀ
void CDhtRteTable::genRteTable(T_DHT_NODE_LIST &tNodes,uint32_t seg_num,uint16_t backup_copy)
{
    uint16_t num_per_seg=0;
    uint16_t seg_idx=0;

    num_per_seg = 65536 /seg_num;
    m_rte_table.m_num_per_seg = num_per_seg;
    //�������2�����ݽڵ�
    if(backup_copy>2) backup_copy =2;

    //��ʼ���ڵ����״̬
    m_table_stats.init(tNodes,backup_copy,seg_num);
    //��ʼ��·�ɱ���
    for(uint32_t i=0;i<seg_num;i++)
    {
        m_rte_table.rtEntry[i].tSegPair.start_idx = seg_idx;
        m_rte_table.rtEntry[i].tSegPair.end_idx = seg_idx-1+num_per_seg;

         m_table_stats.allocateNodes(m_rte_table.rtEntry[i].tNodes);
         seg_idx+=num_per_seg;
    }


}

/*���ȳ�ʼ���ڵ�������Ƭ�������ڵ��������������޸�
     * pfCallBack���ڽڵ�������֪ͨ��Ϣ�ص��ӿ�*/
CDhtRteTable::CDhtRteTable(T_DHT_NODE_LIST &tNodes, uint32_t segment_num,uint16_t backup_copy)
    : m_rte_table(), m_table_stats(), m_self_node_id(0)
{
    init(tNodes,segment_num, backup_copy);
}

//���ñ��ڵ�ID,�������ã������޷�����
void CDhtRteTable::setSelfNodeId(uint16_t self_node_id)
{
    m_self_node_id = m_rte_table.m_self_node_id = self_node_id;
}

//����·�ɱ������ؽڵ��б�
ZENIC_RESULT CDhtRteTable::lookupRteTable(T_ZCS_RESOURCE_KEY &tResKey, T_DHT_NODES_GROUP &tNodes)
{
    //���RESOURCE_ID��·�ɱ��е��±�
    uint16_t hash_v = zcs_hash_func(tResKey.res_key,tResKey.key_len);

    uint16_t seg_idx = getSegIdxByRID(hash_v,m_rte_table.m_num_per_seg);
    tNodes = m_rte_table.rtEntry[seg_idx].tNodes;

     return RESULT_ZENIC_SUCCESS;
}

//���ӽڵ㣬�ڵ�ID�̻�Ϊ1-256;
//ֻ����һ�����ӡ�ɾ���ڵ㣬ֱ�����нڵ����Ϊֹ
#ifndef ZCRS_RTE_TABLE_OPT
ZENIC_RESULT CDhtRteTable::addNode(uint16_t node_id)
{
    ZENIC_RESULT ret;
    T_DHT_NODE_LIST tNodes;
    uint16_t cur_nodes_num = m_rte_table.tActiveNodes.node_num;

    if(cur_nodes_num<2)
    {

        tNodes = m_rte_table.tActiveNodes;
        tNodes.nodes[tNodes.node_num].node_id=node_id;
        tNodes.nodes[tNodes.node_num].node_state=DHT_NODE_ACTIVE;
        tNodes.node_num++;
        this->init(tNodes,m_rte_table.m_seg_num,m_rte_table.backup_copy);
        return RESULT_ZENIC_SUCCESS;
    }
    ret = insertNode(node_id);
    if(ret!=RESULT_ZENIC_SUCCESS)
        return ret;
    //���ȼ���ÿ���ڵ��ڵ���ǰ/��Ӧ�ø������Ƭ����
    uint32_t cur_seg_per_node, next_seg_per_node;


    next_seg_per_node = m_rte_table.m_seg_num/(cur_nodes_num+1);
    cur_seg_per_node = cur_nodes_num==0?0:m_rte_table.m_seg_num/cur_nodes_num;

    m_rte_table.m_seg_per_node = next_seg_per_node;

    adjustAfterAddNode(node_id,next_seg_per_node,cur_seg_per_node);

    return RESULT_ZENIC_SUCCESS;
}
#else
ZENIC_RESULT CDhtRteTable::addNode(uint16_t node_id)
{
    ZENIC_RESULT ret;
    T_DHT_NODE_LIST tNodes;
    uint16_t cur_nodes_num = m_rte_table.tActiveNodes.node_num;

    if(cur_nodes_num<2)
    {

        tNodes = m_rte_table.tActiveNodes;
        tNodes.nodes[tNodes.node_num].node_id=node_id;
        tNodes.nodes[tNodes.node_num].node_state=DHT_NODE_ACTIVE;
        tNodes.node_num++;
        this->init(tNodes,m_rte_table.m_seg_num,m_rte_table.backup_copy);
        return RESULT_ZENIC_SUCCESS;
    }
    ret = insertNode(node_id);
    if(ret!=RESULT_ZENIC_SUCCESS)
        return ret;

    m_rte_table.m_seg_per_node = m_rte_table.m_seg_num/(cur_nodes_num+1);

    adjustAfterAddNode( node_id );

    return RESULT_ZENIC_SUCCESS;
}
#endif

//ɾ��һ���ڵ㣬������·�ɱ����ڵ�ID�̻�Ϊ1-256;
ZENIC_RESULT CDhtRteTable::RemoveNode(uint16_t node_id)
{
    ZENIC_RESULT ret;

    ret = deleteNode(node_id);
    if(ret!=RESULT_ZENIC_SUCCESS)
        return ret;
    adjustAfterRemoveNode(node_id);

    return RESULT_ZENIC_SUCCESS;
}

//�޸�·�ɱ�����ڴӽڵ���ͬ�����ص�·�ɱ�������������¼�
ZENIC_RESULT CDhtRteTable::modifyRteEntry(T_DHT_SEGMENT_PAIR &tPair,const T_DHT_NODES_GROUP &tNewNodes)
{
    uint16_t seg_idx = tPair.start_idx / m_rte_table.m_num_per_seg;
    if(m_rte_table.rtEntry[seg_idx].tSegPair.start_idx!=tPair.start_idx
        || m_rte_table.rtEntry[seg_idx].tSegPair.end_idx!=tPair.end_idx)
    {
        return ERROR_INVALID_PARAM;
    }
    if(m_rte_table.rtEntry[seg_idx].tNodes==tNewNodes)
        return RESULT_ZENIC_SUCCESS;
    else
    {
        m_rte_table.rtEntry[seg_idx].tNodes = tNewNodes;
        return RESULT_ZENIC_SUCCESS;
    }
}

//�ж�ĳ��Resource_id�Ƿ��ɱ��ش������ӿڿ��ܿ���̵���
//to-do����Ҫ�ĳɸĳɹ����ڴ�汾
bool CDhtRteTable::isLocal(const T_ZCS_RESOURCE_KEY &tResKey)
{
    uint16_t hash_v = zcs_hash_func(tResKey.res_key,tResKey.key_len);
    uint16_t seg_idx = getSegIdxByRID(hash_v,m_rte_table.m_num_per_seg);

    if(m_rte_table.rtEntry[seg_idx].tNodes.master_node_id == m_rte_table.m_self_node_id)
        return true;
    else
      return false;
}

 //�����±�ֱ�ӷ���·�ɱ���
 const T_DHT_RTE_ENTRY * CDhtRteTable::operator[](uint32_t idx)
 {
     if(idx>=m_rte_table.m_seg_num)
         return NULL;
     return &(m_rte_table.rtEntry[idx]);

 }

//���������л���������֪ͨ�ϲ�Ӧ��
void CDhtRteTable::forceM2S(uint16_t node_id, bool needNotify)
{
    T_DHT_NODES_GROUP tNewNodes;
    ZENIC_RESULT ret;
    for(uint32_t i=0;i<m_rte_table.m_seg_num;i++)
    {
        if((m_rte_table.rtEntry[i].tNodes.master_node_id == node_id) &&
                (m_rte_table.rtEntry[i].tNodes.backup_nodes_num>=1))
        {
            tNewNodes = m_rte_table.rtEntry[i].tNodes;
            tNewNodes.master_node_id = tNewNodes.backup_nodes[0];
            tNewNodes.backup_nodes[0] = node_id;
            //����֪ͨ
            ret=RESULT_ZENIC_SUCCESS;

            if(ret==RESULT_ZENIC_SUCCESS)
            {
                m_rte_table.rtEntry[i].tNodes= tNewNodes;
                m_rte_table.rtEntry[i].has_m2s = true;
            }
        }
    }

    m_table_stats.init(m_rte_table);
}
 //����һ���ڵ�
ZENIC_RESULT CDhtRteTable::blockNode(uint16_t node_id, bool needNotify)
{
    if(node_id>DHT_MAX_NODE_NUMBER) return ERROR_INVALID_PARAM;
    bool found;
    uint16_t idx;
    found = findNode(node_id,idx);
    if(!found)
        return ERROR_RECORD_NOT_FOUND;

    //ֻ���ڽڵ�״̬�ڻ������²�ʵ�ʴ�������
    if(m_rte_table.tActiveNodes.nodes[idx].node_state==DHT_NODE_ACTIVE)
    {
        forceM2S(node_id);
    }

    m_rte_table.tActiveNodes.nodes[idx].node_state=DHT_NODE_BLOCKED;

    return RESULT_ZENIC_SUCCESS;

}

//��������һ���ڵ�
ZENIC_RESULT CDhtRteTable::unblockNode(uint16_t node_id)
{
    if(node_id>DHT_MAX_NODE_NUMBER) return ERROR_INVALID_PARAM;
    bool found;
    uint16_t idx;
    found = findNode(node_id,idx);
    if(!found)
        return ERROR_RECORD_NOT_FOUND;

    if(m_rte_table.tActiveNodes.nodes[idx].node_state!= DHT_NODE_BLOCKED)
        return ERROR_RECORD_NOT_FOUND;

    //�ָ��ýڵ������
    restoreMaster(node_id);


    m_rte_table.tActiveNodes.nodes[idx].node_state=DHT_NODE_ACTIVE;

    return RESULT_ZENIC_SUCCESS;

}

//��ָ���ڵ������������,��ת��
ZENIC_RESULT CDhtRteTable::master2Slave(uint16_t node_id)
{
    if(node_id>DHT_MAX_NODE_NUMBER) return ERROR_INVALID_PARAM;
    bool found;
    uint16_t idx;
    found = findNode(node_id,idx);
    if(!found)
        return ERROR_RECORD_NOT_FOUND;

    forceM2S(node_id);
    return RESULT_ZENIC_SUCCESS;
}

//��ָ���ڵ�ָ����ô�����һ�����ڽڵ�ָ���Ĵ���
ZENIC_RESULT CDhtRteTable::restoreMaster(uint16_t node_id)
{
    T_DHT_NODES_GROUP tNewNodes;
    ZENIC_RESULT ret;
    for(uint32_t i=0;i<m_rte_table.m_seg_num;i++)
    {
        if((m_rte_table.rtEntry[i].tNodes.backup_nodes_num>=1) &&
                (m_rte_table.rtEntry[i].tNodes.backup_nodes[0] == node_id) &&
                (m_rte_table.rtEntry[i].has_m2s))
        {
            tNewNodes = m_rte_table.rtEntry[i].tNodes;
            tNewNodes.backup_nodes[0] = tNewNodes.master_node_id;
            tNewNodes.master_node_id = node_id;
            //����֪ͨ
            ret=RESULT_ZENIC_SUCCESS;
            if(ret==RESULT_ZENIC_SUCCESS)
            {
                m_rte_table.rtEntry[i].tNodes= tNewNodes;
                m_rte_table.rtEntry[i].has_m2s = false;
            }
        }
    }
    m_table_stats.init(m_rte_table);
     return RESULT_ZENIC_SUCCESS;
}

//��ȡϵͳ·�ɱ�������
int CDhtRteTable::getRteEntryCount(void)
{
      return m_rte_table.m_seg_num;
}


/*���ӽڵ��ĵ���*/
#ifndef ZCRS_RTE_TABLE_OPT
ZENIC_RESULT CDhtRteTable::adjustAfterAddNode(uint16_t node_id,uint32_t next_seg_per_node,uint32_t cur_seg_per_node)
{
    //�Ƚ��ڵ����ͳ������
    m_table_stats.addNode(node_id);
    uint32_t offset=0,index;
    //������ʼ�������������ֵ���Ƭ��������ڵ�Ϊ��ǰ�ڵ㡣���ݽڵ�ͬ����Ҫ����
    T_DHT_NODES_GROUP tNodes;
    if(m_table_stats.getNodeCount() % 2==0)
        offset = m_rte_table.m_seg_num/2;

     for(uint32_t i=0;i<m_rte_table.m_seg_num;i++)
     {
         index = (i+offset) % m_rte_table.m_seg_num;
         m_table_stats.AdjustAfterAddNode(node_id,m_rte_table.rtEntry[index].tNodes,tNodes);
         m_rte_table.rtEntry[index].tNodes=tNodes;
    }
    return RESULT_ZENIC_SUCCESS;
}
#else
ZENIC_RESULT CDhtRteTable::adjustAfterAddNode(uint16_t node_id )
{
    //�Ƚ��ڵ����ͳ������
    m_table_stats.addNode(node_id);
    
    /*�����ڵ�ֲ�����newnode�����master�ڵ㣬����bak[0]*/
    adjMasterDupNodes( ADD_ADJUST_MASTER );

    /*�������ݽڵ㣬�ĺ�������Ҳ�ɷ���oam���������������ʵ��*/
    //adjustBackUpNodes(  );

    return RESULT_ZENIC_SUCCESS;
}
#endif

/*��ӡ������Ϣ*/
void CDhtRteTable::printRteTable()
{
    T_DHT_RTE_ENTRY *p= m_rte_table.rtEntry;
    printf("\nDHT Routing Table, num of entries=%u, seg_per_node=%u,self_node_id=%u,num_per_seg=%u\n",m_rte_table.m_seg_num,
          m_rte_table.m_seg_per_node,m_rte_table.m_self_node_id,m_rte_table.m_num_per_seg);

    printf("total_node=%u\n",m_rte_table.tActiveNodes.node_num);

    printf("Seg_start  Seg_End  Master_node Backup_Num  Backup_node1  Backup_Node2 M2S\n");
    printf("---------------------------------------------------------------------------\n");
    for(uint32_t i=0;i<m_rte_table.m_seg_num;i++)
    {
        printf("%6u  %8u %10u %10u %10u %12u  \t%s\n",p[i].tSegPair.start_idx, p[i].tSegPair.end_idx, p[i].tNodes.master_node_id,
              p[i].tNodes.backup_nodes_num, p[i].tNodes.backup_nodes[0], p[i].tNodes.backup_nodes[1],
              p[i].has_m2s?"TRUE":"FALSE");
    }

    //m_table_stats.print_stats();
    uint16_t node_stats[DHT_MAX_NODE_NUMBER][3];
    memset( node_stats,0x00,sizeof(uint16_t)*3*DHT_MAX_NODE_NUMBER );
    for(uint32_t i=0;i<m_rte_table.m_seg_num;i++)
    {
         if( m_rte_table.rtEntry[i].tNodes.master_node_id>0 && m_rte_table.rtEntry[i].tNodes.master_node_id<=DHT_MAX_NODE_NUMBER)
            node_stats[m_rte_table.rtEntry[i].tNodes.master_node_id-1][0]++;

         if( m_rte_table.rtEntry[i].tNodes.backup_nodes[0]>0 && m_rte_table.rtEntry[i].tNodes.backup_nodes[0]<=DHT_MAX_NODE_NUMBER)
            node_stats[m_rte_table.rtEntry[i].tNodes.backup_nodes[0]-1][1]++;

         if( m_rte_table.rtEntry[i].tNodes.backup_nodes[1]>0 && m_rte_table.rtEntry[i].tNodes.backup_nodes[1]<=DHT_MAX_NODE_NUMBER)
            node_stats[m_rte_table.rtEntry[i].tNodes.backup_nodes[0]-1][2]++;
    }

    uint16_t ms_stat = 0;
    uint16_t bk1_stat = 0;
    uint16_t bk2_stat = 0;
    printf("\n\n---------------node stats---------------------\n");
    printf("nodeid      master      backup1     backup2\n");
    for( uint32_t i=0;i<DHT_MAX_NODE_NUMBER;i++ )
    {
        if( node_stats[i][0]>0 || node_stats[i][1]>0 || node_stats[i][2]>0 )
        {
            printf("%-12d%-12d%-12d%-12d\n",i+1,node_stats[i][0],node_stats[i][1],node_stats[i][2]);
            ms_stat+=node_stats[i][0];
            bk1_stat+=node_stats[i][1];
            bk2_stat+=node_stats[i][2];
        }
    }
    printf("all         %-12d%-12d%-12d\n",ms_stat,bk1_stat,bk2_stat);
}

CDhtRteTable::CDhtRteTable() {
}

/*���ȳ�ʼ���ڵ�������Ƭ�������ڵ��������������޸�
     * pfCallBack���ڽڵ�������֪ͨ��Ϣ�ص��ӿ�*/
ZENIC_RESULT CDhtRteTable::init(T_DHT_NODE_LIST& tNodes, uint32_t segment_num,
        uint16_t backup_copy)
{
    uint16_t nodes_num;
    nodes_num =(tNodes.node_num>DHT_MAX_NODE_NUMBER?DHT_MAX_NODE_NUMBER:tNodes.node_num);


    //��ʼ���ؼ�����
    m_rte_table.m_rte_entry_num=m_rte_table.m_seg_num = segment_num;
    m_rte_table.m_seg_per_node = nodes_num==0?(uint16_t)-1:m_rte_table.m_seg_num / nodes_num;

    m_rte_table.backup_copy = backup_copy;
    m_rte_table.m_self_node_id = m_self_node_id;
    m_rte_table.tActiveNodes = tNodes;

    initRteTable();

    reorderNodeList(m_rte_table.tActiveNodes);
    //���ɳ�ʼ·�ɱ�

    genRteTable(tNodes, segment_num,backup_copy);

    return RESULT_ZENIC_SUCCESS;
}

/*��ȡ·�ɱ�*/
ZENIC_RESULT CDhtRteTable::getRteTable(T_DHT_RTE_TABLE* ptRteTable)
{
    if(NULL== ptRteTable)
        return ERROR_NULL_POINTER;
    *ptRteTable = m_rte_table;
    return RESULT_ZENIC_SUCCESS;
}

/*�Ƚ�����·�ɱ������ز���·�ɱ���*/
uint16_t CDhtRteTable::compareRteTable(const T_DHT_RTE_TABLE& tRteTable,
        T_ZCS_CHGOVER_RTE_ITEM* chg_rte, uint16_t num)
{
    uint16_t count=0;
    if(tRteTable.m_rte_entry_num!=m_rte_table.m_rte_entry_num)
        return 0;
    for(uint16_t i=0;i<m_rte_table.m_rte_entry_num;i++)
    {
        if(!isEqual(m_rte_table.rtEntry[i],tRteTable.rtEntry[i]))
        {
            chg_rte[count].start_seg = m_rte_table.rtEntry[i].tSegPair.start_idx;
            chg_rte[count].end_seg = m_rte_table.rtEntry[i].tSegPair.end_idx;
            chg_rte[count].new_master = m_rte_table.rtEntry[i].tNodes.master_node_id;
            chg_rte[count].old_master = tRteTable.rtEntry[i].tNodes.master_node_id;
            chg_rte[count].new_backup_node_num = m_rte_table.rtEntry[i].tNodes.backup_nodes_num;
            memcpy(chg_rte[count].new_backup_node, m_rte_table.rtEntry[i].tNodes.backup_nodes,
                    ZCS_MAX_BACKUP_NODE_NUM*sizeof(uint16_t));
            chg_rte[count].old_backup_node_num = tRteTable.rtEntry[i].tNodes.backup_nodes_num;
            memcpy(chg_rte[count].old_backup_node,tRteTable.rtEntry[i].tNodes.backup_nodes,
                    ZCS_MAX_BACKUP_NODE_NUM*sizeof(uint16_t));
            count++;

        }
    }

    return count;
}

/*����·�ɱ�*/
ZENIC_RESULT CDhtRteTable::copyRoutingTable(const T_DHT_RTE_TABLE& tRteTable)
{
    m_rte_table = tRteTable;
    recalcRteStat();
    return RESULT_ZENIC_SUCCESS;
}

/*�Ƚ�����·�ɱ����Ƿ����*/
bool CDhtRteTable::isEqual(const T_DHT_RTE_ENTRY& rtEntry1,
        const T_DHT_RTE_ENTRY& rtEntry2)
{
    if(rtEntry1.tSegPair.start_idx!=rtEntry2.tSegPair.start_idx ||
            rtEntry1.tSegPair.end_idx!=rtEntry2.tSegPair.end_idx ||
            rtEntry1.tNodes.master_node_id !=rtEntry2.tNodes.master_node_id ||
            rtEntry1.tNodes.backup_nodes_num!=rtEntry2.tNodes.backup_nodes_num)
        return false;
    for(uint8_t i=0;i<rtEntry1.tNodes.backup_nodes_num;i++)
    {
        if(rtEntry1.tNodes.backup_nodes[i]!=rtEntry2.tNodes.backup_nodes[i])
            return false;
    }
    return true;
}

//�Խڵ��б���������
void CDhtRteTable::reorderNodeList(T_DHT_NODE_LIST& tNodes)
{
    std::map<uint16_t,T_DHT_NODE> node_map;
    std::map<uint16_t,T_DHT_NODE>::iterator it;
    uint16_t count=0;
    for(uint16_t i=0;i<tNodes.node_num;i++)
    {
        node_map.insert(std::make_pair(tNodes.nodes[i].node_id,tNodes.nodes[i]));
    }

    for(it=node_map.begin();it!=node_map.end();++it)
    {
        tNodes.nodes[count++] = it->second;
    }
    tNodes.node_num = count;
}

/*����һ���ڵ�*/
ZENIC_RESULT CDhtRteTable::insertNode(uint16_t node_id)
{
    if(node_id>DHT_MAX_NODE_NUMBER) return ERROR_INVALID_PARAM;

     uint16_t nodes_num = m_rte_table.tActiveNodes.node_num;
     uint16_t idx;
     bool found = findNode(node_id,idx);
     if(found)
             return ERROR_ALREADY_EXIST;

	 m_rte_table.tActiveNodes.nodes[nodes_num].node_state = DHT_NODE_ACTIVE;
     m_rte_table.tActiveNodes.nodes[nodes_num++].node_id = node_id;
     m_rte_table.tActiveNodes.node_num = nodes_num;

     reorderNodeList(m_rte_table.tActiveNodes);

     return RESULT_ZENIC_SUCCESS;
}

/*�ӽڵ��б���ɾ��һ���ڵ㣬����·�ɱ���*/
ZENIC_RESULT CDhtRteTable::deleteNode(uint16_t node_id)
{
    if(node_id>DHT_MAX_NODE_NUMBER) return ERROR_INVALID_PARAM;
     bool found;
     uint16_t nodes_num = m_rte_table.tActiveNodes.node_num;
     uint16_t idx;
     found = findNode(node_id,idx);

     if(!found)
         return ERROR_RECORD_NOT_FOUND;

     m_rte_table.tActiveNodes.nodes[idx] = m_rte_table.tActiveNodes.nodes[nodes_num-1];
     m_rte_table.tActiveNodes.node_num--;

     reorderNodeList(m_rte_table.tActiveNodes);

     return RESULT_ZENIC_SUCCESS;
}

/*�ڽڵ��б��в��ҽڵ�ID*/
bool CDhtRteTable::findNode(uint16_t node_id, uint16_t &idx)
{
    bool found=false;
    uint16_t nodes_num = m_rte_table.tActiveNodes.node_num;
    uint16_t i;
    for(i=0;i<nodes_num;i++)
    {
        if(m_rte_table.tActiveNodes.nodes[i].node_id==node_id)
        {
            found = true;
            idx = i;
            break;
        }
    }

    return found;
}

/*��ʼ��·�ɱ�Ϊ��Чֵ*/
void CDhtRteTable::initRteTable()
{

    uint16_t seg_idx=0;
    uint16_t num_per_seg = m_rte_table.m_num_per_seg;
    for(uint32_t i=0;i<m_rte_table.m_rte_entry_num;i++)
     {
         m_rte_table.rtEntry[i].tSegPair.start_idx = seg_idx;
         m_rte_table.rtEntry[i].tSegPair.end_idx = seg_idx-1+num_per_seg;
         m_rte_table.rtEntry[i].tNodes.master_node_id = DHT_INVALID_NODE_ID;
         m_rte_table.rtEntry[i].tNodes.backup_nodes_num = 0;
         m_rte_table.rtEntry[i].tNodes.backup_nodes[0]=DHT_INVALID_NODE_ID;
         m_rte_table.rtEntry[i].tNodes.backup_nodes[1]=DHT_INVALID_NODE_ID;
         m_rte_table.rtEntry[i].bRejectSwitchAccess = false;
         seg_idx+=num_per_seg;
     }
}

/*�ڵ�ɾ����·�ɱ��Ĵ�������Ҫ�߼����£�
 * 1�����ڸýڵ������ýڵ㣬��ֱ�ӽ���һ���ڵ���Ϊ���ڵ㣬�������ƴ���
 * 2�����ڸýڵ��Ǳ��ýڵ㣬*/
#ifndef ZCRS_RTE_TABLE_OPT
ZENIC_RESULT CDhtRteTable::adjustAfterRemoveNode(uint16_t node_id)
{
    m_table_stats.removeNode(node_id);
    //����ڵ������Ѿ�Ϊ0��������·�ɱ�
    if(m_rte_table.tActiveNodes.node_num==0)
    {
        this->initRteTable();
        m_table_stats.clear();
        return RESULT_ZENIC_SUCCESS;
    }
    m_rte_table.m_seg_per_node = m_rte_table.m_seg_num/m_rte_table.tActiveNodes.node_num;
    T_DHT_NODES_GROUP tNodes;
    for(uint32_t i=0;i<m_rte_table.m_seg_num;i++)
    {
        m_table_stats.AdjustAfterDeleteNode(node_id,m_rte_table.rtEntry[i].tNodes,tNodes,m_rte_table.rtEntry[i].has_m2s);
        m_rte_table.rtEntry[i].tNodes=tNodes;
   }
    recalcRteStat();
    return RESULT_ZENIC_SUCCESS;
}
#else
ZENIC_RESULT CDhtRteTable::adjustAfterRemoveNode(uint16_t node_id)
{
    m_table_stats.removeNode(node_id);
    //����ڵ������Ѿ�Ϊ0��������·�ɱ�
    if(m_rte_table.tActiveNodes.node_num==0)
    {
        this->initRteTable();
        m_table_stats.clear();
        return RESULT_ZENIC_SUCCESS;
    }
    m_rte_table.m_seg_per_node = m_rte_table.m_seg_num/m_rte_table.tActiveNodes.node_num;
    uint16_t bakup_num = m_table_stats.get_real_backup_copy();

    /*master��backup1���棬���·�ɱ���ɾ���Ľڵ�ID��Ϊ0*/
    for(uint32_t i=0;i<m_rte_table.m_seg_num;i++)
    {
        if( m_rte_table.rtEntry[i].tNodes.master_node_id == node_id )
        {
            m_rte_table.rtEntry[i].tNodes.master_node_id = m_rte_table.rtEntry[i].tNodes.backup_nodes[0];
            m_table_stats.decrease(E_RTE_STATS_MASTER, node_id);
            m_table_stats.decrease(E_RTE_STATS_BACKUP1,m_rte_table.rtEntry[i].tNodes.backup_nodes[0]);
            m_table_stats.increase(E_RTE_STATS_MASTER, m_rte_table.rtEntry[i].tNodes.backup_nodes[0]);
            if(bakup_num == 1)
                m_rte_table.rtEntry[i].tNodes.backup_nodes[0] = DHT_INVALID_NODE_ID;
        }
        
        if( bakup_num>=1 && m_rte_table.rtEntry[i].tNodes.backup_nodes[0]==node_id )
        {
            if( bakup_num == 1 )
                m_rte_table.rtEntry[i].tNodes.backup_nodes[0] = DHT_INVALID_NODE_ID;
            else
            {
                m_rte_table.rtEntry[i].tNodes.backup_nodes[0] = m_rte_table.rtEntry[i].tNodes.backup_nodes[1];
                m_table_stats.increase(E_RTE_STATS_BACKUP1,m_rte_table.rtEntry[i].tNodes.backup_nodes[1]);
                m_table_stats.decrease(E_RTE_STATS_BACKUP2,m_rte_table.rtEntry[i].tNodes.backup_nodes[1]);
                //backup2��ʱ�����ǵ���
            }
        }
        if( bakup_num == 0 )
            m_rte_table.rtEntry[i].tNodes.backup_nodes[0] = DHT_INVALID_NODE_ID;
    
    }

    /*����master���ظ��Ľڵ�*/
    adjMasterDupNodes( DEL_ADJUST_MASTER );
    
    /*ѡ����ʵĽڵ㲹��bakup�б����桢ɾ���Ľڵ�*/
    fill_backup_nodes( );

    /*����bakup���ظ��Ľڵ㣬������ܿ��Է�����Ӧoam��"�����طֲ�����"����*/
    //adjustBackUpNodes( );
    
    //recalcRteStat();/*���õĵ�����adjustBackUpNodes���ܵ�Ӱ��*/
    return RESULT_ZENIC_SUCCESS;
}


/*backup���ж�����ɾ��master�Ľڵ㣬����ʱ���Ϊ0��������Ҫѡ����ʵĽڵ��滻*/
ZENIC_RESULT CDhtRteTable::fill_backup_nodes( void )
{
    uint16_t cur_nodes = 0;
    uint16_t adj_truncks = 0;
    uint16_t bk_cnt = 0;
    uint16_t  fillup_nodes[DHT_MAX_NODE_NUMBER];
    uint16_t  fill_num;
    uint16_t ms_ids[DHT_MAX_NODE_NUMBER];
    uint16_t bk_ids[DHT_MAX_NODE_NUMBER];
    uint16_t ms_num;
    uint16_t  bk_num;
    
    cur_nodes = m_rte_table.tActiveNodes.node_num;
    if( cur_nodes == 0 )
        return RESULT_ZENIC_SUCCESS;

    adj_truncks = m_rte_table.m_seg_num/cur_nodes;
    bk_cnt = m_table_stats.get_real_backup_copy();
	memset(ms_ids,DHT_INVALID_NODE_ID,sizeof(uint16_t)*DHT_MAX_NODE_NUMBER);

    if( 0 == m_rte_table.m_seg_num%cur_nodes )/*����������£���ǰ�������*/
    {
        for( uint32_t i=0;i<adj_truncks;i++ )
        {
            for( uint8_t k=0;k<bk_cnt;k++)
            {
                memset(fillup_nodes,DHT_INVALID_NODE_ID,sizeof(uint16_t)*DHT_MAX_NODE_NUMBER );
                fill_num=0;
                memset(ms_ids,DHT_INVALID_NODE_ID,sizeof(uint16_t)*DHT_MAX_NODE_NUMBER);
                memset(bk_ids,DHT_INVALID_NODE_ID,sizeof(uint16_t)*DHT_MAX_NODE_NUMBER);
                ms_num=0;
                bk_num=0;
                for( uint16_t j=0;j<cur_nodes;j++)
                {
                    if( DHT_INVALID_NODE_ID!= m_rte_table.rtEntry[i*cur_nodes+j].tNodes.backup_nodes[k] )
                        bk_ids[bk_num++]=m_rte_table.rtEntry[i*cur_nodes+j].tNodes.backup_nodes[k];
                    ms_ids[ms_num++]=m_rte_table.rtEntry[i*cur_nodes+j].tNodes.master_node_id;
                }
                fill_num=calc_fill_nodes( ms_ids,ms_num,bk_ids,bk_num,fillup_nodes);

                if( fill_num>1 && (fill_num%2) != 0 && fill_num < DHT_MAX_NODE_NUMBER*2)
                {
                    uint16_t tmp = fillup_nodes[fill_num/2];
                    fillup_nodes[fill_num/2]=fillup_nodes[fill_num/2-1];
                    fillup_nodes[fill_num/2-1]=tmp;
                }
                
                for( uint16_t j=0;j<cur_nodes;j++)
                {
                    uint16_t check_id = m_rte_table.rtEntry[i*cur_nodes+j].tNodes.backup_nodes[k];
                    if( check_id == DHT_INVALID_NODE_ID )
                    {                
                        uint16_t master_id = m_rte_table.rtEntry[i*cur_nodes+j].tNodes.master_node_id;
                        uint16_t fill_id = DHT_INVALID_NODE_ID;
                        if(fill_num <= DHT_MAX_NODE_NUMBER)
                        {
                            fill_id = get_fill_node( master_id,fillup_nodes,fill_num,ms_ids,ms_num);
                        }
                        m_rte_table.rtEntry[i*cur_nodes+j].tNodes.backup_nodes[k] = fill_id;
                        if( fill_id != DHT_INVALID_NODE_ID)
                        {                            
                            if( k == 0)
                            {
                                m_table_stats.increase( E_RTE_STATS_BACKUP1 ,fill_id );
                            }
                            if( k == 1 )
                            {
                                m_table_stats.increase( E_RTE_STATS_BACKUP2 ,fill_id );
                            }
                        }
                    }
                } 
            }
        }   
    }
    else/*������������£��Ӻ���ǰ����*/
    {
        for( uint32_t i=m_rte_table.m_seg_num-cur_nodes;i>=m_rte_table.m_seg_num%cur_nodes;)/*��������*/
        {
            for( uint8_t k=0;k<bk_cnt;k++)
            {
                memset(fillup_nodes,DHT_INVALID_NODE_ID,sizeof(uint16_t)*DHT_MAX_NODE_NUMBER );
                fill_num = 0;
                memset(ms_ids,DHT_INVALID_NODE_ID,sizeof(uint16_t)*DHT_MAX_NODE_NUMBER);
                memset(bk_ids,DHT_INVALID_NODE_ID,sizeof(uint16_t)*DHT_MAX_NODE_NUMBER);
                ms_num=0;
                bk_num=0;
                
                for( uint32_t j=0;j<cur_nodes;j++)
                {
                    if( DHT_INVALID_NODE_ID!= m_rte_table.rtEntry[i+j].tNodes.backup_nodes[k] )
                        bk_ids[bk_num++]=m_rte_table.rtEntry[i+j].tNodes.backup_nodes[k];
                    ms_ids[ms_num++]=m_rte_table.rtEntry[i+j].tNodes.master_node_id;
                }
                fill_num=calc_fill_nodes( ms_ids,ms_num,bk_ids,bk_num,fillup_nodes);
                if( fill_num>1 && (fill_num%2) != 0 && fill_num < DHT_MAX_NODE_NUMBER*2)
                {
                    uint16_t tmp = fillup_nodes[fill_num/2];
                    fillup_nodes[fill_num/2]=fillup_nodes[fill_num/2-1];
                    fillup_nodes[fill_num/2-1]=tmp;
                }
                                
                for( uint16_t j=0;j<cur_nodes;j++)
                {
                    uint16_t check_id = m_rte_table.rtEntry[i+j].tNodes.backup_nodes[k];
                    if( check_id == DHT_INVALID_NODE_ID )
                    {                
                        uint16_t master_id = m_rte_table.rtEntry[i+j].tNodes.master_node_id;
                        uint16_t fill_id = DHT_INVALID_NODE_ID;
                        if(fill_num <= DHT_MAX_NODE_NUMBER)
                        {
                            fill_id = get_fill_node( master_id,fillup_nodes,fill_num,ms_ids,ms_num);
                        }
                        m_rte_table.rtEntry[i+j].tNodes.backup_nodes[k] = fill_id;
                        if( fill_id != DHT_INVALID_NODE_ID )
                        {
                            if( k == 0)
                            {                                
                                m_table_stats.increase( E_RTE_STATS_BACKUP1 ,fill_id );
                            }
                            if( k == 1 )
                            {
                                m_table_stats.increase( E_RTE_STATS_BACKUP2 ,fill_id );
                            }
                        }
                    }
                } 
            }
            if( int32_t(i=i-cur_nodes)<0 )
                break;
        }

        for( uint32_t k = 0;k<bk_cnt; k++ )/*��������*/
        {
            memset(fillup_nodes,DHT_INVALID_NODE_ID,sizeof(uint16_t)*DHT_MAX_NODE_NUMBER );
            fill_num = 0;
            //memset(ms_ids,0x00,sizeof(uint16_t)*DHT_MAX_NODE_NUMBER);
            memset(bk_ids,DHT_INVALID_NODE_ID,sizeof(uint16_t)*DHT_MAX_NODE_NUMBER);
            ms_num=cur_nodes;
            bk_num=0;

            //for( uint32_t j=0;j<m_rte_table.m_seg_num%cur_nodes;j++)
            //{
                //if( 0!= m_rte_table.rtEntry[j].tNodes.backup_nodes[k] )
                //    bk_ids[bk_num++]=m_rte_table.rtEntry[j].tNodes.backup_nodes[k];
                //ms_ids[ms_num++]=m_rte_table.rtEntry[j].tNodes.master_node_id;
            //}

            fill_num=calc_fill_nodes( ms_ids,ms_num,bk_ids,bk_num,fillup_nodes);
            if( fill_num>1 && (fill_num%2) != 0 && fill_num < DHT_MAX_NODE_NUMBER*2)
            {
                uint16_t tmp = fillup_nodes[fill_num/2];
                fillup_nodes[fill_num/2]=fillup_nodes[fill_num/2-1];
                fillup_nodes[fill_num/2-1]=tmp;
            }

            for( uint16_t j=0;j<m_rte_table.m_seg_num%cur_nodes;j++)
            {
                uint16_t check_id = m_rte_table.rtEntry[j].tNodes.backup_nodes[k];
                if( check_id == DHT_INVALID_NODE_ID )
                {                
                    uint16_t master_id = m_rte_table.rtEntry[j].tNodes.master_node_id;
                    uint16_t fill_id = DHT_INVALID_NODE_ID;
                    if(fill_num <= DHT_MAX_NODE_NUMBER)
                    {
                        fill_id = get_fill_node( master_id,fillup_nodes,fill_num,ms_ids,ms_num);
                    }
                    m_rte_table.rtEntry[j].tNodes.backup_nodes[k] = fill_id;
                    if( fill_id != DHT_INVALID_NODE_ID )
                    {
                        if( k == 0)
                        {                            
                            m_table_stats.increase( E_RTE_STATS_BACKUP1 ,fill_id );
                        }
                        if( k == 1 )
                        {
                            m_table_stats.increase( E_RTE_STATS_BACKUP2 ,fill_id );
                        }
                    }
                }
            } 
        }
    }
    return RESULT_ZENIC_SUCCESS;
}

/*ȡ������õĽڵ��滻backupΪ0�Ľڵ�*/
uint16_t CDhtRteTable::get_fill_node( uint16_t filter_master,uint16_t *fill_nodes,uint16_t &fill_num,uint16_t *ms_ids,uint16_t ms_num )
{
    uint16_t retid= 0;
    
    if( fill_num == 0 )
        return DHT_INVALID_NODE_ID;
    
    for( int16_t j=fill_num-1;j>=0;j-- )
    {
        if( fill_nodes[j] != DHT_INVALID_NODE_ID && fill_nodes[j]!=filter_master )
        {
            retid=fill_nodes[j];
            fill_nodes[j]=DHT_INVALID_NODE_ID;
            for( uint16_t k=j;k<fill_num;k++ )
            {
                if(k < fill_num-1)
                {
                    fill_nodes[k]=fill_nodes[k+1];
                }
                else
                {
                    fill_nodes[k]=DHT_INVALID_NODE_ID;
                }
            }
            fill_num--;
            return retid;
        }
    }
    return DHT_INVALID_NODE_ID;
}

/*�������Ҫ���backupΪ0�Ľڵ�*/
uint16_t CDhtRteTable::calc_fill_nodes( uint16_t *ms_ids,uint16_t ms_num,uint16_t *bk_ids, uint16_t bk_num ,uint16_t *fill_nodes)
{
   memcpy( fill_nodes,ms_ids,ms_num*sizeof(uint16_t));
   return ms_num;
}


#endif


//���½���·�ɱ���ͳ����Ϣ������ÿ���ڵ�е������á����÷�Ƭ����
void CDhtRteTable::recalcRteStat()
{
    m_table_stats.init(m_rte_table);
}

inline bool CDhtRteTable::isNodeInGroup(uint16_t node_id,
        const T_DHT_NODES_GROUP& tGrp)
{

    if(node_id==tGrp.master_node_id)
        return true;
    for(uint16_t i=0;i<tGrp.backup_nodes_num;i++)
    {
        if(tGrp.backup_nodes[i]==node_id)
            return true;
    }
    return false;
}

CDhtRteTable::~CDhtRteTable() {
    // TODO Auto-generated destructor stub
}

//����Resource_id����·�ɱ����±�
inline uint16_t CDhtRteTable::getSegIdxByRID(uint16_t hash_v,uint32_t seg_num)
{
    return (uint16_t)(hash_v / seg_num);
}
#ifdef ZCRS_RTE_TABLE_OPT
uint32_t CDhtRteTable::getAdjNodes( uint8_t *nodes_cur_chunk,uint16_t cur_len,uint16_t *nodes_adj ,uint16_t adj_len)
{
    uint8_t all_nodes[DHT_MAX_NODE_NUMBER];
    uint32_t adj_num = 0;

    memset(all_nodes,0x00,sizeof(uint8_t)*DHT_MAX_NODE_NUMBER);

    for( uint32_t i = 0;i<m_rte_table.tActiveNodes.node_num;i++ )
        all_nodes[m_rte_table.tActiveNodes.nodes[i].node_id-1]=1;

    for( uint32_t i=0;i<cur_len&&i<DHT_MAX_NODE_NUMBER;i++ )
        all_nodes[i] ^= nodes_cur_chunk[i];

    for( uint32_t i=0;i<cur_len&&i<DHT_MAX_NODE_NUMBER;i++ )
    {
        if( all_nodes[i] != 0 )
        {
            nodes_adj[adj_num]=i+1;
            adj_num++;
        }
    }
    return adj_num;
}

uint32_t CDhtRteTable::getDupNode( uint16_t *node_id_arr,uint32_t cur_nodes)
{
    uint16_t tmp_arr[DHT_MAX_NODE_NUMBER];
    uint16_t dup_num = 0;
    
    memset((uint8_t*)&tmp_arr,0x00,sizeof(uint16_t)*DHT_MAX_NODE_NUMBER);
    for( uint32_t i=0;i<cur_nodes;i++ )
    {
        if( node_id_arr[i]<=DHT_MAX_NODE_NUMBER &&node_id_arr[i]>0 )
            ++tmp_arr[node_id_arr[i]-1];
    }

    for( uint32_t i=0;i<DHT_MAX_NODE_NUMBER;i++ )
    {
        if( tmp_arr[i] >= 2 )
        {
            for(uint32_t j= tmp_arr[i];j>1;j--)
            {
                node_id_arr[dup_num]= i+1;
                dup_num++;
            }
        }
    }
    
    return dup_num;
}

void  CDhtRteTable::calc_adj_pos( uint16_t *node_arr,uint16_t node_num,uint16_t *adj_pos_arr,uint16_t &pos_num )
{
    uint16_t node_stat[DHT_MAX_NODE_NUMBER];
    pos_num = 0;

    if( node_num == 0 || node_num > DHT_MAX_NODE_NUMBER)
        return;
    
    memset((uint8_t*)&node_stat,0x00,sizeof(uint16_t)*DHT_MAX_NODE_NUMBER);
    for( uint32_t i=0;i<node_num;i++ )
    {
        if( node_arr[i]<=DHT_MAX_NODE_NUMBER &&node_arr[i]>0 )
            ++node_stat[node_arr[i]-1];
    }

    for( uint32_t i=0;i<node_num;i++ )
    {
        if( node_arr[i]<=DHT_MAX_NODE_NUMBER &&node_arr[i]>0 )
        {
            if( node_stat[node_arr[i]-1]>0 )
            {
                if( (node_stat[node_arr[i]-1]-1)>0 )
                {
                    adj_pos_arr[pos_num++]=i;
                    node_stat[node_arr[i]-1]--;
                }
            }
        }
    }
    return;
}


uint16_t CDhtRteTable::calc_adj_master( uint16_t *adj_arr,uint16_t &adj_num )//�˺�����Ҫ����
{
    if( adj_num > DHT_MAX_NODE_NUMBER)
        return DHT_INVALID_NODE_ID;
    for( int16_t i = adj_num-1; i>=0;i-- )
    {
        if( adj_arr[i]>0 && adj_arr[i]<=DHT_MAX_NODE_NUMBER  )
        {
            uint16_t retid = adj_arr[i];
            adj_arr[i] = DHT_INVALID_NODE_ID;
            adj_num--;
            return retid;
        }
    }
    return DHT_INVALID_NODE_ID;
}

ZENIC_RESULT CDhtRteTable::adjMasterDupNodes( uint8_t adj_flag )
{
    uint16_t nodes_adj[DHT_MAX_NODE_NUMBER];
    uint16_t adj_num = 0;
    uint16_t pos_num = 0;
    
    uint16_t adj_pos_arr[DHT_MAX_NODE_NUMBER];
    uint8_t nodes_cur_chunk[DHT_MAX_NODE_NUMBER];
    uint16_t nodes_arr[DHT_MAX_NODE_NUMBER];


    uint16_t cur_nodes = m_table_stats.getNodeCount();
    if( cur_nodes == 0 )
        return RESULT_ZENIC_SUCCESS;

    uint32_t insert_chunks = m_rte_table.m_seg_num/cur_nodes;

    memset(m_adj_record,0x00,sizeof(uint8_t)*DHT_MAX_RTE_ENTRY);

    if( 0 == m_rte_table.m_seg_num%cur_nodes )/*��������£�����˳���ǰ����*/
    {
        for(uint32_t i=0;i<insert_chunks;i++) 
        {
            memset(nodes_cur_chunk,0x00,sizeof(uint8_t)*DHT_MAX_NODE_NUMBER);
            memset(nodes_arr,DHT_INVALID_NODE_ID,sizeof(uint16_t)*DHT_MAX_NODE_NUMBER);
            memset(nodes_adj,DHT_INVALID_NODE_ID,sizeof(uint16_t)*DHT_MAX_NODE_NUMBER);
            memset(adj_pos_arr,0x00,sizeof(uint16_t)*DHT_MAX_NODE_NUMBER);
             
            for( uint32_t j=0;j<cur_nodes;j++ )
            {
                if( m_rte_table.rtEntry[i*cur_nodes+j].tNodes.master_node_id <= DHT_MAX_NODE_NUMBER )
                    nodes_cur_chunk[m_rte_table.rtEntry[i*cur_nodes+j].tNodes.master_node_id-1 ] = 1;
                nodes_arr[j]=m_rte_table.rtEntry[i*cur_nodes+j].tNodes.master_node_id;
            }
              
            adj_num = getAdjNodes( (uint8_t*)nodes_cur_chunk ,(uint16_t)DHT_MAX_NODE_NUMBER,(uint16_t*)nodes_adj,(uint16_t)DHT_MAX_NODE_NUMBER );
            calc_adj_pos(nodes_arr,cur_nodes,adj_pos_arr,pos_num);
            //������master
            for( uint32_t j = 0;j<pos_num; j++ )
            {
                T_DHT_NODES_GROUP tOldNodes = m_rte_table.rtEntry[i*cur_nodes+adj_pos_arr[j]].tNodes;
                uint16_t ms_id=m_rte_table.rtEntry[i*cur_nodes+adj_pos_arr[j]].tNodes.master_node_id;
                uint16_t backup_id = m_rte_table.rtEntry[i*cur_nodes+adj_pos_arr[j]].tNodes.backup_nodes[0];
                
                if(  ADD_ADJUST_MASTER== adj_flag || (DEL_ADJUST_MASTER==adj_flag&&DHT_INVALID_NODE_ID != backup_id) )
                {
                    uint16_t adj_id = calc_adj_master(nodes_adj,adj_num );
                    if( adj_id >0 && adj_id != DHT_INVALID_NODE_ID)
                    {
                        if( adj_id != backup_id )
                        {
                            m_rte_table.rtEntry[i*cur_nodes+adj_pos_arr[j]].tNodes.backup_nodes[0]= ms_id;
                            m_rte_table.rtEntry[i*cur_nodes+adj_pos_arr[j]].tNodes.master_node_id=adj_id;                          
                        }
                        else
                        {
                            m_rte_table.rtEntry[i*cur_nodes+adj_pos_arr[j]].tNodes.master_node_id=m_rte_table.rtEntry[i*cur_nodes+adj_pos_arr[j]].tNodes.backup_nodes[0];
                            m_rte_table.rtEntry[i*cur_nodes+adj_pos_arr[j]].tNodes.backup_nodes[0]=ms_id;
                        }
                        m_table_stats.adjustCounter( m_rte_table.rtEntry[i*cur_nodes+adj_pos_arr[j]].tNodes,tOldNodes);
                        m_adj_record[i*cur_nodes+adj_pos_arr[j]] |= RTAB_ADJ_BACKUP1;  
                    }
                }
                if( DEL_ADJUST_MASTER== adj_flag && DHT_INVALID_NODE_ID == backup_id )
                {
                    uint16_t adj_id = calc_adj_master(nodes_adj,adj_num);
                    if( adj_id>0 && adj_id != DHT_INVALID_NODE_ID)
                    {
                        
                        m_rte_table.rtEntry[i*cur_nodes+adj_pos_arr[j]].tNodes.backup_nodes[0]=ms_id;
                        m_rte_table.rtEntry[i*cur_nodes+adj_pos_arr[j]].tNodes.master_node_id=adj_id;
                        m_table_stats.adjustCounter( m_rte_table.rtEntry[i*cur_nodes+adj_pos_arr[j]].tNodes,tOldNodes);
                        m_adj_record[i*cur_nodes+adj_pos_arr[j]] |= RTAB_ADJ_BACKUP1;
                    }
                }
                if( adj_num ==0 )
                    break;
            }
            m_rte_table.rtEntry[i].tNodes.backup_nodes_num = m_table_stats.get_real_backup_copy();
        }
    }
    else/*����������£�����˳��Ӻ���ǰ*/
    {
        for( uint32_t i=m_rte_table.m_seg_num-cur_nodes;i>=m_rte_table.m_seg_num%cur_nodes;) 
        {
            memset(nodes_cur_chunk,0x00,sizeof(uint8_t)*DHT_MAX_NODE_NUMBER);
            memset(nodes_arr,DHT_INVALID_NODE_ID,sizeof(uint16_t)*DHT_MAX_NODE_NUMBER);
            memset(nodes_adj,DHT_INVALID_NODE_ID,sizeof(uint16_t)*DHT_MAX_NODE_NUMBER);
            memset(adj_pos_arr,0x00,sizeof(uint16_t)*DHT_MAX_NODE_NUMBER);
            
            for( uint32_t j=0;j<cur_nodes;j++ )
            {
              if( m_rte_table.rtEntry[i+j].tNodes.master_node_id <= DHT_MAX_NODE_NUMBER )
                  nodes_cur_chunk[m_rte_table.rtEntry[i+j].tNodes.master_node_id-1 ] = 1;
              nodes_arr[j]=m_rte_table.rtEntry[i+j].tNodes.master_node_id;
            }
              
            adj_num = getAdjNodes( (uint8_t*)nodes_cur_chunk ,(uint16_t)DHT_MAX_NODE_NUMBER,(uint16_t*)nodes_adj,(uint16_t)DHT_MAX_NODE_NUMBER );
            calc_adj_pos(nodes_arr,cur_nodes,adj_pos_arr,pos_num);
              
            for( uint32_t j=0;j<pos_num;j++ )
            {
                T_DHT_NODES_GROUP tOldNodes = m_rte_table.rtEntry[i+adj_pos_arr[j]].tNodes;
                uint16_t ms_id=m_rte_table.rtEntry[i+adj_pos_arr[j]].tNodes.master_node_id;
                uint16_t backup_id = m_rte_table.rtEntry[i+adj_pos_arr[j]].tNodes.backup_nodes[0];

                if(ADD_ADJUST_MASTER== adj_flag || (DEL_ADJUST_MASTER==adj_flag&&DHT_INVALID_NODE_ID != backup_id) )
                {
                    uint16_t adj_id = calc_adj_master(nodes_adj,adj_num);
                    if( adj_id >0 && adj_id != DHT_INVALID_NODE_ID)
                    {
                        if( adj_id != backup_id )
                        {
                            m_rte_table.rtEntry[i+adj_pos_arr[j]].tNodes.backup_nodes[0]= ms_id;
                            m_rte_table.rtEntry[i+adj_pos_arr[j]].tNodes.master_node_id=adj_id;                          
                        }
                        else
                        {
                            m_rte_table.rtEntry[i+adj_pos_arr[j]].tNodes.master_node_id=m_rte_table.rtEntry[i+adj_pos_arr[j]].tNodes.backup_nodes[0];
                            m_rte_table.rtEntry[i+adj_pos_arr[j]].tNodes.backup_nodes[0]=ms_id;
                        }
                        m_table_stats.adjustCounter( m_rte_table.rtEntry[i+adj_pos_arr[j]].tNodes,tOldNodes);
                        m_adj_record[i+adj_pos_arr[j]] |= RTAB_ADJ_BACKUP1;  
                    }
                }
                if( DEL_ADJUST_MASTER== adj_flag && DHT_INVALID_NODE_ID == backup_id)
                {
                    uint16_t adj_id = calc_adj_master(nodes_adj,adj_num);
                    if( adj_id>0 && adj_id != DHT_INVALID_NODE_ID)
                    {
                        m_rte_table.rtEntry[i+adj_pos_arr[j]].tNodes.backup_nodes[0]=ms_id;
                        m_rte_table.rtEntry[i+adj_pos_arr[j]].tNodes.master_node_id=adj_id;
                        m_table_stats.adjustCounter( m_rte_table.rtEntry[i+adj_pos_arr[j]].tNodes,tOldNodes);
                        m_adj_record[i+adj_pos_arr[j]] |= RTAB_ADJ_BACKUP1;
                    }
                }
                if( adj_num ==0 )
                    break;
                m_rte_table.rtEntry[i].tNodes.backup_nodes_num = m_table_stats.get_real_backup_copy();
            }

            if( int32_t(i=i-cur_nodes)<0 )
                break;
        }

         memset(nodes_cur_chunk,0x00,sizeof(uint8_t)*DHT_MAX_NODE_NUMBER);
         memset(nodes_arr,DHT_INVALID_NODE_ID,sizeof(uint16_t)*DHT_MAX_NODE_NUMBER);
         
         cur_nodes = m_rte_table.m_seg_num%cur_nodes;
         for( uint32_t j=0;j<cur_nodes;j++ )
         {
             if( m_rte_table.rtEntry[j].tNodes.master_node_id <= DHT_MAX_NODE_NUMBER )
                 nodes_cur_chunk[m_rte_table.rtEntry[j].tNodes.master_node_id-1 ] = 1;
             nodes_arr[j]=m_rte_table.rtEntry[j].tNodes.master_node_id;
         }
             
        adj_num = getAdjNodes( (uint8_t*)nodes_cur_chunk ,(uint16_t)DHT_MAX_NODE_NUMBER,(uint16_t*)nodes_adj,(uint16_t)DHT_MAX_NODE_NUMBER );
         calc_adj_pos(nodes_arr,cur_nodes,adj_pos_arr,pos_num);
    
         for( uint32_t j=0;j<pos_num;j++ )
         {
            T_DHT_NODES_GROUP tOldNodes = m_rte_table.rtEntry[adj_pos_arr[j]].tNodes;
            uint16_t ms_id=m_rte_table.rtEntry[adj_pos_arr[j]].tNodes.master_node_id;
            uint16_t backup_id = m_rte_table.rtEntry[adj_pos_arr[j]].tNodes.backup_nodes[0];

            if(    ADD_ADJUST_MASTER== adj_flag || (DEL_ADJUST_MASTER==adj_flag&&DHT_INVALID_NODE_ID != backup_id) )
            {
                uint16_t adj_id = calc_adj_master(nodes_adj,adj_num);
                if( adj_id >0 && adj_id != DHT_INVALID_NODE_ID)
                {
                    if( adj_id != backup_id )
                    {
                        m_rte_table.rtEntry[adj_pos_arr[j]].tNodes.backup_nodes[0]= ms_id;
                        m_rte_table.rtEntry[adj_pos_arr[j]].tNodes.master_node_id=adj_id;                          
                    }
                    else
                    {
                        m_rte_table.rtEntry[adj_pos_arr[j]].tNodes.master_node_id=m_rte_table.rtEntry[adj_pos_arr[j]].tNodes.backup_nodes[0];
                        m_rte_table.rtEntry[adj_pos_arr[j]].tNodes.backup_nodes[0]=ms_id;
                    }
                    m_table_stats.adjustCounter( m_rte_table.rtEntry[adj_pos_arr[j]].tNodes,tOldNodes);
                    m_adj_record[adj_pos_arr[j]] |= RTAB_ADJ_BACKUP1;  
                }
            }
            if( DEL_ADJUST_MASTER== adj_flag && DHT_INVALID_NODE_ID == backup_id )
            {
                uint16_t adj_id = calc_adj_master(nodes_adj,adj_num);
                if( adj_id>0 && adj_id != DHT_INVALID_NODE_ID)
                {
                    m_rte_table.rtEntry[adj_pos_arr[j]].tNodes.backup_nodes[0]=ms_id;
                    m_rte_table.rtEntry[adj_pos_arr[j]].tNodes.master_node_id=adj_id;
                    m_table_stats.adjustCounter( m_rte_table.rtEntry[adj_pos_arr[j]].tNodes,tOldNodes);
                    m_adj_record[adj_pos_arr[j]] |= RTAB_ADJ_BACKUP1;
                }
            }
            if( adj_num ==0 )
                break;
            m_rte_table.rtEntry[j].tNodes.backup_nodes_num = m_table_stats.get_real_backup_copy();
        }
    }

    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CDhtRteTable::adjustBackUpNodes( void )
{
    uint32_t cur_nodes = 0;
    uint32_t adj_truncks = 0;
    uint16_t node_id_arr[ZCS_MAX_BACKUP_NODE_NUM][DHT_MAX_NODE_NUMBER];
    uint8_t  nodes_cur_chunk[ZCS_MAX_BACKUP_NODE_NUM][DHT_MAX_NODE_NUMBER];
    uint16_t nodes_adj[DHT_MAX_NODE_NUMBER];
    uint32_t adj_num = 0;
    uint32_t dup_num = 0;
    uint32_t bk_cnt = 0;
    //uint8_t  adj_flag[3]={ RTAB_ADJ_MASTER,RTAB_ADJ_BACKUP1,RTAB_ADJ_BACKUP2};


    cur_nodes = m_rte_table.tActiveNodes.node_num;
    if( cur_nodes == 0 )
        return RESULT_ZENIC_SUCCESS;

    adj_truncks = m_rte_table.m_seg_num/cur_nodes;
    bk_cnt = m_table_stats.get_real_backup_copy();
    bk_cnt = bk_cnt < ZCS_MAX_BACKUP_NODE_NUM ? bk_cnt : ZCS_MAX_BACKUP_NODE_NUM;
    if( 0 == m_rte_table.m_seg_num%cur_nodes)/*��������£���ǰ�����滻*/
    {
        for( uint32_t i = 0; i<adj_truncks; i++ )
        {
            memset( nodes_cur_chunk,0x00,sizeof(uint8_t)*DHT_MAX_NODE_NUMBER);
            memset( node_id_arr,DHT_INVALID_NODE_ID,sizeof(uint16_t)*DHT_MAX_NODE_NUMBER);

            for( uint32_t bk = 0;bk<bk_cnt;bk++ )
            {
                for( uint32_t j =0;j<cur_nodes;j++ )
                {
                    if( m_rte_table.rtEntry[i*cur_nodes+j].tNodes.backup_nodes[bk]>0 \
                    && m_rte_table.rtEntry[i*cur_nodes+j].tNodes.backup_nodes[bk] <= DHT_MAX_NODE_NUMBER )
                    {
                        node_id_arr[bk][j] = m_rte_table.rtEntry[i*cur_nodes+j].tNodes.backup_nodes[bk];
                        nodes_cur_chunk[bk][ m_rte_table.rtEntry[i*cur_nodes+j].tNodes.backup_nodes[bk]-1] = 1;
                    }                
                }   
            }
            for( uint32_t bk = 0;bk<bk_cnt;bk++ )
            {
                adj_num = getAdjNodes( (uint8_t*)nodes_cur_chunk[bk] ,(uint16_t)DHT_MAX_NODE_NUMBER,(uint16_t*)nodes_adj,(uint16_t)DHT_MAX_NODE_NUMBER );
                dup_num = getDupNode( node_id_arr[bk],cur_nodes);
                if( dup_num > DHT_MAX_NODE_NUMBER)
                    return RESULT_ZENIC_SUCCESS;
                for( uint32_t k = 0; k<dup_num;k++ )
                {
                    for( int32_t j =cur_nodes-1;j>=0;j-- )
                    {
                        if( m_rte_table.rtEntry[i*cur_nodes+j].tNodes.backup_nodes[bk] == node_id_arr[bk][k]\
                            && m_rte_table.rtEntry[i*cur_nodes+j].tNodes.master_node_id != nodes_adj[adj_num-1]\
                            /*&& (m_adj_record[i*cur_nodes+j]&adj_flag[k+1]) == 0*/ )
                        {
                            if( bk ==0 )
                            {
                                m_table_stats.decrease(E_RTE_STATS_BACKUP1,m_rte_table.rtEntry[i*cur_nodes+j].tNodes.backup_nodes[bk]);
                                m_table_stats.increase(E_RTE_STATS_BACKUP1,nodes_adj[adj_num-1]);
                            }
                            if( bk == 1)
                            {
                                m_table_stats.decrease(E_RTE_STATS_BACKUP2,m_rte_table.rtEntry[i*cur_nodes+j].tNodes.backup_nodes[bk]);
                                m_table_stats.increase(E_RTE_STATS_BACKUP2,nodes_adj[adj_num-1]);
                            }
        
                            m_rte_table.rtEntry[i*cur_nodes+j].tNodes.backup_nodes[bk] = nodes_adj[adj_num-1];
                            adj_num--;
                            break;
                        }
                    }
                    if( adj_num == 0)
                        break;
                }
                if( adj_num == 0)
                    break;
            }
        }
    }
    else/*����������£��Ӻ���ǰ�滻*/
    {
        for( uint32_t i=m_rte_table.m_seg_num-cur_nodes;i>=m_rte_table.m_seg_num%cur_nodes;) 
        {
            memset( nodes_cur_chunk,0x00,sizeof(uint8_t)*DHT_MAX_NODE_NUMBER);
            memset( node_id_arr,DHT_INVALID_NODE_ID,sizeof(uint16_t)*DHT_MAX_NODE_NUMBER);
            
            for( uint32_t bk = 0;bk<bk_cnt;bk++ )
            {
                for( uint32_t j =0;j<cur_nodes;j++ )
                {
                    if( m_rte_table.rtEntry[i+j].tNodes.backup_nodes[bk]>0 \
                    && m_rte_table.rtEntry[i+j].tNodes.backup_nodes[bk] <= DHT_MAX_NODE_NUMBER )
                    {
                        node_id_arr[bk][j] = m_rte_table.rtEntry[i+j].tNodes.backup_nodes[bk];
                        nodes_cur_chunk[bk][ m_rte_table.rtEntry[i+j].tNodes.backup_nodes[bk]-1] = 1;
                    }                
                }   
            }
            for( uint32_t bk = 0;bk<bk_cnt;bk++ )
            {
                adj_num = getAdjNodes( (uint8_t*)nodes_cur_chunk[bk] ,(uint16_t)DHT_MAX_NODE_NUMBER,(uint16_t*)nodes_adj,(uint16_t)DHT_MAX_NODE_NUMBER );
                dup_num = getDupNode( node_id_arr[bk],cur_nodes);
                if( dup_num > DHT_MAX_NODE_NUMBER)
                    return RESULT_ZENIC_SUCCESS;
                for( uint32_t k = 0; k<dup_num;k++ )
                {
                    for( uint32_t j =0;j<cur_nodes;j++ )
                    {
                        if( m_rte_table.rtEntry[i+j].tNodes.backup_nodes[bk] == node_id_arr[bk][k]\
                            && m_rte_table.rtEntry[i+j].tNodes.master_node_id != nodes_adj[adj_num-1]\
                            /*&& (m_adj_record[i+j]&adj_flag[k+1]) == 0*/ )
                        {
                            if( bk ==0 )
                            {
                                m_table_stats.decrease(E_RTE_STATS_BACKUP1,m_rte_table.rtEntry[i+j].tNodes.backup_nodes[bk]);
                                m_table_stats.increase(E_RTE_STATS_BACKUP1,nodes_adj[adj_num-1]);
                            }
                            if( bk == 1)
                            {
                                m_table_stats.decrease(E_RTE_STATS_BACKUP2,m_rte_table.rtEntry[i+j].tNodes.backup_nodes[bk]);
                                m_table_stats.increase(E_RTE_STATS_BACKUP2,nodes_adj[adj_num-1]);
                            }
        
                            m_rte_table.rtEntry[i+j].tNodes.backup_nodes[bk] = nodes_adj[adj_num-1];
                            adj_num--;
                            break;
                        }
                    }
                    if( adj_num == 0)
                        break;
                }
                if( adj_num == 0)
                    break;
            }
            if( int32_t(i=i-cur_nodes)<0 )
                break;
        }

        memset( nodes_cur_chunk,0x00,sizeof(uint8_t)*DHT_MAX_NODE_NUMBER);
        memset( node_id_arr,DHT_INVALID_NODE_ID,sizeof(uint16_t)*DHT_MAX_NODE_NUMBER);
        
        for( uint32_t bk = 0;bk<bk_cnt;bk++ )
        {
            for( uint32_t j =0;j<m_rte_table.m_seg_num%cur_nodes;j++ )
            {
                if( m_rte_table.rtEntry[j].tNodes.backup_nodes[bk]>0&& m_rte_table.rtEntry[j].tNodes.backup_nodes[bk] <= DHT_MAX_NODE_NUMBER )
                {
                    node_id_arr[bk][j] = m_rte_table.rtEntry[j].tNodes.backup_nodes[bk];
                    nodes_cur_chunk[bk][ m_rte_table.rtEntry[j].tNodes.backup_nodes[bk]-1] = 1;
                }                
            }   
        }
        
        for( uint32_t bk = 0;bk<bk_cnt;bk++ )
        {
            adj_num = getAdjNodes( (uint8_t*)nodes_cur_chunk[bk] ,(uint16_t)DHT_MAX_NODE_NUMBER,(uint16_t*)nodes_adj,(uint16_t)DHT_MAX_NODE_NUMBER );
            dup_num = getDupNode( node_id_arr[bk],cur_nodes);
            if( dup_num > DHT_MAX_NODE_NUMBER)
                return RESULT_ZENIC_SUCCESS;
            for( uint32_t k = 0; k<dup_num;k++ )
            {
                for( uint32_t j=0;j<m_rte_table.m_seg_num%cur_nodes;j++ )
                {
                    if( m_rte_table.rtEntry[j].tNodes.backup_nodes[bk] == node_id_arr[bk][k]\
                        && m_rte_table.rtEntry[j].tNodes.master_node_id != nodes_adj[adj_num-1]\
                        /*&& (m_adj_record[j]&adj_flag[k+1]) == 0*/ )
                    {
                        if( bk ==0 )
                        {
                            m_table_stats.decrease(E_RTE_STATS_BACKUP1,m_rte_table.rtEntry[j].tNodes.backup_nodes[bk]);
                            m_table_stats.increase(E_RTE_STATS_BACKUP1,nodes_adj[adj_num-1]);
                        }
                        if( bk == 1)
                        {
                            m_table_stats.decrease(E_RTE_STATS_BACKUP2,m_rte_table.rtEntry[j].tNodes.backup_nodes[bk]);
                            m_table_stats.increase(E_RTE_STATS_BACKUP2,nodes_adj[adj_num-1]);
                        }
        
                        m_rte_table.rtEntry[j].tNodes.backup_nodes[bk] = nodes_adj[adj_num-1];
                        adj_num--;
                        break;
                    }
                }
                if( adj_num == 0)
                    break;
            }
            if( adj_num == 0)
                break;
        }

    }

    return RESULT_ZENIC_SUCCESS;
}
#endif


