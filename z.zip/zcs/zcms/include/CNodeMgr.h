/*
 * CNodeMgr.h
 *
 *  Created on: 2014-8-31
 *      Author: wangjun
 */

#ifndef CNODEMGR_H_
#define CNODEMGR_H_

#include "zcms_common.h"
#include "CInstMgr.hpp"
#include "CZcmsMgr.h"
#include "CNodeConfig.h"
#include "zenic_zbt.hpp"

struct T_ACS_PHY_ADDR {
    uint8_t ucRackId;
    uint8_t ucShelfId;
    uint8_t ucSlotId;
    uint8_t ucCpuId;
};

struct T_LOGIC_ADDR_ALLOC {
    uint8_t ucRackId;
    uint8_t ucShelfId;
    uint8_t ucSlotId;
    uint8_t ucCpuId;
    uint16_t wModule;
    uint16_t wUnit;
    uint16_t wNodeID;
};

static const T_LOGIC_ADDR_ALLOC g_tSysNodeLa[ZCS_MAX_NODE_NUM]={
    {1,1,1,1,OMP_MODULE,OMP_UNIT,ZCS_MASTER_NODE_ID_1},{1,1,2,1,OMP_MODULE,OMP_UNIT,ZCS_MASTER_NODE_ID_2},
    {1,1,3,1,2,1,2},
    {1,1,4,1,3,1,3}, {1,1,5,1,4,1,4}, {1,1,6,1,5,1,5},{1,1,7,1,6,1,6},
    {1,1,8,1,7,1,7}, {1,1,9,1,8,1,8}, {1,1,10,1,9,1,9}, {1,1,11,1,10,1,10},
    {1,1,12,1,11,1,11}, {1,1,13,1,12,1,12},{1,1,14,1,13,1,13},{1,1,15,1,14,1,14},
    {1,1,16,1,15,1,15}, {1,1,17,1,16,1,16},{1,1,18,1,17,1,17},{1,1,19,1,18,1,18},
    {1,1,20,1,19,1,19}, {1,1,21,1,20,1,20},{1,1,22,1,21,1,21},{1,1,23,1,22,1,22},
    {1,1,24,1,23,1,23}, {1,2,1,1,24,1,24}, {1,2,2,1,25,1,25},{1,2,3,1,26,1,26},
    {1,2,4,1,27,1,27}, {1,2,5,1,28,1,28}, {1,2,6,1,29,1,29}, {1,2,7,1,30,1,30},
    {1,2,8,1,31,1,31}, {1,2,9,1,32,1,32}, {1,2,10,1,33,1,33}, {1,2,11,1,34,1,34},
    {1,2,12,1,35,1,35}, {1,2,13,1,36,1,36}, {1,2,14,1,37,1,37}, {1,2,15,1,38,1,38},
    {1,2,16,1,39,1,39}, {1,2,17,1,40,1,40}, {1,2,18,1,41,1,41}, {1,2,19,1,42,1,42},
    {1,2,20,1,43,1,43}, {1,2,21,1,44,1,44}, {1,2,22,1,45,1,45}, {1,2,23,1,46,1,46},
    {1,2,24,1,47,1,47}, {1,3,1,1,48,1,48}, {1,3,2,1,49,1,49}, {1,3,3,1,50,1,50},
    {1,3,4,1,51,1,51}, {1,3,5,1,52,1,52}, {1,3,6,1,53,1,53}, {1,3,7,1,54,1,54},
    {1,3,8,1,55,1,55}, {1,3,9,1,56,1,56}, {1,3,10,1,57,1,57}, {1,3,11,1,58,1,58},
    {1,3,12,1,59,1,59}, {1,3,13,1,60,1,60}, {1,3,14,1,61,1,61}, {1,3,15,1,62,1,62},
    {1,3,16,1,63,1,63}, {1,3,17,1,64,1,64}, {1,3,18,1,65,1,65},{1,3,19,1,66,1,66},
    {1,3,20,1,67,1,67}, {1,3,21,1,68,1,68}, {1,3,22,1,69,1,69},{1,3,23,1,70,1,70},
    {1,3,24,1,71,1,71}, {1,4,1,1,72,1,72}, {1,4,2,1,73,1,73},{1,4,3,1,74,1,74},
    {1,4,4,1,75,1,75}, {1,4,5,1,76,1,76},{1,4,6,1,77,1,77},{1,4,7,1,78,1,78},
    {1,4,8,1,79,1,79}, {1,4,9,1,80,1,80},{1,4,10,1,81,1,81},{1,4,11,1,82,1,82},
    {1,4,12,1,83,1,83},{1,4,13,1,84,1,84},{1,4,14,1,85,1,85},{1,4,15,1,86,1,86},
    {1,4,16,1,87,1,87},{1,4,17,1,88,1,88},{1,4,18,1,89,1,89},{1,4,19,1,90,1,90},
    {1,4,20,1,91,1,91},{1,4,21,1,92,1,92},{1,4,22,1,93,1,93},{1,4,23,1,94,1,94},
    {1,4,24,1,95,1,95},
    {2,1,1,1,96,1,96},{2,1,2,1,97,1,97},{2,1,3,1,98,1,98},{2,1,4,1,99,1,99},
    {2,1,5,1,100,1,100},{2,1,6,1,101,1,101},{2,1,7,1,102,1,102},{2,1,8,1,103,1,103},
    {2,1,9,1,104,1,104},{2,1,10,1,105,1,105},{2,1,11,1,106,1,106},{2,1,12,1,107,1,107},
    {2,1,13,1,108,1,108},{2,1,14,1,109,1,109},{2,1,15,1,110,1,110},{2,1,16,1,111,1,111},
    {2,1,17,1,112,1,112},{2,1,18,1,113,1,113},{2,1,19,1,114,1,114},{2,1,20,1,115,1,115},
    {2,1,21,1,116,1,116},{2,1,22,1,117,1,117},{2,1,23,1,118,1,118},{2,1,24,1,119,1,119},
    {2,2,1,1,120,1,120},{2,2,2,1,121,1,121},{2,2,3,1,122,1,122},{2,2,4,1,123,1,123},
    {2,2,5,1,124,1,124},{2,2,6,1,125,1,125},{2,2,7,1,126,1,126},{2,2,8,1,127,1,127},
    {2,2,9,1,128,1,128},{2,2,10,1,129,1,129}
};


struct T_Node_Event_Register {
    uint32_t dwJNO;
    bool bNeedAck;
    bool bIsCurEventSnd;
    bool bIsCurEventAcked;
    bool bReserved;
    uint32_t dwNotifySndFailed;
    uint32_t dwNotifySnd;
    uint32_t dwAckRcv;
};

struct T_ACTIVE_NODE {
    uint16_t wNodeID;
    uint32_t dwLastAckSeq;
    uint32_t dwAckRcvCount;
};

class CNodeMgr {
public:
    CNodeConfig *m_pConfig;
    CZcmsMgr *m_pZcmsMgr;
    uint32_t m_isMgrWorking;
    
struct Client_Reg_cb_t
{
    uint32_t dwInitClientCnt;
    uint32_t dwQingClientCnt;
    uint32_t dwRegisteringClientCnt;
    uint32_t dwActiveClientCnt;
    uint32_t dwInactiveClientCnt;
    uint32_t dwTotalCnt;
    /* msg stt */
    uint32_t dwQApplyRcvCnt;
    uint32_t dwRegRcvCnt;
    uint32_t dwHBRcvCnt;
    uint32_t dwQAckSndCnt;
    uint32_t dwRegAckSndCnt;
    uint32_t dwRstSndCnt;

    /* admin op */
    uint32_t dwAdminAdd;
    uint32_t dwAdminRemove;
    uint32_t dwAdminBlock;
    uint32_t dwAdminUnblock;
     uint32_t dwAdminBalance;
    uint32_t dwAdminAddFailed;
    uint32_t dwAdminRemoveFailed;
    uint32_t dwAdminBlockFailed;
    uint32_t dwAdminUnblockFailed;
    uint32_t dwAdminBalanceFailed;
    uint32_t dwAdminOpNodeNotFound;
    uint32_t dwAdminOpDup;

    /* Event to UPL */
    uint32_t dwJoinNotify;
    uint32_t dwLeaveNotify;
    uint32_t dwBlockNotify;
    uint32_t dwUnblockNotify;
    uint32_t dwBalanceNotify;
    uint32_t dwJoinNotifyFailed;
    uint32_t dwLeaveNotifyFailed;
    uint32_t dwBlockNotifyFailed;
    uint32_t dwUnblockNotifyFailed;
    uint32_t dwBalanceNotifyFailed;
    uint32_t dwJoinNotifyAck;
    uint32_t dwLeaveNotifyAck;
    uint32_t dwBlockNotifyAck;
    uint32_t dwUnblockNotifyAck;
    uint32_t dwBalanceNotifyAck;
    uint32_t dwEventNodeNotFound;
    uint32_t dwEventAckNodeNotFound;
    
    /* change over stt */
    uint32_t dwQApplyRcvCntInChgOver;
    uint32_t dwRegRcvCntInChgOver;
    uint32_t dwHBRcvCntInChgOver;
    uint32_t dwBlockNodeInChgOver;
    uint32_t dwUnblockNodeInChgOver;
    uint32_t dwRemoveNodeInChgOver;
    uint32_t dwBalanceNodeInChgOver;
    /* error stt */
    uint32_t dwNodeHBTimeOutCnt;
    uint32_t dwRcvNodeHBTOCnt;
    uint32_t dwNodeNotFound;
    uint32_t dwNodeErrState;
    uint32_t dwNodeInfoDiff;
    uint32_t dwMsgSndFailed;
    uint32_t dwMCastMsgFailed;
    uint32_t dwErrorMsgRcv;
    uint32_t dwErrorPoweronTickCnt;
};

typedef struct {
    uint16_t node_id;
    T_ZCS_NODE_EVENT node_op;
} _ZENIC_PACKED T_ZCMS_NODE_OP_EVENT_KEY;

typedef struct {
    uint16_t wNodeId;
    T_ZCS_NODE_EVENT tNodeOp;
    uint32_t dwReserved;
} _ZENIC_PACKED T_ZCMS_NODE_OP_EVENT;

typedef zbt::unordered_tmap<T_ZCMS_NODE_OP_EVENT_KEY, T_ZCMS_NODE_OP_EVENT> ::iterator NODEEVENTINSTIT;

private:
    uint32_t m_dwQueueClntCnt;
    uint32_t m_dwMultiCastClntCnt;
    uint32_t m_dwSyncSeq;
    uint32_t m_ClientHBCheckTimerID;
    uint32_t m_SlaveMgrSyncReqTimerID;
    uint32_t m_MasterMgrMSSyncTimerID;
    uint32_t m_NotifyUPLWaitACKTimerID;
    uint32_t m_MSMgrSyncFlag;
    uint32_t m_MasterMgrMultiCastSyncTimerID;
    uint32_t m_dwChgOverFlag;
    uint32_t m_ChgOverTimerID;
    bool m_bIsMateOnline;
    JID m_MateJID;
    T_ZCS_NODE_LIST *m_ptActiveNodeList;

    InstMgr::CInstMgr1<T_ACS_PHY_ADDR, T_LOGIC_ADDR_ALLOC> m_tNodePool;
    InstMgr::CInstMgr1<uint32_t, T_Node_Event_Register> m_tNodeEventSubscriber;
    zbt::unordered_tmap<T_ZCMS_NODE_OP_EVENT_KEY, T_ZCMS_NODE_OP_EVENT> m_tNodeEventQueue;
    
    Client_Reg_cb_t o_tMgrStt;

public:
    InstMgr::CInstMgr1<uint16_t, T_ZCMS_NODE_INFO> m_tAllCNodesInfo;
    InstMgr::CInstMgr1<uint16_t, T_ACTIVE_NODE> m_tActiveNodes;
    
public:
    CNodeMgr();
    ZENIC_RESULT init(CNodeConfig *ptNodeConf, CZcmsMgr *pZcmsMgr, uint16_t wWorkState);
    ZENIC_RESULT onLAPoolinit();
    ZENIC_RESULT onAppLAReq(void *pMsg, uint16_t msg_len);
    ZENIC_RESULT subMateOnlineState();
    void onHandleTipcSubscribe(void *pMsg, uint16_t msg_len);
    ZENIC_RESULT setMateOnlineState(bool isOnline);
    bool isMateOnlineState();
    ZENIC_RESULT NodeEventSubinit();
    ZENIC_RESULT getSelfNodeType(T_ZCS_NODE &tSelfNode);
    ZENIC_RESULT getSelfPhyAddr(T_PhysAddress &tSelfPhyAddr);
    uint32_t getMgrPowerOnTick();
    uint32_t getQingClientCnt();
    ZENIC_RESULT increaseQingClientCnt();
    ZENIC_RESULT decreaseQingClientCnt();
    uint32_t getMultiCastClientCnt();
    ZENIC_RESULT increaseMultiCastClientCnt();
    ZENIC_RESULT decreaseMultiCastClientCnt();

    ZENIC_RESULT saveCNodeInfo(uint32_t idx, T_ZCMS_CNODE_INFO* ptCNodeInfo);
    bool checkCNodeInfo(uint32_t idx, T_ZCMS_CNODE_INFO* ptCNodeInfo);
    ZENIC_RESULT initNodeInfo(uint16_t node_id);
    uint32_t getTotalNodeNum();
    ZENIC_RESULT clearCNodeInfo(uint32_t idx);
    T_ZCS_NODE_STATE getCNodeManageStatus(uint32_t idx);
    ZENIC_RESULT setCNodeManageStatus(uint32_t idx, T_ZCS_NODE_STATE tManageStatus);
    ZENIC_RESULT setCNodeLinkState(uint32_t idx, E_ZCMS_NODE_LINK_STATE tLinkState);
    E_ZCMS_NODE_LINK_STATE getCNodeLinkState(uint32_t idx);
    ZENIC_RESULT increaseCNodeHBTOCnt(uint32_t idx);
    ZENIC_RESULT alarm2OamWorker(T_ZCMS_NODE_INFO node);
    ZENIC_RESULT clearCNodeHBTOCnt(uint32_t idx);
    uint32_t getCNodeHBTOCnt(uint32_t idx);
    ZENIC_RESULT setCNodeQueueID(uint32_t idx, uint32_t dwQID);
    ZENIC_RESULT decreaseCNodeQueueID(uint32_t idx);
    uint32_t getCNodeQueueID(uint32_t idx);
    ZENIC_RESULT setCNodeSvcState(uint32_t idx, uint16_t wSState);
    uint16_t getCNodeSvcState(uint32_t idx);
    void removeCNodefromQApplyQueue(uint32_t dwCurQID);
    void checkLinkNodeTimeOut();
    ZENIC_RESULT constructMateJID(JID &MateJID);
    ZENIC_RESULT constructClientJID(uint16_t wModule, uint16_t wRouteType, JID &CJID);
    void printQueueApplyMsg(ZCMS_QUEUE_REQ_MSG *pQueueReq);
    void printQueueAckMsg(ZCMS_QUEUE_ACK_MSG *pQueueAck);
    void printFormallyRegMsg(ZCMS_REG_REQ_MSG *pFReq);
    void printCEchoMsg(ZCMS_HEART_BEAT_MSG *pEcho);

    ZENIC_RESULT findConfClientNode(uint16_t wNodeID, uint32_t& idx);
    void onQueueApplyAck(void *pMsg, uint16_t msg_len);
    void onNodeJoinAck(void *pMsg, uint16_t msg_len);
    void onHandleClientHeartBeat(void *pMsg, uint16_t msg_len);
    ZENIC_RESULT saveNode(uint16_t node_id, T_ZCMS_CNODE_INFO *ptCNodeInfo);
    /*����ɾ���������ڵ�*/
    ZENIC_RESULT addNode(uint16_t node_id);
    ZENIC_RESULT removeNode(uint16_t node_id);
    void sendResetMsgToClient(uint16_t NodeID, E_ZCMS_RESET_LINK_REASON eRSTReason);
    
    ZENIC_RESULT addMultiCastClient(uint16_t node_id);
    ZENIC_RESULT updateMultiCastClientAckSeq(uint16_t node_id, uint32_t newAckedSeq);
    bool checkMultiCastAckedByAllClients();
    ZENIC_RESULT removeMultiCastClient(uint16_t node_id);
    ZENIC_RESULT preAddNode(uint16_t node_id);
    void onNodeEventAck(void *pMsg, uint16_t msg_len);
    void onSelfTriggerNodeEventAck(void *pMsg, uint16_t msg_len);
    void onNodeEventSubscribe(void *pMsg, uint16_t msg_len);
    void insertNodeEvent(uint16_t wNodeID, T_ZCS_NODE_EVENT event);
    bool findNodeEvent(uint16_t wNodeID, T_ZCS_NODE_EVENT event);
    bool findNodeEventNotNotified(uint16_t wNodeID, T_ZCS_NODE_EVENT event);
    bool verifyNodeEvent(uint16_t wNodeID, T_ZCS_NODE_EVENT event);
    void removeNodeEvent(uint16_t wNodeID, T_ZCS_NODE_EVENT event);
    ZENIC_RESULT notifyUPLNodeEvent(bool isFirstSend);
    bool checkNodeEventAckedByAllSubs();
    ZENIC_RESULT writeShmActiveNodes();
    void fillNotifyNodeEvent(T_EV_ZCS_NODE_EVENT &tNodeEv, uint16_t wNodeId, T_ZCS_NODE_EVENT tEvent);
    void recordAllNodeUPLEventAckStats(uint16_t wNodeId, T_ZCS_NODE_EVENT tEvent);
    void recordAllNodeUPLEventStats(uint16_t wNodeId, T_ZCS_NODE_EVENT tEvent, bool isSuccess);
    void saveAllCNodesStt();
    
    /* debug functions */
    void showLAPool();
    void showGeneralStt();
    void showRegStt(T_ZCMS_NODE_REG_STT *pRegStt);
    void showAllCNodesStt(int NotshowAll);
    void showNodeEventSub();
    void showNodeEventQueue();

    /* SM config file sync functions */
    void constrNodeDataSyncInfo(T_ZCMS_NODE_SYNC_INFO &tNodeSync);
    void onSaveNodeDataSyncInfo(void *data, uint32_t len);
    void constrNodeEventSyncInfo(T_ZCMS_NODE_EVENT_SYNC &tEventSync);
    void onSaveNodeEventSyncInfo(void *data, uint32_t len);
    void onZcsMSSyncReq();
    void onZcsMSSync(uint32_t SyncType);
    void onZcsMSSyncAck(void *pMsg, uint16_t msg_len);
    void onZcsHandleMSSyncAck();

    /* Multicast sync functions */
    void constrMultiCastSyncInfo(T_ZCS_NODE_LIST &tNodeSync);
    void onZcsMultiCastSync();
    void onHandleMultiCastSyncAck(void *pMsg, uint16_t msg_len);

    /* Admin Management */
    void onNodeAdminManage(void *pMsg, uint16_t msg_len);
    ZENIC_RESULT onNodeAdminAdd(uint16_t node_id);
    ZENIC_RESULT onNodeAdminRemove(uint16_t node_id);
    ZENIC_RESULT onNodeAdminBlock(uint16_t node_id);
    ZENIC_RESULT onNodeAdminUnblock(uint16_t node_id);	
    ZENIC_RESULT onNodeAdminbBalance(uint16_t node_id);

    ZENIC_RESULT preChangeOver();
    uint32_t getChangeOverState();
    bool isChangingOver();
    bool metSndChgOverAckCondition();
    ZENIC_RESULT changeOver();
    ZENIC_RESULT postChangeOver();
    ZENIC_RESULT shutdown();
    virtual ~CNodeMgr();
};

#endif /* CNODEMGR_H_ */
