/*
 * zcps_recv_entry.cpp
 *
 *  Created on: 2014-9-3
 *      Author: wangjun
 */

#include "tulip.h"
#include "tulip_oss.h"
#include "tulip_scs.h"
#include "zcs_common.h"
#include "CSyncStateMgr.h"

extern CSyncStateMgr g_zcpsSyncMgr;
void zcps_recv_msg_handler(uint32_t msgId, void *pMsg, void *pPData, uint16_t msg_len);

/*ZCMS�������*/
#ifdef __cplusplus
extern "C" {
#endif
JID g_zcps_recv_jid;

void zcps_recv_entry(WORD16 wState, WORD32 dwMsgId, void *pMsgBody, void *pPData, BOOLEAN bSame)
{
    switch(wState)
    {
        case S_StartUp:
        {
            XOS_GetSelfJID(&g_zcps_recv_jid);
            switch(dwMsgId)
            {
                case EV_MASTER_POWER_ON:
                {
                    XOS_PowerOnAck(EV_POWER_ON_SUCCESS, NULL, 0, 0);
                    XOS_SetNextState(ZCS_JOB_STATE_SNODE_WORK);
                }
                break;
                case EV_SLAVE_POWER_ON:
                {
                    XOS_PowerOnAck(EV_POWER_ON_SUCCESS, NULL, 0, 0);
                    XOS_SetNextState(ZCS_JOB_STATE_SNODE_WORK);
                }
                break;
            }
        }
        break;
        case ZCS_JOB_STATE_SNODE_WORK:
        {
            uint16_t msg_len;
            XOS_GetMsgDataLen(&msg_len);
            zcps_recv_msg_handler(dwMsgId,pMsgBody,pPData,msg_len);
        }
        break;
        default:
            XOS_SetDefaultNextState();
        break;
    }

    XOS_SetDefaultNextState();
    return;
}

#ifdef __cplusplus
}
#endif


void zcps_recv_msg_handler(uint32_t msgId, void *pMsg, void *pPData, uint16_t msg_len)
{

    switch(msgId)
    {
        case EV_SYS_ZCS_INNER_DATA_SYNC:
        {
            g_zcpsSyncMgr.onPackDataSync((uint8_t *)pMsg, msg_len);
            break;
        }

    }

}



