
#include "tulip.h"
#include "tulip_oss.h"
#include "tulip_scs.h"
#include "zcs_test.h"
#include "zcs_common.h"
#include "zcs_api.h"

#ifdef __cplusplus
extern "C" {
#endif
#ifdef ZCS_TEST

void zcs_test_entry(WORD16 wState, WORD32 dwMsgId, void *pMsgBody, void *pPData, BOOLEAN bSame)
{
    switch(wState)
    {
        case S_StartUp:
        switch(dwMsgId)
        {
				        case EV_MASTER_POWER_ON:
				        {
           					T_ZCS_NODE_ROLE role;
           					ZENIC_RESULT ret;
           					T_ZCS_CONFIG_INFO tConf;
           					uint16_t i;
           					printf("[zcs_test_entry]Recv EV_MASTER_POWER_ON\n");
                XOS_WaitJob(XOS_ConstructJNO(ZCS_JOB_TYPE_ZCMS, 1), JOB_STATE_WORK, WAIT_FOREVER);
                role = zcs_get_node_role();
           					printf("[zcs_test_entry]zcs_get_node_role:%u\n", role);
                               ret = zcs_get_config_info(tConf);
           					printf("[zcs_test_entry]zcs_get_config_info:%d. node_role:%u, replica_num:%d, node_num:%d\n", ret,
           						                       tConf.node_role, tConf.replica_num, tConf.tNodeList.node_num);
           					for(i = 0; i < tConf.tNodeList.node_num; i++)
           					{
                    printf("[zcs_test_entry]Node[%d]: nodeId[%d], moduleId[%d], route_type[%d]\n", 
           							                                              i, tConf.tNodeList.tNodes[i].nodeId,
           							                                               tConf.tNodeList.tNodes[i].moduleId,
           							                                               tConf.tNodeList.tNodes[i].route_type);
           					}

                XOS_PowerOnAck(EV_POWER_ON_SUCCESS, NULL, 0, 0);
                zcs_launch_service();
                printf("[zcs_test_entry]XOS_PowerOnAck EV_POWER_ON_SUCCESS!\n");
                XOS_SetNextState(ZCS_TEST_JOB_STATE_MWORK);
            }
            break;
            
				        case EV_SLAVE_POWER_ON:
				        {
           					T_ZCS_NODE_ROLE role;
           					ZENIC_RESULT ret;
           					T_ZCS_CONFIG_INFO tConf;
           					uint16_t i;
           					printf("[zcs_test_entry]Recv EV_SLAVE_POWER_ON\n");
                XOS_WaitJob(XOS_ConstructJNO(ZCS_JOB_TYPE_ZCMS, 1), JOB_STATE_WORK, WAIT_FOREVER);
                role = zcs_get_node_role();
           					printf("[zcs_test_entry]zcs_get_node_role:%u\n", role);
                               ret = zcs_get_config_info(tConf);
           					printf("[zcs_test_entry]zcs_get_config_info:%d. node_role:%u, replica_num:%d, node_num:%d\n", ret,
           						                       tConf.node_role, tConf.replica_num, tConf.tNodeList.node_num);
           					for(i = 0; i < tConf.tNodeList.node_num; i++)
           					{
                    printf("[zcs_test_entry]Node[%d]: nodeId[%d], moduleId[%d], route_type[%d]\n", 
           							                                              i, tConf.tNodeList.tNodes[i].nodeId,
           							                                               tConf.tNodeList.tNodes[i].moduleId,
           							                                               tConf.tNodeList.tNodes[i].route_type);
           					}
                XOS_PowerOnAck(EV_POWER_ON_SUCCESS, NULL, 0, 0);
                zcs_launch_service();
                printf("[zcs_test_entry]XOS_PowerOnAck EV_POWER_ON_SUCCESS!\n");
                XOS_SetNextState(ZCS_TEST_JOB_STATE_SWORK);
            }
            break;
        }
        break;
			
        case ZCS_TEST_JOB_STATE_MWORK:
        case ZCS_TEST_JOB_STATE_SWORK:
			     {
            switch(dwMsgId)
            {
    				        case EV_SLAVE_TO_MASTER:
    				        case	EV_MASTER_TO_SLAVE:
    				        {
    				        	   printf("[zcs_test_entry]Rcv changeOver msg and ack!\n");
    			             XOS_SetDefaultNextState();
    				        }
    				        break;
    				        
                case EV_MS_FINISH:
                {
                	   printf("[zcs_test_entry]Rcv EV_MS_FINISH!\n");
                    XOS_SetNextState(ZCS_TEST_JOB_STATE_SWORK);
                }
                break;
                
                case EV_SM_FINISH:
                {
                    printf("[zcs_test_entry]Rcv EV_SM_FINISH!\n");
                    XOS_SetNextState(ZCS_TEST_JOB_STATE_MWORK);
                }
                break;
            }
        }
        break;

        default:
			     {
			        XOS_SetDefaultNextState();
        }
        break;
    }

    XOS_SetDefaultNextState();
    return;
}
#endif

#ifdef __cplusplus
}
#endif


