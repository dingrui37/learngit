/*
 * CZcrsRteMgr.cpp
 *
 *  Created on: 2014-9-4
 *      Author: wangjun
 */

#include <stdio.h>
#include "CZcrsRteMgr.h"
#include "zcs_common.h"

CZcrsRteMgr::CZcrsRteMgr()
    : p_cur_rte_table(NULL), m_new_rte_table(), m_self_node_id(0),
      m_work_state(0),  rte_changed(false)
{
#ifdef ZCRS_RTE_TABLE_OPT
    memset(m_adj_record, 0, sizeof(m_adj_record));
#endif
}

/*��ʼ��·�ɱ�*/
ZENIC_RESULT CZcrsRteMgr::init(uint16_t self_node_id, uint16_t work_state,
        T_ZCS_NODE_LIST& tNodes)
{
    T_DHT_NODE_LIST dht_nodes;
    this->m_self_node_id = self_node_id;
    m_work_state=work_state;

    /*ֻ�������ؽڵ��ϲŻ��ʼ��·�ɱ�����������ǵȴ�·�ɱ�ͬ��*/
    memset(p_cur_rte_table,0,sizeof(T_DHT_RTE_TABLE));

    if(m_work_state==ZCS_JOB_STATE_MNODE_WORK)
    {
        construct_node_list(tNodes,dht_nodes);
        m_new_rte_table.init(dht_nodes,DHT_MAX_RTE_ENTRY,1);
        m_new_rte_table.setSelfNodeId(self_node_id);
        m_new_rte_table.getRteTable(p_cur_rte_table);
    }

    return RESULT_ZENIC_SUCCESS;
}

ZENIC_RESULT CZcrsRteMgr::setRteTable(const T_DHT_RTE_TABLE& newRtTable)
{ 
    return m_new_rte_table.copyRoutingTable(newRtTable); 
}

//���������ڴ�
ZENIC_RESULT CZcrsRteMgr::createRoutingShm()
{
	ZENIC_RESULT ret = zcs_getRoutingShm(&p_cur_rte_table,DHT_MAX_RTE_ENTRY,true);
	if(ret!=RESULT_ZENIC_SUCCESS)
	{
		printf("[ZCRS]Init Shared Memory failed\n");
		return ret;
	}
	
	return ret;
}


/*���ýڵ�״̬*/
uint16_t CZcrsRteMgr::setWorkState(uint16_t new_work_state)
{
    m_work_state = new_work_state;
    return m_work_state;
}

/*����һ���ڵ㣬���ı���·�ɱ����ִ�·�ɱ���Ҫ��commit���޸�*/
uint16_t CZcrsRteMgr::addNode(uint16_t node_id, uint16_t chg_rte_num,
        T_ZCS_CHGOVER_RTE_ITEM* chg_rte)
{
    uint16_t changed_num;
    m_new_rte_table.addNode(node_id);
    changed_num = m_new_rte_table.compareRteTable(*p_cur_rte_table,chg_rte,chg_rte_num);
    ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCRS]Add Node,id=%u,changed_rte_entry=%u\n",node_id,changed_num);
    rte_changed = true;
    return changed_num;
}

/*����һ���ڵ㣬���ı���·�ɱ����ִ�·�ɱ���Ҫ��commit���޸�*/
uint16_t CZcrsRteMgr::removeNode(uint16_t node_id, uint16_t chg_rte_num,
        T_ZCS_CHGOVER_RTE_ITEM* chg_rte)
{
    uint16_t changed_num;
    m_new_rte_table.RemoveNode(node_id);
    changed_num = m_new_rte_table.compareRteTable(*p_cur_rte_table,chg_rte,chg_rte_num);
    ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCRS]Remove Node,id=%u,changed_rte_entry=%u\n",node_id,changed_num);
    rte_changed = true;
    return changed_num;
}

uint16_t CZcrsRteMgr::balanceNode( uint16_t chg_rte_num, T_ZCS_CHGOVER_RTE_ITEM *chg_rte )
{
#ifndef ZCRS_RTE_TABLE_OPT
    return 0;    
#else
    uint16_t changed_num;
    m_new_rte_table.adjustBackUpNodes( );
    changed_num = m_new_rte_table.compareRteTable(*p_cur_rte_table,chg_rte,chg_rte_num);
    if( changed_num >0 )
        rte_changed = true;
    
    printf("[ZCRS]balanceNode,changed_rte_entry=%u\n",changed_num);
    
    return changed_num;
#endif
}

/*������Ϻ��ύ*/
ZENIC_RESULT CZcrsRteMgr::commit()
{
    m_new_rte_table.getRteTable(p_cur_rte_table);
    rte_changed = false;
	for (int i=0;i<DHT_MAX_RTE_ENTRY;i++)
	{
		p_cur_rte_table->rtEntry[i].bRejectSwitchAccess =false;	
	}
	printf("[ZCRS]Routing Table chgover success.\n");
    return RESULT_ZENIC_SUCCESS;
}


/*�ع�·�ɱ����Ƿ���Ҫ֪ͨ�ϲ�Ӧ�ã���Ҫ��һ���о�*/
ZENIC_RESULT CZcrsRteMgr::rollback()
{
    rte_changed = false;
    return RESULT_ZENIC_SUCCESS;
}

/*����T_ZCS_NODE����T_DHT_NODE_LIST*/
void CZcrsRteMgr::construct_node_list(const T_ZCS_NODE_LIST& tZcsNodes,
        T_DHT_NODE_LIST& tDhtNodes)
{
    tDhtNodes.node_num = tZcsNodes.node_num;
    for(uint16_t i=0;i<tZcsNodes.node_num;i++)
    {
        tDhtNodes.nodes[i].node_id = tZcsNodes.tNodes[i].nodeId;
        tDhtNodes.nodes[i].node_state =DHT_NODE_ACTIVE;
    }
}

/*��ȡ��ǰ·�ɱ�����ģ��ά������·�ɱ���һ���ǵ�ǰ·�ɱ���һ������·�ɱ�
 * ��·�ɱ�commit֮��ű�ɵ�ǰ·�ɱ�*/
ZENIC_RESULT CZcrsRteMgr::getCurRteTable(T_DHT_RTE_TABLE* pRteTable)
{
    if(NULL== pRteTable)
        return ERROR_NULL_POINTER;
    memcpy(pRteTable,p_cur_rte_table,sizeof(T_DHT_RTE_TABLE));
    return RESULT_ZENIC_SUCCESS;
}

/*��ȡ����·�ɱ��仯���*/
uint16_t CZcrsRteMgr::getChangedRteTable(T_ZCS_CHGOVER_RTE_ITEM* chg_rte,
        uint16_t num)
{
    return m_new_rte_table.compareRteTable(*p_cur_rte_table,chg_rte,num);
}

/*����·�ɱ���ͨ�������������ؽڵ����·��ͨ�������*/
uint16_t CZcrsRteMgr::updateRoutingTable(const T_DHT_RTE_TABLE& newRtTable,
        T_ZCS_CHGOVER_RTE_ITEM* chg_rte, uint16_t num)
{
    uint16_t chg_num;

    m_new_rte_table.copyRoutingTable(newRtTable);
    m_new_rte_table.setSelfNodeId(this->m_self_node_id);
    chg_num = m_new_rte_table.compareRteTable(*p_cur_rte_table,chg_rte,num);
    if(chg_num>0)
        rte_changed = true;
    else
        rte_changed = false;
    ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCRS]Updating Routing Table, changed_rte_num=%u\n",chg_num);
    return chg_num;
}

/*·�ɱ�����*/
ZENIC_RESULT CZcrsRteMgr::rteLookup(const T_ZCS_RESOURCE_KEY& resource_key,
        T_DHT_NODES_GROUP& tNodes) const
{
    if(p_cur_rte_table==NULL) //��δ��ʼ��
        return ERROR_RECORD_NOT_FOUND;
    uint16_t hash_v = zcs_hash_func(resource_key.res_key,resource_key.key_len);

	//0����
	if (p_cur_rte_table->m_num_per_seg == 0)
	{
		ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCRS]no node join,p_cur_rte_table->m_num_per_seg=%d.\n",p_cur_rte_table->m_num_per_seg);
		return ERROR_INVALID_PARAM;
	}
    uint16_t seg_idx = hash_v / p_cur_rte_table->m_num_per_seg;
    tNodes = p_cur_rte_table->rtEntry[seg_idx].tNodes;

     return RESULT_ZENIC_SUCCESS;
}

/*�����Ƿ��Ǳ��ش���*/
bool CZcrsRteMgr::isLocal(const T_ZCS_RESOURCE_KEY& tResKey) const
{
    if(p_cur_rte_table==NULL) //��δ��ʼ��
        return false;

    uint16_t hash_v = zcs_hash_func(tResKey.res_key,tResKey.key_len);

    uint16_t seg_idx = hash_v / p_cur_rte_table->m_num_per_seg;

    if(p_cur_rte_table->rtEntry[seg_idx].tNodes.master_node_id == p_cur_rte_table->m_self_node_id)
        return true;
    else
      return false;
}

/*��ӡ������Ϣ*/
void CZcrsRteMgr::print_stats()
{
    /*if(p_cur_rte_table)
    {
        printf("\n[Cur_Routing_table]RTE_Entry_num=%u, num_per_seg=%u, seg_per_node=%u, self_node_id=%u\n",
                p_cur_rte_table->m_seg_num,p_cur_rte_table->m_num_per_seg,
                p_cur_rte_table->m_seg_per_node,p_cur_rte_table->m_self_node_id);
        printCurRteTable();
    }
    else
    {
        printf("Current routing Uninitialized\n");
    }
    if(rte_changed)//��ӡ�µ�·�ɱ���Ϣ
    {
        printf("\n-------------------new routing table-----------------------------------\n");
        m_new_rte_table.printRteTable();
    }*/
    m_new_rte_table.printRteTable();
}

/*��ӡ��ǰ·�ɱ���Ϣ*/
void CZcrsRteMgr::printCurRteTable()
{
    T_DHT_RTE_ENTRY *p= p_cur_rte_table->rtEntry;

    printf("Seg_start  Seg_End  Master_node Backup_Num  Backup_node1  Backup_Node2 M2S\n");
    printf("---------------------------------------------------------------------------\n");
    for(uint32_t i=0;i<p_cur_rte_table->m_seg_num;i++)
    {
        printf("%6u  %8u %10u %10u %10u %12u  \t%s\n",p[i].tSegPair.start_idx, p[i].tSegPair.end_idx, p[i].tNodes.master_node_id,
                p[i].tNodes.backup_nodes_num, p[i].tNodes.backup_nodes[0], p[i].tNodes.backup_nodes[1],
                p[i].has_m2s?"TRUE":"FALSE");
    }
}

/*����һ���ڵ㣬����·�ɱ��仯���*/
uint16_t CZcrsRteMgr::blockNode(uint16_t node_id, uint16_t chg_rte_num,
        T_ZCS_CHGOVER_RTE_ITEM* chg_rte)
{
    uint16_t changed_num;
    m_new_rte_table.blockNode(node_id,false);
    changed_num = m_new_rte_table.compareRteTable(*p_cur_rte_table,chg_rte,chg_rte_num);
    ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCRS]Block Node,id=%u,changed_rte_entry=%u\n",node_id,changed_num);
    rte_changed = true;
    return changed_num;
}

/*�����һ���ڵ㣬����·�ɱ��仯���*/
uint16_t CZcrsRteMgr::unblockNode(uint16_t node_id, uint16_t chg_rte_num,
        T_ZCS_CHGOVER_RTE_ITEM* chg_rte)
{
    uint16_t changed_num;
    m_new_rte_table.unblockNode(node_id);
    changed_num = m_new_rte_table.compareRteTable(*p_cur_rte_table,chg_rte,chg_rte_num);
    ZCS_LOG_SIMPLE(LOG_NOTICE,"[ZCRS]Unblock Node,id=%u,changed_rte_entry=%u\n",node_id,changed_num);
    rte_changed = true;
    return changed_num;
}

ZENIC_RESULT CZcrsRteMgr::getNewRteTable(T_DHT_RTE_TABLE* pRteTable)
{
    if(NULL== pRteTable)
        return ERROR_NULL_POINTER;
    m_new_rte_table.getRteTable(pRteTable);
    return RESULT_ZENIC_SUCCESS;
}

//���÷�Ƭ�ı�־λ�����ڱ�ʶ��ǰ���������ڸ÷�Ƭ�ڵĽ���������
void CZcrsRteMgr::setSwitchRteTable(T_ZCS_CHGOVER_SEG_LIST tSegList)
{
	for (int i=0;i<tSegList.wSegNum&&i<ZCS_MAX_RTE_ENTRY;i++)
	{
        if(tSegList.aSegIdx[i]<ZCS_MAX_RTE_ENTRY)
		p_cur_rte_table->rtEntry[tSegList.aSegIdx[i]].bRejectSwitchAccess = true;
	}
}

CZcrsRteMgr::~CZcrsRteMgr() {
    // TODO Auto-generated destructor stub
}


