/*
 * CSyncDataPool.cpp
 *
 *  Created on: 2014-9-3
 *      Author: wangjun
 */

#include "CSyncDataPool.h"
#include "zcs_job_def.h"
#include "zcps_common.h"
#include "zcs_common.h"
#include <algorithm>
#include "CCpEventReg.h"

CSyncDataPool::CSyncDataPool()
    : m_cur_scan_index(0), m_chgover_data_count(0), m_self_node_id(0),
      m_max_sync_count(0), m_send_data_count(0),
      m_recv_ack_count(0), m_send_sync_retry(0), m_sync_pool_alloc_fail(0)
{
    memset(&m_self_jid, 0, sizeof(m_self_jid));
    memset(&m_recv_jid, 0, sizeof(m_recv_jid));
}

/*��ʼ��ϵͳ*/
ZENIC_RESULT CSyncDataPool::init(uint16_t self_node_id)
{
    m_self_node_id =self_node_id;
    XOS_GetSelfJID(&m_self_jid);
    m_recv_jid = m_self_jid;
    m_recv_jid.dwJno = (ZCS_JOB_TYPE_ZCPS_RECV<<16) +1;//��ʼ�����շ���Jid

    m_sync_data_pool.init(ZCPS_SYNC_POOL_SIZE);
    m_syncQueue.init(ZCPS_SYNC_MAX_NODE_NUM);
    m_cur_scan_index = 0;
    m_max_sync_count = ZCPS_MAX_SYNC_COUNT_PER_ROUND;
    m_over_retry_count = 0;
    return RESULT_ZENIC_SUCCESS;
}

extern "C" void zcps_show(uint16_t dwShowAppId, uint16_t dwShowDataType);

/*ͬ����ʱ����ɨ����Դ�أ���������ͬ��*/
void CSyncDataPool::onSyncTimerEvent(uint32_t param)
{
    uint32_t sync_count=0;
    uint32_t max_sync_count;
    
    max_sync_count = this->getSendWindowSize();
    if(m_cur_scan_index >= ZCPS_SYNC_POOL_SIZE) 
        m_cur_scan_index=0;
    while(sync_count<max_sync_count)
    {
        if(m_sync_data_pool.getInstanceState(m_cur_scan_index)==InstMgr::INST_STATE_ALLOCATED)
        {
            T_ZCPS_SYNC_POOL_DATA *pData = &m_sync_data_pool[m_cur_scan_index];
            if(pData->retry_count>=ZCPS_MAX_SYNC_RETRY_COUNT)
            {
                deQueue(pData->dst_node_id,m_cur_scan_index);
                m_sync_data_pool.releaseInst(m_cur_scan_index);
                m_over_retry_count++;
                CCpEventReg::inc_over_retry_stats(pData->tMsg.tSyncHdr.app_id,pData->tMsg.tSyncHdr.tDataKey.data_type);
            }
            else
            {
                enQueue(pData->dst_node_id,m_cur_scan_index);
                if(pData->retry_count != 0)
                {
                    CCpEventReg::inc_retry_stats(pData->tMsg.tSyncHdr.app_id,pData->tMsg.tSyncHdr.tDataKey.data_type);
                }
                pData->retry_count++;
            }
        }
        m_cur_scan_index=((m_cur_scan_index+1) % ZCPS_SYNC_POOL_SIZE);
        sync_count++;
    }
    
    flushAllQueue();
}

/*����ĳ���ڵ㵱ǰ��ͬ�����г���*/
uint32_t CSyncDataPool::getQueueLen(uint16_t node_id)
{
    int ret;
    uint32_t idx;
    ret = m_syncQueue.findInstByKey1(node_id,idx);
    if(ret==InstMgr::RESULT_INST_SUCCESS)
        return m_syncQueue[idx].dwCounter;
    else
        return 0;
}

/*ͬ�����ݣ������ǽ����ݷ�����Դ�أ��ɺ����Ķ�ʱ������ɨ�账��*/
ZENIC_RESULT CSyncDataPool::syncData(const T_ZCPS_MSG& tMsg, uint16_t dest_node,
        uint32_t cookie, bool isChgOverData)
{
    int ret;
    uint32_t idx;

    ret = m_sync_data_pool.allocInst(idx);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        m_sync_pool_alloc_fail++;
        return ERROR_ALLOC_INSTANCE_FAIL;
    }

    T_ZCPS_SYNC_POOL_DATA *pData = &m_sync_data_pool[idx];
    pData->cookie = cookie;
    pData->retry_count = 0;
    pData->tMsg = tMsg;
    pData->dst_node_id = dest_node;
    pData->isChgOverData = isChgOverData;
    if(isChgOverData) 
        m_chgover_data_count++;
    return RESULT_ZENIC_SUCCESS;
}

/*�յ�һ��Ӧ����Ϣ�Ĵ���*/
ZENIC_RESULT CSyncDataPool::onSyncAck(const T_EV_ZCS_INNNER_DATA_SYNC_ACK& tAck, uint32_t& cookie) 
{
    uint32_t idx = tAck.seq;

    m_recv_ack_count++;//���������������ڼ��㻬������
    if(m_sync_data_pool.getInstanceState(idx)!=InstMgr::INST_STATE_ALLOCATED)
    {
        m_recv_ack_invalid++;
        ZCS_LOG_SIMPLE(LOG_ERROR,"[ZCRS]recv ack msg,but seq is invalid, src_node=%u,seq=%u\n",
                tAck.node_id,tAck.seq);
        return ERROR_RECORD_NOT_FOUND;
    }

    cookie = m_sync_data_pool[idx].cookie;
    
    deQueue(tAck.node_id,idx);
    m_sync_data_pool.releaseInst(idx);
    return RESULT_ZENIC_SUCCESS;
}

/*�������ͬ��״̬�����ص���ʼֵ*/
void CSyncDataPool::clear() {
    m_sync_data_pool.clearAllInstance();
    m_syncQueue.clearAllInstance();
}

/*���ͱ�������*/
ZENIC_RESULT CSyncDataPool::sendSyncMsg(uint16_t QueueIdx, T_ZCPS_SYNC_ITEM* pSndItem)
{
    JID tRecvJid = m_recv_jid;
    uint16_t dst_node_id = m_syncQueue[QueueIdx].wDstNodeId;
    if(NULL == pSndItem)
    {
        return ERROR_NULL_POINTER;
    }
    uint16_t lenth = 0;
    T_ZCPS_ITEM_OBJ* pObj = pSndItem->tItemHdr.tItemData;
    for(uint16_t i = 0; i<pSndItem->tItemHdr.wObjCnt && lenth<pSndItem->tItemHdr.wObjLen; i++)
    {
        CCpEventReg::incSendCounter(pObj->tObjHdr.app_id,pObj->tObjHdr.tDataKey.data_type,dst_node_id);
        
        lenth += pObj->tObjHdr.data_len+sizeof(T_ZCS_APP_SYNC_MSG_HDR);
        pObj = (T_ZCPS_ITEM_OBJ*)((uint8_t*)pSndItem->tItemHdr.tItemData + lenth);
    }
    
    return zcps_send_msg(EV_SYS_ZCS_INNER_DATA_SYNC,(uint8_t *)&pSndItem->tItemHdr,pSndItem->wDataLen,dst_node_id,tRecvJid);
}

/*���ͱ�������*/
void CSyncDataPool::flushQueue(uint16_t dst_node_id)
{
    uint32_t QueueIdx = 0;
    
    int ret = m_syncQueue.findInstByKey1(dst_node_id, QueueIdx);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        XOS_ASSERT(0);
        return;
    }

    T_ZCPS_SYNC_ITEM* pSndItem = &m_syncQueue[QueueIdx].tItem;;
    if(pSndItem)
    {
        if(m_syncQueue[QueueIdx].snd_wnd == 0)
        {
            m_syncQueue[QueueIdx].zero_wnd++;
            ZCS_LOG_SIMPLE(LOG_NOTICE, "==flushQueue[%d]:item[%u] snd_wnd 0,sync queue congest", dst_node_id, pSndItem->tItemHdr.dwTsn);
        }
        if(ZCPS_ITEM_SENT == pSndItem->ucState)
        {
            //ZCPS_ITEM_INIT could occur when deQueue and flushQueue.
            return;
        }
        else if(ZCPS_ITEM_READY4SEND == pSndItem->ucState || ZCPS_ITEM_FILLING == pSndItem->ucState)
        {
            /* ����ͬ�����󣬲��Է��ʹ��ڽ��и��� */
            ZENIC_RESULT snd_ret = sendSyncMsg(QueueIdx, pSndItem);
            //m_syncQueue[QueueIdx].snd_wnd--;  //todo
            if(RESULT_ZENIC_SUCCESS == snd_ret)
            {
                m_syncQueue[QueueIdx].item_snt_suc++;
                m_syncQueue[QueueIdx].obj_snt_suc += pSndItem->tItemHdr.wObjCnt;
                ZCS_LOG_SIMPLE(LOG_DEBUG, "==flushQueue[%d]:item[%u] contains ObjCnt[%d] ObjLen[%d]send success", 
                    dst_node_id, pSndItem->tItemHdr.dwTsn, pSndItem->tItemHdr.wObjCnt, pSndItem->tItemHdr.wObjLen);
            }
            else
            {
                m_syncQueue[QueueIdx].item_snt_fail++;
                m_syncQueue[QueueIdx].obj_snt_fail += pSndItem->tItemHdr.wObjCnt;
                ZCS_LOG_SIMPLE(LOG_ERROR, "==flushQueue[%d]:item[%u] contains ObjCnt[%d] ObjLen[%d]send fail", 
                    dst_node_id, pSndItem->tItemHdr.dwTsn, pSndItem->tItemHdr.wObjCnt, pSndItem->tItemHdr.wObjLen);
            }
            pSndItem->ucState = ZCPS_ITEM_SENT;
        }
        else
        {
            m_syncQueue[QueueIdx].item_state_err++;
            ZCS_LOG_SIMPLE(LOG_NOTICE, "==flushQueue[%d]:item[%u] state[%d] err", 
                    dst_node_id, pSndItem->tItemHdr.dwTsn, pSndItem->ucState);
        }
    }

    return;
}

void CSyncDataPool::flushAllQueue()
{
    for(uint16_t QueueIdx = 0; QueueIdx < m_syncQueue.getTotalInstNum(); QueueIdx++)
    {
        if(m_syncQueue.getInstanceState(QueueIdx)==InstMgr::INST_STATE_ALLOCATED)
        {
            flushQueue(m_syncQueue[QueueIdx].wDstNodeId);
        }
    }
}

T_ZCPS_SYNC_ITEM* CSyncDataPool::getNewSyncItem(uint16_t node_id)
{
    uint32_t QueueIdx = 0;
    int ret = m_syncQueue.findInstByKey1(node_id, QueueIdx);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        return NULL;
    }

    T_ZCPS_SYNC_ITEM* pSndItem = &m_syncQueue[QueueIdx].tItem;
    XOS_ASSERT(ZCPS_ITEM_INIT == pSndItem->ucState || ZCPS_ITEM_SENT == pSndItem->ucState);
    //memset(pSndItem, 0, _OFFSET(T_ZCPS_SYNC_ITEM, data));
    pSndItem->ucState    = ZCPS_ITEM_FILLING; //ZCPS_ITEM_INIT --> ZCPS_ITEM_FILLING
    pSndItem->ucRetryCnt = 0;
    pSndItem->wDataLen   = sizeof(T_ZCPS_ITEM_HEAD);
    pSndItem->wCookieCnt = 0;
    pSndItem->pObjBuff   = pSndItem->data;
    
    pSndItem->tItemHdr.wObjLen = 0;
    pSndItem->tItemHdr.wObjCnt = 0;
    pSndItem->tItemHdr.dwTsn = m_syncQueue[QueueIdx].snd_new;
    m_syncQueue[QueueIdx].snd_new++;

    return pSndItem;
}

inline int CSyncDataPool::getQueue(uint16_t node_id, uint32_t& idx)
{
    int ret = m_syncQueue.findInstByKey1(node_id, idx);
    if(ret!=InstMgr::RESULT_INST_SUCCESS)
    {
        ret = m_syncQueue.allocInstByKey1(node_id, idx);
        if(ret==InstMgr::RESULT_INST_SUCCESS)
        {
            memset(&m_syncQueue[idx], 0, sizeof(T_ZCPS_SYNC_QUEUE));  //do not need to memset data because of effeciency.
            m_syncQueue[idx].wDstNodeId = node_id;
            m_syncQueue[idx].dwCounter = 0;
            /* the initial sequence: highest 8bits: node_id, lowest 24bits:random number. */
            m_syncQueue[idx].ini_seq = ((node_id<<24)&0xff000000)|(XOS_GetCurStdSecs()&0x00ffffff);
            m_syncQueue[idx].snd_new = m_syncQueue[idx].ini_seq;
            m_syncQueue[idx].snd_wnd = 1;  //todo
        }
    }
    return ret;
}

/* ��Ӳ��� */
uint32_t CSyncDataPool::enQueue(uint16_t node_id, uint32_t data_idx)
{
    uint32_t cnt;
    uint32_t queue_idx = 0;
    uint16_t obj_len = 0;
    int ret = getQueue(node_id, queue_idx);
    if(ret != InstMgr::RESULT_INST_SUCCESS)
    {
        m_sync_queue_alloc_fail++;
        return 0;
    }

    T_ZCPS_SYNC_QUEUE* pSyncQue = &m_syncQueue[queue_idx];
    T_ZCPS_SYNC_ITEM* pSyncItem = &pSyncQue->tItem;
    T_ZCPS_SYNC_POOL_DATA* pSnddata = &m_sync_data_pool[data_idx];

    if (!pSyncItem || ZCPS_ITEM_FILLING != pSyncItem->ucState)
    {
        pSyncItem = getNewSyncItem(node_id);
        /* �����ڵȴ�������ݵķ���obj��ֱ�Ӳ���һ���µ�obj */
        ZCS_LOG_SIMPLE(LOG_NOTICE, "==enQueue2Node[%d]QIdx[%u]:[appid:0x%x][seq:0x%x] len:%d bytes, new item[%u]!",
            node_id, queue_idx, pSnddata->tMsg.tSyncHdr.app_id, data_idx, pSnddata->tMsg.tSyncHdr.data_len, pSyncItem->tItemHdr.dwTsn);
    }
    else if((pSnddata->tMsg.tSyncHdr.data_len +sizeof(T_ZCS_APP_SYNC_MSG_HDR) +pSyncItem->wDataLen -sizeof(T_ZCPS_ITEM_HEAD)
            > ZCPS_DEFAULT_MTU_LEN) || (pSyncItem->wCookieCnt >= ZCPS_MAX_SYNC_OBJ))
    {
        /* ���ڵȴ����ķ���obj��������λ�ò��������µ����� */
        /* �����Ƚ���һ�������״̬����Ϊ�ɷ���״̬ */
        pSyncItem->ucState = ZCPS_ITEM_READY4SEND;  //ZCPS_ITEM_FILLING --> ZCPS_ITEM_READY4SEND
        flushQueue(node_id);
        uint32_t dwOldTsn = pSyncItem->tItemHdr.dwTsn;     
        /* �ٲ���һ���µ�obj */
        pSyncItem = getNewSyncItem(node_id);
        ZCS_LOG_SIMPLE(LOG_NOTICE, "==enQueue2Node[%d]QIdx[%u]:[appid:0x%x][seq:0x%x] len:%d bytes, flush last item[%u] and get new one[%u]!",
            node_id, queue_idx, pSnddata->tMsg.tSyncHdr.app_id, data_idx, pSnddata->tMsg.tSyncHdr.data_len, dwOldTsn, pSyncItem->tItemHdr.dwTsn); 
    }
    else
    {
        ZCS_LOG_SIMPLE(LOG_NOTICE, "==enQueue2Node[%d]QIdx[%u]:[appid:0x%x][seq:0x%x] len:%d bytes, put in item[%u]!",
            node_id, queue_idx, pSnddata->tMsg.tSyncHdr.app_id, data_idx, pSnddata->tMsg.tSyncHdr.data_len, pSyncItem->tItemHdr.dwTsn);
    }
    if (!pSyncItem)
    {
        /* ���ͻ���������ˢ�·��ͻ�����,ֱ�ӷ��ش��� */
        ZCS_LOG_SIMPLE(LOG_NOTICE, "==enQueue2Node[%d]QIdx[%u]:[appid:0x%x][seq:0x%x] len:%d bytes , but no item buffer!",
            node_id, queue_idx, pSnddata->tMsg.tSyncHdr.app_id, data_idx, pSnddata->tMsg.tSyncHdr.data_len);
        return 0;
    }

    cnt = pSyncItem->wCookieCnt;
    pSyncItem->dwCookie[cnt] = pSnddata->cookie;
    pSyncItem->bIsChgOverData[cnt] = pSnddata->isChgOverData;
    pSyncItem->wCookieCnt++;

    /* ���Ӧ�����ݶ���*/
    T_ZCPS_ITEM_OBJ* pObj = (T_ZCPS_ITEM_OBJ*)pSyncItem->pObjBuff;
    pObj->tObjHdr = pSnddata->tMsg.tSyncHdr;
    pObj->tObjHdr.seq = data_idx; //seq filled here
    memcpy(pObj->ucObjData, pSnddata->tMsg.data, pSnddata->tMsg.tSyncHdr.data_len);
    obj_len = pSnddata->tMsg.tSyncHdr.data_len + sizeof(T_ZCS_APP_SYNC_MSG_HDR);
    pSyncItem->wDataLen += obj_len;
    pSyncItem->pObjBuff += obj_len;
    
    pSyncItem->tItemHdr.wObjLen += obj_len;;
    pSyncItem->tItemHdr.wObjCnt++;

    m_send_data_count++;
    if(0 == m_sync_data_pool[data_idx].retry_count)
    {
        pSyncQue->dwCounter++;
    }
    else
    {
        m_send_sync_retry++;
        pSyncQue->rexmit_cnt++;
    }
    return pSyncQue->dwCounter;
}

/*���Ӳ��������ض��г���*/
uint32_t CSyncDataPool::deQueue(uint16_t node_id, uint32_t data_idx)
{
    uint32_t queue_idx = 0;
    int ret = getQueue(node_id, queue_idx);
    if(ret!= InstMgr::RESULT_INST_SUCCESS)
    {
        m_sync_queue_alloc_fail++;
        return 0;
    }
    
    if(m_syncQueue[queue_idx].dwCounter > 0)
    {
        m_syncQueue[queue_idx].dwCounter--;
    }
    /*�����ش����������ı��ķ�������*/
    T_ZCPS_SYNC_POOL_DATA* pData = &m_sync_data_pool[data_idx];
    if(pData->isChgOverData)
        m_chgover_data_count--;
    return m_syncQueue[queue_idx].dwCounter;
}

uint32_t CSyncDataPool::getFreeLen()
{
    return m_sync_data_pool.getFreeInstNum();
}

/*ͳ����Ϣ��ӡ*/
void CSyncDataPool::print_stats()
{
    printf("[Sync_data_pool]:capacity=%u,allocated=%u,ChgOverData_num=%u, scan_index=%u, ErrInvalidAck=%u\n",
            m_sync_data_pool.getTotalInstNum(),m_sync_data_pool.getAllocatedInstNum(),
            m_chgover_data_count,m_cur_scan_index, m_recv_ack_invalid);
    printf("m_sync_pool_alloc_fail=%u,m_over_retry_count=%u\n",m_sync_pool_alloc_fail,m_over_retry_count);
    uint32_t count=0;
    printf("----------------------------------------------Sync Queue Info----------------------------------------------\n");
    printf("DestNode UnAckMsg  RexmitCnt InitSeq   SndNew   SndWnd  ItemSuc   ObjSuc ItemFail  ObjFail  ItemErr  ZeroWnd\n");
    for(uint32_t i=0;i<m_syncQueue.getTotalInstNum();i++)
    {
        if(m_syncQueue.getInstanceState(i)==InstMgr::INST_STATE_ALLOCATED)
        {
            printf("%8u %8u  %8u %8u %8u %8u %8u %8u %8u %8u %8u %8u\n",
                    m_syncQueue[i].wDstNodeId, m_syncQueue[i].dwCounter, m_syncQueue[i].rexmit_cnt,
                    m_syncQueue[i].ini_seq, m_syncQueue[i].snd_new, m_syncQueue[i].snd_wnd,
                    m_syncQueue[i].item_snt_suc, m_syncQueue[i].obj_snt_suc, 
                    m_syncQueue[i].item_snt_fail, m_syncQueue[i].obj_snt_fail,
                    m_syncQueue[i].item_state_err, m_syncQueue[i].zero_wnd);
            ++count;
        }
    }
    printf("--------------------------------------------Sync Queue Total:%3u-------------------------------------------\n", count);
}

void CSyncDataPool::showInstMgrStats()
{
    printf("m_sync_data_pool stats:\n");
    m_sync_data_pool.showStats();    
    printf("\nm_syncQueue stats:\n");
    m_syncQueue.showStats();    
    printf("\n");
}

void CSyncDataPool::cleanDataPoolStats()
{
    m_sync_data_pool.getStats().init();
}

uint32_t CSyncDataPool::getPoolDataNum()
{
    return this->m_sync_data_pool.getAllocatedInstNum();
}

uint32_t CSyncDataPool::getChgOverDataNum()
{
    return m_chgover_data_count;
}

/*���㷢�ʹ��ڴ�С*/
uint32_t CSyncDataPool::getSendWindowSize()
{
    uint32_t qlen = m_sync_data_pool.getAllocatedInstNum();

/*���ʿ��ƣ�����Խ������ʾδȷ�ϵ�����Խ�࣬����ӵ������Ҫ���ٷ��ͳ���*/
    if(qlen==0)
    {
        m_max_sync_count = ZCPS_MIN_SYNC_COUNT_PER_ROUND;
    }
    else
    {
        if(m_recv_ack_count>=m_send_data_count)//�����յ���ȷ����Ϣ�Ƚ���
        {
            m_max_sync_count<<=1;//����2
        }
        else
        {
            m_max_sync_count>>=1;//����2
        }
        if(m_max_sync_count<ZCPS_MIN_SYNC_COUNT_PER_ROUND)
             m_max_sync_count = ZCPS_MIN_SYNC_COUNT_PER_ROUND;
         else if(m_max_sync_count>ZCPS_MAX_SYNC_COUNT_PER_ROUND)
             m_max_sync_count=ZCPS_MAX_SYNC_COUNT_PER_ROUND;
    }


    m_recv_ack_count = 0;
    m_send_data_count = 0;

    return m_max_sync_count;

}
uint32_t CSyncDataPool::getSendRetryCount()
{
	return m_send_sync_retry;	
}

void CSyncDataPool::resetSendRetryCount()
{
	m_send_sync_retry=0;
}

uint32_t CSyncDataPool::getSyncPoolAllocFailCount()
{
	return m_sync_pool_alloc_fail;	
}

void CSyncDataPool::resetSyncPoolAllocFailCount()
{
	m_sync_pool_alloc_fail=0;
}


CSyncDataPool::~CSyncDataPool() {
    // TODO Auto-generated destructor stub
}

